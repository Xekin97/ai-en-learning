# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: cr037-auth-account.spec.ts >> CR037 password dialog exact copy, cancel, confirmation and shared helper: en-US
- Location: tests/e2e/cr037-auth-account.spec.ts:132:3

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  locator('.settings-grid .card-footer .button-secondary')
Expected: focused
Received: inactive
Timeout:  5000ms

Call log:
  - Expect "toBeFocused" with timeout 5000ms
  - waiting for locator('.settings-grid .card-footer .button-secondary')
    14 × locator resolved to <button type="button" class="button button-secondary">Change password</button>
       - unexpected value "inactive"

```

```yaml
- button "Change password"
```

# Test source

```ts
  85  |         await leadingHint(page, copy!);
  86  |         await page.locator(".auth-alt a").click();
  87  |         await ready(page);
  88  |         await leadingHint(page, copy!);
  89  |       }
  90  |       await page.locator('input[autocomplete="username"]').fill("learner_e2e");
  91  |       await page
  92  |         .locator('input[autocomplete="current-password"]')
  93  |         .fill("WrongPass123!");
  94  |       await page.locator("form button[type=submit]").click();
  95  |       await expect(page.locator(".app-error")).toBeVisible();
  96  |       await leadingHint(
  97  |         page,
  98  |         en ? "Continue to Account when you’re done." : "完成后返回账号设置。",
  99  |       );
  100 |       expect(
  101 |         await page.evaluate(
  102 |           () => document.documentElement.scrollWidth <= innerWidth,
  103 |         ),
  104 |       ).toBe(true);
  105 |     },
  106 |   );
  107 |   test(
  108 |     "CR037 no intent and stale claims preserve normal auth layout: " + locale,
  109 |     async ({ page }) => {
  110 |       await actor(page, "visitor", locale);
  111 |       for (const route of ["/login", "/register"]) {
  112 |         for (const suffix of ["", "?redirect=https%3A%2F%2Foutside.example"]) {
  113 |           await page.goto(route + suffix);
  114 |           await ready(page);
  115 |           await expect(page.locator(".auth-intent")).toHaveCount(0);
  116 |           expect(
  117 |             await page
  118 |               .locator(".auth-card")
  119 |               .evaluate((card) => card.firstElementChild?.tagName),
  120 |           ).toBe("H2");
  121 |         }
  122 |         await page.goto(route + "?claim=1&redirect=%2Freview");
  123 |         await ready(page);
  124 |         await expect(page.locator(".notice-warning")).toHaveCount(0);
  125 |         await leadingHint(
  126 |           page,
  127 |           en ? "Continue to Review when you’re done." : "完成后返回复习。",
  128 |         );
  129 |       }
  130 |     },
  131 |   );
  132 |   test(
  133 |     "CR037 password dialog exact copy, cancel, confirmation and shared helper: " +
  134 |       locale,
  135 |     async ({ page }) => {
  136 |       await actor(page, "learner", locale);
  137 |       await page.goto("/account");
  138 |       await ready(page);
  139 |       const trigger = page.locator(
  140 |         ".settings-grid .card-footer .button-secondary",
  141 |       );
  142 |       const writes: unknown[] = [];
  143 |       await page.route("**/api/v1/me/password", async (route) => {
  144 |         writes.push(route.request().postDataJSON());
  145 |         await route.fulfill({ status: 204 });
  146 |       });
  147 |       await trigger.click();
  148 |       const dialog = page.locator("dialog[open]");
  149 |       await expect(dialog.locator("h2")).toHaveText(
  150 |         en ? "Change password" : "修改密码",
  151 |       );
  152 |       await expect(dialog.locator(".field-label")).toHaveText(
  153 |         en
  154 |           ? ["Current password", "New password", "Confirm new password"]
  155 |           : ["当前密码", "新密码", "确认新密码"],
  156 |       );
  157 |       await expect(dialog.locator(".helper")).toHaveText(
  158 |         en
  159 |           ? [
  160 |               "Confirm it’s you",
  161 |               "8–128 characters",
  162 |               "Enter the same password again",
  163 |             ]
  164 |           : ["用于确认是账号本人", "8–128 个字符", "再次输入相同密码"],
  165 |       );
  166 |       await expect(dialog.locator(".notice")).toHaveText(
  167 |         en
  168 |           ? "Your current session will stay open. Other sessions will be signed out."
  169 |           : "修改成功后保留当前会话，其他已有会话全部退出。",
  170 |       );
  171 |       await expect(dialog.locator(".dialog-footer button")).toHaveText(
  172 |         en ? ["Cancel", "Update password"] : ["取消", "确认修改"],
  173 |       );
  174 |       const inputs = dialog.locator('input[type="password"]'),
  175 |         submit = dialog.locator('button[type="submit"]');
  176 |       await expect(submit).toBeDisabled();
  177 |       await inputs.nth(0).fill("CurrentPass123!");
  178 |       await inputs.nth(1).fill("UpdatedPass123!");
  179 |       await inputs.nth(2).fill("MismatchPass123!");
  180 |       await expect(submit).toBeDisabled();
  181 |       await inputs.nth(2).fill("UpdatedPass123!");
  182 |       await expect(submit).toBeEnabled();
  183 |       await dialog.locator(".button-secondary").click();
  184 |       await expect(page.locator("dialog")).toHaveCount(0);
> 185 |       await expect(trigger).toBeFocused();
      |                             ^ Error: expect(locator).toBeFocused() failed
  186 |       expect(writes).toEqual([]);
  187 |       await trigger.click();
  188 |       for (let i = 0; i < 3; i++) await expect(inputs.nth(i)).toHaveValue("");
  189 |       await inputs.nth(0).fill("CurrentPass123!");
  190 |       await inputs.nth(1).fill("UpdatedPass123!");
  191 |       await inputs.nth(2).fill("UpdatedPass123!");
  192 |       await submit.click();
  193 |       await expect(page.locator("dialog")).toHaveCount(0);
  194 |       await expect(page.locator(".account-notice .notice-title")).toHaveText(
  195 |         en ? "Password updated" : "密码已更新",
  196 |       );
  197 |       expect(writes).toEqual([
  198 |         {
  199 |           current_password: "CurrentPass123!",
  200 |           new_password: "UpdatedPass123!",
  201 |           new_password_confirmation: "UpdatedPass123!",
  202 |         },
  203 |       ]);
  204 |       await page.locator(".danger-zone .button-danger").click();
  205 |       await expect(page.locator("dialog .field .helper")).toHaveText(
  206 |         en ? "Confirm it’s you" : "用于确认是账号本人",
  207 |       );
  208 |       await page.keyboard.press("Escape");
  209 |       await expect(page.locator("dialog")).toHaveCount(0);
  210 |     },
  211 |   );
  212 | }
  213 | 
```