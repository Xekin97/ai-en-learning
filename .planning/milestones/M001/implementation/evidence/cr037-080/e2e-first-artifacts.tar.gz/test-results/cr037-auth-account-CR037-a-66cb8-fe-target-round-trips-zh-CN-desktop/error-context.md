# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: cr037-auth-account.spec.ts >> CR037 auth hint precedes headings through safe target round trips: zh-CN
- Location: tests/e2e/cr037-auth-account.spec.ts:42:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "/register"
Received: "/login"
```

# Page snapshot

```yaml
- generic [ref=f6e3]:
  - link "跳到主要内容" [ref=f6e4] [cursor=pointer]:
    - /url: "#main-content"
  - banner [ref=f6e5]:
    - generic [ref=f6e6]:
      - link "词涟" [ref=f6e7] [cursor=pointer]:
        - /url: /
      - navigation "主要导航" [ref=f6e16]:
        - link "开始学习" [ref=f6e17] [cursor=pointer]:
          - /url: /create
        - link "复习" [ref=f6e18] [cursor=pointer]:
          - /url: /review
        - link "学习记录" [ref=f6e19] [cursor=pointer]:
          - /url: /library
      - generic [ref=f6e20]:
        - generic [ref=f6e21]:
          - generic [ref=f6e22]: 界面语言
          - combobox "界面语言" [ref=f6e27] [cursor=pointer]:
            - option "中文" [selected]
            - option "EN"
        - link "登录" [ref=f6e28] [cursor=pointer]:
          - /url: /login
        - link "注册" [ref=f6e29] [cursor=pointer]:
          - /url: /register
  - main [ref=f6e30]:
    - generic [ref=f6e31]:
      - generic [ref=f6e32]:
        - paragraph [ref=f6e33]: 你的词语，你的语境
        - heading "从一组自己的词开始" [level=1] [ref=f6e34]
        - paragraph [ref=f6e35]: 用一个用户名，开始积累自己的词汇语境。
      - generic [ref=f6e36]:
        - status [ref=f6e37]: 完成后返回这篇短文。
        - heading "创建账号" [level=2] [ref=f6e38]
        - paragraph [ref=f6e39]: 几秒钟即可开始。
        - form "创建账号并继续" [ref=f6e40]:
          - generic [ref=f6e41]:
            - generic [ref=f6e42]: 用户名
            - textbox "用户名 3–32 个字母、数字或下划线" [ref=f6e43]
            - generic [ref=f6e44]: 3–32 个字母、数字或下划线
          - generic [ref=f6e45]:
            - generic [ref=f6e46]: 密码
            - textbox "密码 8–128 个字符" [ref=f6e47]
            - generic [ref=f6e48]: 8–128 个字符
          - generic [ref=f6e49]:
            - generic [ref=f6e50]: 确认密码
            - textbox "确认密码 再次输入相同密码" [ref=f6e51]
            - generic [ref=f6e52]: 再次输入相同密码
          - button "创建账号并继续" [ref=f6e53] [cursor=pointer]
        - paragraph [ref=f6e54]:
          - text: 已有账号？
          - link "去登录" [ref=f6e55] [cursor=pointer]:
            - /url: /login?redirect=/library/batch-e2e
```

# Test source

```ts
  1   | import { expect, test, type Page } from "@playwright/test";
  2   | 
  3   | const origin = "http://127.0.0.1:3300";
  4   | async function actor(page: Page, role: "visitor" | "learner", locale: string) {
  5   |   await page
  6   |     .context()
  7   |     .addCookies([
  8   |       { name: "wordweave_ui_locale", value: locale, url: origin },
  9   |       ...(role === "learner"
  10  |         ? [{ name: "wordweave_session", value: role, url: origin }]
  11  |         : []),
  12  |     ]);
  13  | }
  14  | async function ready(page: Page) {
  15  |   await page.waitForFunction(
  16  |     () => document.documentElement.dataset.appReady === "true",
  17  |   );
  18  | }
  19  | async function leadingHint(page: Page, text: string) {
  20  |   const hint = page.locator(".auth-intent");
  21  |   await expect(hint).toHaveText(text);
  22  |   await expect(hint).toHaveAttribute("role", "status");
  23  |   expect(
  24  |     await hint.evaluate((element) => {
  25  |       const title = element.parentElement!.querySelector("h2")!;
  26  |       return {
  27  |         first: element.parentElement!.firstElementChild === element,
  28  |         precedesTitle: Boolean(
  29  |           element.compareDocumentPosition(title) &
  30  |           Node.DOCUMENT_POSITION_FOLLOWING,
  31  |         ),
  32  |         aboveTitle:
  33  |           element.getBoundingClientRect().bottom <=
  34  |           title.getBoundingClientRect().top,
  35  |       };
  36  |     }),
  37  |   ).toEqual({ first: true, precedesTitle: true, aboveTitle: true });
  38  |   await expect(hint).toHaveCSS("margin-bottom", "20px");
  39  | }
  40  | for (const locale of ["en-US", "zh-CN"]) {
  41  |   const en = locale === "en-US";
  42  |   test(
  43  |     "CR037 auth hint precedes headings through safe target round trips: " +
  44  |       locale,
  45  |     async ({ page }) => {
  46  |       test.setTimeout(90_000);
  47  |       await actor(page, "visitor", locale);
  48  |       for (const [path, copy] of [
  49  |         [
  50  |           "/review",
  51  |           en ? "Continue to Review when you’re done." : "完成后返回复习。",
  52  |         ],
  53  |         [
  54  |           "/review/session-e2e?batch=batch-e2e",
  55  |           en ? "Continue to Review when you’re done." : "完成后返回复习。",
  56  |         ],
  57  |         [
  58  |           "/library",
  59  |           en ? "Continue to Library when you’re done." : "完成后返回学习记录。",
  60  |         ],
  61  |         [
  62  |           "/library/batch-e2e",
  63  |           en
  64  |             ? "Return to this story when you’re done."
  65  |             : "完成后返回这篇短文。",
  66  |         ],
  67  |         [
  68  |           "/account",
  69  |           en ? "Continue to Account when you’re done." : "完成后返回账号设置。",
  70  |         ],
  71  |       ]) {
  72  |         await page.goto(path!);
  73  |         await ready(page);
  74  |         await page.locator(".auth-gate .button-primary").click();
  75  |         await ready(page);
  76  |         await leadingHint(page, copy!);
  77  |         expect(new URL(page.url()).searchParams.get("redirect")).toBe(path);
  78  |         await page.locator(".auth-alt a").click();
  79  |         await ready(page);
  80  |         await leadingHint(page, copy!);
> 81  |         expect(new URL(page.url()).pathname).toBe("/register");
      |                                              ^ Error: expect(received).toBe(expected) // Object.is equality
  82  |         expect(new URL(page.url()).searchParams.get("redirect")).toBe(path);
  83  |         await page.reload();
  84  |         await ready(page);
  85  |         await leadingHint(page, copy!);
  86  |         await page.locator(".auth-alt a").click();
  87  |         await ready(page);
  88  |         await leadingHint(page, copy!);
  89  |       }
  90  |       await page.locator('input[autocomplete="username"]').fill("learner_e2e");
  91  |       await page
  92  |         .locator('input[autocomplete="current-password"]')
  93  |         .fill("WrongPass123!");
  94  |       await page.locator("form button[type=submit]").click();
  95  |       await expect(page.locator(".app-error")).toBeVisible();
  96  |       await leadingHint(
  97  |         page,
  98  |         en ? "Continue to Account when you’re done." : "完成后返回账号设置。",
  99  |       );
  100 |       expect(
  101 |         await page.evaluate(
  102 |           () => document.documentElement.scrollWidth <= innerWidth,
  103 |         ),
  104 |       ).toBe(true);
  105 |     },
  106 |   );
  107 |   test(
  108 |     "CR037 no intent and stale claims preserve normal auth layout: " + locale,
  109 |     async ({ page }) => {
  110 |       await actor(page, "visitor", locale);
  111 |       for (const route of ["/login", "/register"]) {
  112 |         for (const suffix of ["", "?redirect=https%3A%2F%2Foutside.example"]) {
  113 |           await page.goto(route + suffix);
  114 |           await ready(page);
  115 |           await expect(page.locator(".auth-intent")).toHaveCount(0);
  116 |           expect(
  117 |             await page
  118 |               .locator(".auth-card")
  119 |               .evaluate((card) => card.firstElementChild?.tagName),
  120 |           ).toBe("H2");
  121 |         }
  122 |         await page.goto(route + "?claim=1&redirect=%2Freview");
  123 |         await ready(page);
  124 |         await expect(page.locator(".notice-warning")).toHaveCount(0);
  125 |         await leadingHint(
  126 |           page,
  127 |           en ? "Continue to Review when you’re done." : "完成后返回复习。",
  128 |         );
  129 |       }
  130 |     },
  131 |   );
  132 |   test(
  133 |     "CR037 password dialog exact copy, cancel, confirmation and shared helper: " +
  134 |       locale,
  135 |     async ({ page }) => {
  136 |       await actor(page, "learner", locale);
  137 |       await page.goto("/account");
  138 |       await ready(page);
  139 |       const trigger = page.locator(
  140 |         ".settings-grid .card-footer .button-secondary",
  141 |       );
  142 |       const writes: unknown[] = [];
  143 |       await page.route("**/api/v1/me/password", async (route) => {
  144 |         writes.push(route.request().postDataJSON());
  145 |         await route.fulfill({ status: 204 });
  146 |       });
  147 |       await trigger.click();
  148 |       const dialog = page.locator("dialog[open]");
  149 |       await expect(dialog.locator("h2")).toHaveText(
  150 |         en ? "Change password" : "修改密码",
  151 |       );
  152 |       await expect(dialog.locator(".field-label")).toHaveText(
  153 |         en
  154 |           ? ["Current password", "New password", "Confirm new password"]
  155 |           : ["当前密码", "新密码", "确认新密码"],
  156 |       );
  157 |       await expect(dialog.locator(".helper")).toHaveText(
  158 |         en
  159 |           ? [
  160 |               "Confirm it’s you",
  161 |               "8–128 characters",
  162 |               "Enter the same password again",
  163 |             ]
  164 |           : ["用于确认是账号本人", "8–128 个字符", "再次输入相同密码"],
  165 |       );
  166 |       await expect(dialog.locator(".notice")).toHaveText(
  167 |         en
  168 |           ? "Your current session will stay open. Other sessions will be signed out."
  169 |           : "修改成功后保留当前会话，其他已有会话全部退出。",
  170 |       );
  171 |       await expect(dialog.locator(".dialog-footer button")).toHaveText(
  172 |         en ? ["Cancel", "Update password"] : ["取消", "确认修改"],
  173 |       );
  174 |       const inputs = dialog.locator('input[type="password"]'),
  175 |         submit = dialog.locator('button[type="submit"]');
  176 |       await expect(submit).toBeDisabled();
  177 |       await inputs.nth(0).fill("CurrentPass123!");
  178 |       await inputs.nth(1).fill("UpdatedPass123!");
  179 |       await inputs.nth(2).fill("MismatchPass123!");
  180 |       await expect(submit).toBeDisabled();
  181 |       await inputs.nth(2).fill("UpdatedPass123!");
```