---
milestone: M002
stage: technical-design
role: backend-architect/base
agent_name: backend-alex
status: awaiting_user_review
version: M002-BE-01
date: 2026-09-20
blocking_alignment: M002-CR-003
---

# 后端架构交接 M002-BE-01

交出角色 **backend-alex**。本轮后端/API/AI设计已形成可审阅稿；有 **M002-CR-003** 数据接收补充未关闭，不能宣称全技术阶段可直接实施。工作流仍technical-design/backend-alex，本文不批准方案、不激活DBA/前端。

## 输入与确认边界

- [PRODUCT-03](../product/overview.md) / TRANSITION-M002-006，全量49 CAP与32 DATA索引承接一期。
- [UI22验收](../reviews/uiux-design.md)、[H01交接](uiux.md)、[M001→M002差异](../design/frontend-delta.md)，25页面/28视图保持，后台八模块完整。
- [DB-01](../technical/database.md) / [TRANSITION-M002-009批准](../reviews/database-design.md)，旧handoff中的待审是冻结时点，正式批准不受其影响。
- 用户确认DB2-Q01取消跨设备草稿、DB2-Q02基础与体验分账、DB2-Q03分析90天，见DB §1.1。本次没有新增业务问答或将猜测标CONFIRMED。
- 实际代码HEAD及保护摘要：[inputs](../technical/evidence/M002-BE-01-inputs.json)。长期USER-COMPAT-001、USER-CLAIM-DELETE-001和三项AI遗留继续有效。模型路由codex-balanced@1.0.0锁定，无运行时模型切换/子agent；实际model/usage未观测。

## 当前产物与接续任务

| ID | 接收入口与完成要求 |
|---|---|
| BE2-R01 总体与一期继承 | [backend §2–3](../technical/backend.md#2-模块与内部调用)，49CAP逐项定位；保留登录/密码/注销/书架六项/日期/单批/模型计划用户管理，不能仅实现新成长页 |
| BE2-R02 配套HTTP合同 | [API index](../technical/api/index.md)，7份Markdown分主题；strict DTO、权限、错误、分页、idempotency/revision，旧actions明确替换，无OpenAPI或双协议 |
| BE2-R03 复习 | [API-008](../technical/api/review.md)，安全整份题面、本机草稿、整批提交/最小重试、临时总结/末批redo；CR-003待DBA补足最小概况/范围替换 |
| BE2-R04 成长与权益 | [API-203/204](../technical/api/growth-benefits.md)、backend §4，base/trial分账、历史签到差额、手动领奖全或无、四类卡/逐模型/当前退换积分/永久资格 |
| BE2-R05 后台与预设 | [管理契约](../technical/api/administration.md)、[生成预设](../technical/api/generation-presets.md)，八模块和旧完整表单；预览独立记录真实调用用量、未知null，草稿→预览→手动发布 |
| BE2-R06 分析安全与清理 | [API-209](../technical/api/analytics.md)，服务端事实同事务、匿名汇总、90天/注销清关联、迟交cohort、Clarity仅公开入口 |
| BE2-R07 AI与旧锁顺序 | [AI方案](../technical/ai-integration.md)、backend §4.1/6，复用r10，核对actual claim/run/cleanup锁序，启动/停机不能漏refund extra来源 |
| BE2-R08 工程验证 | backend §7–8、DB2-M/V；仅后续实施计划，本轮未运行数据库/并发/应用/真实AI验证 |

## 跨角色接收问题

[M002-CR-003](../changes/CR-003.md)是本轮新提出、尚未由守门器登记角色迁移的专业接收请求；workflow/open_change_requests不由backend自行改。

1. 产品CAP-020的“含跳过概况”：建议attempt仅增has_unanswered标志、旧skip_count>0迁移，不存答案。
2. UI22确认替换未完成范围：建议session增abandoned状态、同事务建新范围，保留旧已提交事实，不伪造完成。
3. UI22消息管理的独立双语标题：DB-01仅有正文；建议补title_zh/en及至少一套完整语言约束，不从正文首行替代标题。

这是批准需求/设计落到数据时的缺口，不要求用户重述原需求。相关DTO/迁移实施标BLOCKED；其他架构可独立审阅。先交dba-diana出补充版本并核验，再由backend-alex同步去掉条件标记。不得直接改DB-01已冻结正文/批准或让前端猜字段。

## 前端接收提醒

- UI22和frontend-delta是外观/文案真源，API不把需求说明塞进产品页。Header首页/精选/学习/复习/书架、四个人中心视图/八后台模块保持。
- AuthActor本人id供IndexedDB账号隔离；存用户输入/导航，不存标准答案；服务端验状态后再展示恢复。退出清当前内存但本机未提交草稿隔离保留；换设备无答案同步。
- 当次comparison不持久化，submitted重试仅receipt；响应丢失/刷新不做历史结果回放。前后/概览无需请求判分，local revision处理多标签冲突/存储失败。
- quota与model时间分开展示；所有可用/退款/覆盖条件取服务端投影，不能从原型fixture金额/日期写业务规则。Amount十进制字符串；provider成本用明确credits单位或unknown，不擅自美元显示。
- 登录欢迎10秒、较大days、300ms淡入淡出、在消息层之上；同学习日应使用welcome.today专门文案，现有UI22原型0天残留由前端修正并定向验收。显式login一次，先完成claim再通知；bootstrap不重复弹。
- 新接口与前端typed mapper/mocks需同步；独立标题改名不暴露到提交前题面；锁定预设完整样文/配置及释义语言筛选不能降成摘要。

## 文档整理、证据与实际验证范围

- 首次建立本角色后端正文、API和AI文件；不改产品/设计/批准DB/一期文档/应用。只保留当前可执行规则和ID链接，不复制一整套历史修订正文；API专题按域拆为7份，角色交接为小入口。
- [静态检查](../technical/evidence/M002-BE-01-check.json)、[交付清单](../technical/evidence/M002-BE-01-manifest.json)、[恢复快照](../technical/evidence/M002-BE-01.tar.gz)、[冻结结果](../technical/evidence/M002-BE-01-freeze-results.json)对应准确交付版本。检查范围含49CAP/32DATA/25PAGE引用、现有route继承/替换、相对文件链接、受保护文件hash；CR-003不因静态PASS变已解决。
- 没有连接运行数据库、迁移、安装包、运行应用测试、真实模型调用、部署或git提交；这些是后续实施验证任务。未执行独立新会话交接测试，不能把本轮自检当专业角色独立接收。
- 文档规模以manifest字符/字节计量，实际tokens与费用unknown。完整继承/复杂权益使设计超过规划软预算，使用索引和按任务节号缩短后续读取，不以删需求压缩；没有整理或移动其他角色历史。

## 未完成、风险与下一步

- **BLOCKED**：BE2-D01/M002-CR-003，DBA补充与正式接收后可解除。backend后续同步需重新做针对性检查及快照，不覆盖BE-01证据。
- **OPEN**：M002-CR-001/002的应用落地继续保留；CR039-L1、CR042-L1、AI-QUALITY-90原状态。本稿不修词形、不扩取证平台、不声明90%质量达标。
- **尚未验证**：BE2-V01–17、DB2-V；真实负载性能/故障恢复/供应商usage帧形状实测。外部文档核对不是实际provider探针。
- **运营待配置**：计划优先级、等级/签到/道具数值由用户后台调整，不用原型夹具覆盖生产；一期统计/数据必须保留。

建议下一步经守门器将CR-003有限交回dba-diana，再由backend-alex接收修订，随后frontend-bob完成前端架构与本机恢复/新旧设计差异映射。本交接不能自行切换阶段或角色。
