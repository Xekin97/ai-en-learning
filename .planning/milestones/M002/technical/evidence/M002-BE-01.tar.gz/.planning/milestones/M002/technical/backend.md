---
milestone: M002
stage: technical-design
role: backend-architect/base
agent_name: backend-alex
version: M002-BE-01
status: awaiting_user_review
date: 2026-09-20
blocking_alignment: M002-CR-003
---

# M002 后端架构方案

## 1. 当前结论、输入与边界

继续一期 **Go模块化单体＋PostgreSQL＋同源Nuxt/Nginx**。本期在原模块内扩展身份、学习库、复习与授权，增加成长、道具、预设、通知及分析领域模块；不拆服务，不引入Redis、外部队列或另一套生成引擎。本文是设计交付，不是实现/上线记录。

输入：PRODUCT-03/[当前产品](../product/overview.md)、UI22/[设计差异H01](../design/frontend-delta.md)、[DB-01](database.md)/TRANSITION-M002-009、M001已验收[后端](../../M001/technical/backend.md)、[AI](../../M001/technical/ai-integration.md)与[API](../../M001/technical/api/index.md)。locked Profile consumer-ai-web@1.0.0（commit b5badf88cd7194400c3d4d0e9395e7c98490dc26），当前technical-design/backend-alex；不采用工作框架中后来的Profile改版。

实测代码HEAD `5da571b226635113c41cd9cb8c4f33433946fbad`，Go module wordweave，Go1.26、Chi5.3.2、pgx5.10、sqlc查询及0001–0007迁移；文件保护摘要见[inputs](evidence/M002-BE-01-inputs.json)。版本号表示仓库事实，不声称已核验最新安全补丁。原Nginx/Go/Nuxt三个独立构建边界、单Go副本和进程内取消registry保留。

### 1.1 已确认决策的落实

- DB2-Q01已纠正：未提交答案仅当前浏览器IndexedDB恢复，服务器只保留attempt最小事实及固定题序，不做跨设备答案同步。
- DB2-Q02已确认：基础/体验同计划分别记账；管理员重置目标base epoch，trial用量和到期不动。
- DB2-Q03已确认：个人分析明细90天，之后只匿名汇总，不收集答案/正文；注销清关联个人数据。
- D2-43：当次总结响应不留历史答案；D2-51：退换取当前下架积分；D2-56：签到自动、其他奖励手动；D2-65/73：模型卡逐模型加时、计划优先扣次数；D2-81/82：私有标题可编辑、预设单标题无说明。
- 一期原词释义/全部提示及正文位置/随机词序/日期范围与单篇独立/六项库统计/注册登录/模型计划用户管理均继承。USER-COMPAT-001不承诺旧客户端；USER-CLAIM-DELETE-001明确删除时移除consumed claim。M001历史一次性清库批准不适用于M002。

### 1.2 BE2-D01 接收缺口（OPEN）

[M002-CR-003](../changes/CR-003.md)记录三处DB接收缺口：会话“含跳过”最小标志、替换未完成范围的关闭状态、设计中独立双语消息标题。建议仅加最小字段/状态，由dba-diana接收后出新版本，backend-alex再同步。本文对应接口有条件标记；**不静默改已批准DB-01、不删批准界面、不绕过交接门进入实施**。除此之外未发现需要新增产品决策的关键假设。技术方案及新增依赖本身仍待审。

### 1.3 有实际取舍的技术选择

| 项目 | 采用 | 另一方案的实际代价 |
|---|---|---|
| 成长结算 | 与原业务同Postgres事务 | 事件队列需要额外恢复/幂等系统，反而推迟已要求的全或无到账 |
| 复习 | 可重建安全题面＋本机最终答案＋最小DB状态 | 服务器答案仓库扩大未要求的留存/同步；全内存attempt无法满足刷新恢复 |
| 预设预览 | 复用AI校验流程、独立preview run/用量 | 塞进generation_runs会冲突现有有效生成计费/累计约束 |
| Markdown | goldmark解析＋bluemonday白名单清洗 | 浏览器各自解析会令后台预览和弹窗安全策略不一致 |
| 随机词 | 当前约1.386万词过滤后random limit1 | 先建缓存或推荐模型没有规模/效果证据；先随机再排除可能假报无候选 |
| 分析 | 现有maintenance分钟聚合＋90天删除 | 独立分析平台超出本期，且会扩大个人数据副本 |

goldmark默认不启用不安全HTML；仍在输出后做显式HTML清洗，依赖版本在实施时锁go.mod/go.sum并做漏洞检查。[goldmark官方](https://github.com/yuin/goldmark)、[bluemonday官方](https://github.com/microcosm-cc/bluemonday)。不为Markdown增加插件执行、模板语言或远程资源抓取。

## 2. 模块与内部调用

```mermaid
flowchart LR
  Browser[浏览器 / Nuxt SSR] --> HTTP[Go HTTP / 权限 / DTO]
  HTTP --> Domains[身份 · 书架 · 复习 · 预设 · 运营]
  HTTP --> Gen[生成编排]
  Gen --> Ent[计划 / 模型授权 / 扣额来源]
  Gen --> AI[现有 AI 适配与校验]
  AI --> OR[OpenRouter]
  Domains --> Tx[短事务 / 成长结算]
  Gen --> Tx
  Ent --> Tx
  Tx --> DB[(PostgreSQL)]
  Maintenance[现有维护调度] --> DB
```

| 模块/入口 | 责任与边界 |
|---|---|
| `identity` | 原Cookie/密码/角色/语言；新增资料和欢迎事实。last_login与last_learning分开，认证不代替学习 |
| `vocabulary` | 固定词表搜索/规范化、lexeme映射与随机过滤，不在本期做考试词库管理 |
| `entitlement` | ResolveEffectivePlan、ResolveModels、ReadQuota、ReserveChargeInTx、RefundChargeInTx；统一普通/预设/后台读投影来源 |
| `generation` | 预检/预占/上游运行/终态CAS/临时草稿/取消；调用growth的事务方法，不让模型层操作积分 |
| `learning` | 原收录/claim/库/六项统计/参与/删除，新增title及收录成长；管理员通过只读reader |
| `review` | 会话快照、稳定匿名题面、整批比较/提交/重来、最小进度；替换原内存逐题actions，拒绝任何历史答案读取 |
| `growth`（新增） | 学习日、签到/补差、实际mastery插入计经验、等级/成就资格和手动领取、唯一结算账本 |
| `items`（新增） | 四类型定义/库存/兑换/预览/启用/下架退换；不成为可任意混搭的权益规则引擎 |
| `presets`（新增） | 草稿版本/完整预览/发布，解析服务端固定spec；预览复用AI Runner，隔离计费目的 |
| `notices`（新增） | 双语Markdown、可见/提醒、渲染清洗与排序，无个人收件/已读 |
| `analytics`（新增） | 固定访问事件、业务事实写入、指定指标聚合与保留；无通用事件属性平台 |
| `admin` | 八模块HTTP权限与DTO，调用领域命令；不能直接SQL调余额/冒充学习者 |
| `maintenance` | 原退款/过期清理；新增资格重算、模型退款资格补判、分钟分析/04:00成熟结算/90天清理 |
| `httpapi`/`platform` | strict decode、CSRF/认证、mapper、Problem/SSE/健康；领域层不依赖页面copy或前端状态 |

只抽实际共用的事务协作方法，不引入通用事件总线/通用workflow。`...InTx(ctx,tx,lockedActor,command)`只接收已开启短事务，不自己Begin/Commit；由原业务服务持有事务并一次提交。成长服务无反向HTTP/生成调用；AI Runner不访问用户账号/奖励。数据库操作通过现有pgx/sqlc，可逐域新增query文件；不在设计阶段生成DDL或正式代码。

用量Observer只记录每次provider call的token/cost，独立于原CR042内容取证；普通日志继续无内容。配置影响查询、Preview与Command共享纯计算函数，Command必须重新读当前状态，预览不能充当权限缓存。

## 3. 全量继承与用例追踪

API详见[当前目录](api/index.md)。UC列指模块用例；一行一个稳定CAP避免遗漏一期。DATA-015是替代索引，不新增结果仓库。

| CAP | UC / 本期去向 | API | DATA |
|---|---|---|---|
| CAP-001 | 首页/试用入口保留，静态首页不触发AI | API-001/202 | DATA-018/212 |
| CAP-002 | 注册basic、轮换会话 | API-002 | DATA-003/004/018 |
| CAP-003 | 登录退出/角色路由 | API-002 | DATA-003/004/204 |
| CAP-004 | 本人改密/撤其他会话 | API-003 | DATA-003/004 |
| CAP-005 | 注销全个人数据 | API-003 | DATA-003/004/009–018/201–211/213 |
| CAP-006 | 词表精确合法选词 | API-004 | DATA-001/002 |
| CAP-007 | 一份有效计划、合并模型、分别次数 | API-004 | DATA-005/006/008/009/211 |
| CAP-008 | 流生成/严格完整结果 | API-005 | DATA-007/009/010/011 |
| CAP-009 | 取消/系统失败原来源退款 | API-005 | DATA-009/010/011/211 |
| CAP-010 | 完整收录/放弃、默认标题 | API-006 | DATA-009/011/012/013/208 |
| CAP-011 | 访客认证claim一次绑定 | API-006 | DATA-005/017/012/013/206 |
| CAP-012 | 原六项统计/旧到新库列表 | API-007 | DATA-012/016/202 |
| CAP-013 | 完整目标词搜索，不搜标题 | API-007 | DATA-002/012/013 |
| CAP-014 | 完整正文/词义/位置详情 | API-007 | DATA-012/013 |
| CAP-015 | 参与范围开关，仅影响新会话 | API-007 | DATA-012/014 |
| CAP-016 | 永久删批次/claim，不回退成长 | API-007 | DATA-012/013/014/017/202 |
| CAP-017 | 浏览器日期范围/固定随机安排 | API-008 | DATA-012/013/014 |
| CAP-018 | 替代索引→CAP-201原词填空 | API-008 | DATA-013/201 |
| CAP-019 | 替代索引→CAP-201逐occurrence填空 | API-008 | DATA-013/201 |
| CAP-020 | 独立会话恢复/最小完成概况（CR-003） | API-008 | DATA-014/015/201/202 |
| CAP-021 | 账号语言持久/访客本机语言 | API-001 | DATA-018 |
| CAP-022 | 单批复习，忽略参与开关 | API-008 | DATA-012/014/202 |
| CAP-101 | 凭据脱敏/加密替换/探针 | API-101 | DATA-007 |
| CAP-102 | 模型新增编辑启停，完整保留 | API-101 | DATA-008 |
| CAP-103 | 四基础计划全权益配置 | API-102 | DATA-006/008 |
| CAP-104 | 用户查询/详情/成长读投影 | API-103 | DATA-003/006/009/204/207/208 |
| CAP-105 | 指定用户base调整重置 | API-103 | DATA-003/006/009/211 |
| CAP-106 | 管理员重置密码/撤会话 | API-103 | DATA-003/004 |
| CAP-107 | 管理员只读学习库 | API-103 | DATA-012/013/016 |
| CAP-201 | 整份匿名题面/本机移动/整批提交 | API-008 | DATA-013/201/202 |
| CAP-202 | 本机概览/最新完整草稿提交 | API-008 | DATA-201/202 |
| CAP-203 | 当次对照/最小结算/重来 | API-008 | DATA-014/202/203/208 |
| CAP-204 | 校验服务端状态后本机恢复 | API-008 | DATA-014/201/202 |
| CAP-205 | 模型正式移除/计划解引用/卡资格 | API-101/204 | DATA-006/008/210/211/212 |
| CAP-206 | 设计布局/真实成功失败toast | API-004及各命令 | DATA-006/211；无额外UI表 |
| CAP-207 | 首页示例/动效前端，公开预设读 | API-202 | DATA-212 |
| CAP-208 | 排除已选/当前库的随机词 | API-004 | DATA-002/013/203 |
| CAP-209 | 本人资料/登录欢迎事实 | API-002/201 | DATA-003/204 |
| CAP-210 | 独立平台消息/登录提醒（标题CR-003） | API-205/207 | DATA-205 |
| CAP-211 | 04:00学习日/有效生成自动签到 | API-005/006/203 | DATA-206/207/208 |
| CAP-212 | 补签/历史规则后续差额 | API-203 | DATA-206/207/210 |
| CAP-213 | owner+lexeme首次掌握/累计 | API-008/203 | DATA-202/203/207/208 |
| CAP-214 | 动态等级/成就/手动全或无领取 | API-203 | DATA-207/208/209/210 |
| CAP-215 | 兑换/库存/手动下架退积分 | API-204 | DATA-207/210/211 |
| CAP-216 | 逐模型加时/计划体验/额度组合 | API-004/204 | DATA-006/009/210/211 |
| CAP-217 | 成长配置/类型道具/正数补分 | API-103/206 | DATA-206/207/208/209/210 |
| CAP-218 | 预设目录/固定台/草稿预览发布 | API-202/208 | DATA-010/011/012/212/214 |
| CAP-219 | 访问/学习漏斗/留存/概览 | API-209/900 | DATA-009/202/213/214 |
| CAP-220 | 本人新旧批次标题编辑 | API-007 | DATA-012 |

32 DATA索引均有承接；账号删除覆盖全部个人数据，不意味着删除平台配置/公开预设。25 PAGE读取与命令见API索引/各专题；PAGE-215两视图、PAGE-208两模块分别承接，不把八模块压成一个简化管理表。

## 4. 新旧事务统一

真源[DB §11](database.md#11-事务边界并发与失败恢复)。Read Committed短事务＋唯一/FK；锁顺序：配置共享/排它 →账号稳定序（涉及访客先account后visitor）→run/claim稳定序→session/attempt/batch→定义→余额/库存/权益/settlement。无外部HTTP、密码昂贵校验或全用户重算持有配置锁。

### 4.1 实际旧入口的改造点

| 实际位置 | 现状与M002必须调整 |
|---|---|
| `generation/service.go Reserve` | 已锁主体；前置配置共享锁，改用统一quota state+charge，不再只查quota_reset_at |
| `generation/service.go CompleteValid` | app pool事务CAS+draft；改配置→主体→run顺序并同事务加入charge consumed、签到/有效学习/成长/分析 |
| `generation/service.go CompleteFailure`、`settlement.go` | 原单UPDATE退款；改短事务锁原主体/run/charge，恢复实际plan/extra来源，回读也核对charge，不能只看quota_charged=false |
| `learning/service.go ConsumeClaim` | 原先claim FOR UPDATE再run/draft；先无锁读取索引用于定位，再配置→account→visitor→run/claim锁，重验所有权/状态/过期，避免逆序 |
| `learning` save/delete | 增account锁并复核run/批次存在，收录成长/删除claim完整事务；不先锁draft再去账号 |
| `review/attempt.go completeBatch` | 原先session锁＋内存结果；改配置→account→session/attempt/batch，数据库draft最小状态，提交whole answers不写入数据库 |
| `admin/user_detail.go` | 已锁账号且事务内读新详情；前置配置共享锁，target base epoch及新配额投影，trial不变；后台编辑配置拿排它锁，不能账号锁后升级 |
| `identity` 删除/密码 | 密码计算在事务外，锁账号后重验凭据版本/会话；注销协调所有个人事实与分析关联，不能跟并发发卡错开 |
| `maintenance.SettleActiveGenerations` | 原直接UPDATE所有active run；逐run查定位后走相同failure settlement，不绕过extra退款、取消/valid赢家 |
| 原draft/claim/visitor cleanup | 原run/claim先SKIP LOCKED；改先枚举候选ID、按统一主体/对象顺序小批重验删除，不能把批清理反向锁带入新事务 |

新增模块必须接收同一个tx；只读聚合用一致快照不拿全用户锁。配置编辑短排它写完成就提交，资格重算分批在独立用户事务做，避免把全用户扫描放在全局配置事务中。

### 4.2 业务原子边界

| BE用例 | DB事务 | 提交与失败边界 |
|---|---|---|
| 有效普通/预设生成 | DB2-T01 | validated必须在run+draft+charge+签到/活跃/自动奖励+分析提交确认后发送；失败不能只保留奖励 |
| 收录/claim | DB2-T02 | 完整资源/title+disposition+成长/激活；同日claim可签到，不重复生成/扣次；删批后旧claim404 |
| 整批复习 | DB2-T03 | attempt状态/最小flag+进度+实际新增masteries+成长/分析；唯一attempt；不存答案hash或comparison |
| 补签/手动奖励 | DB2-T04/05 | 卡/日期差额/整档积分经验奖品全或无；正常签到自动，成就/等级只主动领取 |
| 兑换/启用/退换 | DB2-T06/07/08 | 商品/数量/余额幂等；当前计划覆盖拒绝模型卡；覆盖确认绑定旧trial；refund只撤本卡 |
| 补分/基础计划调整 | DB2-T09/10 | 仅正数，来源去重；base目标epoch重置不动trial及卡；返回事务内完整详情 |
| 预设发布 | DB2-T11 | current draft/成功preview/配置一致→发布指针原子，失败旧线上不动 |
| 删除/注销 | DB2-T12/13 | 先账号锁与并发写串行；删批保留成长、注销全删；分析个人关联不可仅置空owner |

结算键保存已确认非敏感参数指纹；same key/different input拒绝。growth_settlements.config_snapshot采用类型化版本，保存实际奖励/价格/到账后余额等最小结算回执字段，便于后续余额变化后仍返回原receipt，不保存HTTP全文；管理补发原因保存在该来源快照，不混入学习内容。自然幂等(run/attempt/card/tier)加数据库唯一，不能只依赖浏览器disable。只对完整DB事务的明确死锁/序列化回滚做至多2次重试，抖动短退避；不重试外部AI，不把COMMIT异常当明确回滚。未知提交结果读领域唯一事实，失联期间不宣称已到账/已退款。

### 4.3 复习流程闭环

详见[API-008](api/review.md)：服务端固定安排、draft事实和匿名题面；用户全部输入/前后/概览在本机；submit一次生成临时comparison并持久最小事实。首提交将该批标completed，重来建立独立attempt且旧事实不撤；下批仅显式start建立。最后提交使session completed，完成按钮只是离开；当次末批重来检查无同模式新会话冲突后重新打开当前session。get submitted只最小回执，不提供last-result。

题目ID/domain-HMAC需进程重启稳定，正常部署保留密钥。提交前不投影标题、标准答案、surface、目标ID或短文答案长度；原词字母槽的长度是批准提示。GET题面可续签2h能力，不使草稿2h失效。本机恢复需认证account ID隔离；切账号不读取上个账号内容；当服务端submitted/restarted/deleted及时清残留。

### 4.4 权益与时间

统一`LearningDay(t)=(t in Asia/Shanghai -4h).date`；仅签到/欢迎/成长/分析。日期复习用浏览器IANA，quota用滚动24h；三种时钟不得合并。duration一天=24h，体验关页面不暂停。

ResolveEffectivePlan比较唯一priority、同plan取base；ResolveModels取plan+有效model贡献排除禁用/retired。ReserveCharge取生效plan当前origin/epoch、无余额才extra最早到期；记录来源后，不因后来plan改变或卡过期换退款来源。管理员base Pro重置、原trial Pro已用8保持；回trial还是原8（随滚动窗口自然恢复）。

逐模型贡献使用owner锁串行，甲乙3+乙丙6为3/9/6，反向不会覆盖；plan模型权限不计入卡时间。高档覆盖plan trial确认绑定旧trial/ends/config，同档续期不重置quota。下架资格由最后retired时刻与卡当时有效性判定，延迟job也能懒补；refund按最新积分、一次到账，其他卡及plan不改。临时禁用/供应商失败不作为正式下架。

## 5. 安全、数据与输入

- 身份/CSRF/Origin/Fetch Metadata/会话期限沿现有M001，不新增OAuth、找回密码或账户锁定产品流程。昂贵密码哈希与只读凭据探针避免持业务锁；验证后事务重查目标，防密码变更/注销竞争。
- 所有私有query带owner条件，服务层再次验角色，管理员reader不暴露writer；签名token/不透明ID都不是ownership替代。随机词查询只能排本人库。
- 类型化四类卡/严格生成参数拒绝隐藏越权字段；确认token绑定操作、主体、对象与相关当前状态，预览过期需重算。最大HTTP体积沿现有防御值，不能变成用户可见的预设词数/正文上限；合法超限需在调优保护时告知，不静默截断。
- 普通标题/昵称/道具名称纯文本，Markdown仅公告，goldmark不启用unsafe，bluemonday显式允许段落/标题/列表/强调/代码/安全链接等；移除raw HTML、style、on*、iframe、javascript/data协议。后台预览和用户展示同pipeline；不执行远程图片下载。
- 数据库app/ai/maintenance/migrator权限依DB §13逐表授予。app可读/插账本，不授予任意UPDATE/DELETE账本（账号CASCADE按批准删除）；AI池仍专门凭据访问，不扩大到个人成长。不得给新表复制`GRANT ALL ON ALL TABLES`。当前schema的旧宽授权需迁移时按DB计划审计，不以运行账号superuser解约束。
- SSE与所有私有响应no-store；正文/答案不进日志、APM、分析、错误或幂等响应缓存。唯一CR042有界专用账号诊断保留原授权50次/24h/容量与访问隔离，不顺带采集所有用户，不导入管理分析。
- account删除即时清在线关联个人数据；后端无法物理遥删离线IndexedDB，客户端下次展示前校验。匿名汇总可保留，不含自由UTM文本/可逆身份键；90天过期不以成长记录重新拼个人分析。

## 6. 可靠性、维护与可观测

沿现有5秒退款重试、5分钟小批清理（当前batch200）。分析每分钟聚合，04:00结算成熟cohort；成长config扫描按revision游标分批、个人读取同步兜底；模型下架资格批判＋本人读/退时兜底。使用一个现有maintenance调度，不开额外服务。

运行active状态由DB可信，registry只持取消函数/短期状态。进程启动和shutdown对遗留active执行真实来源退款；反向写入迟到valid必须CAS失败，不能生成部分奖励。shutdown沿现有30s预算，先readiness下线、停止接新写/AI、取消在途并尽力结算，未完成由下次startup恢复；单副本前提下旧进程退出才启动新接受流量，不能两个进程互相退款对方active任务。

DB在AI结束后暂不可用：已有有限失败恢复逻辑持续核对，SSE不会伪造已退；断连/重启依据持久active/charge收敛。额外次数已过期退款可记回原余额，但读时仍不可消费，不能凭补偿延期限。卡和trial以绝对时间判有效，job停摆也不延权。

日志：request_id、run/attempt的技术关联ID、有限error code、stage、duration、charge来源类别、settlement成功/待确认；无输入文本/账号名字/凭据；trace仅诊断不等于永久分析数据。指标：原生成首段/总时长/失败/退款待确认；增加事务冲突率、领奖/兑换失败枚举、维护滞后、90天清理滞后、配置重算滞后、预览调用/未知用量计数。labels只固定类别，无user/run/card IDs或词。

健康检查复用API-900，provider故障不让登录/书架不可用。超时沿现有连接10s/TLS10s/响应头30s，generation无新增总时限，heartbeat15s；不重设产品“生成30秒必须结束”。容量/SLO与真实负载未测，不虚构性能达标；公开preset全文分页、随机词过滤与大用户成就计算需实施后测查询计划。

## 7. 发布、配置和回滚

1. **设计门**：先关闭CR-003 DBA接收并同步BE版本、完成frontend-bob方案，由守门器确认全技术阶段齐备；本稿不授权实现。
2. **实施顺序**：新增不可变后续SQL迁移→生成/学习旧入口锁与charge改造→review→growth/items→admin/presets/notices/analytics→配套前端。DB2-M01–07为DDL/数据迁移真源。保留0001–0007和原账号/批次/全部资源/统计，不重新AI生成历史内容。
3. **隔离验证**：从脱敏M001代表数据恢复到一次性测试库，执行新迁移、检查原六项统计/账号/库/固定计划一致。旧active进程安排停写并退款，无迁移跨新旧client混跑。
4. **运营初始化**：准备真实priority、初始level、签到/首次掌握经验、奖品/商品规则；由用户后台配置，fixture示例只测试。growth activated_at在确认配置可用后正式写一次，不靠每次启动默认now，不补一期成长。配置缺失维持可见不可用反馈，不能“暂填奖励”污染账本。
5. **构建部署**：backend/、frontend/、nginx/独立Docker contexts与现有compose，planning不进镜像；应用/migrator/密钥分离。先备份+校验恢复，再单次migrator，匹配backend/frontend schema后开放；现有runtime secrets继续复用，不输出明文、不自动探针所有真实模型。
6. **上线验证**：账号与原库/日期复习/单篇/正常及预设生成/卡扣额/消息/管理八模块冒烟，未授权不真实调用模型；可先用隔离fake provider契约链。真实模型小样本须明确模型/次数/预算和采集边界后执行，保留AI-QUALITY-90未验证状态。
7. **回滚**：迁移前可还原备份；若已有M002用户写入，不直接运行down丢成长/库存/私有新数据或用M001镜像读新schema。停写诊断优先前修，确需整库恢复必须用户明确接受恢复点后的数据损失。DB2回滚检查与镜像版本配套，不把“可构建”当已演练恢复。

## 8. 实施验证清单（尚未运行）

沿现有Go unit/integration、race、strict DTO/HTTP测试、sqlc与golangci检查。设计阶段只做文件/追踪/一致性静态检查，不机械运行无改动应用测试，也不声称以下场景通过。

| ID | 必需验证及可观察结果 |
|---|---|
| BE2-V01 | 一期登录注册/密码/语言/注销；admin完整模型/计划/用户，角色/CSRF/未知字段/对象归属均拒绝越权 |
| BE2-V02 | M001迁移前后账号/六统计/库资源等价；title默认/所有来源编辑/冲突；管理员只读；claim删后不重建 |
| BE2-V03 | words半截、短文部分、全空、全对提交；前后/概览不判分；submitted重复不返回comparison/不重奖 |
| BE2-V04 | 固定随机题序、HMAC题目重启稳定、token到期续取；no title/entry/surface泄题；本机多标签冲突由前端验证 |
| BE2-V05 | 最后一批redo与新同模式session竞争；range替换保留历史；部分未答概况；先删后提交失败/先提交后删成长保留（CR-003） |
| BE2-V06 | 计划base/trial隔离、同计划base重置+trial8保持；计划→extra最早到期；失败原来源一次退款/取消不退/重启退款 |
| BE2-V07 | 普通权限限制vs预设例外；访客/账号各自次数；版本过期/模型下架不换配置；仅标题重用preview、参数变更必须重预览 |
| BE2-V08 | 04:00自动签到、同日claim/跨日不签、历史补签及后续差额/无历史签到经验；两个卡并发补同日只扣一份 |
| BE2-V09 | masteries跨批原词去重、首次经验；跨级逐档/满级新增档/降级暂停/称号快照；一奖品无效整档积分经验均不发 |
| BE2-V10 | 模型甲6+3、甲乙3+乙丙6及反向、计划全覆盖阻新启用/不暂停旧；高盖低过期确认拒绝；退款gift/已用/后过期资格/当前金额/仅本卡 |
| BE2-V11 | 历史删除/注销与发卡领奖生成并发，账本不可恢复正文；余额对账非负，重复键异参409，管理员零负补分拒绝 |
| BE2-V12 | 公告Markdown攻击、URL协议、双语回退/隐藏提醒；显式login+claim编排，bootstrap不重复弹；标题存储CR-003 |
| BE2-V13 | 模型enable探针事务外，配置并发不覆盖；四优先级交换；商品ever_issued删除保护、奖励引用竞争；游标稳定排序 |
| BE2-V14 | UV跨登录、重复PV、30分钟bounce、7日激活与D7区别、迟交开始队列、3/1/1/1失败率25%、预览不污染 |
| BE2-V15 | 90天刚过读取过滤/物理清理、停止job/延迟告警、注销关联清除、历史UV不可相加；Clarity无私有采集 |
| BE2-V16 | fake provider SSE任意分块/usage末帧/最多3call/取消/断流/数据库commit未知；只有最终valid可收录 |
| BE2-V17 | 新旧SQL锁顺序并发压力、死锁重试不重发AI、数据迁移回放/恢复演练、公开全文与随机词EXPLAIN；记录实测而非预设成功 |

实际未来命令以backend/Makefile及既有test harness为准，隔离库和fake provider优先；测试金额/时長是合成夹具不写运营配置。CR039-L1的safe派生、CR042-L1单回复replay和AI-QUALITY-90继续开放，不在本期结构变更中顺手扩大调优或诊断平台。

## 9. 本轮交付证据与交接

当前权威入口为本文、[API索引](api/index.md)、[AI集成](ai-integration.md)、[角色交接](../handoffs/backend-architecture.md)；产品/设计/DB与原应用字节受保护。没有改workflow/agent/project镜像，也没部署、连接运行DB或真实AI调用。

[静态检查](evidence/M002-BE-01-check.json)记录CAP/DATA/PAGE/原路由继承/链接/保护摘要及**CR-003阻塞**；[manifest](evidence/M002-BE-01-manifest.json)和[快照](evidence/M002-BE-01.tar.gz)确定交付版本。静态文档PASS不代表应用功能/性能/AI质量验收；未执行独立新会话接收试验。

下一步建议先由守门器把CR-003有限数据补充交dba-diana；收到批准版本后backend-alex复核同步，再由frontend-bob接收完整API和UI22差异，明确本机草稿/临时总结/欢迎分支。专业角色不自行批准或改阶段。
