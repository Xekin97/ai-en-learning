---
milestone: M002
stage: technical-design
role: dba/base
agent_name: dba-diana
status: awaiting_user_review
version: M002-DB-01
date: 2026-09-20
---

# M002 数据库设计交接

## 当前状态与输入

交出角色 **dba-diana**，方案 **M002-DB-01** 待用户审阅。正式状态仍是 technical-design / dba/base / dba-diana；本文不激活 backend-alex，不批准迁移或实施。

- [角色激活 TRANSITION-M002-008](../reviews/technical-entry.md)。
- [当前完整产品](../product/overview.md)、[数据资产](../product/data-assets.md)、[能力与验收](../product/abilities.md)，版本 PRODUCT-03 / [006 批准](../reviews/product-title-revision.md)；所有 29 项一期能力继续承接。
- [UI22 设计验收](../reviews/uiux-design.md)、[H01 交接](./uiux.md)、[M001→M002 前端差异](../design/frontend-delta.md)。原件时点的“待审/当前 UI 阶段”不覆盖之后正式批准与当前 state。
- [当前一期数据库契约](../../M001/technical/database.md)、[迁移 0001–0007](../../../../backend/db/migrations/)、[实际输入摘要](../technical/evidence/M002-DB-01-inputs.json)。源码 HEAD 与工作区摘要均已记录，未连接运行库。
- 长期约束：[USER-COMPAT-001](../../M001/reviews/first-release-compatibility-policy.md)、[USER-CLAIM-DELETE-001](../../M001/reviews/claimed-batch-delete-retention-exception.md)。

## 需求确认与纠正

当前确认真源是[数据库方案 §1.1](../technical/database.md)：

- **DB2-Q01 / CORRECTED**：用户指出未要求跨设备保留草稿。已撤下 DBA 额外建议；本方案仅在当前浏览器存未提交草稿，服务器不增加逐题草稿表。CAP-204 的恢复确认仍保留。本机存储是本次技术建议，不把它记成用户指定 IndexedDB。
- **DB2-Q02 / CONFIRMED**：用户明确“采用基础与体验分别记账”。基础 Pro 调整后只重置 base 来源；原 Pro trial 已用次数、体验到期保持，之后回到 trial 延续其原用量。§8 已定义键与重置事务。
- **DB2-Q03 / CONFIRMED**：用户独立选择监控明细 **90 天**，到期仅保留不含个人标识汇总；不采集正文和复习答案。与草稿没有绑定关系。
- 其他规则引用 D2-18/22/25/41/43/49–82，不重开已确认奖励、卡片或预设流程。无待答复的关键业务解释；技术方案本身尚未获批。

## 产物与按任务接收

唯一当前正文：[database.md](../technical/database.md)。

| 接收任务 | 定位与完成要求 |
|---|---|
| DB2-R01 数据继承 | §2–4、§12；32 DATA 索引逐项有去向。保留账号、学习库、固定词表、日期/单批会话、原六项统计、完整模型/计划/用户管理；不借 M001 清库旧授权清数据 |
| DB2-R02 复习 | §5、DB2-T03、DB2-V02/03；本机答案恢复，服务端 attempt 最小事实；提交重试不重复结算，不留历史答案；会话进度、重来和最终完成须有一致状态边界 |
| DB2-R03 成长结算 | §6、DB2-T01–06/09；稳定词身份去重、签到历史标准与补差、等级降级/跨级、成就自动达成和手动整档领奖；配置重算不自动发奖 |
| DB2-R04 卡与计量 | §7–8、DB2-T07/08/10；逐卡逐模型时间贡献、下架资格持久、当前下架积分、基础/体验来源隔离、计划优先再额外次数、失败原来源退款 |
| DB2-R05 预设与分析 | §9–10、DB2-T11；草稿/预览/发布原子切换，单标题无说明；预览独立计量；分析 90 天/匿名汇总、迟交队列、零分母/未成熟及注销关联删除 |
| DB2-R06 实施边界 | §11–14；统一新旧锁顺序，原迁移不改，只写新迁移；保留数据且不默认旧接口混跑；隔离库/并发/恢复验证尚待实施 |

后端 API 路径、DTO、HTTP 错误、认证与 SSE 编排由 backend-alex 制定；本稿不替其设计完整 API。前端由 frontend-bob 接收设计差异，并明确本机草稿恢复/终态清理、临时总结、跨标签冲突、存储失败提示。旧原型 sessionStorage 夹具不等于工程存储方案。

## 文档整理与追踪

- 本次首次建立二期数据库正文，修改集中在本角色 `technical/database.md` 和本交接；没有复制或改写一期批准文档、产品、设计和控制面。
- DB2-Q01 原推断已撤销，相关草稿表、跨设备写入/TTL、验证和交接同步更正；DB2-Q02/03 的明确答复记录在同一正文，不堆叠问答文件。
- 正文按 DATA、DB2-T01–13、DB2-M01–07、DB2-V01–16 定位；[自检结果](../technical/evidence/M002-DB-01-check.json)、[交付清单](../technical/evidence/M002-DB-01-manifest.json)、[可恢复快照](../technical/evidence/M002-DB-01.tar.gz)定位本次准确版本。
- 覆盖 32 个数据索引（DATA-015 为替代索引）、49 个能力的继承/修改或无存储变化去向；静态追踪不等同所有接口或运行时验证通过。
- 完整继承与奖励/权益关系读取超过 planning 软预算，已按当前小交接+正文节号收敛，未整理他人历史；输入字符计量及保护摘要见自检，实际 tokens/费用 unknown。未执行独立新会话交接测试，不把本轮静态核对称作独立接收。

## 未完成与风险

- **实施/验证待做**：DDL、实际存储转换、约束/并发/删除/计量测试、代表负载 EXPLAIN、备份恢复演练；DB2-V01–16 是计划，不是通过记录。本轮没有生产数据库操作、应用改动、真实 AI 调用或部署。
- **运营准备待做**：奖励门槛/价格/期限、计划优先级初值等由运营填写；隔离测试可用明确标注的合成值，不能把原型 fixture 当生产批准。缺有效配置时不得启用真实成长结算。
- **接收职责待做**：backend-alex 核对配置/账号/旧仓储锁顺序、生成失败退款来源、模型停用与正式移除的区分、复习总结后重来状态机及分析关联删除；frontend-bob 落实本机恢复和 CAP-209 同日欢迎分支。
- **既有开放事项**：CR-001/002 的应用落实继续追踪；[CR039-L1](../../M001/changes/CR-039.md#retained-limitations)、[CR042-L1](../../M001/verification/CR-042-generation-evidence.md#retained-limitations)、[AI-QUALITY-90](../../M001/verification/ai-evaluation.md)保持原状态。本稿不扩展词形/取证平台，不声称已达到 90% 质量。
- 用户规模、真实数据库容量与性能/恢复目标未测；不能以文档完整性声称运行性能或生产可靠性已验收。已匿名汇总不能恢复过期窗口的任意精确 UV/WAU，查询按 §10 标明可用范围。

## 下一步

请审阅本数据库方案。用户批准并由守门器登记角色交接后，推荐由 **backend-alex** 在同一 technical-design 阶段接收，完成后端模块、Markdown API、AI 集成及事务编排。完成条件是本文已确认数据/生命周期/失败边界在对应 CAP/API 上有明确去向；发现冲突回本角色处理，不擅自忽略。

本交接不切换阶段或角色。运行时模型未切换，实际模型及 usage 未观测。
