---
milestone: M002
stage: technical-design
role: dba/base
agent_name: dba-diana
status: awaiting_user_review
version: M002-DB-02
revision_scope: M002-CR-003
date: 2026-09-20
---

# M002 数据库设计交接

## 当前状态与输入

**dba-diana** 已完成 **M002-DB-02** 的三项有限修订，待用户审阅。正式状态仍为 technical-design / dba/base / dba-diana；本交接不激活后端、不批准实施。DB-01 已由 009 批准，准确原件保存在下列快照；该批准不覆盖 DB-02 新增修改。

- [授权 TRANSITION-M002-010](../reviews/database-reception-rework.md)、[任务 M002-CR-003](../changes/CR-003.md)、[后端待审交接 BE-01](backend-architecture.md)。
- [PRODUCT-03](../product/overview.md)、[能力验收](../product/abilities.md)、[数据资产](../product/data-assets.md)与 [006 批准](../reviews/product-title-revision.md)；[UI22 验收](../reviews/uiux-design.md)、[H01](uiux.md)及[前端差异](../design/frontend-delta.md)。
- [DB-01 批准](../reviews/database-design.md)、[冻结原件](../technical/evidence/M002-DB-01.tar.gz)与[原清单](../technical/evidence/M002-DB-01-manifest.json)；[DB-02 输入/保护摘要](../technical/evidence/M002-DB-02-inputs.json)。
- [实际迁移 0001–0007](../../../../backend/db/migrations/)未改；长期约束 [USER-COMPAT-001](../../M001/reviews/first-release-compatibility-policy.md)、[USER-CLAIM-DELETE-001](../../M001/reviews/claimed-batch-delete-retention-exception.md)继续适用。

## 需求确认与产物

唯一当前正文：[database.md](../technical/database.md)。无新的待确认业务解释。DB2-Q01 的跨设备扩展仍已撤下，只保存当前浏览器草稿；DB2-Q02 基础/体验分别记账、DB2-Q03 监控明细 90 天均沿用户明确答复。三项补充的功能依据来自已批准产品/UI，010 授权修订；本次数据方案本身保持 PROPOSED。

| 接收 ID | 本次结果与后端复核入口 |
|---|---|
| DB2-R07 / CR-003-1 | §5.1/5.3/5.4、DB2-V17：submitted 增 has_unanswered，迁移 skip_count>0；首次提交保进度，最新提交算概况，全部成功尝试算累计。后端同步 API-008；不保存具体答案或空题编号 |
| DB2-R08 / CR-003-2 | §5.5、DB2-T14、DB2-V18：旧范围 abandoned、旧 draft restarted；旧完成事实保留，新建与关闭同事务。后端核对版本验证、空范围回滚、并发先后和失效旧页；单批会话不变 |
| DB2-R09 / CR-003-3 | §4.3、DB2-M02、DB2-V19：独立 title_zh/en，完整语言对 CHECK 与整套回退；通知相同时间按 id ASC 与 API-205 对齐。后端同步消息管理及公开投影，不能从正文取首行补标题 |

其余数据库规则继承 DB-01，不重复展开。保留任务定位：DB2-R01→§2–4/12 数据继承；R02→§5/T03 复习；R03→§6 成长；R04→§7–8 卡与计量；R05→§9–10 预设分析；R06→§11–14 实施、恢复与验证。它们保持原验收条件，尚未实施。后端 API/HTTP/鉴权及编排归 backend-alex；前端归 frontend-bob，仍须落实本机草稿隔离、恢复确认、终态清理、存储失败反馈及 CAP-209 同日欢迎分支。

## 自检与文档整理

- [静态结果](../technical/evidence/M002-DB-02-check.json)、[交付清单](../technical/evidence/M002-DB-02-manifest.json)、[准确快照](../technical/evidence/M002-DB-02.tar.gz)与[冻结核对](../technical/evidence/M002-DB-02-freeze-results.json)定位本次版本。
- 32 个 DATA 索引、49 个 CAP 的原映射保留；新增 DB2-T14、DB2-V17–19，不重排 T01–13 / M01–07 / V01–16。源码事实核对以实际 0002 的状态 CHECK、活跃部分唯一及 skip_count 约束为依据。
- 当前正文替换 DB-01 的三处不完整表达；DB-01 全文/交接与 BE-01 原始 CR 均可从各自冻结快照恢复，原批准、证据、产品、UI、应用与控制面不改。CR-003 仅补 DBA 处理进展，仍 OPEN。
- 当前交接按任务定位，不复制全部正文；同口径字符/字节及保护核对见静态结果，实际 tokens/费用 unknown。未做独立新会话接收；本次静态自检不当作后端专业接收或运行验证。

## 未完成与接收条件

- **M002-CR-003 / OPEN**：DBA 修订已交付；须用户批准 DB-02 后经守门器交回 backend-alex，复核 BE2-D01、API-008/205 和消息管理相关契约，形成后端新版本并记录是否消除缺口。BE-01 的 BLOCKED 不由 DBA 自行解除。
- **实施/验证待做**：DB2-M01–07 迁移，DB2-V01–19 隔离库、并发、删除、对账、性能与备份恢复验证；本轮只做文档与源码事实检查，没有运行数据库、应用测试或模型调用。
- **运营/规模未测**：初始奖励、等级、价格/期限与优先级仍待运营配置，不能以原型样本填生产；实际用户规模、数据库容量、性能和恢复能力未知。
- **既有开放项**：[M002-CR-001](../changes/M002-CR-001.md)、[M002-CR-002](../changes/M002-CR-002.md)的应用落实，以及 [CR039-L1](../../M001/changes/CR-039.md#retained-limitations)、[CR042-L1](../../M001/verification/CR-042-generation-evidence.md#retained-limitations)、[AI-QUALITY-90](../../M001/verification/ai-evaluation.md)保持原状态；不扩大诊断或模型评测范围。

## 下一步

请审阅 DB-02 三项修订。批准后由守门器登记本版本并交 **backend-alex** 复核；完成条件是 CR-003 三处字段、事务和查询语义与新后端方案一致，再按既定顺序进入前端架构。本角色不自行切换角色、关闭 CR 或沿用旧审批。实际运行模型未切换，usage unknown。
