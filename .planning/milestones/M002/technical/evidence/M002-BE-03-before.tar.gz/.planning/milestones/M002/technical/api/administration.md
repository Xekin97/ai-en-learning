# 管理 API-101/102/103/206/207/208

全部路径 `/api/v1/admin`、仅认证管理员A，修改需CSRF。普通L403、访客401；不提供代学习/代领取/修改短文。八模块为概览、数据分析、模型管理、计划管理、用户管理、成长运营、首页预设、独立消息管理。概览/分析另见 [analytics](analytics.md)。配置修改统一expected_revision，冲突409保留表单，成功200回完整当前对象及新revision。列表默认20最大100，公共规则见 [index](index.md)。

## 1. API-101 凭据与模型

`Credential={configured:bool,masked_hint:string|null,updated_at:Time|null}`。未配置后两值null，永不返回原文/可复用密文。

| Method / 路径 | 请求 | 成功 |
|---|---|---|
| GET /openrouter-credential | 无 | 200 `{credential:Credential,revision}` |
| PUT /openrouter-credential | `{api_key:string,confirmed:true,expected_revision}` | 200同GET，原有只读连通性验证后加密替换；空值不等于删除 |
| GET /models | cursor/limit，`status?:enabled\|disabled\|retired` | 200 `{items:AdminModel[],revision}`，created_at ASC,id ASC |
| POST /models | `{display_name,description?:string\|null,openrouter_model_id}` | 201 `{model:AdminModel,revision}`，默认disabled |
| PATCH /models/{id} | `{expected_revision,display_name?,description?:string\|null,openrouter_model_id?}` 至少一实际字段 | 200 `{model,revision}`；改provider ID自动disable |
| POST /models/{id}/enable | `{expected_revision}` | 200 `{model,revision}`；现有最小真实流兼容性探针通过才enable |
| POST /models/{id}/disable | `{expected_revision}` | 200 `{model,revision}`；只阻止新请求，非正式下架 |
| GET /models/{id}/removal-impact | 无 | 200 `RemovalImpact` |
| DELETE /models/{id} | `{expected_revision,confirmation_token,confirmed:true}` | 200 `{model,affected_groups:PlanCode[],revision}`；领域正式移除，不物理删历史身份 |

`AdminModel={id,display_name,description:string|null,openrouter_model_id,enabled:bool,retired_at:Time|null,assigned_group_codes:PlanCode[],created_at,updated_at}`；PlanCode含visitor，关联固定顺序visitor/basic/pro/plus。retired后不能编辑providerID或重新enable，422 model_retired；同供应商新建为新ID不恢复旧卡权限。enabled探针缺凭据/目录不支持/流校验失败422 model_incompatible，不把失败当成功；探针不计用户次数，不进学习分析。

`RemovalImpact={model:AdminModel,affected_groups:[{code,remaining_enabled_models:int}],affected_presets:int,affected_item_definitions:int,affected_owned_cards:int,confirmation_token,revision}`。不列个人身份/短文。token5分钟签名绑定模型、配置revision和受影响配置集合；库存数量为当时提示快照，不必因新库存变化永久阻塞下架。执行重读配置影响；集合改变409 impact_changed；确认成功清group_models、retired_at不可逆，保留历史快照并启动卡资格补判。无剩余计划模型也可确认，但结果明确0；有效模型卡可继续满足普通造文模型权限。新请求排除retired，在途按开始配置结算。

数据库名称/providerID的在用唯一性冲突409 model_conflict；描述null可清空，其他必填trim非空。兼容性网络探针必须在长事务外，最后短事务重新核验配置revision与模型状态再启用；过期结果不能覆盖管理员中途更改。

## 2. API-102 固定基础计划

`Group={code:PlanCode,priority:int,rolling_24h_limit:int|null,max_entries:int,allowed_lengths:Length[],models:[{id,display_name,enabled:bool}]}`。

- `GET /groups` →200 `{items:Group[],revision}`，四计划固定顺序。
- `POST /groups/{code}/impact-preview` body `{expected_revision,priority,rolling_24h_limit,max_entries,allowed_lengths,model_ids}` →200 `{base_users:int,active_trial_users:int,priority_changed:bool,may_change_effective_plan:bool,loses_all_models:bool,revision}`，只读估计，不能宣称数量锁定。
- `PUT /groups/{code}` body同preview →200 `{group:Group,revision}`。全替换，优先级唯一；rolling null无限、0无计划次数、正数有限；max_entries正整数（无额外产品上限）；模型必须现存非retired，可暂未启用；长度去重排序，空模型/长度允许但有警示。不增删改名。
- `POST /groups/priority-impact` body `{expected_revision,priorities:[{code,priority}]}` →200 `{affected_base_users:int,affected_trial_users:int,revision}`；完整四计划、不重复code/priority。
- `PUT /groups/priorities` 同body →200 `{items:Group[],revision}`；四档交换优先级同事务使用DB延迟唯一校验，避免用户无法交换两个值。未改其他权益。路由注册优先固定priorities于动态code。

改计划配置影响新请求且trial实时跟随；不重置任何用户base/trial已用，不修改卡期限。提高base/改优先级可能覆盖仍计时trial，同目标取base计量；不逐项拼最大值。invalid priority422 duplicate_priority；其他非法422validation。数据读取/写配置不执行AI、不处理生产样本。

## 3. API-103 用户管理完整继承

`UserSummary={id,username,role:"learner"|"admin",plan_code:Plan|null,status:"active",created_at}`，admin.plan_code=null。`GET /users?username=&cursor=&limit=` →200 `{items:UserSummary[]}`。trim/lower query；排序精确匹配tier0→其余包含tier1，再lower(username),id ASC。cursor沿v2绑定query、管理员和三排序键；空/非法/旧游标422，不能前端每页再排序。

`UserDetail`保留summary全部字段，加 `{ui_locale:Locale|null,nickname:string|null,gender:"male"|"female"|null,last_login_at:Time|null,last_learning_at:Time|null,learning_batch_count:int,generation_quota:{kind:"limited"|"unlimited",remaining:int|null}|null,growth:{level_number:int,points:Amount,experience:Amount,mastered_total:int,saved_total:int}|null,base_revision:string|null,effective_plan_code:Plan|null}`。

- L对象generation_quota始终非空；只显示生效计划可用次数，extra和trial分项通过下面benefits，不把extra混进limit；unlimited remaining=null，有限remaining≥0。admin quota/growth/base_revision/effective_plan全null，不当无限。
- `GET /users/{id}` →200 `{user:UserDetail}`，读取同一数据库快照，无额外扣额；不存在404、数据库失败500，不用0或Unlimited掩盖错误。
- `GET /users/{id}/benefits` →200 `{base_plan:{code,quota:PlanQuota},trial:{code,ends_at,quota:PlanQuota}|null,effective_origin:"base"|"trial",extra_quota:{remaining,earliest_expires_at}}`，仅目标L；为管理员准确解释调整影响，不提供代启用。base/trial quota分别按原来源用量投影。
- `PUT /users/{id}/group` body `{group_code:Plan,confirmed:true,expected_base_revision}` →200 `{user:UserDetail,quota_reset:true}`。同目标计划也代表一次明确人工重置；只把目标plan/base epoch+1和reset_at，trial/卡/奖励不动。事务内生成响应，提交后不再pool独立查询。stale revision409 base_plan_changed，先GET对账；重试不能再次重置。不改角色、不能把学习者变admin。
- `PUT /users/{id}/password` body `{new_password,new_password_confirmation,confirmed:true}` →204。密码8–128，直接设置并注销目标全部会话；无原密码/强制改密标记/通知发送。保留原管理目标限制，不接受role/group混入。
- `GET /users/{id}/batches?cursor=&limit=` →200 `{items:BatchSummary[]}`（[书架DTO](identity-library.md)，无single_batch_review操作字段），saved_at ASC,id ASC。
- `GET /users/{id}/batches/{batch_id}` →200 `{batch:BatchDetail}`，只读当前标题与完整资源，target必须属于此用户；没有PATCH/DELETE/复习代操作。
- `GET /users/{id}/points-ledger?cursor=&limit=` →200同个人流水，补发来源可含 `{admin_username:string|null}`（管理员注销后null），不显示秘密/学习内容。
- `POST /users/{id}/point-grants` body `{points:Amount,reason:string}`+Idempotency-Key →200 `{receipt:SettlementReceipt}`。points>0；reason为1–200字符管理说明，纯文本，不包含密码。只允许补发，无负数/撤回/直接设置余额接口；目标非L422，余额/账本同事务，不影响经验/等级。

## 4. API-206 成长运营配置

范围DATA-206–211，四固定成就类型，动态任意多档。`Bilingual={zh_CN:string|null,en_US:string|null}`，至少一种非空，另一缺失回退；不是空值自动翻译。文本均plain，notice正文Markdown例外。固定name_zh/en存储到API键通过mapping，禁止通用任意JSON奖励。

`RewardInput={points:Amount,item_definition_id:string|null,item_count:int}`，item_id null时count=0，否则>0；achievement再加experience:Amount。每档单一可多份卡定义，符合 DB-02 延续的奖励定义，不在API扩展多类奖品数组。

| Method / 路径 | 请求 | 成功 |
|---|---|---|
| GET /growth/settings | 无 | 200 `{mastery_experience:Amount,growth_started_at:Time,revision}` |
| PUT /growth/settings | `{mastery_experience:Amount,expected_revision}` | 200同GET；启用时间只读，不能回拨或回填一期 |
| GET /growth/checkin-rule | 无 | 200 `{current:CheckinRule,pending:CheckinRule\|null,revision}` |
| PUT /growth/checkin-rule | `{base_points:Amount,step_points:Amount,cap_points:Amount,normal_experience:Amount,expected_revision}` | 200同GET，写下一学习日pending，响应明确effective_day |
| GET /growth/levels | cursor/limit | 200 `{items:LevelConfig[],revision}`，level_number ASC |
| POST /growth/levels | LevelInput | 201 `{level:LevelConfig,revision}` |
| PUT /growth/levels/{id} | LevelInput+expected_revision | 200 `{level,revision}` |
| POST /growth/levels/impact-preview | `{id:string\|null,...LevelInput,expected_revision}` | 200 `{may_downgrade:bool,affected_users:int,rewards_use_latest_config:true,revision}`，不写配置 |
| GET /growth/achievements | kind?/cursor/limit | 200 `{items:AchievementConfig[],revision}`，固定kind顺序/threshold ASC,id ASC |
| POST /growth/achievements | AchievementInput | 201 `{achievement:AchievementConfig,revision}` |
| PUT /growth/achievements/{id} | AchievementInput+expected_revision | 200 `{achievement,revision}` |

`CheckinRule={effective_day:Date,base_points:Amount,step_points:Amount,cap_points:Amount,normal_experience:Amount}`；cap≥base、其他≥0。已生效历史immutable，同一天改pending覆盖待生效版本，按revision保护。

`LevelInput={level_number:int,min_experience:Amount,reward_enabled:bool,reward:RewardInput}`；LevelConfig加id。level_number≥1唯一、累计门槛随级数严格增且初始0、初始奖励0且item=null；不固定档数。已有稳定ID不因改门槛改变，不允许更换已存在level_number对应身份；通过新增高档扩展。停用只暂停该等级奖，不取消该等级参与经验判断。无删除已达成身份接口。

`AchievementInput={kind:AchievementKind,threshold:int,enabled:bool,name:Bilingual,title:Bilingual,reward:RewardInput&{experience:Amount}}`；Config加id。threshold>0，同kind不同档门槛不重复，类型既有档不可改，标题达成时快照；配置不收回已得。公告/成就/道具说明翻译范围见产品，本表不新增成就独立说明字段（DB无此列）。

配置成功增加growth_settings revision，仅持锁写配置；批处理重算资格、个人读/领同步重算兜底，不自动发奖。门槛提高可降级/暂停高档未领；已领取快照保留，未领用最新积分/经验/卡。等级体验权益与成长等级完全分开。非法门槛/重复档422；失效奖品422 reward_unavailable；有效但商城下架可引用，不因listed=false拒绝。

### 道具定义管理

`ItemInput={kind:ItemKind,name:Bilingual,description:Bilingual,exchange_price:Amount,activation_ttl_seconds:int,effect:EffectInput}`。

```text
EffectInput={kind:"makeup"}
 | {kind:"extra_credit",extra_count:int}
 | {kind:"model_trial",model_ids:string[],trial_seconds:int,retirement_points:Amount}
 | {kind:"plan_trial",target_plan_code:Plan,trial_seconds:int}
```

kind与effect.kind一致；有效期限/时长/次数>0，价格/下架积分≥0；模型集合非空去重存在，不能新引用正式retired模型；plan只能existing basic/pro/plus（能否被用户启用由当时优先级决定）。模型卡不接受extra_count；plan卡不接受模型/次数/词数。

`ItemConfig`=ItemInput加`{id,listed:bool,ever_issued:bool,reference_count:int,created_at,updated_at}`。

| Method / 路径 | 请求 | 成功 |
|---|---|---|
| GET /growth/items | `q?:string,kind?:ItemKind,listed?:bool,cursor,limit` | 200 `{items:ItemConfig[],revision}`，双语名称包含匹配，created_at DESC,id ASC |
| POST /growth/items | ItemInput，禁止listed字段 | 201 `{item:ItemConfig,revision}`，listed恒false |
| GET /growth/items/{id} | 无 | 200 `{item:ItemConfig,revision}` |
| PUT /growth/items/{id} | ItemInput+expected_revision | 200 `{item,revision}`，kind immutable，变化422 item_type_immutable |
| PUT /growth/items/{id}/listing | `{listed:bool,expected_revision}` | 200 `{item,revision}`；只变兑换状态 |
| GET /growth/items/{id}/references | cursor/limit | 200 `{ever_issued:bool,items:[{kind:"level"\|"achievement",id,name:string,enabled:bool}]}`；kind/id ASC |
| DELETE /growth/items/{id} | `{expected_revision,confirmed:true}` | 204，仅ever_issued=false且无引用，否则409 item_has_history/item_in_use |

已发作用/启用期限/模型集/时长不回写；retirement_points是立即生效例外。plan卡身份+时长快照，实际plan权益读最新。商城上下架不终止现有体验，也不阻止有效奖励发放。删除和发卡/奖励引用竞争由DB配置锁+FK+ever_issued保证，不能删掉“全部已过期”但有历史定义。

## 5. API-207 独立消息管理

`NoticeInput={title:Bilingual,body_markdown:Bilingual,visible:bool,remind:bool}`，至少一个语言完整title+body非空，按整套语言回退；body技术上限每语言64KiB UTF-8，title200 code points。后台原文仅A，存Markdown；用户安全HTML见API-205。独立双语标题沿 UI22，已接收获批 [DB-02 §4.3](../database.md#43-平台通知)，对应 [CR-003](../../changes/CR-003.md) / DB2-R09，不能从正文取首行代替。

title.zh_CN/en_US 分别映射 title_zh/en，body_markdown.zh_CN/en_US 分别映射 body_zh/en；标题按纯文本保存，Markdown 非空时保留原排版，空白字段归 null。至少一个同语言标题和正文完整，服务层先校验、数据库完整语言对 CHECK 兜底；另一语言仅填一个字段允许保存，用户端视为缺少该语言完整翻译。只有中标题+英正文、两语言均不完整或全空时422 validation_failed，字段提示定位 title/body_markdown 的缺项，不能交叉拼成完整对。前端保留输入供修正。

- `GET /notices?cursor=&limit=` →200 `{items:AdminNotice[],revision}`，published_at DESC,id ASC。
- `POST /notices` NoticeInput →201 `{notice:AdminNotice,revision}`。
- `GET /notices/{id}` →200 `{notice:AdminNotice,revision}`。
- `PUT /notices/{id}` NoticeInput+expected_revision →200同GET。开关可组合，visible=false即使remind=true也不对用户返回。
- `POST /notices/preview` `{body_markdown:string}` →200 `{body_html:string}`；与用户端同render/sanitize，预览不存/不发布。

`AdminNotice`=NoticeInput加`{id,published_at,updated_at}`。保存时在配置锁/revision 校验下将标题、正文和开关作为一份更新，冲突409 revision_conflict、任一验证失败均不部分保存；重复未知结果先 GET 核对再决定新的编辑意图。published_at由服务端创建时确定，编辑标题/正文/开关不伪造新发布排序。没有个人消息、已读关系、发送邮件，也不增加未批准的单独删除功能；隐藏满足停止显示。

验收 BE2-V12 / DB2-V19：中文完整、英文完整、双语完整均成功；另一语言不完整时原文可往返但用户投影整套回退；跨语言拼凑和空值拒绝；同时编辑冲突无半份更新。Markdown 预览只验证渲染，不保存标题或绕过整份 NoticeInput 校验。

## 6. API-208 热门预设管理

`PresetInput={title:string,configuration:{model_id,entries:string[],meaning_language,scenario,length}}`，无description/双标题。title trim非空≤200 code points，entries非空合法规范词去重，所有平台支持配置可选，无访客计划上限；配置中无prompt或provider字段。

`AdminPreset={id,draft_version:string,published_version:string|null,listed:bool,title:string,configuration:PresetConfiguration,draft_state:"needs_preview"|"preview_ready",has_unpublished_changes:bool,preview:{preview_run_id,completed_at,result:ValidatedResult,usage:UsageSummary}|null,published:{title,configuration,sample:ValidatedResult,version_created_at}|null}`；draft引用完整当前配置，published是线上独立快照；new draft不改变线上。PresetConfiguration和ValidatedResult见 [生成契约](generation-presets.md)。

| Method / 路径 | 请求 | 成功 |
|---|---|---|
| GET /presets | cursor/limit | 200 `{items:AdminPreset[],revision}`，updated_at DESC,id ASC |
| POST /presets | PresetInput | 201 `{preset:AdminPreset,revision}`，草稿/未上架 |
| GET /presets/{id} | 无 | 200 `{preset,revision}` |
| PUT /presets/{id} | PresetInput+expected_revision | 200 `{preset,revision}`，创建不可变新draft version |
| POST /presets/{id}/previews/stream | `{draft_version}` | API-202 preview SSE，无quota |
| POST /presets/{id}/publish | `{draft_version,expected_revision,confirmed:true}` | 200 `{preset,revision}`，完整成功preview匹配才切线上 |
| POST /presets/{id}/unpublish | `{expected_revision,confirmed:true}` | 200 `{preset,revision}`，listed=false，保留草稿/版本 |
| GET /preset-preview-usage | `start_date,end_date,cursor,limit` | 200 `{summary:UsageSummary,items:PreviewUsage[]}`，started_at DESC,id ASC |

preview cancel与/admin/generation-options见API-202；路由属于A。无预设物理删除入口（当前产品仅下架）；旧已开始run配置独立保留按生成生命周期清理，不因草稿GC失败。

`UsageSummary={logical_runs:int,provider_calls:int,input_tokens:int|null,output_tokens:int|null,cost:{amount:string,unit:"openrouter_credits"}|null,unknown_calls:int}`；金额十进制文本、明确供应商报告单位，未知null，不未经换算标美元。只要总和含未知，summary对应总值null，items保留已知各项，不用0补齐。`PreviewUsage={preview_run_id,preset_id:string|null,draft_version:string|null,status:"active"|"valid"|"failed"|"cancelled",started_at,completed_at:Time|null,usage:UsageSummary}`，单逻辑run的logical_runs=1。provider_calls包括同run内部纠正/续写，每call只能记一次。管理员预览不计用户生成篇数、转化或签到。

发布事务核验draft版本、preview有效/配置摘要一致和模型仍启用；标题-only可复用原preview，词条/model/语言/scene/length任一改动须重做，422 preview_required；失效引用422 preset_unavailable；版本变化409 revision_conflict。成功线上标题/完整样文/配置一起切换，失败原线上保持。保存草稿/预览成功均不会自动上线。

## 7. 管理验证

BE2-V01/07/09/10/12/13：模型完整CRUD中的正式移除、无模型计划、固定四计划全权益与优先级交换、用户搜索cursor v2/密码/只读库、base重置trial不动、正数补发幂等、动态第5档以上、类型字段注入拒绝、发过卡不可删、奖品引用竞争、隐藏提醒、发布前后原子一致、未知用量明确null。自动审批/阶段切换不属于这些管理API。
