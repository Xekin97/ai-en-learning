---
milestone: M002
stage: technical-design
role: backend-architect/base
agent_name: backend-alex
status: awaiting_user_review
version: M002-BE-03
date: 2026-09-20
blocking_alignment: null
input_database: M002-DB-03
revision_scope: M002-CR-004
---

# 后端架构交接 M002-BE-03

交出角色 **backend-alex**。本轮已接收获批 DB-03，完成 CR-004 三项后端契约补齐，BE-03 待用户审阅；前端 schema/保存编排接收尚未完成，CR-004 仍 OPEN。正式状态保持 technical-design/backend-alex，不激活前端或实施。

## 输入与需求确认

- [PRODUCT-03](../product/overview.md) / 006，49 CAP、32 DATA 索引完整继承；[UI22 验收](../reviews/uiux-design.md)、[H01](uiux.md)、[设计差异](../design/frontend-delta.md)保持。
- [DB-03](../technical/database.md)、[DBA 交接](database.md)及 [014 批准与接收授权](../reviews/database-cr004-revision.md)：DB2-R10/11、T15/16、V20–23 为本轮数据库依据。原稿的待审文字属于冻结时点，不能覆盖正式批准。
- [CR-004](../changes/CR-004.md) 和 [FE-01 接收](frontend-architecture.md)明确三个缺口；没有新业务解释待回答。可空成就说明、五值/多档一次保存、管理员全部支持配置由原产品/UI与 DB-03 确定，接口字段、校验、行映射与失败规则由本版细化。
- DB2-Q01 当前浏览器草稿、Q02 base/trial 分账、Q03 分析90天保持；USER-COMPAT-001 / USER-CLAIM-DELETE-001 保持，旧一次性清库不适用。本轮不新增计划、任务、道具类别、自动奖励或数据保留能力。
- [输入/保护记录](../technical/evidence/M002-BE-03-inputs.json)对应源码 HEAD `5da571b226635113c41cd9cb8c4f33433946fbad`；Profile consumer-ai-web@1.0.0 保持，模型路由未实际切换，usage unknown，无子代理。

## 当前产物与接续任务

权威入口为 [后端方案](../technical/backend.md)、[API index](../technical/api/index.md)、[AI 方案](../technical/ai-integration.md)。保留 BE2-R01–08：R01→backend §2–3 全量继承，R02→七份 API，R03→API-008 复习，R04→API-203/204 成长权益，R05→管理/API-202 预设，R06→API-209 分析，R07→AI 与旧锁序，R08→backend §7–8 工程验证。它们均需后续实现验证。

| 本次接收 | 新版契约与前端具体动作 | 完成条件 |
|---|---|---|
| FE2-G01 / BE2-D02.1 | [API-206](../technical/api/administration.md#api-206-growth-config) description:OptionalBilingual；[API-203](../technical/api/growth-benefits.md) description:string或null；建立可空 schema，管理槽保真，个人页纯文本显示/空则省略 | 单侧/双侧/双空/纯空白/尖括号示例确定；缺译回退不写回配置、不影响称号快照 |
| FE2-G02 / BE2-D02.2 | API-206 三个整组命令；设置页五值一起提交，等级先完整变化集 preview 再确认，成就内容弹窗留在草稿。列表全量读不分页；保存返回完整 configuration/saved_rows，绑定新增档 id | 第五/第六档及多行修改一次成功；字段错误按发出时 changes 映射 client_key；409/未知提交保留草稿并重读，不能客户端补偿或逐行落库 |
| FE2-G03 / BE2-D02.3 | [API-202 §5](../technical/api/generation-presets.md#5-管理员预览边界) 的 AdminGenerationOptions 与 can_preview/reason，独立于普通计划选项 | 有模型无凭据、凭据存在无模型、两者缺失优先级、正常成功、503读取失败和401/403分别建 mock；不猜 provider/额度/max_entries |

类型示例入口：[M002-BE-03-contract-examples.json](../technical/evidence/M002-BE-03-contract-examples.json)。它是合成契约示例，不是种子、代码生成源或数据库运行测试。API Markdown 为契约真源；示例值和 token 不能用于生产。

前端须移除旧草案的分拆 checkin-rule 保存和单档 POST/PUT 调用；这些路径未实施，不建旧客户端兼容层。整组确认 token 绑定管理员/会话/revision/完整变化集，编辑后须重做 preview；影响人数不是冻结所有用户。transport 超限或任何行失败都不自动拆单。未知 COMMIT 时 GET 只是当前状态，不当成原保存收据。

## 继承提醒

- 原登录注册/密码/注销、书架六统计/完整详情/可编辑标题、日期与单批复习、模型计划用户管理保持；Header 与个人中心四视图、后台八模块按 UI22/H01，不把接口文案直接展示给用户。
- BE2-D01/CR-003 已由 012 关闭设计接收。API-008 的 M001 Receipt.has_answer=bool或null、最新概况与首次进度分开、abandoned/restarted 终态清本机残留保持；消息标题/正文整套语言回退保持。不要把成就逐字段回退改成消息规则。
- 本机 IndexedDB 按账号隔离、恢复确认、存储失败提示；不存标准答案，服务端终态优先。当次 comparison 不持久化，submitted 重试无历史答案回放。
- Amount 十进制字符串、次数/模型权限分开、模型卡逐模型加时、基础/体验分账、下架当前积分保持。AI 策略沿 BE-02/r10，不扩展词形或真实模型评测。
- CAP-209 同学习日欢迎仍需前端使用 welcome.today，10秒/较大天数/淡入淡出/消息之上；显式 login 且 claim 优先，bootstrap 不重复弹。UI22 中该残留不因后端方案完成而消失。

## 文档整理与自检

- 就地更新后端、API-203/206/202 与 API index、交接和 CR-004 解决段；AI 文件仅版本/接收入口更新，调用规则不变。其他三份 API、DBA、产品/UI、应用/迁移、控制面及 CR-003 原件不改。
- [BE-02 原件](../technical/evidence/M002-BE-02.tar.gz)、[DB-03 原件](../technical/evidence/M002-DB-03.tar.gz)、[FE-01 原件](../technical/evidence/M002-FE-01.tar.gz)和历史批准保留；本次改前八份源码另存 [before](../technical/evidence/M002-BE-03-before.tar.gz)。仅更新当前有效入口，不复制全部历史。
- [静态检查](../technical/evidence/M002-BE-03-check.json)、[清单](../technical/evidence/M002-BE-03-manifest.json)、[准确快照](../technical/evidence/M002-BE-03.tar.gz)、[冻结核对](../technical/evidence/M002-BE-03-freeze-results.json)定位本版。检查类型示例/追踪/变化范围与保护摘要，不能证明数据库原子性或应用已实现。
- 49 CAP/32 DATA/25 PAGE 引用和 R01–08、V01–17 继承，新增 V18–21；DB 验证仍以 DB2-V01–23 为准。按同一文件范围报告前后字符/字节，实际 token/费用 unknown；未执行独立新会话接收，须前端专业接收。

## 未完成与下一步

- **CR-004 / OPEN**：BE-03 待批准；随后 frontend-bob 按上表补 schema/mocks/保存编排、验证完整覆盖并交修订版，才能提请守门器解除缺口。后端不能自行宣布 FE-01 完整通过或改 workflow。
- **未执行验证**：BE2-V01–21 / DB2-V01–23 的实现、HTTP/隔离库/故障/并发/迁移恢复及性能。没有安装依赖、运行应用测试、数据库连接、真实 AI 调用、部署或 git 提交。
- **既有 OPEN**：CR-001/002 应用落实、CR039-L1、CR042-L1、AI-QUALITY-90 保持原入口及验收，不扩大诊断采集或宣称90%质量达标。
- **运营配置**：计划优先级、签到/经验、等级/成就及道具数值由用户后台填写，不能以示例覆盖生产；实际规模/性能仍未知。

请审阅 BE-03。批准后由守门器交 **frontend-bob** 接收 CR-004 并更新前端方案。此为后端架构修订交付，不是实施授权。
