---
milestone: M002
stage: technical-design
role: dba/base
agent_name: dba-diana
status: awaiting_user_review
version: M002-DB-03
revision_scope: M002-CR-004
date: 2026-09-20
---

# M002 数据库设计交接

## 当前状态与输入

**dba-diana** 已完成 **M002-DB-03** 的有限修订，待用户审阅。正式状态仍为 technical-design / dba/base / dba-diana；本交接不激活后端、不批准实施。DB-02 / BE-02 历史批准保持，不覆盖本版新增修改；FE-01 仍是缺口修订输入。

- [授权 TRANSITION-M002-013](../reviews/frontend-reception-rework.md)、[任务 M002-CR-004](../changes/CR-004.md)、[前端 FE-01 交接](frontend-architecture.md)。
- [PRODUCT-03](../product/overview.md)、[CAP-214/217](../product/abilities.md)、[DATA-206/208/209](../product/data-assets.md)与 [006 批准](../reviews/product-title-revision.md)；[UI22 验收](../reviews/uiux-design.md)、[H01](uiux.md)及[前端差异](../design/frontend-delta.md)。
- [DB-02 批准](../reviews/database-revision.md)及[冻结原件](../technical/evidence/M002-DB-02.tar.gz)；[BE-02 批准](../reviews/backend-design.md)及[冻结原件](../technical/evidence/M002-BE-02.tar.gz)；[FE-01 原件](../technical/evidence/M002-FE-01.tar.gz)。[本次输入与保护摘要](../technical/evidence/M002-DB-03-inputs.json)已核验这三包成员与来源。
- [实际迁移 0001–0007](../../../../backend/db/migrations/)未改；[USER-COMPAT-001](../../M001/reviews/first-release-compatibility-policy.md)、[USER-CLAIM-DELETE-001](../../M001/reviews/claimed-batch-delete-retention-exception.md)继续适用。

## 需求确认与本次结果

唯一当前正文：[database.md](../technical/database.md)。没有新业务选择待用户答复。DB2-Q01 同浏览器草稿、Q02 基础/体验分别记账、Q03 监控明细 90 天不变。R10/11 的产品与交互依据已批准，013 已授权补齐；具体数据库方案保持 PROPOSED。

| 接收 ID | 数据库结果 | backend-alex 必须接收 |
|---|---|---|
| FE2-G01 / DB2-R10 | §6.3、M02、V20：成就独立 description_zh/en 可空纯文本；缺译逐字段回退，两种皆空省略；管理保留实际语言槽；当前说明与达成时称号快照分离 | API-206 管理读写与 API-203 成就投影补 description；明确长度/空值/回退，移除“不新增说明”的旧限制；不新增说明必填 |
| FE2-G02 / DB2-R11 | §6.4、T15/16、V21–23：签到五值单事务、等级/同类成就变化集单事务；完整最终集合校验，原 id 不变、新档可超过四档；配置锁内检查全局 revision，一次提交只推进一次 | 用明确命令替代 UI 的逐行保存；补整组门槛影响预览/确认绑定、行字段错误、同版本完整响应及提交不明的重读契约。签规则下一学习日生效，mastery 提交后生效；内容弹窗并入外层保存 |
| FE2-G03 / 后端事项 | 未发现新增数据资产或表需求；复用现有模型/词表/支持枚举/凭据可用性事实 | API-202 的 GET /admin/generation-options 补严格成功 DTO、缺凭据/无模型/读取失败分支；不能泄露密钥、扩成新供应商配置或新增管理员额度 |

后端应重点核对：已有所有配置写入口遵守相同锁序；两处门槛 UNIQUE 可延迟但 CHECK 不可延迟；不能拿延迟唯一约束当 upsert 冲突目标；分页未提交行不删除且参与校验。拿配置锁后统一取保存时刻，避免排队跨 04:00 修改已生效签到规则。多查询配置读先持配置共享锁，或一个 SQL 快照完成；跨页 revision 改变应重读。保存不遍历所有用户、不发奖，重算游标与 revision 原子登记。

未改业务：手动领奖整笔结算、既有称号和实发奖励保留、配置按当前值影响未领资格、奖励卡不可用暂停整档领取、四类卡边界和固定四基础计划。第五档以上指成长等级/成就。没有创建 SQL、接口实现或本机/云端数据库修改。

## 继承与文档整理

保留原 32 个 DATA 索引（含 DATA-015 替代）、49 个 CAP 和完整 M001 继承。R01→§2–4/12；R02→§5；R03→§6；R04→§7–8；R05→§9–10；R06→§11–14。CR-003 的 R07–09 已由 011/012 批准接收，T14/V17–19 保持；**不重开 CR-003**。本次新增 T15/16、V20–23，M01–07 编号不变，在 M02 补说明列与约束。

- [静态检查](../technical/evidence/M002-DB-03-check.json)、[冻结清单](../technical/evidence/M002-DB-03-manifest.json)、[准确快照](../technical/evidence/M002-DB-03.tar.gz)及[冻结核对](../technical/evidence/M002-DB-03-freeze-results.json)定位待审版本。
- 仅更新数据库正文、当前 DBA 交接和 CR-004 解决进展；CR 原始缺口段落不改。旧 DB/BE/FE 冻结包、产品/UI、控制面及应用源码保留。旧正文/交接和 CR004 本次前态另存 [输入快照](../technical/evidence/M002-DB-03-before.tar.gz)。
- 当前入口按接收任务定位，不复制全部历史。正文相对 DB-02 的差异、字节/字符统计与受保护文件核对在静态报告；实际 token/费用 unknown，未声称运行模型切换。此次非独立新会话接收，静态检查不等于数据库测试或后端接收。

## 未完成与交接条件

- **CR-004 / OPEN**：本次仅交付 DBA 方案；须用户批准 DB-03，经守门登记后由 backend-alex 接收三个缺口并产出新版。再由 frontend-bob 同步 schema/mock/保存编排，复核五档以上、双语回退、整组失败和管理员生成选项；不能由 DBA 自行解除 FE-01 阻塞或批准完整技术阶段。
- **实施/验证**：M01–07、V01–23 均需实施验证；特别是 V20–23 的空值回退、合法门槛批量修改、故障注入、并发保存/领奖、04:00 等待跨界及未知 COMMIT。只有文档和源码事实检查已执行，没有连接数据库、运行应用测试或调用模型。
- **运营/容量**：奖励、门槛、价格/期限与优先级由运营填写；原型不是生产种子。实际规模、容量、性能和恢复能力仍未知。
- **既有开放项**：[CR-001](../changes/M002-CR-001.md)、[CR-002](../changes/M002-CR-002.md)的应用落实，以及 [CR039-L1](../../M001/changes/CR-039.md#retained-limitations)、[CR042-L1](../../M001/verification/CR-042-generation-evidence.md#retained-limitations)、[AI-QUALITY-90](../../M001/verification/ai-evaluation.md)保持。CAP-209 同日欢迎仍须前端落实，不据数据库方案认定界面已实现。

## 下一步

请审阅 DB-03。批准后由守门器登记本版本并交 **backend-alex** 接收 CR-004；该批准只针对数据库设计修订，不批准代码实施、数据库迁移或 FE-01 全稿。本角色不自行切换角色或关闭 CR。
