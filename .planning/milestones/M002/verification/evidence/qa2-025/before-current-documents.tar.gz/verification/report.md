---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: integrated_walkthrough_ready
result: scoped_pass
version: M002-QA-24
date: 2026-09-29
---

# 当前本地验收结果

**UAT24-MOCK-01 已修复：3302 的本地生成替身现按实际选词、释义语言和篇幅返回合法测试样文。** 原先固定返回 learn/weave/book，用户换词时真实校验报 `annotation_source_unknown`，失败计次已退回；[原失败](evidence/qa2-024/before-reproduction.json)与[用户日志摘要](evidence/qa2-024/reported-failures.json)保留。责任属于 QA 测试夹具，不是产品实现；保持 verification / qa-quinn，不启动实现阶段或新增产品规则。

[6项实际复验](evidence/qa2-024/results.json)通过：中文不同词组、英文部分原词、日文含空格/撇号词组的原始流与终态一致；普通台手动＋随机选词及预设台真实生成并进入登录收录；兼容性探针原响应一致。短/中篇幅和三个释义语言有实际结果，其余配置沿当前输入生成模板但不宣称穷举验收。页面脚本错误0、截图0、真实AI调用0。

仅替换本地 fixture/proxy 进程；前端CR023构建、Go/Postgres进程、原账号和配置保留。新匿名会话正常产生测试记录，没有复位既有数据。释义明确标为测试占位，不代表词义或AI质量。首次浏览器检查读取SSE响应体遇CDP方法错误，原件保留，仅补验UI/探针，三项API不重跑；见[方法记录](evidence/qa2-024/method-notes.json)。原QA23检查按产品源未变复用，最终人工UAT仍待用户继续。

[当前恢复脚本](evidence/qa2-024/preview.py)、[运行记录](evidence/qa2-024/preview-start.json)、[证据清单](evidence/qa2-024/manifest.json)。旧五份QA23正文保留在qa2-024/before-documents.tar.gz；历史失败与冻结证据不改。

## 已通过的四项界面修复（QA23）

**用户本轮反馈的四项界面问题均已修复，真实Go/Postgres候选8项独立复验通过。** 开发交付另有37单测、20浏览器通过；QA未重跑开发检查。原3302已更新到frontend-cr023生产构建，用户数据库/模型/计划/消息配置保留，未重置或补种数据。

| 条目 | 实际结果与证据 |
|---|---|
| UAT23-01 错误反馈 | 真实登录错误401、已有用户名注册409；20px无填充线性图标，描边与错误文字同色、role=alert；中/英文访客界面通过 |
| UAT23-02 访客入口 | library/review真实服务端重定向到login，登录表单实际渲染，无旧AuthGate；注册/登录互跳保持原目标，成功登录返回复习 |
| UAT23-03 计划表单 | 两个原型选项组/四种长度/保存图标完整；1440两列、390单列，无页面横溢；输入与真实后台计划一致，不写用户配置。确认保存/刷新由开发契约环境20项证据覆盖 |
| UAT23-04 消息弹窗 | 使用当前后台2条真实提醒，无需备用夹具；统一弹窗标题、纯日期/位置、正文标题/Markdown、分页与关闭正确；欢迎Toast在modal上方，Escape关闭后继续，刷新不重复提醒 |

[独立原始结果](evidence/qa2-023/results.json)、[脚本](evidence/qa2-023/retest.mjs)、[输入](evidence/qa2-023/inputs.json)、[开发视觉对照](../implementation/evidence/frontend-cr023/visual-check.json)。QA为Chromium1440/WebKit390，两种访客语言；认证后的实际账号偏好为中文，开发另外覆盖完整中英文。页面脚本错误0、QA截图/送模图片0、真实模型调用0。已核对实际字段与行为，不用页面存在或截图代替业务结果。

## 版本、复用与限制

287份前端源与13项变更、446份编译文件匹配开发交付；288份后端源未变。设计仍UI22，PRODUCT03/H01/DB03/BE03/FE02的无关规则保持；本轮用户允许的复习/书架直接登录在这两个入口优先于FE02旧AuthGate描述。旧34组前端与QA22三条集成证据仅按未受影响依赖复用，受影响认证/图标/消息/计划范围用本轮结果补充；不宣称重新通过全站所有UIA。

开发首次路由问题确有FAIL：地址改为login而SSR仍渲染旧卡；改为路由中间件后已修复，原失败保留。视觉对照发现的保存图标/关闭文字/日期差异也已补齐。实际安全Markdown按后端语义渲染，未复制原型简易解析器把段落吞进h2的行为。没有下调验收期望或改后端消除失败。

[当前清单](coverage-matrix.md)仍保留49 CAP/25 PAGE/28视图/119 UIA/31活跃DATA。最终用户UAT仍待本次修复复核，真实AI、生产代理/发布、真机/人工读屏、CR039-L1/CR042-L1/AI-QUALITY-90及历史W01不因此关闭。独立新会话交接未执行；token未知。

## 运行版交付

**http://127.0.0.1:3302** 已切换当前构建，刷新后复核四处；[账号及操作清单](uat.md)。后台/数据库进程与用户数据保留，只有前端进程替换；隔离开发服务已停止，[清理记录](evidence/qa2-023/cleanup.json)。当前QA22五份正文已归档，旧冻结证据保持。

CR023已由APPROVAL-M002-056限定关闭。QA24为当前本地mock修复，用户复核结果仍由用户给出，不填写整期完成。
