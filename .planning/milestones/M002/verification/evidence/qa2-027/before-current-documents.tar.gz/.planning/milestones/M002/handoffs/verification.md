---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: real_provider_manual_uat_ready
result: partial_model_availability
version: M002-QA-26
date: 2026-09-29
---

# 当前质量交付

M002 / verification / quality/base / qa-quinn。用户最新要求“切换为正式模型配置我测测看吧”，已切换http://127.0.0.1:3302直连OpenRouter供手工测试。**DeepSeek V4 Flash 0731、GLM可用；MiniMax两次启用校验失败，保持禁用。** 当前热门试用预设绑定MiniMax而不可生成，已明确告知用户；请从普通学习页选择两款可用模型。

当前[报告](../verification/report.md)、[操作清单](../verification/uat.md)、[配置核对](../verification/evidence/qa2-026/final-check.json)、[清单](../verification/evidence/qa2-026/manifest.json)。采用一期Docker实际运行的正式地址和加密凭据，仓库backend/.env是旧mock配置，不能作为恢复真源。凭据仅内存解密并通过M002后台重新加密，证据不含API key。原Docker数据只读，没有迁移。

前端CR024、现有账号/批次/消息和计划数值保留；原mock模型ID转为MiniMax以保留引用，另添加DeepSeek/GLM，并加入原mock所属计划；plus原无模型授权不改。只执行3模型启用加1次MiniMax复验；未代用户普通生成或开展自动质量批次。MiniMax确切原因未知，不扩大成AI调优任务；不得为了让页面可用绕过检查。

当前mock端口38084已停止，代理3302只转发，Go环境指向https://openrouter.ai/api/v1。只能用qa2-026/preview.py resume/stop恢复或停止；旧脚本会启动mock，不再使用。私有旧配置备份在当前运行目录real-provider-backup（0700/0600）。QA25/UI、QA24/mock的原有证据按相应范围保持，不能宣称真实AI通过。

下一步用户在/create手动生成并反馈；最终UAT、AI-QUALITY-90、CR039-L1/CR042-L1及历史W01保持未完成，真实批量评测仍未授权，发布未通过。无阶段或角色切换。旧QA25五份正文在qa2-026/before-current-documents.tar.gz，原失败均保留。新会话交接未执行，token unknown。
