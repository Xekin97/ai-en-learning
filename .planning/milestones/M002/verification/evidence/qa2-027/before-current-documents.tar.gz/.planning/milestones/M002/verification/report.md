---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: real_provider_manual_uat_ready
result: partial_model_availability
version: M002-QA-26
date: 2026-09-29
---

# 当前本地验收环境

**用户要求“切换为正式模型配置我测测看吧”，3302已切换直连OpenRouter，DeepSeek V4 Flash 0731与GLM可供用户真实生成。** MiniMax首次及一次复验均返回model_incompatible，保持禁用；既有热门预设绑定此模型，当前model_unavailable。先在普通“学习”页选择两款可用模型；未绕过启用校验或改写预设配置隐藏问题。

复用一期实际Docker运行配置和加密凭据；backend/.env中的6002属于旧mock地址，未采用。原数据库只读取模型和凭据，未迁移；凭据只在内存中解密，通过当前后台API重新加密保存。旧配置备份在运行目录私有0700/0600文件中，证据不含真实API key。[源检查](evidence/qa2-026/source-check.json)、[配置操作](evidence/qa2-026/configuration-result.json)、[MiniMax复验](evidence/qa2-026/minimax-retry.json)、[方法和边界](evidence/qa2-026/method-notes.json)。

实际执行3个模型启用检查，MiniMax另复验1次；没有代用户进行普通生成或批量质量评测。DeepSeek/GLM启用通过，MiniMax两次422，不能记为全部模型通过。精确失败原因未定位，不自动重开AI调优。模型目录/凭据检查与真实推理质量分开，用户此次授权不等于AI-QUALITY-90达标。

[运行核对](evidence/qa2-026/final-check.json)确认访客和普通账号均获得两款真实模型，真实浏览器选择器可见，计划数值/长度限制保留。当前前端CR024、用户数据与消息配置保留；只变更提供方、加密凭据、模型及原mock所属计划的模型授权。无模型授权的plus未改，历史批次快照未改。mock端口38084已停止，3302代理只转发。[运行记录](evidence/qa2-026/preview-start.json)和[恢复脚本](evidence/qa2-026/preview.py)用于后续接续，旧脚本不得恢复mock。

QA25两项、开发四项UI还原检查继续有效；QA24仅是历史mock结构测试，不作为此轮真实生成质量证据。旧QA25五份正文归档在qa2-026/before-current-documents.tar.gz，冻结证据与原失败保持。当前专业角色/verification阶段不变，最终用户UAT、真实模型稳定成功率及发布仍未通过。CR039-L1/CR042-L1/AI-QUALITY-90和历史W01保持，其他未验范围见[矩阵](coverage-matrix.md)和[AI范围](ai-evaluation.md)。
