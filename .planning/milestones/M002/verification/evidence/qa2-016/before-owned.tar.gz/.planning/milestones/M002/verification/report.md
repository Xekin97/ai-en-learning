---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: awaiting_user_review
result: fail_title_edit_icon_fidelity
version: M002-QA-15
date: 2026-09-28
---

# 继承与标题闭环验证

**CR001的29项一期继承接收核对通过，建议按原遗漏范围关闭。CR002标题业务与四宽度补验通过，但发现编辑标题按钮缺少批准铅笔图标，新增P3问题CR019/F16；CR002设计接收继续保留。** 本轮综合9项判定为8 PASS / 1 FAIL，不宣称整期或用户UAT通过。

## 基线与确认

沿[APPROVAL-M002-041](../reviews/verification-acceptance-041.md)继续verification/qa-quinn。PRODUCT03/UI22/H01/DB03/BE03/FE02有效；[CR001](../changes/M002-CR-001.md)仅处理完整继承及接收，[CR002](../changes/M002-CR-002.md)处理本人批次标题与预设单标题/去说明。[输入](evidence/qa2-015/inputs.json)冻结前端282/后端288源文件和444份生产构建；应用未改，未重建前后端或重跑开发单元/静态检查。

依据[AC220](../product/abilities.md#cap-220-编辑本人学习批次标题)、[标题UIA](../design/design-spec.md#继承的标题交互验收与来源)及API007，使用批准的360/390/768/1440宽度。标题技术上限沿[API007](../technical/api/identity-library.md)的title_max_length；没有新增业务字数限制。本机复习草稿、04:00、基础/体验分账、90天明细及USER-COMPAT-001/USER-CLAIM-DELETE-001保持，无新增待确认需求。

## 独立验证与证据接续

[综合判定](evidence/qa2-015/assessment.json)逐项指向原始PASS；[接续审计](evidence/qa2-015/audit.json)保留继承、标题验收和版本映射。

| 范围 | 结论 |
|---|---|
| CR001一期29项 | 完整产品逐项继承、替代关系、当前页面/AC与既有运行证据均有去向，原遗漏接收通过；不把该审计算成29项新运行或全量UI通过 |
| CR002已有业务证据 | QA01本人标题/纯文本/权限/草稿，QA05管理员只读，QA07/08书架，QA09默认值/发布/预设展示，QA12重新登录/切语言/旧与暂停批次/同源隔离保持；19份历史证据摘要核对，当前源码变化仅已验的标题/日期及测试4文件 |
| UI15两语言×四宽度，8项 | 短标题及接口允许的最长标题可读，无横向溢出；原型与生产字体、行高、换行、手机编辑按钮位置一致。编辑区准确文案与顺序、保存/取消、Enter保存、刷新持久、正文/配置/参与/保存时间和另一批次不变均通过 |
| 键盘与区域axe | Chromium使用Tab；当前macOS WebKit默认Tab跳过按钮，原型/生产一致，Option+Tab均到保存/取消并可Enter执行。有效8项包含32次标题/表单区域axe扫描，0违规；不代替人工读屏或真机 |
| 复习隐藏标题 | 四个WebKit代表样本覆盖普通与暂停预设批次、中英文、390/1440；真实进入复习后，单词页/概览的可见文字、aria及会话API均不含自定义标题 |
| I01视觉对照 | FAIL / F16：批准按钮含pencil SVG，生产按钮只有文字，来源为UIA-PAGE-006-ICON10；记录为CR019，不影响上述业务通过结论 |

CR017/018及FE2-R16-W1已沿041限定关闭，CR016沿039关闭，历史结果不改写。UIA006-02/03/04在声明的功能/布局范围通过，ICON10的标题入口仍失败；CAP220业务断言通过，完整设计接收保持PARTIAL。

## 确认缺陷

[CR019](../changes/CR-019.md)，P3，交frontend-claire补齐既有pencil图标。准确期望、生产位置及[同条件截图比较](evidence/qa2-015/visual-check.json)均已记录；该图标在现有AppIcon中可用。复验限定为双语桌面/手机图标、点击及可访问名称/布局和编辑入口，不要求重跑所有业务测试，也不新增设计选择。

## 原始失败与方法修正

所有原始结果保留：[修正记录](evidence/qa2-015/corrections.json)。首次8项因长样本超出已批准技术上限，被客户端正常拒绝；control改用接口返回的最大code points后Chromium4项通过，WebKit4项停在普通Tab假设。keyboard-control证明Option+Tab可操作，但错误要求编辑器外的焦点节点也与含演示面板的原型相同；原型落在演示SUMMARY，产品落在BODY。confirmed-control改按编辑器范围检查，1440双语通过，390的补充复习检查又误把预设第一词固定为五个字母（实际四个）。final-control仅重跑这两个受影响样本，按首输入可见判定就绪后通过。另有一次端口TIME_WAIT探针失败，未启动服务或测试，记录在control/preflight.json。

最终8项有效判定来自control的4项Chromium、confirmed-control的2项WebKit1440和final-control的2项WebKit390；没有将失败轮次改写成全通过。图标缺失由最终截图与批准源对照发现，自动布局/axe通过不能代替视觉还原。

## 环境与保护

所有运行均复制原可丢弃数据库为新克隆，只在克隆中修改合成标题/开始复习，结束删除克隆并停服；五轮执行记录位于各目录execution.json。本地/真实AI均0，复用已核对的后端二进制及前端构建。[复现说明](evidence/qa2-015/README.md)记录依赖和有效证据选择。

仅修改五份QA正文、新建QA15证据及CR019；QA14五份原稿存[before-owned](evidence/qa2-015/before-owned.tar.gz)，原QA14其余38份artifact及全部旧失败保持。源码、设计、批准上游和控制面不变。[最终检查](evidence/qa2-015/finalization.json)与[manifest](evidence/qa2-015/manifest.json)记录保护、链接、服务与静态大小；新会话交接实验未执行，input/token unknown。

## 下一步与限制

建议守门按原继承遗漏范围关闭CR001，登记CR019并激活frontend-claire作限定修复；CR002保持开放等待设计接收。修复后只复验I01相关范围，已通过业务证据沿版本接续。QA不自行关闭问题或切换角色。

[矩阵](coverage-matrix.md)保持49 CAP/25 PAGE/28视图/119 UIA，其他未完成项不扩大、不取消。CR039-L1、CR042-L1、AI-QUALITY-90、历史未定位W01、生产代理/真机/人工读屏/04:00实际跨日及[最终UAT](uat.md)保持原状态；无发布、提交或里程碑完成结论。
