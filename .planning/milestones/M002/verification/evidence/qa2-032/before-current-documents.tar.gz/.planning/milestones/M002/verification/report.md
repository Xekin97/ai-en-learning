---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: scoped_qa_passed
version: M002-QA-31
date: 2026-10-01
---

# 当前验收结果

CR026“只提醒一次”已实现并限定通过。用户明确选择同一浏览器按账号分别记录，D2-88-LOCAL-SCOPE已解决；后台逐消息开关默认关，用户端仅实际自动展示的当前正文记入账号+消息本地记录。未展示条目、手动阅读和后台预览不计，当前队列能往返；再登录排除已显示一次消息，A/B独立，退出保留、清缓存可重现，存储不可用降级不阻断登录。

[最终开发交付](../implementation/evidence/notice-once/manifest-final.json)、[开发范围](../implementation/frontend-validation.md#once28)、[输入与预算](evidence/qa2-031/reception.json)、[修复后接收](evidence/qa2-031/reception-final.json)。302前端源和5项后端源摘要匹配，复用39前端单测、4服务层测试、5项后端请求子用例、4浏览器场景+1欢迎/翻页回归。原型2场景及两张实现局部图已检查，后台开关顺序与说明层级一致，390英文换行无溢出。不是重跑全站或真机读屏。

[QA31真实HTTP](evidence/qa2-031/results-final.json)通过：临时真实API与隔离数据库，管理员创建/修改/重新读取、用户投影含remind_once、安全Markdown、提醒关闭仍可手动读、隐藏404、访客401/学习者管理403、revision冲突409、缺省false均验证；0 provider调用。没有把浏览器契约替身称为真实后端UI贯通；真实协议/持久化与浏览器状态分别有证据。

首次HTTP发现F01：缺失新字段返回422；通用校验误将它作为required。沿088改成请求DTO可省略新字段，保留其他必填与类型校验，输出固定boolean；沿089在相同HTTP用例复验通过。原[失败](evidence/qa2-031/initial-http.log)和[方法说明](evidence/qa2-031/method-notes.json)保留，没有改期望。预算1个质量用例/0新截图，因实际失败定向重跑一次，不扩测。

交控制层限定关闭CR026。3311前端及本地契约服务已更新，后台保存的通知设置可在该预览的用户消息中读取；fixture正文按安全文本展示，正式Markdown由已验证后端渲染。3302真实模型入口/数据库未更改；其后续更新必须先应用0014再启新后端。原五项遗留和发布/人工边界继续保留，新UI用户UAT未代签，M002不在本次宣布完成。

[覆盖矩阵](coverage-matrix.md#qa31)、[QA绑定](evidence/qa2-031/manifest.json)；旧QA30当前文档在[快照](evidence/qa2-031/before-current-documents.tar.gz)，CR025/027/028限定关闭及其证据保持。

## 保留事项

| ID / 范围 | 现有结论与影响 | 来源、后续动作与完成条件 |
|---|---|---|
| QA26-MINIMAX | 两次启用校验返回 model_incompatible，保持禁用；当时绑定该模型的热门预设不能生成。原因未定位，本轮未重新查询运行状态 | [原失败](evidence/qa2-026/minimax-retry.json)、[配置核对](evidence/qa2-026/final-check.json)。需要恢复该模型时从既有失败定向排查；启用检查与关联预设实际生成通过后才能认定解决 |
| CR039-L1 | safe→safety/safely 被拒，safer 未核实 | [原约束与验收](../../M001/changes/CR-039.md#retained-limitations)。后续明确恢复词形改进时按原样本核验，不自动重启调优 |
| CR042-L1 | 未知标注反馈定位精度、多回复整包回放仍有限制 | [原约束与验收](../../M001/verification/CR-042-generation-evidence.md#retained-limitations)。按实际失败定向处理，未扩展回放平台 |
| AI-QUALITY-90 | 稳定成功率 ≥90% 仍未验证 | [AI 验证范围](ai-evaluation.md)、[一期评估](../../M001/verification/ai-evaluation.md)。需单独明确评测范围与调用授权；本次 UAT 不提供统计证明 |
| W01 | 个人页曾出现未定位的 hydration console 警告，后续定向捕获未复现；未据此宣称修复 | [QA03 原观察](evidence/qa2-003/manifest.json)。再次出现时记录具体页面、堆栈和操作，定位并定向复验 |
| 环境与人工专项 | 生产 SSE 代理、Linux 部署与容量/告警、真实设备输入法/读屏、04:00 实时时点等仍按矩阵保留证据边界 | [矩阵](coverage-matrix.md#api数据与剩余工作)。属于后续对应环境验证；用户整体 UAT 不补写未执行的专项测试 |



原保留项不因本轮修复而消失；开放CR和角色以workflow为准。未执行新会话交接测试，token unknown。
