---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: verification_in_progress
result: fail
version: M002-QA-20
date: 2026-09-28
---

# 前端复验与剩余交互

**32组有效测试，30 PASS / 2 FAIL。CR021三项修复均通过；新增CR022一项已批准交互遗漏。** 19类页面×中英×320/390/768/1440，共152次正常态访问。复用frontend-cr021生产构建，无应用改动、重建或重跑开发单元检查。

- [root 22组](evidence/qa2-020/results.json)：领奖成功后成就回组summary、等级回对应h3；WebKit选择器46px；768英文大额积分完整换行，无页面横溢。普通台默认、可操作选择、随机及语言切换保留，详情设置快照和四宽度页面检查通过。
- [extra](evidence/qa2-020/extra/results.json)：中英六组欢迎场景通过，包括当日/从未学习/距上次5天、字面昵称、完整10秒、动态减少动效，以及普通保存反馈替换旧欢迎动画。两组精选8秒自动、阅读暂停、语言切换保持暂停、减少动效手动操作、浏览不生成通过，但离开再入丢失释义筛选，归[CR022](../changes/CR-022.md)。
- [资料两组](evidence/qa2-020/profile-control/results.json)：语言切换保留未保存资料、空昵称回退账号名、取消改密后清空临时密码通过。原exact-label定位未命中包装label，已修正测试选择器，保留[方法说明](evidence/qa2-020/corrections.json)与原记录，不作为产品缺陷。

[判定](evidence/qa2-020/assessment.json)、[输入与构建绑定](evidence/qa2-020/inputs.json)、[manifest](evidence/qa2-020/manifest.json)。所有本地服务已停止；真实模型调用0，没有新增真实后端结算结论。历史证据按版本继承。

CR021可限定关闭；按持续授权立即转前端修复CR022再独立复验，不重复请用户批准。整期/UAT未完成，49 CAP/25 PAGE/28视图/119 UIA仍完整追踪。真实设备、人工读屏、生产部署及一期遗留保持原边界。
