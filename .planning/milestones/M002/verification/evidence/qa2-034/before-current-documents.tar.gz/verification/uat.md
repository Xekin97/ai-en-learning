---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: ready_for_user_acceptance
version: M002-QA-33
scope: CR029 generic model configuration
date: 2026-10-01
---

# CR029 用户验收入口

本轮由代理完成开发和QA，用户尚未确认新功能验收。入口：[http://127.0.0.1:3302/admin/models](http://127.0.0.1:3302/admin/models)，沿用原账号。

可直接查看统一模型列表，新增/编辑服务商、模型ID、API协议、地址和Key，保存不会自动调用模型；需要验证真实连接时由管理员点击“测试连接”。普通造文不设默认模型，预设保持自己的固定模型。原模型和密钥已迁移，不必重新录入。

本轮三协议通信由受控HTTP验证，未消费真实模型额度。真实服务商账号支持情况、实际输出能力仍须使用相应连接确认，不把“连接测试通过”当成学习质量证明。

上一轮091的“验证通过”属于消息/选词等已验收范围，保持历史有效；原文完整保存在[QA32快照](evidence/qa2-033/before-current-documents.tar.gz)。CR029当前等待本次用户反馈，产品待决项为空。
