---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: awaiting_user_review
result: fail_frontend_title_error_handling
version: M002-QA-12
date: 2026-09-28
---

# 标题功能独立验证

**环境限制已解除，四组补测已执行；确认2处前端异常处理缺陷，合并提交CR016。** 登录/语言保持、新旧及暂停批次编辑、同源隔离、失败不误写和删除/鉴权边界已有直接证据；保存失败焦点恢复和会话失效收尾仍须修正。未批准整期质量或最终UAT。

## 来源与版本

用户2026-09-28明确要求将产品目录设为可写并允许本地测试服务；实际监听与写入均恢复。APPROVAL-M002-036仍授权qa-quinn继续verification，不包含自动角色切换。基线为PRODUCT03、UI22/H01、DB03/BE03/FE02，前端280/后端288源文件及既有生产构建匹配[输入摘要](evidence/qa2-012/prepared/inputs.json)。未改应用、上游批准、控制面或重跑开发单元/lint/类型/前端构建。

验收来源为[AC218/220](../product/abilities.md)、[UIA-PAGE-006-03及标题交互](../design/design-spec.md#继承的标题交互验收与来源)、[API007](../technical/api/identity-library.md)。北京时间04:00、本机草稿、基础/体验分账、90天分析及既有删除例外保持。具体源码位置、复现和修正边界集中在[CR016](../changes/CR-016.md)。

## 四组补测结论

| 组 | 已通过的直接断言 | 当前结果 |
| --- | --- | --- |
| T1 取消/空白/普通失败/重试 | 取消及空白不发写请求；一次503保留输入与原值；显式重试只存一次 | **FAIL · F12**：批准设计要求失败后焦点回输入，实际落在BODY |
| T2 登录与语言 | UI重新登录、中英文切换/刷新保持私人标题；后台一个标题和值，无description，保存草稿不改发布内容 | PASS，限定上述标题行为 |
| T3 新旧/暂停/同源隔离 | 一期结构真实插入后迁移，随后浏览器编辑成功；暂停批次可改名，非标题字段、参与状态、同源另一批次及公开预设不变 | PASS，代表样本；不宣称其他版本兼容或穷举组合 |
| T4 删除/会话失效 | 删除后404、不复活；会话失效后401、不误写、不显示成功并出现登录引导 | **FAIL · F13**：页面仍访问已清空批次的titleRevision，控制台TypeError |

[综合判定](evidence/qa2-012/assessment.json)、[第二轮完整结果](evidence/qa2-012/run2/results.json)、[两项定向复现](evidence/qa2-012/control-valid/results.json)。F12影响键盘继续输入，F13是身份失效后的客户端错误；没有数据损坏、泄漏或越权写入证据。两项为P2，同属标题保存收尾，建议一起由frontend-claire修复。

## 原始失败与脚本限制

[初轮](evidence/qa2-012/initial/results.json)四个失败来自未运行脚本的假设：把opaque revision转数字、语言控件定位为不存在的select、对异步受控checkbox使用同步uncheck、DELETE缺JSON请求。已保留原件并仅修正QA脚本，没有以产品修改迁就测试。

[run2](evidence/qa2-012/run2/results.json)原脚本报四PASS/exit0，但只过滤pageerror，漏判Vue记录到console.error的真实TypeError。QA读取完整日志后拒绝该整体通过结论；[控制轮](evidence/qa2-012/control-valid/tests.log)再次复现TypeError，并按既有UIA核对失败焦点，两项均FAIL。原始PASS和FAIL均原样保留，不改写历史结果。最初注入的503响应体不完整，会归为协议错误；追加control-valid使用契约完整的Problem响应，焦点问题仍复现，会话异常也再现。两个控制轮均零模型调用，普通服务端失败结论以control-valid为准。

两轮夹具各调用本地provider6次，控制轮0次，共12次本地/0次真实AI。自建前端、后端与隔离数据库均已停止，见[清理记录](evidence/qa2-012/control-valid/execution.json)。响应/界面/数据库断言不替代完整响应式、读屏、生产部署或真实AI质量检查。

## 一期继承与CR001/002

QA11原证据已落回产品：[29项继承/10组标题历史审计](evidence/qa2-011/audit.json)、[源码连续性](evidence/qa2-011/title-source-continuity.json)。完整QA11暂存稿可从[归档](evidence/qa2-012/prepared-qa11-delivery.tar.gz)恢复，不保留过期的环境阻塞作为当前结论。

CR001所指的完整继承基线与曾遗漏的登录注册、个人复习库、日期复习及核心后台流程已有有效映射和运行证据，可提交原问题范围的限定关闭建议；不等于全部UIA通过。CR002已有保存、冲突、转义、草稿、管理员只读、默认值及预设发布证据，本轮补齐T2/T3等缺口，但F12/F13仍阻止关闭建议。

CR001/002正式仍open；新CR016待守门登记及前端激活。CR014/015沿036、CR012/013沿034及其余限定关闭不变。W01仍是历史未定位hydration观察，原定向控制未复现，不将其升级为当前确定性缺陷；CR039-L1、CR042-L1、AI-QUALITY-90继续保留。

## 保护与下一动作

当前[矩阵](coverage-matrix.md)保持49 CAP/25 PAGE/28视图/119 UIA，CAP220和相关UIA明确标记失败；无关覆盖不升为PASS。QA10五份原文保存在[before-owned](evidence/qa2-012/before-owned.tar.gz)，QA11审计原件保留。新增QA证据、CR016和五份当前质量正文属于本轮唯一写入范围；具体保护与摘要见[manifest](evidence/qa2-012/manifest.json)。

下一步建议由守门器将CR016交给frontend-claire，在现有标题保存路径修正两项并提供相关回归证据，再由qa-quinn独立复验。QA不自行修实现或切换角色。最终[UAT](uat.md)未执行，真实模型批测未授权，没有提交、部署、付费AI、委派或运行时换模。输入token未知；本轮默认交接结构保持，新会话交接实验未执行。
