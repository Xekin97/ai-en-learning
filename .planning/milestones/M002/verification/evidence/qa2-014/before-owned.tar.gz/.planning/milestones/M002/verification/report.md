---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: awaiting_user_review
result: fail_detail_hydration_and_failure_copy
version: M002-QA-13
date: 2026-09-28
---

# 标题修复与日期水合独立验证

**CR016原两处缺陷已独立复验通过，可提交限定关闭；另确认两项前端偏差：英文日期水合警告CR017、普通标题失败文案CR018。** 当前综合13项检查10 PASS / 3 FAIL，其中两项语言用例属于同一文案问题。整期仍未通过，最终UAT未执行。

## 来源、版本与范围

授权TRANSITION-M002-038，当前verification/qa-quinn。PRODUCT03、UI22/H01、DB03/BE03/FE02与API007保持；[输入](evidence/qa2-013/inputs.json)核对前端281/后端288源文件及交付生产构建。沿[AC218/220](../product/abilities.md)、[标题交互UIA006-02/03](../design/design-spec.md#继承的标题交互验收与来源)、[FE02 §11](../technical/frontend.md#quality)执行。§11明确已有“无hydrate警告”检查，未新增验收门槛。

本轮仅复验CR016及相关标题行为、确认FE2-R16-W1，并逐字核对同一失败态的已批准文案。不改应用/设计/契约/控制面，不重跑已通过的开发单元、lint、格式、类型或构建。北京时间04:00、本机草稿、基础/体验分账、90天明细及USER-COMPAT-001、USER-CLAIM-DELETE-001保持。

## 有效结果

[综合判定](evidence/qa2-013/assessment.json)合并run中有效R/C检查与独立date-control结果；[原完整运行](evidence/qa2-013/run/results.json)和[日期控制](evidence/qa2-013/date-control/results.json)分别保留。

| 检查 | 当前结果与范围 |
| --- | --- |
| R01 × Chromium英文1440 / WebKit中文390 | PASS：保存等待控件禁用；契约503保留输入/数据库、解除禁用回焦，可直接键入并Enter显式重试；只两次PATCH，非标题字段不变 |
| R02 × 同两组 | PASS：取消/空白不写；真实并发revision导致409，保留本地输入与最新已存值，显式重试成功 |
| R03 × 同两组 | PASS：撤销真实会话后安全转登录引导，bootstrap确认失效后未发标题PATCH，直接写401，无假成功/误写/console异常；UI重新登录仍见原标题 |
| R04 × Chromium英文 | PASS：编辑时删除，随后保存404、不复活，刷新后不可用 |
| C01 × 中英文 | FAIL · F15 / CR018：普通失败实际使用通用failed，未采用UI22的l.title.failed；保存/回焦/重试行为均正常 |
| H01 WebKit英文 | FAIL · F14 / CR017：直接访问及硬刷新两次SSR逗号/客户端at差异，均有hydration控制台错误；编辑/取消可用，数据库不变 |
| H02 Chromium英文 / H03 WebKit中文 / H04 Firefox英文 | PASS：SSR/DOM日期文本一致，console/pageerror无异常 |

CR016 F12/F13的7项相关独立检查通过，正式状态仍OPEN，等待守门按范围关闭。没有因其他两个问题重判原修复失败。

## 发现与路由

| ID | 级别、归属 | 依据、影响与动作 |
| --- | --- | --- |
| QA2-F14 / CR017 / FE2-R16-W1 | P2，implementation/frontend-implementer | FE02 §11及FE2-V02/14/17。日期语义相同，但WebKit英文SSR与水合格式不一致，console.error可稳定复现。交前端保持首帧一致；修改共享入口时按实际影响回归 |
| QA2-F15 / CR018 | P3，implementation/frontend-implementer | UIA006-02/03/COPY09、FE2-V13及原型save-error。中英文固定提示不符批准l.title.failed；仅需对齐既有文案，保留正常的失败/重试处理 |

[CR017完整复现](../changes/CR-017.md)、[CR018逐字期望/实际](../changes/CR-018.md)。日期差异的修改前复现沿匹配的开发证据记录，本轮独立确认当前构建；不把它直接等同历史个人页W01。QA不指定新业务日期格式、修改04:00规则或自行改共享实现。

原型已在英文1440/中文390实际运行save-error并检查固定文案和焦点，见[原型记录](evidence/qa2-013/prototype-check.json)。R01记录内容顺序和无横向溢出；已人工查看手机原型/实现，正文数据不同不作整页像素等同比较。这是局部设计还原检查，未宣称完整UIA或真机读屏通过。

## 原失败、测量限制与保护

首轮run记录8 PASS / 5 FAIL：H02/H04额外失败因innerText包含CSS大写，错误地与SSR原文本作比较。date-control改用实际DOM textContent，并保留CSS可见值、语言、直接URL/硬刷新及完整console证据；只重跑四项受测量影响的日期检查，WebKit英文仍FAIL。原结果不覆盖，不以忽略hydration或大小写归一化换取通过。

补充澄清QA12 control-valid：当时完整Problem正文仍配application/json响应头，不能作为service_unavailable映射通过证据。其失败焦点/会话TypeError原事实保留；QA13 R01已使用完整Problem及application/problem+json，并断言实际service_unavailable提示。首轮C01失败截图取自延迟比较时的后续页面，正确错误态截图是同轮R01 ordinary-failure，问题单仅引用后者。

本轮仅1次本地provider创建可删除合成短文，真实AI0；date-control/原型0调用。自建服务全部停止，见[run停服](evidence/qa2-013/run/execution.json)、[日期停服](evidence/qa2-013/date-control/execution.json)。已批准前端324项单元等结果按匹配版本复用，没有机械重跑。

唯一现有写入为五份QA正文；新建QA13证据和CR017/018。QA12五份旧正文保存于[before-owned](evidence/qa2-013/before-owned.tar.gz)，原QA12 manifest及CR016保持原件。源码/构建/7125份受保护文件和相对链接检查见[最终记录](evidence/qa2-013/finalization.json)、[manifest](evidence/qa2-013/manifest.json)。静态核对不冒充新会话交接实验，后者未执行；input/token unknown。

## 继承、遗留与下一动作

[矩阵](coverage-matrix.md)仍为49 CAP/25 PAGE/28视图/119 UIA，不因局部通过将整项升为PASS。QA12 T2/T3登录/语言、新旧/暂停批次/同源隔离证据及QA11的29项继承审计继续有效；CR001原遗漏范围可提交限定关闭建议，正式仍open。CR002业务标题边界补齐，CR018固定文案仍待处理，不提交其整体关闭。

建议下一步通过守门将CR016按F12/F13限定关闭，同时登记CR017/018并转frontend-claire一并修复；FE2-R16-W1由CR017继续追踪。CR014/015沿036、CR012/013沿034及其他历史关闭保持。CR039-L1、CR042-L1、AI-QUALITY-90、历史W01、剩余覆盖与[最终UAT](uat.md)未执行保持。无角色切换、提交、部署、真实AI批测或里程碑完成声明。
