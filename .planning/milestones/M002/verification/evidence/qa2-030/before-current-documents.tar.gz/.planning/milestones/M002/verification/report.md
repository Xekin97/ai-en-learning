---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: scoped_qa_passed
result: ui26_header_correction_passed
version: M002-QA-29
date: 2026-10-01
---

# 当前验收结果

用户指出“header里的翻译下拉选择没有跟设计稿同步”，事实成立。QA28遗漏实际页头消费点：LocaleSwitch已改，但AppHeader和admin布局仍用旧切换按钮。CR025仅重开UIA-GLOBAL-SELECT23页头范围；原QA28结论在该点作出纠正，其他证据和失败原件保留。

本轮修复及限定QA通过。两个页头现已接入UI26中文/EN下拉，复用批准样式与既有语言控制器。[开发验证](../implementation/frontend-validation.md#ui26)、[当前源清单](../implementation/evidence/frontend-header-locale/source.json)。核对298源及交付摘要后复用18场景（双引擎、三身份、三宽度、与运行原型样式比较、操作和偏好保存）及2语言回归；不重跑开发类型/lint/构建。[QA29接收](evidence/qa2-029/reception.json)。

[QA29-H01通过](evidence/qa2-029/results.json)：切换语言后，后台计划表单未保存的17仍保留、路由保持/admin/plans、只有语言偏好PUT，没有计划写入。最终原型/实现局部图人工比对通过；关闭箭头过渡中的初次截图保留，静态截图完成过渡后比较，交互操作未跳过。真机读屏/输入法仍未验证。

[覆盖矩阵](coverage-matrix.md#qa29)已纠正旧盘点解释：19个AppSelect模板定义并不等于全部实际入口已接入；新增2个页头消费接入证明。按常设QA授权交守门器限定重新关闭CR025，不需重复修复/QA审批。CR026缓存账号隔离问题、新增范围用户UAT和旧限制仍保留，不宣布里程碑再次完成。

当前预览 http://127.0.0.1:3311 已更新，使用契约测试数据；3302正式模型环境未动。其余UI26功能沿QA28已验来源及[UI26交付](../implementation/evidence/frontend-ui26/manifest.json)复用，后端CR027保持关闭。旧QA28主文档见[快照](evidence/qa2-029/before-current-documents.tar.gz)，本轮[manifest](evidence/qa2-029/manifest.json)绑定准确版本。

## 保留事项

| ID / 范围 | 现有结论与影响 | 来源、后续动作与完成条件 |
|---|---|---|
| QA26-MINIMAX | 两次启用校验返回 model_incompatible，保持禁用；当时绑定该模型的热门预设不能生成。原因未定位，本轮未重新查询运行状态 | [原失败](evidence/qa2-026/minimax-retry.json)、[配置核对](evidence/qa2-026/final-check.json)。需要恢复该模型时从既有失败定向排查；启用检查与关联预设实际生成通过后才能认定解决 |
| CR039-L1 | safe→safety/safely 被拒，safer 未核实 | [原约束与验收](../../M001/changes/CR-039.md#retained-limitations)。后续明确恢复词形改进时按原样本核验，不自动重启调优 |
| CR042-L1 | 未知标注反馈定位精度、多回复整包回放仍有限制 | [原约束与验收](../../M001/verification/CR-042-generation-evidence.md#retained-limitations)。按实际失败定向处理，未扩展回放平台 |
| AI-QUALITY-90 | 稳定成功率 ≥90% 仍未验证 | [AI 验证范围](ai-evaluation.md)、[一期评估](../../M001/verification/ai-evaluation.md)。需单独明确评测范围与调用授权；本次 UAT 不提供统计证明 |
| W01 | 个人页曾出现未定位的 hydration console 警告，后续定向捕获未复现；未据此宣称修复 | [QA03 原观察](evidence/qa2-003/manifest.json)。再次出现时记录具体页面、堆栈和操作，定位并定向复验 |
| 环境与人工专项 | 生产 SSE 代理、Linux 部署与容量/告警、真实设备输入法/读屏、04:00 实时时点等仍按矩阵保留证据边界 | [矩阵](coverage-matrix.md#api数据与剩余工作)。属于后续对应环境验证；用户整体 UAT 不补写未执行的专项测试 |



原保留项不因本轮修复而消失；开放CR和角色以workflow为准。未执行新会话交接测试，token unknown。
