---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: awaiting_user_review
result: scoped_retest_pass_remaining_verification
version: M002-QA-14
date: 2026-09-28
---

# 日期与标题文案修复独立验证

**CR017/F14日期水合、CR018/F15标题失败文案均独立复验通过，建议按原缺陷范围关闭；21项检查全部通过。** 当前仍为verification/qa-quinn，CR017/018正式状态待守门处理。整期覆盖尚未完成，最终UAT未执行。

## 基线与范围

[TRANSITION-M002-040](../reviews/verification-reentry-040.md)授权本轮复验，PRODUCT03/UI22/H01/DB03/BE03/FE02保持。[输入记录](evidence/qa2-014/inputs.json)核对前端282/后端288源文件、开发交付及444份前端构建文件。沿[AC218/220](../product/abilities.md)、[UIA006-02/03](../design/design-spec.md#继承的标题交互验收与来源)、COPY09和[FE02 §11](../technical/frontend.md#quality)检查，没有新增产品条件。

范围为两项缺陷、既有标题失败保护及共享dateTime调用的代表页面。复用匹配版本的开发333项单元、类型、lint、格式、边界和前端构建证据；没有机械重跑。为运行真实API仅编译隔离的后端服务，源码不变。北京时间04:00、本机复习草稿、基础/体验分账、90天明细、USER-COMPAT-001及USER-CLAIM-DELETE-001保持。

## 独立结果

[综合判定](evidence/qa2-014/assessment.json)、[核心13项](evidence/qa2-014/run/results.json)、[共享页面8项](evidence/qa2-014/run/shared-results.json)保存断言、SSR/DOM文本、请求、响应、控制台及截图；数量不重复计算内嵌边界样本。

| 检查 | 结果与范围 |
|---|---|
| H01–04，4项 | WebKit英文/中文、Chromium英文、Firefox英文直接访问及硬刷新，SSR与DOM textContent一致，无hydration警告或页面异常；编辑/取消仍可用，批次记录不变 |
| H01/H03内嵌日期边界 | 浏览器设为洛杉矶，仍按北京时间显示；跨年午夜分别为Jan 1, 2027, 12:00 AM / 2027年1月1日 00:00，中午为12:00 PM / 12:00。恢复原saved_at并核对记录摘要。这是显示验证，不冒充04:00结算实时时点验证 |
| C01，2项 | 英文1440和中文390的普通503失败，分别逐字匹配已批准l.title.failed，输入保留；CR018/F15通过 |
| R01–04，7项 | 契约503回焦、直接键入和Enter重试；取消/空白零写入、实际409保留输入与最新标题、会话失效禁止PATCH、直接写401及UI重新登录、删除404不复活。原CR016/F12/F13修复无回归 |
| shared，8项 | WebKit中英文分别检查个人信息、道具卡到期、平台消息时间、后台用户详情；SSR与客户端文本一致，语言正确、无异常。已验证未来卡午夜到期及消息14:46显示 |

中文固定提示为“标题未保存，请重试。你的输入已保留。”；英文为“Title was not saved. Your text is still here; please try again.”。来源仍是UI22 learning.js和copy.json；沿用QA13匹配原型的实际运行证据，本轮重新读取批准源逐字断言。人工查看手机失败态、英文详情和中文卡片截图，目标文案、焦点和日期均可读。未把局部检查扩大为全页设计或真机验收。

## 证据与环境

仅在从原可丢弃测试库复制的新库运行；预先检查成长已激活及等级/签到配置存在，再显式建立QA14合成通知和未来到期卡。没有修改开发测试库，没有绕过已发行道具定义的数据库保护；结束后删除整个QA14克隆库。[执行记录](evidence/qa2-014/run/execution.json)确认数据库移除及服务停止。

核心控制台5条均为相应请求故意触发的503/409/404 HTTP错误，按用例、URL、状态精确核对；日期及共享页面无警告/异常，没有过滤hydration。核心仅1次固定本地provider用于删除样本，共享检查0次，真实AI0次。脚本和复现限制见[README](evidence/qa2-014/README.md)。

原QA13五份正文存于[before-owned](evidence/qa2-014/before-owned.tar.gz)，QA13失败、测量修正、原型、manifest及CR017/018原文保持不可变。CR018首次逐字偏差和本轮修复复验分别可追溯；开发阶段失败亦未覆盖。本轮只改五份QA正文及新增QA14证据，应用、设计、上游、开发文档和控制面不变。[最终核对](evidence/qa2-014/finalization.json)与[manifest](evidence/qa2-014/manifest.json)记录源文件、旧证据、链接及文档大小；新会话交接实验未执行，input/token unknown。

## 关闭建议与保留范围

建议守门将[CR017](../changes/CR-017.md)仅按F14日期水合及相关共享格式回归关闭，并同步处理其关联FE2-R16-W1；将[CR018](../changes/CR-018.md)仅按F15普通失败中英文文案关闭。QA不修改CR原件或工作流。CR016已沿039按F12/F13关闭；CR014/015沿036、CR012/013沿034和其他历史关闭保持。

[矩阵](coverage-matrix.md)仍为49 CAP/25 PAGE/28视图/119 UIA。CAP220由已确认文案失败恢复PARTIAL，不代表所有标题UIA完成。CR001原继承遗漏的限定关闭建议保持，CR002尚待整体覆盖判断；此次不自动关闭二者。QA11的29项继承审计、QA12登录/语言/新旧及暂停批次/同源隔离均保留。

下一步由守门登记两项限定关闭后，继续矩阵中尚未完成的验证。CR039-L1、CR042-L1、AI-QUALITY-90、历史个人页W01、生产代理、真机/人工读屏、04:00实际跨日及[用户UAT](uat.md)仍保持原状态。当前个人页样本通过不等于已定位或关闭历史W01。无部署、提交、真实AI批测或里程碑完成声明。
