---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: verification_in_progress
result: scoped_pass
version: M002-QA-18
date: 2026-09-28
---

# 前端菜单修复独立复验

**CR020 / QA2-F17 定向复验 4 PASS / 0 FAIL，可按持续授权限定关闭。** 点击外部、焦点移出、Escape返回头像，以及进入四个个人页面后的标题焦点均通过。本轮未发现新问题；整期仍在验证，正式UAT未执行。

## 用户授权与输入

用户先明确“前端相关实现问题一律批准”，本轮补充“前端交付的 QA 也都批准”。前端交付的QA执行、复验、发现问题后的修复交接，以及通过证据支持的限定关闭无需逐项再询问；实际结果仍由证据判断。持续授权不伪造用户实测结果，也不改变已批准产品范围。

当前验证入口为[046](../reviews/verification-reentry-046.md)，前端交付见[frontend-cr020](../implementation/evidence/frontend-cr020/manifest.json)。[inputs](evidence/qa2-018/inputs.json)逐份确认283前端、288后端源文件、62前端/31后端交付文件和QA17的85项证据；复用444文件的生产构建。没有重建、重跑开发单元/lint/type/format或修改应用。

PRODUCT03/UI22/H01/DB03/BE03/FE02不变。期望来自[已批准导航交互](../design/interactions.md#全局导航与个人中心--page-205206214215217)和[CR020](../changes/CR-020.md)，无新增产品假设。

## 实际运行

| 场景 | 结果 | 已验证行为 |
|---|---|---|
| N18-zh-320 / N18-en-320，WebKit | 2 PASS | 手机中文/英文，真实鼠标外部点击、Alt+Tab移出、Escape与四个目的页 |
| N18-zh-1440 / N18-en-1440，Chromium | 2 PASS | 桌面中文/英文，真实鼠标外部点击、Tab移出、Escape与四个目的页 |

四项共88条断言，生产Nuxt与批准原型同条件对照：[原始结果](evidence/qa2-018/results.json)、[有效判定](evidence/qa2-018/assessment.json)。Enter/Space展开关闭、四项文案和顺序保持；Escape关闭后回到头像；外部点击和焦点离开均关闭；个人信息、账号成长、道具卡、兑换中心各自标题接收焦点，当前项唯一，重复选择个人信息也正确；无横向溢出。浏览器warning/error/pageerror均0。

采用QA17已校正的独立方法；WebKit以本机Alt+Tab访问链接，两侧一致，未强制点击遮挡元素。此次全部结果首轮通过，没有放宽验收条件。截图抽看见[visual-check](evidence/qa2-018/visual-check.json)，不以静态截图代替焦点断言。

运行使用现有契约mock验证前端交互；没有新增真实Go/DB、AI质量、人工读屏或真实设备结论。[runtime](evidence/qa2-018/runtime.json)确认四个自建服务已停止，端口释放，provider调用0。

## 证据接续与剩余范围

[continuity](evidence/qa2-018/continuity.json)确认批准设计源未变；相对QA17仅AppHeader事件/焦点处理及开发测试变化。QA17首页8项、动效2项、欢迎4项既有PASS保留，不算本轮新运行；QA17四项原FAIL及其方法修正原件不改写。CAP209恢复PARTIAL，已测四页面的NAV11按限定范围通过；其余49 CAP、25 PAGE/28视图、119 UIA与31活跃DATA不减项，见[矩阵](coverage-matrix.md)。

接续工作先核对既有开发及历轮QA证据与原验收条款的对应关系，再补实际缺口。矩阵的PARTIAL/NOT_FULLY_VERIFIED不自动产生新的浏览器组合、真实90天等待或任意并发排列。真机/人工读屏和部署环境检查单独保留；不把授权当作测试结果。

CR039-L1、CR042-L1、AI-QUALITY-90及未定位W01保持。QA17五份原正文可从[before-owned](evidence/qa2-018/before-owned.tar.gz)按原hash恢复；[finalization](evidence/qa2-018/finalization.json)与[manifest](evidence/qa2-018/manifest.json)记录源、控制面、历史证据和链接保护。专业QA只更新本轮证据及五份当前文档，正式关闭由守门登记。
