---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: awaiting_user_review
result: fail
version: M002-QA-17
date: 2026-09-28
---

# 首页、导航与登录提示验收

**18个有效场景：14 PASS、4 FAIL；新增一个前端问题 CR020 / QA2-F17。** 首页叠卡、选定动效和欢迎/消息并行通过本轮范围；头像菜单在四种语言/视口组合都缺少关闭与焦点处理。当前整期未通过，最终UAT未执行。

## 输入与边界

依据 [APPROVAL-M002-044](../reviews/verification-acceptance-044.md)继续 verification / qa-quinn。CR002/019已正式限定关闭，CR001沿042及更早关闭保持。PRODUCT03/UI22/H01/DB03/BE03/FE02不变，当前唯一新增问题为待登记CR020。

[inputs](evidence/qa2-017/inputs.json)核对282前端、288后端文件和444编译文件，复用frontend-cr019生产构建；未重建或重跑单元、lint、格式、类型检查。批准UI22的六份文案/可运行资源与归档完全相同；三份规范仅有已授权H01交接元数据变化，适用验收正文相同。北京04:00、本机复习草稿、基础/体验分账、90天及既有全局政策保持。

本轮针对现有矩阵中尚无独立证据的入口交互，运行真实Nuxt生产页面、严格契约mock及批准原型。两条消息使用符合API205的合成夹具；登录夹具只调整返回ui_locale，以覆盖中文。没有新真实Go/DB、AI、排序/权限/日差算法或持久化验收声明。

## 独立结果

| 范围 | 有效结果与已证明内容 |
|---|---|
| H17，8 PASS | 中英320/390 WebKit、768/1440 Chromium；首页及路径区逐字对照批准copy/fixture/原型。两篇完整单段、每篇六词、释义、字体、旋转叠放、响应式列数、无横向溢出、五项导航顺序与当前页正确；无生成请求 |
| M17，2 PASS | 英1440 Chromium / 中390 WebKit，真实9.2秒采样：漂浮有可测位移且幅度≤6px（0.1px测量容差），8秒后自动换卡；键盘阅读暂停、减弱动效即时切换、换语言保留暂停、离开再进入重新启动。没有用截图或快进时钟代替动态证据 |
| W17，4 PASS | 中英320×568 WebKit / 1440×900 Chromium；显式登录立即显示提醒正文与唯一欢迎status，位于modal可访问子树及顶层，5天24px/700。逐帧看到300ms淡入、10秒完整停留、300ms淡出；消息翻页、Escape、页面切换、重开与resize保持同节点、同动画、同截止时间。无焦点或点击拦截，短屏间隔/边界正确，消失释放留白，刷新不重弹 |
| N17，4 FAIL | 中英320 WebKit / 1440 Chromium；四项文案、展开、路由、关闭后的当前页正确。但点击外部/焦点移出不收起，Escape与进入个人信息后焦点落BODY；批准原型同条件正确。合并为CR020 / F17 |

[assessment](evidence/qa2-017/assessment.json)逐项绑定有效结果来源；根18项、control6项和keyboard-control2项是含方法修正的26次运行，不能相加冒充26个独立场景。浏览器warning/error/pageerror均0；本轮没有新axe或人工读屏结论。

人工查看英文1440、中文320首页成对截图和双语320欢迎截图：[visual-check](evidence/qa2-017/visual-check.json)。首页比较hero/path区域；原型默认学习者、生产访客及原型说明浮层造成的页头/总高度差异明确保留，不宣称整页像素相等。

## 新发现及责任

[CR020](../changes/CR-020.md)为P2共享头像菜单交互遗漏，来自[已批准交互规范](../design/interactions.md#全局导航与个人中心--page-205206214215217)，不是新产品偏好。所有期望、实际、复现、源定位和限定修复验收已写入问题单，建议返回implementation / frontend-claire。

这是本模块首次独立发现，尚无修复往返。已有F01–16关闭不重开；CR002标题和CR019图标的044关闭不受影响。历史未定位W01仍保持独立观察，不因本轮零告警自动关闭。

## 方法修正与保留

原始失败全部保留：[corrections](evidence/qa2-017/corrections.json)。手机外部点击改为确认命中菜单外的真实坐标；漂浮改测批准CSS使用的translate及实际Y位移；WebKit动画先等startTime就绪再比较；Mac WebKit以Alt+Tab访问链接，原型和生产使用同样按键。没有修改应用、强制点击被遮挡元素、忽略产品失败或放宽四项菜单标准。修正后四个菜单偏差仍全部复现。

## 覆盖与接续

[覆盖矩阵](coverage-matrix.md)及[机器矩阵](evidence/qa2-017/coverage.json)保持49 CAP、25 PAGE/28视图、119 UIA、31活跃DATA。首页文案/叠卡限定通过，NAV11记录F17；欢迎、动效仅扩展本轮所测范围。未测的后台/切出视口动效、其他欢迎状态及减弱动效、真实设备/读屏、生产代理、04:00实时时点等沿既有记录，不扩张新组合；需结合匹配的开发和历轮集成证据判定剩余验收，不因PARTIAL标签机械重测。

QA16五份旧正文存[before-owned](evidence/qa2-017/before-owned.tar.gz)，原hash可恢复，原证据与历史FAIL保持。应用、上下游交付、批准文件、旧CR和控制面受保护；本轮只更新五份QA当前文档、新证据和CR020。[manifest](evidence/qa2-017/manifest.json)及[finalization](evidence/qa2-017/finalization.json)记录一致性、链接与清理。三轮自建服务全部停止，本地/真实AI调用均0。

下一步处理CR020并定向复验，随后结合已有证据收敛剩余验收，准备用户UAT。CR039-L1、CR042-L1、AI-QUALITY-90继续保留；不宣布里程碑完成或部署。
