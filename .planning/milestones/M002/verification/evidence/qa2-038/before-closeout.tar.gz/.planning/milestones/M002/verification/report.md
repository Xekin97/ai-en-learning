---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: ready_for_user_acceptance
version: M002-QA-37
scope: Featured trial meanings fidelity
date: 2026-10-02
---

# 精选试用词义还原（QA37）

[3302精选](http://127.0.0.1:3302/explore)已更新。F01词义错放正文下方已修复：配置事实→逐条词义→试用按钮，重复词签删除。F02语言标签改为设计原名中文/English/日本語；释义不随UI语言重译，后台共享组件同步。

复用开发类型/lint/构建、2项三语言回归和2项后台共享标签检查。QA以真实3302 API、最终生产包、1440/390视口核对最新3篇预设，原型注入同一数据：全部原文/词义、区域顺序、无重复/横溢、字体/颜色/尺寸/标签通过；首卡双视口截图与原型逐字节一致。0页面异常、0真实AI调用；本次仅替换前端，后端、数据库和服务商配置未修改。开发首次漏区域断言导致F01，已补；QA发现语言标签F02后定向返回开发再复验，通过。

[源码与证据](../implementation/evidence/gallery-meanings-fix/manifest.json)、[实际页面](../implementation/evidence/gallery-meanings-fix/delivered-visual.json)、[最终部署](../delivery/gallery-meanings-3302-20261002/deployment-final.json)、[恢复说明](../delivery/gallery-meanings-3302-20261002/README.md)。方法失败与修正见开发验证，原记录保留；不把方法错误当产品通过。本轮不代签用户验收。

CR029/UI31服务商工作区仍待用户反馈；QA36通过范围及0016迁移保持，原当前正文保存在[修复前快照](../implementation/evidence/gallery-meanings-fix/before-documents.tar.gz)，原[QA36证据](evidence/qa2-036/manifest.json)继续有效。

## 保留事项

| ID / 范围 | 现有结论与影响 | 来源、后续动作与完成条件 |
|---|---|---|
| QA26-MINIMAX | 两次启用校验返回 model_incompatible，保持禁用；当时绑定该模型的热门预设不能生成。原因未定位，本轮未重新查询运行状态 | [原失败](evidence/qa2-026/minimax-retry.json)、[配置核对](evidence/qa2-026/final-check.json)。需要恢复该模型时从既有失败定向排查；启用检查与关联预设实际生成通过后才能认定解决 |
| CR039-L1 | safe→safety/safely 被拒，safer 未核实 | [原约束与验收](../../M001/changes/CR-039.md#retained-limitations)。后续明确恢复词形改进时按原样本核验，不自动重启调优 |
| CR042-L1 | 未知标注反馈定位精度、多回复整包回放仍有限制 | [原约束与验收](../../M001/verification/CR-042-generation-evidence.md#retained-limitations)。按实际失败定向处理，未扩展回放平台 |
| AI-QUALITY-90 | 稳定成功率 ≥90% 仍未验证 | [AI 验证范围](ai-evaluation.md)、[一期评估](../../M001/verification/ai-evaluation.md)。需单独明确评测范围与调用授权；本次 UAT 不提供统计证明 |
| W01 | 个人页曾出现未定位的 hydration console 警告，后续定向捕获未复现；未据此宣称修复 | [QA03 原观察](evidence/qa2-003/manifest.json)。再次出现时记录具体页面、堆栈和操作，定位并定向复验 |
| 环境与人工专项 | 生产 SSE 代理、Linux 部署与容量/告警、真实设备输入法/读屏、04:00 实时时点等仍按矩阵保留证据边界 | [矩阵](coverage-matrix.md#api数据与剩余工作)。属于后续对应环境验证；用户整体 UAT 不补写未执行的专项测试 |



原保留项不因本轮修复而消失；开放CR和角色以workflow为准。未执行新会话交接测试，token unknown。
