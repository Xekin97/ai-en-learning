---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: ready_for_user_acceptance
version: M002-QA-35
scope: CR029 generic model configuration
date: 2026-10-01
---

## CR029-F03/F04 服务商批量表单与流式验证（QA35）

已按用户要求更新 [3302 模型管理](http://127.0.0.1:3302/admin/models)：先选择或配置服务商，再连续添加多个模型 ID；每项独立高级配置、启用和显式测试。高级配置分组与间距统一，宽屏两列/手机单列；固定标题和保存操作，中间内容滚动，toast 出现时也不遮挡标题。整批保存一个事务，冲突整体回滚并保留输入。

测试的成功条件为所选模型支持有效 SSE 文本增量且正常结束，三种协议均执行 stream:true。普通 JSON、假 SSE MIME、空流、只有初始整段文本、提前断流不会显示成功；不以 TCP 包数量判断是否流式。结果只归属点击的模型，保存不自动调用上游。

- 开发证据复用：Go AI/admin/HTTP 定向单元、vet、隔离 PostgreSQL 批量与三协议 HTTP 集成通过；369 前端单测、类型/lint/边界/构建通过；16 项中英桌面/手机浏览器交互通过，toast 布局修正后 8 项相关回归通过，4 项原型布局通过。
- 真实部署包：3302 桌面1440与手机390两项冒烟通过。真实管理员登录及模型元数据、连接复用、增删条目、每项配置、当前项加载/反馈、固定头尾与取消不保存均覆盖；截图已查看。探测响应由浏览器拦截，真正的流式协议判定由上述本地 HTTP fixture 验证，未消费真实模型额度。
- 仅更新 Go/Nuxt 二进制，无新增迁移；切换前确认无运行中的生成。原模型/连接/加密凭据/配置表摘要一致，env 未变。进程恢复脚本读取最新 release；旧 release 保留可恢复。没有 Git 提交或生产部署。

证据：[实现](../implementation/evidence/provider-batch30/manifest.json)、[部署](../delivery/generic-models-3302-20261001/provider-batch-deployment.json)、[实际构建冒烟](../delivery/generic-models-3302-20261001/provider-batch-smoke.json)、[QA35 源码与证据](evidence/qa2-035/manifest.json)。当前 UI30 / QA35 / TRANSITION-M002-110，CR029 保持开放等待用户新功能验收；原 QA34/33 仅继续支撑未变范围。保留事项不因此关闭。

## 历史验证（以下记录仅适用于对应范围与版本）

## CR029-F02 当前模型测试反馈（QA34）

用户反馈单个模型点击“测试连接”后全部按钮显示测试中。确认后端只发送当前model ID的一次探测请求，问题是前端共享testing标记用于所有按钮。已修复为加载文案、aria-busy和成功/失败结果只显示在对应模型行；原单次测试串行保护保持。打开编辑弹窗清空列表反馈，避免串入草稿。

类型、目标lint、生产构建通过；4项原配置/编辑回归和4项新增中英×1440/390两模型场景通过。新增用例首轮在浏览器拦截列表无法改变SSR初始数据，先在契约服务准备两模型后定向复验通过；原失败和trace保留。QA复用开发结果，并在3302实际部署包中验证点击第一行成功、第二行失败、两个请求分别指定正确model ID、其他行无加载/结果。该生产前端使用真实账号与模型元数据，探测响应在浏览器拦截，0真实上游调用、0配置写入、0控制台错误。

已只更新3302前端，后端/数据库/模型配置未改。证据：[开发检查](../implementation/evidence/model-test-state/manifest.json)、[部署](../delivery/generic-models-3302-20261001/test-state-deployment.json)、[实际包定向检查](../delivery/generic-models-3302-20261001/test-state-smoke.json)。下方QA33结果继续证明未改动的三协议、数据库与表单基础；CR029整体新功能UAT仍待用户确认。本修复不是整个服务商批量测试功能。

# CR029 当前验证结果

通用模型配置已完成实现及限定QA，并更新到[3302模型管理](http://127.0.0.1:3302/admin/models)，供用户验收。管理员专用、三协议、参考式统一列表/配置表单、不设置默认模型四项已落实；旧OpenRouter专用配置区已移除。CR029保持开放，仅等待新功能用户反馈；用户的旧091验收不覆盖本轮。

- 复用开发验证：Go全单元与vet、admin/generation/postgres真实数据库集成、完整HTTP包138.764s通过；38文件367前端单测、类型/lint/模块边界/生产构建通过；中英×桌面手机8个浏览器交互通过。浏览器交互使用契约测试服务，三协议实际HTTP对接使用受控上游，均未真实付费调用。
- 升级验证：原3302备份完整恢复至隔离数据库并执行0015，再切换原库。59张原业务表全部原字段/行数/摘要不变，模型UUID、时间、密钥密文和既有配置保留。迁移只新增连接结构；原计划、卡、预设和学习关联保持。[迁移/恢复记录](../delivery/generic-models-3302-20261001/README.md)。
- 真实3302浏览器冒烟3项通过：访客无模型管理权限、普通造文无预选；真实管理员登录、模型列表/详情/连接元数据、编辑留空保留Key、弹窗固定操作区与无横溢、取消不写配置。1440/390采用账号实际中文语言；英文由8项开发浏览器矩阵覆盖。0控制台错误/5xx、0配置写入、0真实模型调用。
- 迁移演练发现QA33-F01：UPDATE触发现有模型updated_at变化。原库尚未迁移时即被拦截，旧服务恢复；沿100交后端改用列默认值回填，新增逐值保留回归通过，再沿101重演练通过。首轮证据完整保留。浏览器冒烟首轮的移动端脚本误以cookie覆盖账号语言，定位器等待英文按钮超时；改为使用账号实际语言后通过，未改产品语言逻辑。

证据：[开发manifest](../implementation/evidence/generic-models29/manifest.json)、[QA33接收与结果](evidence/qa2-033/results.json)、[当前交付源](evidence/qa2-033/manifest.json)。旧QA32文档已归档在[evidence/qa2-033/before-current-documents.tar.gz](evidence/qa2-033/before-current-documents.tar.gz)。本次不提交Git、不生产发布；真实服务商兼容性与学习质量不以模拟协议测试代替。

## 保留事项

| ID / 范围 | 现有结论与影响 | 来源、后续动作与完成条件 |
|---|---|---|
| QA26-MINIMAX | 两次启用校验返回 model_incompatible，保持禁用；当时绑定该模型的热门预设不能生成。原因未定位，本轮未重新查询运行状态 | [原失败](evidence/qa2-026/minimax-retry.json)、[配置核对](evidence/qa2-026/final-check.json)。需要恢复该模型时从既有失败定向排查；启用检查与关联预设实际生成通过后才能认定解决 |
| CR039-L1 | safe→safety/safely 被拒，safer 未核实 | [原约束与验收](../../M001/changes/CR-039.md#retained-limitations)。后续明确恢复词形改进时按原样本核验，不自动重启调优 |
| CR042-L1 | 未知标注反馈定位精度、多回复整包回放仍有限制 | [原约束与验收](../../M001/verification/CR-042-generation-evidence.md#retained-limitations)。按实际失败定向处理，未扩展回放平台 |
| AI-QUALITY-90 | 稳定成功率 ≥90% 仍未验证 | [AI 验证范围](ai-evaluation.md)、[一期评估](../../M001/verification/ai-evaluation.md)。需单独明确评测范围与调用授权；本次 UAT 不提供统计证明 |
| W01 | 个人页曾出现未定位的 hydration console 警告，后续定向捕获未复现；未据此宣称修复 | [QA03 原观察](evidence/qa2-003/manifest.json)。再次出现时记录具体页面、堆栈和操作，定位并定向复验 |
| 环境与人工专项 | 生产 SSE 代理、Linux 部署与容量/告警、真实设备输入法/读屏、04:00 实时时点等仍按矩阵保留证据边界 | [矩阵](coverage-matrix.md#api数据与剩余工作)。属于后续对应环境验证；用户整体 UAT 不补写未执行的专项测试 |



原保留项不因本轮修复而消失；开放CR和角色以workflow为准。未执行新会话交接测试，token unknown。
