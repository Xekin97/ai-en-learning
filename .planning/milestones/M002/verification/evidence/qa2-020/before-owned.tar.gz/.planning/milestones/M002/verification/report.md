---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: verification_in_progress
result: fail
version: M002-QA-19
date: 2026-09-28
---

# UI22剩余页面验收

本轮对19类页面执行中英320/768/1440共114次稳定页面检查，并核对普通配置、详情快照与领奖交互。有效18组：**7 PASS / 11 FAIL**；失败归为[CR021](../changes/CR-021.md)的三个已批准要求遗漏，已获持续修复授权。CR020已由[047](../reviews/verification-acceptance-047.md)关闭。

## 实际发现

- **F18：领奖成功后焦点丢失。** 成就不回组summary，等级不回对应h3；成就展开状态本身正常。原型成就正确，生产中英手机及等级桌面实测失败。
- **F19：WebKit下拉框过矮。** 个人信息、普通造文、运营、预设、分析的原生select实际22–23px，批准标准至少46px。原型同受浏览器原生渲染影响；对照响应式规范判定，不能因“与原型一致”忽略明确要求。
- **F20：英文兑换页平板横溢。** 合法大积分在768px标题行撑到约770px；余额与标题需正常换行，不能截断积分或隐藏页面溢出。

详细期望、坐标、复现和范围在CR021；[control原始结果](evidence/qa2-019/control/results.json)、[等级/诊断结果](evidence/qa2-019/supplement/results.json)、[有效判定](evidence/qa2-019/assessment.json)、[截图核对](evidence/qa2-019/visual-check.json)。没有新增产品偏好或扩大权益规则。

## 通过部分及方法

登录/注册同宽同起点、主标题、命名控件和公共导航正常；普通配置Story/Brief、模型/语言留空、键盘选择、随机后与语言切换后的值/展开保持通过，WebKit高度单列为F19。详情只读模型卡、三行设置及成功次数顺序、保存时长模型名和只读状态通过。其余页面正常态没有新增文案标题、装饰SVG或溢出缺陷；这不是所有业务状态自动通过。

首轮把图表SVG误归装饰图标、closed-details内部布局框误算可见，已保留原结果并以control修正范围：[方法记录](evidence/qa2-019/corrections.json)。修正后三个实际问题仍存在。临时注入CSS仅诊断WebKit高度，未计为修复验收；应用文件未动。没有重跑开发unit/lint/type或重建。

[inputs](evidence/qa2-019/inputs.json)绑定frontend-cr020、backend-cr013和QA18；三个本地运行均使用生产Nuxt+契约mock，服务已停止，真实AI调用0。没有新真实后端、账务、人工读屏或真机通过结论。QA18五份当前正文已[归档](evidence/qa2-019/before-owned.tar.gz)，原40项证据可恢复；[manifest](evidence/qa2-019/manifest.json)记录本轮交付。

## 接续

按用户持续授权，直接交frontend-claire修复CR021，再回qa-quinn复验；不会在角色切换处等待“下一步”。已知问题优先处理，原49 CAP/25 PAGE/28视图/119 UIA与31活跃DATA不减项。其余证据继续按原要求收敛，正式UAT未执行；CR039-L1、CR042-L1、AI-QUALITY-90及历史W01保持。
