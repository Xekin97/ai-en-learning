---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: scoped_qa_passed
result: ui26_increment_passed
version: M002-QA-28
date: 2026-10-01
---

# M002 本轮增量验收

UI26/FE04 与 BE04 的本轮实施 **限定范围通过**。包括CR025五项、UI25文案与UI26两处选词、CR027词库搜索权限及limit修复。质量角色先核对297个前端源与2个后端变更源、交付摘要，再复用31项开发浏览器、352单测与BE4真实隔离HTTP/race证据；未重跑开发基础检查。[接收记录](evidence/qa2-028/reception.json)。

本轮新增3项质量检查均通过：[实际结果](evidence/qa2-028/results.json)。QA28-Q01在后台选完整短语后核对保存请求、刷新后词条、发布限制与0生成调用；Q02选词/下拉的WCAG A/AA自动检查0违规（[原件](evidence/qa2-028/accessibility.json)，不等于完整读屏验证）；Q03后台预览共用消息壳、内容语言标题、净化HTML与关闭回焦。原31项覆盖三引擎三尺寸、中英文、消息滚动/翻页、欢迎浮层、三种释义、普通满额/失败/随机、预设保存发布、后台各类表单，见[开发结果与原始失败](../implementation/frontend-validation.md#ui26)。

## 覆盖与版本

当前产品来源PRODUCT04（CR026未决草稿除外），设计UI26、DB03、BE04、FE04；[覆盖矩阵](coverage-matrix.md#qa28)按受影响CAP/PAGE/API/UIA增量接续。原UI22未改行为和QA27用户验收继续只证明原范围。本轮静态源可恢复于[frontend UI26](../implementation/evidence/frontend-ui26/manifest.json)和[backend CR027](../implementation/evidence/backend-cr027/manifest.json)，无需从会话摘要重建。

本轮未增加QA返工：开发内发现并修复Safari消息/下拉指针焦点，生产三引擎复验通过。开发的模型标签、动画测量、代理拓扑及拦截query方法错误均保留原件；开发服务器动态导入错误原因未定位，稳定生产构建无pageerror，不把更换验证环境描述成根因修复。共享控件应用到19处，含保留的模型卡多选；不能按原架构误把19处全部当单选。

## 当前待办与验收边界

本报告建议按持续QA授权限定关闭CR025/027，由守门器登记结果；不再次索要相同实施/QA批准。**CR026 / D2-88-LOCAL-SCOPE仍待产品确认同浏览器是否按账号隔离记录**，不包含在UI26通过项。原“UAT测试已通过”属于本轮改动之前，新增范围需用户按[清单](uat.md)体验；未据此宣布M002再次完成或批准生产发布。

独立预览为 http://127.0.0.1:3311 ，采用生产构建与契约测试API；3302真实模型环境未更新。浏览器模拟、人工视觉检查及自动ARIA检查不能替代真机/输入法/读屏；生产环境和真实AI质量不在本次范围。复用原数据权限和Markdown后端净化证据，未新做攻击面扩测或生成调用。

## 保留事项

| ID / 范围 | 现有结论与影响 | 来源、后续动作与完成条件 |
|---|---|---|
| QA26-MINIMAX | 两次启用校验返回 model_incompatible，保持禁用；当时绑定该模型的热门预设不能生成。原因未定位，本轮未重新查询运行状态 | [原失败](evidence/qa2-026/minimax-retry.json)、[配置核对](evidence/qa2-026/final-check.json)。需要恢复该模型时从既有失败定向排查；启用检查与关联预设实际生成通过后才能认定解决 |
| CR039-L1 | safe→safety/safely 被拒，safer 未核实 | [原约束与验收](../../M001/changes/CR-039.md#retained-limitations)。后续明确恢复词形改进时按原样本核验，不自动重启调优 |
| CR042-L1 | 未知标注反馈定位精度、多回复整包回放仍有限制 | [原约束与验收](../../M001/verification/CR-042-generation-evidence.md#retained-limitations)。按实际失败定向处理，未扩展回放平台 |
| AI-QUALITY-90 | 稳定成功率 ≥90% 仍未验证 | [AI 验证范围](ai-evaluation.md)、[一期评估](../../M001/verification/ai-evaluation.md)。需单独明确评测范围与调用授权；本次 UAT 不提供统计证明 |
| W01 | 个人页曾出现未定位的 hydration console 警告，后续定向捕获未复现；未据此宣称修复 | [QA03 原观察](evidence/qa2-003/manifest.json)。再次出现时记录具体页面、堆栈和操作，定位并定向复验 |
| 环境与人工专项 | 生产 SSE 代理、Linux 部署与容量/告警、真实设备输入法/读屏、04:00 实时时点等仍按矩阵保留证据边界 | [矩阵](coverage-matrix.md#api数据与剩余工作)。属于后续对应环境验证；用户整体 UAT 不补写未执行的专项测试 |


原保留项不因本轮通过而消失；开放变更及当前角色以workflow为准。当前质量文档的旧QA27正文见[快照](evidence/qa2-028/before-current-documents.tar.gz)，历史各轮证据原地保留。本轮摘要与证据绑定见[manifest](evidence/qa2-028/manifest.json)。没有新会话独立交接测试，token unknown。
