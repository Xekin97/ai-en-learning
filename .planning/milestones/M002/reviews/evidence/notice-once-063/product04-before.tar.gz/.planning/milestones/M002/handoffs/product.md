---
milestone: M002
stage: product-planning
role: product/to-c
agent_name: product-maya
status: ready_for_review
version: M002-PRODUCT-04
change_request: M002-CR-025
updated_on: 2026-10-01
---

# M002 产品交接：五项追加展示与交互要求

当前正式角色由 [061](../reviews/product-reopen-061.md) 激活为 product-maya。用户明确提出五项“二期需求及设计改动”，D2-83–87 记录确认来源；原 PRODUCT03、UI22/H01、060 和用户 UAT 保持，不把新改动记成已通过。

当前完整真源：[概览及五项增量](../product/overview.md)、[能力验收](../product/abilities.md)、[数据](../product/data-assets.md)、[页面](../product/pages/index.md)、[AI 边界](../product/ai-behavior.md)。仍为49个能力/验收、25个当前页面职责和32个资产索引，其他一期/二期规则继承。

| 设计接收项 | 验收与边界 |
|---|---|
| 消息布局 | CAP210/PAGE207：正文为主体、视口约束、正文独立滚动；短/长文与长标题、移动端均可见标题和操作；欢迎 toast 的10秒、层级与淡入淡出保持 |
| Markdown | CAP210/PAGE207/209：后台预览与前台一致，现有语法清晰排版；保持安全输出，宽表格/代码局部滚动。概览列 GitHub Markdown CSS light / Tailwind Typography 两个候选，推荐前者作为样式参考；未选定依赖 |
| 预设释义 | CAP218/DATA212/PAGE212/217：展示同一有效预览/已发布样文的全部原词释义，语言随预设，不随 UI 自动翻译；无预览/参数变更显示准确状态，保留草稿/手动发布 |
| 统一下拉 | CAP206：用户端和后台全覆盖；保留原选项值/权限/校验，键盘、长选项、窄屏、弹窗内可操作。原生 select 实现位置见来源文件，交接时重新核对完整清单 |
| 首页优势 | CAP001/207/PAGE205：简洁介绍组合选词、AI 语境短文及现有中英日释义。保留双叠卡/动效/主行动/五项导航；不要写任意词、无限语言、准确率/学习成效保证 |

五项业务意图明确，没有新增待选业务规则；上述尺寸/主题/文案属于设计工作，未作为用户已批准视觉方案。产品不决定组件库、API 字段或数据库结构。当前样文已经含释义，无需为展示另发 AI 请求；依据代码/schema核对，并非本轮真实生成测试。

PRODUCT03 修订前正文、决定和本交接有[快照](../product/evidence/M002-PRODUCT-04-inputs.tar.gz)；[来源](../product/evidence/M002-PRODUCT-04-sources.json)与[静态检查](../product/evidence/M002-PRODUCT-04-check.json)记录追踪及保护。无业务测试/新会话接手测试，token unknown。旧批准原件不修改；CR039-L1/CR042-L1/AI-QUALITY-90/W01/QA26-MINIMAX 继续沿已验质量报告。

下一责任角色 designer-tony 以 UI22 为基线制作五项增量的可运行设计预览、准确双语文案、全下拉场景清单与设计差异，再交用户验收。产品稿本身不批准设计或实现；正式阶段与接收授权以 workflow/守门记录为准。
