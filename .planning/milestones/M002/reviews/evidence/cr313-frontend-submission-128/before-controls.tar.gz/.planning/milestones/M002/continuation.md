# M002 当前续做与原件索引

用户明确：原 M003 是未经授权新建的里程碑，其全部需求都属于 M002。当前为 **M002 / technical-design / frontend-bob**，CR-313 的 M002-UI-33-R3 已由用户明确审核通过，数据方案 M002-DB-CR313-01 已接收，后端方案 M002-BE-CR313-01 已接收，前端技术设计进行中。M002 当前续做未批准收尾；原123历史范围的验收事实保留。

## 当前工作与状态

| 范围 | 状态 | 当前入口与原件 |
|---|---|---|
| 短文质量、普通纠错/付费审稿返修、规划/流式体验、模型自定义参数、相关UAT修正 | 已实现范围沿既有逐项验收；原CR301–312已resolved，模型语义质量仍不属于QA | [业务基线原件](../M003/product/overview.md)、[技术原件](../M003/technical/backend.md)、[验证原件](../M003/handoffs/verification.md)；以下CR列表保留准确状态 |
| 单词发音 | 产品已接受，设计待审 | [M002-PRODUCT-08](product/pronunciation/overview.md)、[M002-UI-32交接](handoffs/pronunciation-uiux.md)；原UI14源与hash保留，未推定批准 |
| 管理台配置导入导出 CR-313 | 产品、正式设计、数据和后端方案已接受；前端技术设计进行中 | [M002-PRODUCT-09-R1](product/config-portability.md)、[M002-UI-33-R3交接](handoffs/config-portability-uiux.md)、[M002-DB-CR313-01](technical/config-portability/database.md)、[数据交接](handoffs/config-portability-database.md)、[后端方案](technical/config-portability/backend.md)、[API合同](technical/config-portability/api.md)、[后端交接](handoffs/config-portability-backend.md) |

原M003目录整棵树（product/design/technical/implementation/verification/changes/decisions/reviews及证据）全部是M002需求的历史原件。路径和冻结版本号保留用于复现，不能据其旧frontmatter推断M003有效或批准状态。新修改写入M002当前入口；不重新编号已引用的DATA/CAP/PAGE/AC/CR/决定号，不重跑已通过验收。

## 历史入口及原件归属

- [原产品原件](../M003/product/overview.md)、[原设计原件](../M003/design/design-spec.md)、[原数据库设计](../M003/technical/database.md)、[原后端/API](../M003/technical/backend.md)、[原前端设计](../M003/technical/frontend.md)。
- [原后端实现](../M003/handoffs/backend-implementation.md)、[原前端实现](../M003/handoffs/frontend-implementation.md)、[原验证/UAT](../M003/handoffs/verification.md)。
- [归属原话](reviews/evidence/m003-ownership-correction-124/authorization.json)、[门禁124](reviews/milestone-ownership-correction-124.md)、[全量旧源hash](reviews/evidence/m003-ownership-correction-124/m003-preservation-manifest.json)、[转接映射](reviews/evidence/m003-ownership-correction-124/rehome-map.json)。

M003初始化001与M004初始化001已撤销；原M002123历史验收不被擦除，仅其终态被本次明确续做替代。以前的M003107/109等专业产物接收在M002中沿用相同范围与原件，不扩张为新版设计批准。

## CR归属

| 编号 | 原状态 | M002当前入口 |
|---|---|---|
| CR-301 | resolved | [CR-301](changes/CR-301.md) |
| CR-302 | resolved | [CR-302](changes/CR-302.md) |
| CR-303 | resolved | [CR-303](changes/CR-303.md) |
| CR-304 | resolved | [CR-304](changes/CR-304.md) |
| CR-305 | resolved | [CR-305](changes/CR-305.md) |
| CR-306 | resolved | [CR-306](changes/CR-306.md) |
| CR-307 | resolved | [CR-307](changes/CR-307.md) |
| CR-308 | resolved | [CR-308](changes/CR-308.md) |
| CR-309 | resolved | [CR-309](changes/CR-309.md) |
| CR-310 | resolved | [CR-310](changes/CR-310.md) |
| CR-311 | resolved | [CR-311](changes/CR-311.md) |
| CR-312 | resolved | [CR-312](changes/CR-312.md) |
| CR-313 | open | [CR-313](changes/CR-313.md) |

## 当前研发边界

M002-UI-33-R3 已由[门禁126](reviews/cr313-technical-entry-126.md)接受；当前配置导入导出数据方案 M002-DB-CR313-01 已由[门禁127](reviews/cr313-backend-entry-127.md)接收，M002-BE-CR313-01 已由[门禁128](reviews/cr313-frontend-entry-128.md)接收；frontend-bob 开展前端技术设计。用户确认 DB313-Q01 选 A（成就身份冲突整次拒绝、不自动合并）；该单项确认仅用于身份冲突；整份数据方案接收另见127。前端技术设计交付仍需用户审阅，实现尚未开始。设计基线：直接继承此前M002视觉基线及原M003已接受的模型/计划增量，不能重画简化管理台。后续阶段按原Profile门禁执行。真实UAT3015和4174/4175原件服务继续可访问；路径中的旧编号只表示历史运行标识。公开新里程碑必须获得明确的里程碑启动授权，“下一步”或“继续研发”不构成新建里程碑授权。
