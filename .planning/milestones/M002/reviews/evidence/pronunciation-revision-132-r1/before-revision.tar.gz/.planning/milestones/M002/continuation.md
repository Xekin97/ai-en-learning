# M002 当前续做与原件索引

用户明确：原 M003 是未经授权新建的里程碑，其全部需求都属于 M002。当前为 **M002 / uiux-design / designer-tony**，CR-313 的 M002-UI-33-R3 已由用户明确审核通过，数据方案 M002-DB-CR313-01 已接收，后端方案 M002-BE-CR313-01 已接收，前端方案 M002-FE-CR313-01 及原作者 B1/TA1 接收补充已批准，CR313后端实现 M002-BI-CR313-01 已由门禁130接收，前端实现 M002-FI-CR313-01 已由门禁131接收，CR313独立QA M002-QA-CR313-01 与本地 UAT M002-CR313-UAT-01 已获用户验收，CR-313 已解决；[验收记录](reviews/cr313-uat-acceptance.md)。M002 当前续做未批准收尾；原123历史范围的验收事实保留。

当前接回单词发音正式设计 M002-UI-32：[恢复门禁132](reviews/pronunciation-review-resume-132.md)、[预览入口](reviews/evidence/pronunciation-review-resume-132/access.json)。原件16文件校验一致，预览已恢复并验证四个页面状态；当前等待用户审阅，尚未进入技术或实现。CR313验收和3016真实OpenRouter配置继续保留。

## 当前工作与状态

| 范围 | 状态 | 当前入口与原件 |
|---|---|---|
| 短文质量、普通纠错/付费审稿返修、规划/流式体验、模型自定义参数、相关UAT修正 | 已实现范围沿既有逐项验收；原CR301–312已resolved，模型语义质量仍不属于QA | [业务基线原件](../M003/product/overview.md)、[技术原件](../M003/technical/backend.md)、[验证原件](../M003/handoffs/verification.md)；以下CR列表保留准确状态 |
| 单词发音 | 产品已接受，正式设计评审已恢复；设计仍待审 | [M002-PRODUCT-08](product/pronunciation/overview.md)、[M002-UI-32交接](handoffs/pronunciation-uiux.md)；原UI14源与hash保留，未推定批准 |
| 管理台配置导入导出 CR-313 | 产品、设计、技术、实现及QA/UAT已接受，CR已解决（保留QA验证边界） | [M002-PRODUCT-09-R1](product/config-portability.md)、[M002-UI-33-R3交接](handoffs/config-portability-uiux.md)、[M002-DB-CR313-01](technical/config-portability/database.md)、[数据交接](handoffs/config-portability-database.md)、[后端方案](technical/config-portability/backend.md)、[API合同](technical/config-portability/api.md)、[后端交接](handoffs/config-portability-backend.md)、[前端方案](technical/config-portability/frontend.md)、[前端交接](handoffs/config-portability-frontend.md)、[后端实现交接](handoffs/config-portability-backend-implementation.md)、[开发验证](implementation/config-portability/backend-validation.md) |

原M003目录整棵树（product/design/technical/implementation/verification/changes/decisions/reviews及证据）全部是M002需求的历史原件。路径和冻结版本号保留用于复现，不能据其旧frontmatter推断M003有效或批准状态。新修改写入M002当前入口；不重新编号已引用的DATA/CAP/PAGE/AC/CR/决定号，不重跑已通过验收。

## 历史入口及原件归属

- [原产品原件](../M003/product/overview.md)、[原设计原件](../M003/design/design-spec.md)、[原数据库设计](../M003/technical/database.md)、[原后端/API](../M003/technical/backend.md)、[原前端设计](../M003/technical/frontend.md)。
- [原后端实现](../M003/handoffs/backend-implementation.md)、[原前端实现](../M003/handoffs/frontend-implementation.md)、[原验证/UAT](../M003/handoffs/verification.md)。
- [归属原话](reviews/evidence/m003-ownership-correction-124/authorization.json)、[门禁124](reviews/milestone-ownership-correction-124.md)、[全量旧源hash](reviews/evidence/m003-ownership-correction-124/m003-preservation-manifest.json)、[转接映射](reviews/evidence/m003-ownership-correction-124/rehome-map.json)。

M003初始化001与M004初始化001已撤销；原M002123历史验收不被擦除，仅其终态被本次明确续做替代。以前的M003107/109等专业产物接收在M002中沿用相同范围与原件，不扩张为新版设计批准。

## CR归属

| 编号 | 原状态 | M002当前入口 |
|---|---|---|
| CR-301 | resolved | [CR-301](changes/CR-301.md) |
| CR-302 | resolved | [CR-302](changes/CR-302.md) |
| CR-303 | resolved | [CR-303](changes/CR-303.md) |
| CR-304 | resolved | [CR-304](changes/CR-304.md) |
| CR-305 | resolved | [CR-305](changes/CR-305.md) |
| CR-306 | resolved | [CR-306](changes/CR-306.md) |
| CR-307 | resolved | [CR-307](changes/CR-307.md) |
| CR-308 | resolved | [CR-308](changes/CR-308.md) |
| CR-309 | resolved | [CR-309](changes/CR-309.md) |
| CR-310 | resolved | [CR-310](changes/CR-310.md) |
| CR-311 | resolved | [CR-311](changes/CR-311.md) |
| CR-312 | resolved | [CR-312](changes/CR-312.md) |
| CR-313 | resolved | [原需求](changes/CR-313.md)、[当前验收记录](reviews/cr313-uat-acceptance.md) |

## 当前研发边界

M002-UI-33-R3 已由[门禁126](reviews/cr313-technical-entry-126.md)接受；当前配置导入导出数据方案 M002-DB-CR313-01 已由[门禁127](reviews/cr313-backend-entry-127.md)接收，M002-BE-CR313-01 已由[门禁128](reviews/cr313-frontend-entry-128.md)接收；M002-FE-CR313-01、FE313-B1 与 TA1 已由[门禁129](reviews/cr313-implementation-entry-129.md)接受；backend-ethan 已完成后端实现及隔离开发验证，提交 M002-BI-CR313-01 并已由[门禁130](reviews/cr313-frontend-implementation-entry-130.md)接收；[提交记录](reviews/evidence/cr313-backend-submission-129/submission-receipt.json)不构成新的阶段迁移。用户确认 DB313-Q01 选 A（成就身份冲突整次拒绝、不自动合并）；该单项确认仅用于身份冲突；整份数据方案接收另见127。当前frontend-claire已完成CR313前端实现及开发验证，已由[门禁131](reviews/cr313-verification-entry-131.md)接收；qa-quinn独立验证交付已随本次CR313用户UAT接受；[前端实现交接](handoffs/config-portability-frontend-implementation.md)、[前端开发验证](implementation/config-portability/frontend-validation.md)、[前端提交记录](reviews/evidence/cr313-frontend-implementation-submission-130/submission-receipt.json)为当前入口；[QA交接](handoffs/config-portability-verification.md)、[QA报告](verification/config-portability/report.md)和[UAT清单](verification/config-portability/uat.md)是当前入口；CR313 用户UAT已独立启动于 http://localhost:3016，真实前后端及独立数据库、无mock；初始使用停用的测试模型，之后已按用户要求[恢复原OpenRouter配置](verification/config-portability/uat-local-20261016/openrouter-restoration.json)，DeepSeek V4 Flash已启用且四档计划均可选择；[访问与账号位置](verification/config-portability/uat-local-20261016/access.json)、[准备检查](verification/config-portability/uat-local-20261016/readiness.json)、[验收说明](verification/config-portability/uat-local-20261016/guide.md)。普通登录、四类别导出和预览取消的准备检查已验证；用户现已回复“验收完毕”，本轮CR313验收已接受，未将整体结论伪填为逐项人工测试结果；原3015环境保持；原批准UI/技术原件保持。不得对现UAT或已有数据库执行迁移。设计基线：直接继承此前M002视觉基线及原M003已接受的模型/计划增量，不能重画简化管理台。后续阶段按原Profile门禁执行。真实UAT3015和4174/4175原件服务继续可访问；路径中的旧编号只表示历史运行标识。公开新里程碑必须获得明确的里程碑启动授权，“下一步”或“继续研发”不构成新建里程碑授权。
