# CR029 通用模型服务（当前契约）

输入 PRODUCT-06 / UI29 / DB CR029；替代原 OpenRouter 专属管理与全局运行连接。本轮无默认模型，不改变普通用户计划/模型卡选择规则。

API-101/102 沿用 `/api/v1/admin/models` GET/POST、`/{model_id}` GET/PATCH、`/enable` `/disable` 和原移除影响/软下架接口。仅admin+原CSRF/session/revision保护。新增 `GET /admin/model-connections` 与 `POST /admin/model-connection-test`。

模型响应：id/display_name/description/provider_model_id/enabled/retired_at/assigned_group_codes/created_at/updated_at/max_output_tokens(整数|null)/output_mode(prompt|json_schema)/connection。connection为{id,name,protocol,base_url,credential_configured,masked_hint}，不返回密钥。列表仍pagination+revision。废除公开契约字段openrouter_model_id以及原全局凭据路由。

POST/PATCH保存完整表单：display_name、description|null、provider_model_id、connection_id(UUID|null)、connection({name,protocol,base_url,api_key}|null)、max_output_tokens|null、output_mode、enabled、expected_revision。connection_id引用已有连接；connection存在时创建新连接（可将connection_id作为原连接密钥来源，仅未修改URL/协议时允许留空沿用；更换目的地必须输入新密钥，防止意外发送旧密钥）。只编辑模型字段沿用原连接。空key只代表保留已存密钥，从不清除。写模型/新连接/密文/revision原子提交。名称与模型ID200/500字符；URL2048；密钥非空且至多8192；输出token正整数至多1048576。表单校验422（无效JSON为400），重复409，版本冲突409，引用不存在404，缺凭据422。保存零上游请求，新建默认停用；管理员可显式启用，连接测试为推荐动作，不能以自动付费探测替代保存。

连接测试body与表单连接、modelID、output上限相同，忽略名称/description/启用位；只发一次短文本流式请求，超时30s，token上限256；验证协议终止且有文本。返回{ok:true}；失败沿原problem安全代码映射(auth/rate-limit/unavailable/protocol)。不返回供应商原始错误/响应文本、密钥；不是学习质量证明。测试不保存或扣用户次数。

运行：统一Gateway从模型UUID加载连接，预检内解密并绑定GenerationSpec私有快照，所有纠错/续写复制沿用。Chat `/chat/completions` Bearer+messages；Responses `/responses` Bearer+instructions/input/store:false；Anthropic `/messages` x-api-key+anthropic-version:2023-06-01+system/messages，必需max_tokens缺省4096。Base URL只在拼接资源时忽略末尾斜线，不补/v1。JSON提示与本地严格校验共用；可选json_schema适用于OpenAI两协议，Anthropic采用提示词JSON。三协议将SSE事件映射为文本/用量/终止，继续使用既有标注清理、schema、词形/覆盖验证、取消退款、诊断脱敏。必须收到明确成功终止，长度截断/中途错误/不完整EOF失败。

连接安全：拒绝userinfo/query/fragment、完整接口资源路径和非http(s)；无重定向；默认解析并固定公网IP拨号，禁私网/本地/metadata地址。仅与服务端既有配置完全相同的本地模拟端点（URL精确匹配）可使用私网client；后台表单不能新增例外目标。密钥不进入JSON/trace/log；测试/保存错误仅分类。

用量：三协议reported tokens保留。只有已知OpenRouter官方端点的cost使用既有openrouter_credits；其他服务费用保持unknown，不猜价格或币种。

主要验证：三个协议实际HTTP请求/多块SSE成功，状态/中途错误/EOF截断/取消；密钥隔离与重定向；保存0calls；同名跨连接；旧数据迁移；普通用户无管理权限；生成preflight缺凭据不扣额。

来源：[Responses迁移与参数](https://developers.openai.com/api/docs/guides/migrate-to-responses)、[OpenAI streaming](https://developers.openai.com/api/docs/guides/streaming-responses)、[Anthropic Messages streaming](https://platform.claude.com/docs/en/build-with-claude/streaming)。使用服务商明确配置，不推测modelID或能力。
