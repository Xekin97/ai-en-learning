# CR029 前端架构交接

frontend-bob，输入PRODUCT-06/UI29/通用模型契约。见technical/frontend.md当前CR029节。保持schema/mapper/store/view边界，UI29直接转换，新结构替代旧专用面板；使用现有AppSelect和AppDialog。测试边界和密钥清理已明确，无默认模型与自动选择。实现验证待完成。
