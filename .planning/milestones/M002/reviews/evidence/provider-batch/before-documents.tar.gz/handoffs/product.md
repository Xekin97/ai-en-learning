---
milestone: M002
stage: product-planning
role: product/to-c
agent_name: product-maya
status: active_revision
version: M002-PRODUCT-06
date: 2026-10-01
---

# 通用模型配置产品交接

[CR029](../changes/CR-029.md)为当前任务；原M002-UAT及不变范围继续有效。当前入口：[overview](../product/overview.md)、[CAP101/102](../product/abilities.md#cap-101)、[DATA007/008](../product/data-assets.md#data-007)、[PAGE208](../product/pages/index.md#page-208)、[AI契约](../product/ai-behavior.md)、[D2-90–92](../decisions/product-decisions.md#d2-90)。

已确认管理员配置、三协议和向参考稿统一结构；撤销“OpenRouter单独保留”解释。旧数据/权益身份保留，配置管理和提供方调用统一重构，保存不调用。D2-92明确不设置默认模型，每次手动选择；当前无产品待决。参考原件及修订前快照见[092](../reviews/evidence/model-generalization-092/)。

designer-tony按参考列表/表单、协议和密钥交互制作Wordweave主题版本；技术角色明确连接隔离、密钥生命周期、迁移、三协议流式解析与费用归属；实现与QA覆盖普通/预设/预览、权限、配置失败、取消退款。采用既有整体输出校验；不加入自由聊天、个人BYOK或模型性能调优。用户明确要求实现，范围内的必要工作继续；不能把未执行的真实模型评测或用户UAT宣称通过。
