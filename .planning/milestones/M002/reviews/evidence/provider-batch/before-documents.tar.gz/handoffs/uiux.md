---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: implementation_reference
version: M002-UI-29
date: 2026-10-01
---

# UI29 通用模型配置

用户明确要求向参考重构，D2-90–92限定管理员/三协议/无默认。PAGE208旧OpenRouter专用面板及原模型表格失效，其他页面不受影响。当前[规格UI29](../design/design-spec.md)、[文案gm.*](../design/copy.json)、[样式UI29](../design/theme.css)、[可运行原型](../design/prototype/index.html?page=models&lang=zh)为一套来源；原型区域在admin.js的models/modelForm。修订前原件见092快照。

前端采用统一模型行与表单，沿参考的信息层级和字段顺序；连接身份与密钥不暴露给普通用户，不设置默认模型。新增业务状态依CAP101/102。1440/390中英、协议切换/草稿/测试/删除/键盘按UIA-MODEL29检查。浏览器自检：1440/390 × 中英文四例，列表/表单/固定操作区/无水平溢出通过，证据见 design/evidence/generic-models29/results.json；已目视检查桌面列表及移动表单。连接复用与错误状态由实际前端验收继续覆盖。用户未进行新一轮视觉验收。技术接收须建立统一连接与模型结构，不再恢复旧专用配置面板。
