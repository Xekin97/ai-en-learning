---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
version: M002-FE-UI28-ONCE
status: ready_for_verification
---

# CR026 本地一次提醒

<a id="once28"></a>
用户明确要求后台逐消息“只提醒一次”，本轮又确认同浏览器按账号分别记录（D2-88）。已接收UI28/FE05和BE05字段，后台新增默认关闭开关，保存/刷新/草稿冲突字段合并与预览维持；用户端不增加内部类别标签。DTO可缺省remind_once为false，现后端固定返回字段。copy由sync-design直接生成，布局沿现有actions/check。

浏览器storage适配器只保存账号+消息去重标识；退出不删，正文编辑不重置。仅AppDialog真正showModal或已打开弹窗的正文切换完成时发shown，自动提醒当前项才写入；队列未展示项不计数，手动/后台预览不计，当前队列可往返。语言刷新保留本次队列，关闭时取消在途提醒刷新；账号epoch阻止旧响应串号。不可写存储在Nuxt实例内回退；SSR不访问window。

39项目标单测（11本地记录/队列生命周期+28后台契约）、类型/目标lint/格式/生产构建通过；新增脚本lint通过。初次类型检查发现可空item保护不充分，已修正显式item保护，原失败typecheck.log保留，最终typecheck-final.log通过。没有修改验收条件。

[4个双引擎浏览器场景](evidence/notice-once/browser-results.json)覆盖1440 Chromium与390 WebKit：后台启用/保存/刷新、后台预览不计；实际测试HTTP登录后显示、提前关闭未展示项、下一次登录跳过、队列往返、刷新不提醒、同浏览器学习者/管理员分别记录、切回原账号、手动仍可查看、清缓存可重现。两张后台局部图已查看，与原型开关顺序和说明层级一致，无横溢。[1项欢迎/消息翻页回归](evidence/notice-once/notice-regression.json)通过。测试服务现在将后台保存的配置同步到用户消息投影，便于3311实际体验；该fixture正文只提供安全文本，正式Markdown仍由后端原渲染负责。

[源码和证据](evidence/notice-once/manifest.json)；旧文/源在before.tar.gz。3311已更新，3302真实模型入口/数据库未变。无真实AI调用。交QA补真实HTTP保存/读取/权限/过滤的跨层检查，复用前端开发证据。用户新UI视觉/UAT不代签；旧五项限制保持。
