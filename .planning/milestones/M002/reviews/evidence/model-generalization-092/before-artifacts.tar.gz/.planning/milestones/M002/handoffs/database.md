# CR026 数据库交接

dba-diana：DB04仅新增默认false的remind_once列，真源technical/database.md CR026节，原DB03保持继承。用户确认D2-88，本地记录不进入数据库。隔离库验证新旧默认/往返；不执行真实库迁移。
