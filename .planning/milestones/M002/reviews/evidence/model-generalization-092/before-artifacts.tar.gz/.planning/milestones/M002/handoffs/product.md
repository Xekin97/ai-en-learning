---
milestone: M002
stage: product-planning
role: product/to-c
agent_name: product-maya
status: requirements_confirmed
version: M002-PRODUCT-05
date: 2026-10-01
---

# 当前产品交接

用户已明确选择同一浏览器按账号分别记录，D2-88-LOCAL-SCOPE完成确认。CR026可继续设计及技术接收；原用户“后台消息配置增加一个只提醒一次的配置，次数缓存到用户浏览器本地”与本次选择共同构成实施范围。

规则真源：[CAP-210/AC-210](../product/abilities.md#cap-210)、[DATA-205](../product/data-assets.md#data-205)、[PAGE207/209](../product/pages/index.md#page-207)、[D2-88](../decisions/product-decisions.md#d2-88)。默认关，实际逐条自动展示才记，同账号下次登录排除已展示项，未展示不记；手动阅读/后台预览不记；正文编辑不重置，退出保留，清站点数据可重现。存储失败不阻断认证。

交designer-tony沿既有后台开关样式补文案/原型，再接收配置持久化和前端账号隔离；不增加服务端已读表、消息标签或新页面。旧正文可从product/evidence/notice-once/before.tar.gz恢复。CR025/027/028关闭保持；旧限制与新UI用户UAT保留。未换运行模型，token unknown。
