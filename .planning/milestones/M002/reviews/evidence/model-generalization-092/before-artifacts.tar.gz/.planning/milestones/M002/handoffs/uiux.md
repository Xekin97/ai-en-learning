---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
version: M002-UI-28
status: ready_for_reception
---

# 当前设计交接

CR026按已确认D2-88接收，原有后台消息开关后增加“只提醒一次”及一行浏览器范围说明，用户消息界面不增加任何类别标签。准确来源与验收见[规格UI28](../design/design-spec.md)，copy来自design/copy.json、原型app.js的messages与loginNotice。旧UI27原件在design/evidence/notice-once/before.tar.gz。

顺序接数据库/接口/前端本地去重，保持原消息阅读与欢迎层级；本轮明确产品功能指令下局部设计，不代签用户新视觉验收。未换模型，token unknown。
