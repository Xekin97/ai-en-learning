---
milestone: M002
stage: implementation
role: backend-implementer/base
agent_name: backend-ethan
version: M002-BE05-ONCE
status: ready_for_verification
---

# CR026 后端实现

DATA205/CAP210/API205/207：新增0014迁移remind_once非空布尔默认false，现有消息行为保持。Input、存储扫描/保存和公开Notice投影贯通；原visible/remind、分页、鉴权、Markdown净化、发布时刻和revision原子更新不变。没有服务端个人提醒历史。

隔离的临时PostgreSQL新建测试库执行全部迁移；4项notice测试-race通过，含默认/开关往返/重复编辑冲突/隐藏与提醒过滤；go vet notices/httpapi通过。证据[backend-checks](evidence/notice-once/backend-checks.json)、backend-tests.log。3302 UAT库未迁移；新版本部署必须先迁移再启新后端，回滚应用可保留字段。无真实AI调用。

[旧文原件](evidence/notice-once/before.tar.gz)保留，上一CR027源及结果仍有效；当前精确增量见manifest。QA补实际HTTP契约连接，不能把服务层通过冒称整条前后端真实集成通过。

## QA31-F01 修复

真实HTTP发现通用配置校验把缺失remind_once作为required拒绝；改为独立请求DTO，只有新字段omitempty，输出模型仍总是返回boolean。其他原必填字段、类型校验保持。5项输入用例与httpapi vet通过，原失败保留在verification/evidence/qa2-031/initial-http.log。无需改变产品/接口默认false约定。[最终源](evidence/notice-once/manifest-final.json)，交QA重跑原HTTP用例；前端/DB/service无变化，不重复其测试。
