# M004 历史原件：已并入 M002

此编号因误拆而撤销，发音需求及后续交付统一归入已正式完成的 M002。从 [M002 已交付基线](../M002/continuation.md)接续；[正式收尾与合并授权](../M002/reviews/milestone-closeout.md)优先于旧稿的流程状态。

本目录仅保存初始产品稿和启动历史；FreeDictionary 等旧范围已被 [M002 浏览器朗读版本](../M002/product/pronunciation/browser-only/overview.md)替代。它不是独立里程碑，也不存在待审设计或下一阶段。原件原地保留以供追溯。
