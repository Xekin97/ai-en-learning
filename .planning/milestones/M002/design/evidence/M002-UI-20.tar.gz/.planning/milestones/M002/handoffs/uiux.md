---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-20
date: 2026-09-20
---

# M002 UI/UX 交接 · designer-tony

输入 [M002-PRODUCT-03](./product.md) / [TRANSITION-M002-006](../reviews/product-title-revision.md)，Profile consumer-ai-web@1.0.0，revision `b5badf88cd7194400c3d4d0e9395e7c98490dc26`。仍为 uiux-design，整稿待审；不把本轮局部修改当作阶段批准。

用户明确要求欢迎消息停留十秒并放大天数，原话及保护记录见 [UI20-reception.json](../design/evidence/UI20-reception.json)。新版替代 UI19 的欢迎五秒时限；普通反馈仍五秒，消息触发、顶层位置和学习日算法保持。“5 天”代表要突出显示的内容，实际值仍来自学习记录。

- [登录原型](http://127.0.0.1:4174/prototype/?page=login&role=guest&lang=zh&v=M002-UI-20)。登录后观察欢迎与提醒同时显示；默认夹具为两天，五天截图来自测试覆盖。
- [设计规格](../design/design-spec.md) 的欢迎提示与反馈层级 / TOAST19；[交互](../design/interactions.md)、[响应式](../design/responsive-accessibility.md)。沿用 PAGE-003 / CAP-209 与 PAGE-207 映射，25 PAGE / 28 视图 / 49 CAP / 31 活跃 DATA 保持。
- [app.js](../design/prototype/app.js) 的 toast：欢迎十秒、其他五秒；[copy.json](../design/copy.json) 的 welcome / welcome.elapsed 用文本节点组合；[theme.css](../design/theme.css) 的 .toast-days：24px、700、1.2 行高，单位与数字不拆行。无新增业务、用户输入不拼 HTML。
- [验证](../design/validation.md)：中英文四个布局、一次 axe、两组针对性检查通过；实际十秒/五秒计时、翻页和关闭期间保持、图层与短屏操作均通过。

[当前冻结包](../design/evidence/M002-UI-20.tar.gz) / [清单](../design/evidence/M002-UI-20-manifest.json) / [当前指针](../design/evidence/design-manifest.json)；[UI-19 原件](../design/evidence/M002-UI-19-manifest.json) 保留。578 个受保护原件不变。当前正文就地更新，未改正式应用/控制面、未提交 Git 或切换阶段；其他 M001/M002 页面与既有约定继续有效。

下一步继续设计审阅；同日欢迎专门文案仍需接入既有 CAP-209，不能以本轮时长/文字验收代替。生产浏览器兼容、真机/Safari/人工读屏、独立 QA 与新会话交接未验证。CR-001/002、CR039-L1、CR042-L1、AI-QUALITY-90 保持。模型用量未知；无本轮阻塞项。
