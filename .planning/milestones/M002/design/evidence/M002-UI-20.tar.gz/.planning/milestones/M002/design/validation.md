---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-20
date: 2026-09-20
---

# UI-20 设计验证

范围为 PAGE-003 / CAP-209 的欢迎时限和间隔文字，沿用 TOAST19 验收映射及 PAGE-207 上层显示。用户要求见 [UI20-reception.json](./evidence/UI20-reception.json)；输入 PRODUCT-03，[UI-19 快照](./evidence/M002-UI-19.tar.gz) 保留。

运行 `node .planning/milestones/M002/design/evidence/verify-ui20.cjs`，[浏览器报告](./evidence/UI20-browser-results.json) 两组首次通过：

- 320×568 / 1440×900 中英文共四个布局，天数及单位 24px / 700，正文 15px；整句文字保持。提示仍在消息顶层、视口内并避开操作按钮，焦点保持在关闭入口。英文桌面 axe 无违规，未发现运行错误。
- 欢迎在六秒时仍可见，消息翻页、Escape 关闭不延长寿命，实际观察 10010ms 消失；普通保存反馈无强调节点，5095ms 消失，仍按五秒计时。

五天仅为测试中的网络夹具覆盖（上次学习设为 2026-09-12 16:24），未修改共享 fixtures.json 或天数计算。实际打开检查 [手机中文](./evidence/UI20-welcome-320-zh.png)、[桌面中文](./evidence/UI20-welcome-1440-zh.png)，天数与单位一同突出，未遮挡操作；英文截图同时保存。

运行 `python3 .planning/milestones/M002/design/evidence/verify-ui20-static.py`，[静态报告](./evidence/UI20-static-results.json) 核对文案双语、JS 语法、路径、当前版本、25 PAGE / 28 视图 / 49 CAP / 31 活跃 DATA，以及 578 个受保护输入/旧证据。[冻结包](./evidence/M002-UI-20.tar.gz)、[清单](./evidence/M002-UI-20-manifest.json)、[当前指针](./evidence/design-manifest.json) 保持同一版本；冻结后摘要检查见 `evidence/UI20-freeze-results.json`。

只修改设计原型及交付文档；未改正式应用、产品、CR、工作流或阶段，未提交 Git 或调用真实 AI。UI19 的其他图层规则保留，本次没有重跑其完整行为及其他页面流程。同日专门文案仍待接入；生产兼容、真机/Safari、人工读屏、独立 QA 与新会话交接未验证。模型实际用量未知，整稿仍待审。
