// Published presets only. Carousel state is local presentation, never generation state.
export function createPresetGallery({ F, t, esc, B, chips, heading, empty, link, scene }) {
  let dispose = () => {}, selected = 0, paused = false;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const value = (group, v) => t('a.preset.' + group + '.' + v);
  function view() {
    if (scene() === 'empty' || !F.presets.length)
      return heading('explore.title', 'gallery.intro') + empty('explore.empty', 'explore.emptydesc', link('create', 'create', 'btn primary'));
    const presets = scene() === 'single' ? F.presets.slice(0, 1) : F.presets;
    selected = Math.min(selected, presets.length - 1);
    return `${heading('explore.title', 'gallery.intro')}<section class="preset-gallery" aria-label="${esc(t('gallery.label'))}" aria-roledescription="${esc(t('gallery.carousel'))}">
      <div class="gallery-toolbar"><p class="gallery-guidance">${esc(t('gallery.hint'))}</p><div class="gallery-controls">
      <button type="button" class="btn quiet" data-gallery="play" aria-controls="presets">${esc(t('gallery.pause'))}</button>
      <button type="button" class="btn gallery-arrow" data-gallery="previous" aria-controls="presets" aria-label="${esc(t('gallery.previous'))}">←</button>
      <span class="gallery-position" aria-live="off"></span>
      <button type="button" class="btn gallery-arrow" data-gallery="next" aria-controls="presets" aria-label="${esc(t('gallery.next'))}">→</button></div></div>
      <div class="gallery-track" id="presets" role="group" tabindex="0" aria-label="${esc(t('gallery.list'))}">${presets.map((p, i) => `<article class="preset-card gallery-card" data-preset-index="${i}" aria-labelledby="preset-name-${i}">
        <div class="gallery-config"><div class="gallery-kicker"><span class="gallery-number" aria-hidden="true">${String(i + 1).padStart(2, '0')}</span><span class="eyebrow">${esc(t('gallery.preset'))}</span></div>
        <h2 id="preset-name-${i}">${esc(p.title)}</h2><dl class="gallery-facts">${[['model', p.model], ['style', value('style', p.style)], ['length', value('length', p.length)], ['explain', value('language', p.language)]].map(([k, v]) => `<div><dt>${esc(t(k))}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>
        <div class="gallery-words"><h3>${esc(t('words'))}</h3>${chips(p.words)}</div><div class="gallery-cta">${B('try', 'try:' + i, 'primary')}<p>${esc(t('gallery.cta.note'))}</p></div></div>
        <div class="gallery-paper"><p class="eyebrow">${esc(t('gallery.fullsample'))}</p><div class="gallery-passage" lang="en">${p.sampleText.split(/\n\s*\n/).map(x => `<p class="story-text">${esc(x)}</p>`).join('')}</div><p class="gallery-sample-note">${esc(t('gallery.sample.note'))}</p></div>
      </article>`).join('')}</div><p class="sr-only gallery-announcement" aria-live="polite" aria-atomic="true"></p></section>`;
  }
  function afterRender() {
    dispose();
    const root = document.querySelector('.preset-gallery');
    if (!root) return;
    const abort = new AbortController(), options = { signal: abort.signal };
    const track = root.querySelector('.gallery-track'), cards = [...track.children];
    const play = root.querySelector('[data-gallery="play"]'), counter = root.querySelector('.gallery-position');
    let timer, scrollTimer, pointerIntent, hovered = false, onScreen = false;
    const multi = cards.length > 1;
    const running = () => multi && !paused && !reduced.matches;
    function update() {
      play.textContent = t(reduced.matches ? 'gallery.manual' : paused ? 'gallery.play' : 'gallery.pause');
      play.disabled = !multi || reduced.matches;
      root.querySelectorAll('[data-gallery="previous"],[data-gallery="next"]').forEach(x => x.disabled = !multi);
      counter.textContent = t('gallery.position', { current: selected + 1, total: cards.length });
      root.dataset.rotation = running() ? 'auto' : 'paused';
    }
    function schedule() {
      clearTimeout(timer);
      if (running() && !hovered && !document.hidden && onScreen)
        timer = setTimeout(() => move(selected + 1, false), 8000);
    }
    const leftOf = i => cards[i].offsetLeft - cards[0].offsetLeft;
    function move(index, manual) {
      selected = (index + cards.length) % cards.length;
      if (manual) paused = true;
      track.scrollTo({ left: leftOf(selected), behavior: reduced.matches ? 'instant' : 'smooth' });
      update();
      if (manual) root.querySelector('.gallery-announcement').textContent = t('gallery.announcement', { current: selected + 1, total: cards.length, title: F.presets[selected].title });
      schedule();
    }
    function pause() { paused = true; update(); schedule(); }
    root.addEventListener('click', e => {
      const button = e.target.closest('[data-gallery]');
      if (!button || button.disabled) return;
      if (button.dataset.gallery === 'play') { paused = e.detail > 0 && pointerIntent !== undefined ? pointerIntent : !paused; pointerIntent = undefined; update(); schedule(); }
      else move(selected + (button.dataset.gallery === 'next' ? 1 : -1), true);
    }, options);
    root.addEventListener('pointerenter', e => { if (e.pointerType === 'mouse') { hovered = true; schedule(); } }, options);
    root.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse') { hovered = false; schedule(); } }, options);
    // Keyboard/assistive focus and direct manipulation stop rotation until explicit play.
    play.addEventListener('pointerdown', () => { pointerIntent = !paused; }, options);
    root.addEventListener('focusin', pause, options);
    play.addEventListener('keydown', e => { if (e.key === 'Tab') pause(); }, options);
    track.addEventListener('pointerdown', pause, options);
    track.addEventListener('wheel', pause, { ...options, passive: true });
    track.addEventListener('keydown', e => {
      if (e.target !== track || !['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) return;
      e.preventDefault();
      move(e.key === 'Home' ? 0 : e.key === 'End' ? cards.length - 1 : selected + (e.key === 'ArrowRight' ? 1 : -1), true);
    }, options);
    track.addEventListener('scroll', () => {
      clearTimeout(scrollTimer);
      scrollTimer = setTimeout(() => {
        selected = cards.reduce((best, _, i) => Math.abs(leftOf(i) - track.scrollLeft) < Math.abs(leftOf(best) - track.scrollLeft) ? i : best, 0);
        update(); schedule();
      }, 120);
    }, { ...options, passive: true });
    document.addEventListener('visibilitychange', schedule, options);
    reduced.addEventListener('change', () => { update(); schedule(); }, options);
    const observer = new IntersectionObserver(entries => {
      onScreen = entries[0].isIntersecting;
      schedule();
    });
    observer.observe(root);
    update();
    track.scrollTo({ left: leftOf(selected), behavior: 'instant' });
    dispose = () => { clearTimeout(timer); clearTimeout(scrollTimer); abort.abort(); observer.disconnect(); };
  }
  return { view, afterRender };
}
