---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-07
date: 2026-09-18
---

# UI-07 设计验证

本轮来源为用户对试用目录的三项明确修订：完整配置、完整预设样文、横向自动滚动。对应 PAGE-217 / CAP-218 / DATA-212，沿用批准的 PRODUCT-03 和 TRANSITION-M002-006。没有修改产品、控制面或正式应用。

## 浏览器检查

从产品仓库根运行下列命令，原型按规格服务在 4174；命令中省略的前缀为 `.planning/milestones/M002/design/evidence/`。使用现有 Playwright Chromium 151.0.7922.34 与 axe-core，无新增依赖。

| 检查 | 原件及覆盖 |
|---|---|
| `node …/verify-ui07.cjs` | [UI07-browser-results.json](./evidence/UI07-browser-results.json)：6 组操作，全文逐段、完整词条/四配置、所选预设到锁定工作台、进入不生成/不扣次、语言切换、键盘、单条/空态、发布与草稿隔离、私人标题保存回归，以及实际定时自动/首尾循环/悬停暂停/焦点暂停/恢复/离开清理。逐组 PASS/FAIL 以原件为准。 |
| 同一主脚本 | 320/390/768/1440px × zh/en 共 8 组，无页面横溢，正文分段未截断；390/1440px 两次 axe 无报告违规。自动过程使用真实等待，不用静态截图代替运动检查。 |
| `node …/verify-ui07-touch.cjs` | [UI07-touch-results.json](./evidence/UI07-touch-results.json)：390px Chromium 触摸仿真，通过浏览器 touchStart/move/end 让原生横向轨道滑到第二项并暂停自动；不是物理手机验证。 |
| `python3 …/verify-ui07-static.py` | [UI07-static-results.json](./evidence/UI07-static-results.json)：25 PAGE、28 视图、49 CAP、31 活跃 DATA；新增 UIA、文案与模块语法、样文/标题、当前版本、保护摘要和相对路径。 |

首次主检查中，测试把访客次数误写为学习者的 5 次，而实际访客夹具是 3 次；改为对照进入目录前的原始额度，不改变业务配置。演示控制条会在页面重绘后收起，旧测试直接选择隐藏控件超时，改为每次选择前先展开；英语配置准确文案为“英语”，不改文案来迎合测试。原 [首次报告](./evidence/UI07-first-browser-results.json)、[首次脚本](./evidence/verify-ui07-first.cjs) 和失败截图保留。首次自动、响应式、axe 和标题回归已通过，最终主报告重新验证修正后的路径。

## 实际视觉检查

已打开并检查 [桌面 1440px](./evidence/UI07-explore-1440.png)、[手机中文 390px](./evidence/UI07-explore-390.png)、[手机英文 390px](./evidence/UI07-explore-390-en.png)：桌面配置与全文并列，下一卡边缘提示可横向浏览；手机配置、入口和正文纵排，三段全文直接展示，没有截断或内部纵向阅读滚动。两种 UI 语言都保留原预设标题和英文正文。截图采用减少动效，展示“手动浏览”；普通模式的自动行为由单独操作检查证明。

原型完整样文是确定性设计夹具，通过 `sampleText` 和同一发布快照串联管理预览、目录。没有本轮真实模型生成或质量评估声明；新增完整样文替换旧两句摘要仅用于当前原型表达，不编辑生产内容。

## 边界与接续

- 未验证真实 API、所有权、数据库、生产预设分页/发布原子性、流式生成或额度结算；继承规则仍由后续技术/QA 实现和验证。
- 未测物理手机、Safari、人工读屏、200% 缩放；自动暂停的页面隐藏和离开视口分支已有设计与源码，未单独做跨标签实机验证。axe 零报告不是完整 WCAG 声明。
- 不重跑全部一期/二期业务；UI-06 的 13 组/27 路由/4 次 axe 只证明旧版本，当前仅沿用其未改规则和历史证据，不能计入本轮测试数量。独立新会话交接未执行。
- CR-001/002 不由设计关闭，既有 CR039-L1、CR042-L1、AI-QUALITY-90 保持开放/未验证状态；没有引入新业务范围或新的产品阻塞。

## 可恢复来源

当前源与本轮证据为 [M002-UI-07.tar.gz](./evidence/M002-UI-07.tar.gz)，[冻结清单](./evidence/M002-UI-07-manifest.json) 记录逐文件摘要；[design-manifest.json](./evidence/design-manifest.json) 为当前版本入口。[UI07-reception.json](./evidence/UI07-reception.json) 记录用户指令、旧源与受保护文件。旧 [UI-06 冻结包](./evidence/M002-UI-06.tar.gz) 及其清单/报告原件保留。设计待审，未提交 Git、未推进阶段。
