---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-09
date: 2026-09-18
---

# UI-09 设计验证

本轮处理用户明确提出的全站文案、表单对齐和页面高度问题。用户此前仅验证功能，未评价或批准设计。输入仍为 PRODUCT-03 / TRANSITION-M002-006；各页 COPY09 验收见设计规格。

## 浏览器与布局

从产品仓库根运行 `node .planning/milestones/M002/design/evidence/verify-ui09.cjs`。最新 [浏览器报告](./evidence/UI09-browser-results.json) 记录认证与移动端承接、后台搜索/模型/计划、预设发布与语言筛选、复习回看/提交、响应式和 axe 检查。28 视图覆盖 390/768/1440px 中文与 1440px 英文，共 112 个页面布局；9 个代表性页面运行 axe。测试只证明所列原型行为，不是生产功能验收。

[首次报告](./evidence/UI09-first-browser-results.json) 和 [首次脚本](./evidence/verify-ui09-first.cjs) 保留：访客测试错误地重复 role 参数、复习测试错误假定随机词序，修正用例；另发现真实交互问题——修改计划额度后，blur 时新增警告使保存按钮在点击过程中移位。现在输入时就更新警告，不重建表单，确认仍保留影响说明。后续报告记录重新验证结果，不隐藏首轮失败。

第二轮仅预设组遇到本地资源 `ERR_CONNECTION_RESET`，其余 6 组通过；保持产品源不变单独重跑预设组通过。[第二轮原报告](./evidence/UI09-second-browser-results.json)、[定向重跑](./evidence/UI09-targeted-results.json) 与 `assemble-ui09-results.py` 保存合并依据。最新报告合并这些通过项，未把失败的那次请求称为成功，也未重复执行已通过的 112 个布局/9 个 axe。

使用 `capture-ui09.cjs before|after` 对 20 路由 × 1440/390px、900px 高视口测量主内容，同步保存 18 张改前与 18 张改后截图。改前源确认为冻结 UI-08。改后首次采集等待了手机上已隐藏的营销 h2，故调整为等待可见标题；[首次采集脚本](./evidence/capture-ui09-first.cjs) 保留。此前一次未改源的基线采集超时，重跑完成，未将未知超时原因解释为产品修复。

原始 [改前数据](./evidence/UI09-before-layout.json)、[改后数据](./evidence/UI09-after-layout.json) 与 [高度比较](./evidence/UI09-height-comparison.json) 分离。390px 示例：

| 页面 | 原主内容高度 | 当前主内容高度 | 减少 |
|---|---:|---:|---:|
| 登录 | 886px | 510px | 42.4% |
| 注册 | 978px | 656px | 32.9% |
| 造文 | 1277px | 959px | 24.9% |
| 复习 | 981px | 694px | 29.2% |
| 试用目录 | 2100px | 1674px | 20.3% |

高度测量不包括顶栏、页尾和演示控制，反映原型夹具而非真实内容性能。复习词序随机，截图题目可能不同；未将字母数量差异解释为功能变更。长短文完整保留，不设“一屏”硬指标。

## 实际视觉检查

已打开实际截图检查桌面登录、首页、用户搜索、计划设置、预设编辑和试用；手机登录、注册、造文、复习和试用。重点核对标题/字段/按钮起点、纵向节奏、可操作区域与完整正文。代表图：

- [桌面登录](./evidence/UI09-after-login-1440.png)、[手机注册](./evidence/UI09-after-register-390.png)：统一表单表面；手机不重复营销介绍。
- [用户搜索](./evidence/UI09-after-users-1440.png)、[计划表单](./evidence/UI09-after-plans-1440.png)、[预设编辑](./evidence/UI09-after-presets-1440.png)：字段底部对齐，保存区明确。
- [手机复习](./evidence/UI09-after-review-390.png)、[手机造文](./evidence/UI09-after-create-390.png)、[试用全文](./evidence/UI09-after-explore-390.png)：重复入口和信息删减；核心输入、释义、完整内容仍可见。

自动检查没有替代用户对视觉质量的审阅。

## 静态、保护与交接

运行 `python3 .planning/milestones/M002/design/evidence/verify-ui09-static.py`，报告为 [UI09-static-results.json](./evidence/UI09-static-results.json)。检查 PAGE/CAP/DATA/UIA 对应、双语文案、模块语法、当前元数据与链接，以及 308 个受保护产品、CR、流程、旧证据文件的摘要。旧版本原件保持。

本版源与证据冻结为 [M002-UI-09.tar.gz](./evidence/M002-UI-09.tar.gz)，见 [冻结清单](./evidence/M002-UI-09-manifest.json) 和 [当前清单](./evidence/design-manifest.json)。本轮不修改正式应用，不调用真实 AI/API，不提交 Git，不切换阶段；CR-001/002 仍由守门器接收，CR039-L1、CR042-L1、AI-QUALITY-90 保持原状态。

未验证真实服务、生产认证和计量、跨设备/并发、Safari、物理手机、人工读屏和 200% 缩放。axe 无违规不是完整 WCAG 声明；新会话独立接收未执行，模型用量未知。当前是设计整稿待审。
