---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-17
date: 2026-09-18
---

# UI-17 设计验证

范围为 PAGE-206/214/215 的 ACCOUNT17：共享个人区、资料/安全、账号成长、道具卡和兑换中心。产品输入 PRODUCT-03；本稿待审，[UI-16 快照](./evidence/M002-UI-16.tar.gz) 及原件保持。

## 浏览器与视觉

运行 `node .planning/milestones/M002/design/evidence/verify-ui17.cjs`，[最终报告](./evidence/UI17-browser-results.json) 六组通过：

- 四视图 × 中英文 × 320/390/768/1440px，共 32 个布局，无页面横溢。390px 中文、1440px 英文每页各一次 axe，共 8 次，无违规；无浏览器运行错误或缺少文案。
- 个人信息修改昵称/性别、语言切换草稿、跨四页显示、空昵称回退；密码确认不一致、关闭弹窗焦点、注销确认取消、保存失败保留输入、长昵称窄屏。
- 成就/等级逐次手动领取：积分/经验/卡对应发放、已领禁用，展开组与稳定焦点保留；补签更新日历、消耗卡、积分补差而不补经验。
- 奖励不可用/停用/降级/领取失败，满级和空态仍有明确结果；失败不改变积分，空态不产生卡片。
- 兑换取消/确认、余额扣减与库存增加，模型重叠时长累加和逐模型日期，计划启用更新生效计划并禁止已覆盖模型卡，模型下架手动退分及已退禁用，积分不足/过期状态。
- 头像四入口、普通工具台四项可编辑及默认值、独立试用配置只读摘要回归。

[首次报告](./evidence/UI17-first-browser-results.json) / [首次脚本](./evidence/verify-ui17-first.cjs) 保留。两组首次失败为测试定位错误：取消文案按钮实际共用 data-action=close，脚本误用不存在的 cancel 动作。只修正测试定位，使用 `UI17_RETRY=1 node .planning/milestones/M002/design/evidence/verify-ui17.cjs` 重跑失败组，报告明确保留首次通过的其余组；不是产品故障。

另运行 `node .planning/milestones/M002/design/evidence/capture-ui17.cjs`，[最终截图记录](./evidence/UI17-capture-results.json) 为手机标题/积分对齐微调后的 12 个页面截图与溢出检查。实际打开检查 [个人信息桌面](./evidence/UI17-profile-1440-zh.png)、[成长桌面](./evidence/UI17-growth-1440-zh.png)、[兑换桌面](./evidence/UI17-shop-1440-zh.png)、[道具手机](./evidence/UI17-bag-390-zh.png)、[资料手机](./evidence/UI17-profile-390-zh.png)，以及最终成长/英文窄屏。共用左侧资料一致，字段/操作对齐，成就和升级奖励减少无意义留白，卡片的状态、效果、期限及价格层级清楚。修改前截图保留在 UI17-before-*，仅为对照，不作验收基线。

## 一致性、冻结与边界

新增 account.* 共 9 组双语文案，现有运营内容、规则与业务夹具不变。复用本地 Lucide；共享样式限定个人区，新生效计划显示读取原 BD.plan()，不新增权益算法。领奖焦点处理局限成长页。

运行 `python3 .planning/milestones/M002/design/evidence/verify-ui17-static.py`，[静态报告](./evidence/UI17-static-results.json) 核对 25 PAGE、28 视图、49 CAP、31 活跃 DATA、UIA、文案、JS 语法、版本和链接，及 505 个受保护输入/旧证据。[冻结包](./evidence/M002-UI-17.tar.gz) / [清单](./evidence/M002-UI-17-manifest.json) 与 [当前指针](./evidence/design-manifest.json) 同版；冻结核对 `evidence/UI17-freeze-results.json` 检查逐文件摘要和所有链接。

首次静态报告仅因链接指向尚未生成的冻结结果而失败，原件保留为 [UI17-first-static-results.json](./evidence/UI17-first-static-results.json)；文档改为标明冻结后报告路径，最终脚本再核对实际文件与链接。

这是可运行设计原型，未修改正式前端/后台、产品/CR/控制面，未提交 Git、调用 AI 或迁移阶段。未重跑后台/首页完整流程；生产接口、账务与权限、真机/iOS Safari、人工读屏和缩放、独立新会话交接未验证。模型实际用量未知；本次浏览器自检不代替独立 QA 或用户设计批准。
