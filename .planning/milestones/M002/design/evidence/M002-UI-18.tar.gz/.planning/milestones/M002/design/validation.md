---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-18
date: 2026-09-18
---

# UI-18 设计验证

范围为 PAGE-005 / LIBRARY18：书架统计、搜索、短文列表及管理/复习入口。输入 PRODUCT-03；[UI-17 快照](./evidence/M002-UI-17.tar.gz) 保留，用户对个人页的局部认可不等于全阶段批准。

## 浏览器与视觉

运行 `node .planning/milestones/M002/design/evidence/verify-ui18.cjs`，[最终报告](./evidence/UI18-browser-results.json) 五组通过：

- 320/390/768/1440px 中英文共 8 个布局：六项统计为 12/7/2/1/3/2，初始 b1/b2 从旧到新，标题、目标词和操作完整；无页面横溢。390px 中文、1440px 英文两个 axe 无违规，未发现运行错误/缺失文案。
- Enter 搜索及按钮搜索仅匹配目标词；标签不会命中，搜索不改六项全量统计；无结果、清除、已提交查询的语言切换和窄屏均正确，焦点回输入。
- 参与切换同步统计和日期范围命中，成功回焦、失败恢复原值；暂停的 b1 可直接复习，离开保存草稿，返回显示继续复习并先确认恢复。
- 加载第三篇后聚焦新增标题；详情改长标题返回保留已加载三篇及滚动位置，显示原目标词。搜索标题中的词无结果，搜索原目标词正常；带查询去详情再回列表保持查询和对应行焦点。
- 删除取消回焦、确认后库内统计改变而累计生成保持；删除失败不移除内容。首次空库有造文入口，加载/错误/重试可用。

[首次报告](./evidence/UI18-first-browser-results.json) / [首次脚本](./evidence/verify-ui18-first.cjs) 保留。参与失败场景本应自动恢复勾选，而 Playwright uncheck 要求最终未勾选，导致测试工具报错；改为真实 click 后断言恢复勾选及失败提示。只修正测试，使用 `UI18_RETRY=1 node .planning/milestones/M002/design/evidence/verify-ui18.cjs` 重跑该组，报告明确继承其余通过组。

实际打开检查 [桌面](./evidence/UI18-library-1440-zh.png)、[手机](./evidence/UI18-library-390-zh.png)、[窄屏英文](./evidence/UI18-library-320-en.png)、[长标题](./evidence/UI18-long-title-390.png)，与 [修改前桌面](./evidence/UI18-before-1440.png) 对照。统计区和列表更紧凑，书页图形只作装饰，阅读信息与操作分组明确；手机等宽按钮同高，管理行对齐。长标题截图包含保存后的短暂 toast，不代表固定卡片内容。另有搜索空结果与首次空库截图。

## 一致性与边界

固定文案复用 copy.json，新增双语搜索 placeholder，数量以篇短文表示批次，参与/暂停明确日期复习。配置枚举复用既有翻译，业务夹具不变。样式限书架区域，焦点/返回定位在 learning.js，未修改复习判分、权限或计量。

运行 `python3 .planning/milestones/M002/design/evidence/verify-ui18-static.py`，[静态报告](./evidence/UI18-static-results.json) 核对 25 PAGE、28 视图、49 CAP、31 活跃 DATA、UIA、双语文案、JS 语法、路径与版本，537 个受保护输入/旧证据保持。[冻结包](./evidence/M002-UI-18.tar.gz) / [清单](./evidence/M002-UI-18-manifest.json) / [当前指针](./evidence/design-manifest.json) 对应同一交付；冻结后结果在 `evidence/UI18-freeze-results.json` 核对逐文件摘要及链接。

这是可运行原型的浏览器自检，未修改正式应用/产品/CR/控制面，未提交 Git、调用真实 AI 或迁移阶段。未重跑个人中心/后台/首页完整流程；生产持久化/权限/删除事务、真机/iOS Safari、人工读屏/缩放、独立 QA 与新会话交接未验证。模型实际用量未知。
