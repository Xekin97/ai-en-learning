---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-16
date: 2026-09-18
---

# UI-16 设计验证

范围为 PAGE-204 / SETTINGS16：将认可的试用配置视觉用于普通造文的可编辑选择器，并保持连续编辑。产品输入 PRODUCT-03，设计整稿待审；[UI-15 快照](./evidence/M002-UI-15.tar.gz) 与原证据保持。

## 浏览器与视觉

运行 `node .planning/milestones/M002/design/evidence/verify-ui16.cjs`，[最终结果](./evidence/UI16-browser-results.json) 三组通过：

- 320/390/768/1440px 中英文共 8 个布局：模型/释义语言初始空、Story/Brief 默认，未填完整禁用生成；窄屏初始收起，展开选择后保持展开与当前控件焦点。四选择器保持原生可编辑，选项文案使用当前语言，页面无横溢。390px 中文、1440px 英文两个 axe 无违规。
- 手机连续选择场景和释义语言、切换界面语言、再次改场景、随机加词、生成，配置与展开状态保持；生成期间四项禁用，完成后仍显示选择值。
- 无额度/模型/合法长度保留禁用，长模型名不撑宽窄屏，独立试用台继续为四项只读摘要。

[首次报告](./evidence/UI16-first-browser-results.json) / [首次脚本](./evidence/verify-ui16-first.cjs) 保留。第二组发现真实问题：切换 UI 语言缓存 news 后，改选 business 仍被通用 restoreForm 覆盖为 news。普通配置四项已有 S 状态作为来源，修复为不由旧表单缓存重复恢复这四项；其他输入保持原缓存规则。仅重跑失败组 `UI16_RETRY=1 node .planning/milestones/M002/design/evidence/verify-ui16.cjs`，最终报告记录继承的通过组与合并来源。

实际打开检查 [桌面](./evidence/UI16-create-1440-zh.png) 和 [手机](./evidence/UI16-create-390-zh.png)，对照 [修改前](./evidence/UI16-create-before-1440.png)：模型分组突出，三行标签/选择框统一对齐，原生选择器清晰可辨。截图为用户已选 Model A/中文状态，初始仍要求显式选择；蓝色边框是保留的键盘焦点。另保存平板与 320px 中英文截图。

## 一致性、冻结与边界

未新增文案键，复用 config/model/style/length/explain 和 a.preset.* 的准确标签。共享 select 辅助函数只增加可选装饰图标参数，其他调用默认输出不变。样式局限 `.creation-settings`，业务夹具保持。

运行 `python3 .planning/milestones/M002/design/evidence/verify-ui16-static.py`，[静态报告](./evidence/UI16-static-results.json) 核对追踪、双语、模块、文档/链接和 487 个受保护输入/历史证据。[当前冻结包](./evidence/M002-UI-16.tar.gz) / [清单](./evidence/M002-UI-16-manifest.json) 保存一致版本，[当前指针](./evidence/design-manifest.json) 同步。

未重跑首页/后台全流程，未修改正式应用、产品、CR 或工作流，未提交 Git、未调用 AI。生产 API、真机/iOS Safari、人工读屏和缩放未验证，原型流程与 axe 不代表生产验收。独立新会话交接未执行，模型用量未知。
