---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-11
date: 2026-09-18
---

# UI-11 设计验证

范围为用户确认的「首页 → 精选 → 学习 → 复习 → 书架」及移除轮播播放/暂停控件，对应各用户页面 NAV11 与 PAGE-217 CAR11。输入仍为 PRODUCT-03，整稿视觉待审；UI-10 首页/图标与 UI-09 布局规范保留。原 [UI-10 冻结包](./evidence/M002-UI-10.tar.gz) 和证据不改写。

## 浏览器与交互

从产品根运行 `node .planning/milestones/M002/design/evidence/verify-ui11.cjs`；[结果](./evidence/UI11-browser-results.json) 的四组检查均通过：

1. 320/390/1440px、中英文、访客/学习者组合共 12 个首页布局，五项菜单文字、顺序及路由正确，无页面横溢。
2. 点击五个入口进入原有页面；试用、批次和复习高亮对应导航。书架标题及访客登录承接使用一致文案。
3. 精选页 1440px 中文、390px 中文、320px 英文共 3 个布局，控制区仅两个箭头与计数，无播放按钮或状态文案；箭头、Home 键、全文、释义筛选、单条/空态和正确预设跳转保持。三个 axe 扫描无违规。
4. 正常动效下实际等待首次 8 秒自动切换；鼠标进入可见文章后停止，移开后再等 8.5 秒位置保持；离开再进入恢复初始自动模式。触摸后停止，界面语言重绘保持停止，减少动效时无自动切换。

[首次报告](./evidence/UI11-first-browser-results.json) / [首次脚本](./evidence/verify-ui11-first.cjs) 保留。第四组首次失败是测试在自动到达第二卡后用 hover 定位第一卡，浏览器因此将第一卡滚入视口，而测试立即记录了尚未更新的计数。测试改为悬停当前可见的第二卡，再仅重跑该组：`UI11_CHECK='automatic preview' node .planning/milestones/M002/design/evidence/verify-ui11.cjs`。产品代码未因该测试修正而改变；最终报告保留首次通过的三组、布局和 axe 记录，并记录合并来源。

## 实际视觉

已打开检查 [桌面首页](./evidence/UI11-header-1440.png) 与 [手机精选](./evidence/UI11-gallery-390-zh.png)：五个短标签顺序一致，桌面与手机导航可读；手机前后按钮和计数靠右，配置、词签与完整正文保持，无页面横溢。截图中的蓝色轨道外框是键盘操作后的焦点圈。

另保存 [手机首页](./evidence/UI11-header-390.png)、[桌面精选](./evidence/UI11-gallery-1440-zh.png)、[320px 英文精选](./evidence/UI11-gallery-320-en.png)。截图和自动检查不代表用户已认可全部视觉。

## 静态、冻结与边界

[文案差异](./evidence/UI11-copy-changes.json) 记录双语菜单及书架用词同步、播放控件文案删除。运行 `python3 .planning/milestones/M002/design/evidence/verify-ui11-static.py`；[报告](./evidence/UI11-static-results.json) 核对追踪、文案、模块语法、版本、链接、实际导航与播放控件删除，以及 403 个受保护输入/控制文件/历史证据摘要。

当前源与证据冻结为 [M002-UI-11.tar.gz](./evidence/M002-UI-11.tar.gz) / [清单](./evidence/M002-UI-11-manifest.json)；[当前清单](./evidence/design-manifest.json) 指向本版。本轮未改产品、正式应用、工作流或 CR，未提交 Git、未调用真实 AI、未切换阶段。

本次没有重新执行全部旧版业务验证；继承结果只代表其原版本。未测生产 API、物理手机、Safari、人工读屏或 200% 缩放；axe 不等于完整 WCAG 认证。独立新会话交接未执行，模型用量未知。CR-001/002 与原开放验证事项保持原状态。
