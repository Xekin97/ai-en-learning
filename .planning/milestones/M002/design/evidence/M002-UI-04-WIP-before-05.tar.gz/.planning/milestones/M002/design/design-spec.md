---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-04
date: 2026-09-18
---

# 二期设计规格 · M002-UI-04


## 当前目标与有效范围

用户在二期产品阶段批准并进入 UI/UX 后，进一步回复“批准”，授权开始本次设计。产品批准来源为 [TRANSITION-M002-002](../reviews/product-planning.md)，完整规则见 [CAP-201–219](../product/abilities.md)；产品文件摘要已冻结，不由设计改写。

本版本覆盖 PAGE-201–216 及继承的 M001 PAGE-002/003/005/006/007/008/103，共 28 个原型视图；PAGE-205 为 home/explore，PAGE-208 为 models/plans，PAGE-213 为 adminhome/metrics，PAGE-215 为 bag/shop，用户管理为 users/userdetail 及 points 入口 credits。设计本身待用户审阅，未批准实施、未切换技术阶段。原型是本地示例，不连接账号、AI、积分或监控服务，不证明业务事务已实现。设计源冻结于 `evidence/M002-UI-04.tar.gz`，逐文件摘要见 [版本清单](./evidence/design-manifest.json)。

保留品牌名称词涟 / WordWeave、编织标识及 DEC-019 阅读质感。二期替代一期窄版心、居中复习、每题即时判对及单一收尾流程；新范围内不得套回这些旧行为。未受本期改变的登录、词库、复习日期选择、单篇入口、密码校验和账号删除策略继续引用 [M001 交接](../../M001/handoffs/uiux.md)。日期范围保留 ≤1080px 结果条、≥1081px 320px 侧卡及 ≤560px 日期纵排；本期造文配置继续使用自身 1100px 断点。

## 本轮用户修订 · M002-UI-02

用户明确要求头像下拉依次为“个人信息、账号成长、道具卡、兑换中心”，四个视图共用左侧个人基础信息、右侧具体内容；首页保持简洁，主导航增加“试用”，移除“学习成长”。本轮将这些要求同步到原型、文案、布局与交接，不增加业务能力。

旧 M002-UI-01 的主导航成长入口、头像直接跳个人页、独立个人资料侧栏、背包/兑换页签和首页多篇预设列表被本版本替代，不再作为当前前端接收标准。可恢复原稿见 `evidence/M002-UI-01.tar.gz`，原清单见 [M002-UI-01-manifest.json](./evidence/M002-UI-01-manifest.json)。批准产品原件保持冻结，本节记录用户随后对信息架构和展示位置的修订；原 PAGE/CAP/DATA 继续追踪。

## 一期学习者功能继承核查 · M002-UI-04

来源：用户指出“按日期复习、用户自己的复习库”被丢弃，随后指出“登录注册界面也没了”。核查确认原型只画了二期增量，遗漏了一期页面和连接；这不是用户新增范围。UI-03.1 的四项主导航、直接打开固定复习样例、按钮模拟登录、收录直接跳答题及简化改密/注销流程全部失效。

当前主导航为首页 / 造文工作台 / 复习库 / 复习 / 试用。“复习”进入日期选择；头像仍只有四个个人中心入口，无成长主导航。未明确被二期替换的一期功能继续保留，以下表格同时约束后续技术方案与实现。

| 一期能力与现有实现 | UI-03.1 缺口 | 当前合并结果与入口 |
|---|---|---|
| CAP-001 首页主任务；index.vue | 没有复习库，复习跳固定样例 | 保持简洁首页，通过导航提供造文、复习库、日期复习及试用 |
| CAP-002/003 注册登录；login.vue / register.vue | 没有页面与表单，直接切身份 | `login` / `register` 独立页面、用户名密码规则、确认密码、通用登录失败、用户名占用、注册登录互跳、管理员分流、受限入口返回；不增加邮箱/手机/找回密码 |
| CAP-004/005 账号生命周期；account.vue | 改密只有新密码，注销缺密码和二次确认 | 个人信息保留只读用户名/计划、当前密码+新密码+确认、其他会话失效说明；注销先校验密码及永久删除理解确认，再最终确认；退出保留 |
| CAP-006/007 选词配置；create.vue | 缺部分场景与释义语言 | 词表候选/精确添加/去重/多词条/上限；四场景、三种释义语言，长度按计划；Story/Brief 为二期默认，模型/释义语言仍显式选择 |
| CAP-008/009 生成/取消/失败 | 结果缺原词资源，离开无提示 | 模拟流完成后显示整篇短文、标签、每个原词释义及提示短语；进行中不能保存；取消不退次，失败返还，离开/放弃确认；真实完整性校验仍属后端 |
| CAP-010/011 收录与访客承接 | 收录直接跳固定复习样例，无复习库数据 | 完整结果收录为整批 → 批次详情 → 复习库可按目标词找到；放弃不产生批次；访客登录/注册后一次收录、不重调模型、不再扣次、先收录后提醒；丢失状态明确 |
| CAP-012/013 复习库；library/index.vue | 整页缺失 | `library`：六项全量摘要、仅目标词搜索、旧到新、续载、参与和暂停批次均可见；查询/已加载结果在打开详情返回时保留 |
| CAP-014 详情；library/[batchId].vue | 整页缺失 | `batch`：完整原文、标签、原词资源、保存时间、生成快照及成功次数，只读；原模型下架不改写快照，无历史作答结果 |
| CAP-015/016 参与与删除 | 没有用户自己的内容管理 | 列表/详情可切换“参与日期范围复习”，只影响新范围；直接复习始终可用。永久删除确认明确无法恢复，库内数量更新，二期累计成长不回退 |
| CAP-017 日期范围；review/index.vue / ReviewRangeSetup.vue | 整页缺失 | `range`：最近七天、起止包含、只选参与批次、命中数量、日期错误/零命中/未知数量、未完成范围入口；原生日期控件保持编辑焦点 |
| CAP-018/019 答题 | 独立固定样例没有上下文 | 从实际选定批次读取原词和短文；固定两层随机顺序，同原词重复词形匿名分组；二期改为字母槽位、非空前进、概览修改后提交 |
| CAP-020/022 会话、恢复、单篇入口 | 一个全局草稿，下一批实际重来同样例 | 日期范围与每个单篇分别保存未提交草稿、步骤、顺序；暂停批次也可单独复习；恢复询问，重来只清本批；提交保存最小事实，下一批推进不同批次，已完成不重放；结束给会话概况 |
| CAP-021 语言 | 部分表单/内容保持未覆盖 | 页面及全局中英文；切换保持任务和暂存密码（仅内存）；保存释义语言与 UI 语言分开，界面切换不翻译历史材料 |
| CAP-101–107 后台 | UI-03 已恢复 | 沿用下表八模块与 M001 后台完整能力；本次不以学习者整改替换后台 |

上述路径使用 `prototype/learning.js`、`identity.js` 及 app.js 生成模块。代码对照位于产品仓库 `frontend/app/pages/`；能力真源为 [M001 能力](../../M001/product/abilities.md)及[页面职责](../../M001/product/pages/index.md)，只用二期已批准差异替换原规则。

原型页签与底部显示 `M002-UI-04`，资源使用同一版本参数；此前用户已确认看到了最新 UI-03.1，本轮是功能遗漏整改，不再归因于预览版本。历史 UI-03.1 快照与 [清单](./evidence/M002-UI-03.1-manifest.json)保留。

## 后台总体对照与整改 · M002-UI-03

来源：2026-09-18 用户先指定七个模块，随后明确“消息管理还是要独立的”，最终为八个一级模块；并要求对照 M001 实现补齐总体需求。原 UI-02 后台六项导航、模型计划混页、缺少用户管理及仅展示部分字段的设计已失效。本轮按以下总表完成替换；UI-01/02 检查不代表本轮后台通过。个人中心 UI-02 布局继续有效；学习者主导航按 UI-04 补回复习库和日期入口。

| 模块与入口 | M001 必须继承 | M002 合并内容 | 旧稿缺口 / 本轮接收要求 |
|---|---|---|---|
| 概览 `adminhome` | 独立管理员壳层、语言切换与退出 | CAP-219 的核心指标摘要和其余七模块入口 | 旧稿只有混合监控；概览与详细分析分开，摘要复用同一口径 |
| 数据分析 `metrics` | 无旧统计页 | PAGE-213 / CAP-219 流量、渠道、跳出率、漏斗、失败、留存、WAU、频次、生成/收录、独立预览用量、Clarity | 指标全部保留，空分母/观察中/延迟/无来源明确，不新增未定义成本 KPI |
| 模型管理 `models` | PAGE-101 / CAP-101/102：全局 OpenRouter 密钥脱敏/替换；模型新增、名称/说明/原始 ID、启停、计划引用 | PAGE-208 / CAP-205 模型移除，关联计划/卡/预设影响；CAP-206 操作反馈 | 旧稿只剩名称和移除。完整恢复配置；密钥不回显，不把停用等同删除；历史内容保留 |
| 计划管理 `plans` | PAGE-102 / CAP-103：visitor/basic/pro/plus 固定四组、模型多选、四档长度、最大词条正整数、滚动 24h 次数或不限、允许保存不可生成配置但警示 | PAGE-208 / CAP-216：唯一档位优先级、权益即时影响基础/体验用户、用量与期限不重置 | 旧稿合页、仅两档优先级和少数字段。独立完整编辑器；成长多档不解释为可增删基础计划 |
| 用户管理 `users` / `userdetail` / `credits` | PAGE-103 / CAP-104–107：用户名搜索、结果续载/返回保留、角色与基础计划、换计划确认重置、密码重置使旧会话失效、只读批次/原词释义/短语/标签/配置 | PAGE-211 / CAP-217 正数补发和积分来源；CAP-209/214 个人资料/等级/经验；D2-55 仅指定用户基础计划调整重置 | 旧稿用户管理完全缺失，积分页不能代替用户管理。详情分资料与计划、等级与成长、积分、学习记录；等级经验只读，规则到成长运营配置；无代复习/删除用户/内容编辑/历史答案 |
| 成长运营 `operations` | 全局后台权限与双语 | PAGE-210 签到、经验、等级、四类成就多档、手动奖励、四类道具管理 | 补齐双语名称/说明/称号、分类奖励、保留编辑草稿、档位启停/查找；消息不归入本模块 |
| 消息管理 `messages` | 全局后台权限与双语 | PAGE-209 / CAP-210 中英文 Markdown 公告、显示/提醒开关、列表和预览 | 根据用户纠正保留独立一级入口；原先拟归成长运营的解释撤销 |
| 首页预设 `presets` | 现有生成支持的场景/长度/释义语言 | PAGE-212 / CAP-218：完整配置、双语展示、草稿与线上分开、生成预览/失败取消、发布/下架、独立预览用量 | 旧稿未正确分离各预设的预览和发布状态，缺完整选项。按每条预设维护草稿与线上快照，参数修改重新预览；对应前台入口仍在“试用” |

代码对照：[模型页](../../../../frontend/app/pages/admin/models.vue)、[计划页](../../../../frontend/app/pages/admin/plans.vue)、[用户搜索](../../../../frontend/app/pages/admin/users/index.vue)、[用户详情](../../../../frontend/app/pages/admin/users/[userId]/index.vue)、[后台契约](../../../../frontend/app/infrastructure/http/schemas/admin.ts)。产品来源：[M001 管理职责](../../M001/product/pages/index.md#3-管理员页面)、[M001 能力](../../M001/product/abilities.md)、[M002 页面](../product/pages/index.md)及 CAP-205/206/210/214–219。此对照修复设计遗漏，不改写批准产品或应用代码。UI-02 原稿保留于 `evidence/M002-UI-02.tar.gz` 与 [原清单](./evidence/M002-UI-02-manifest.json)，其后台结构退出当前标准。

## 设计表达

以“故事带来记忆”为主线。首页是大字号双栏编辑式构图：左侧价值与主动作，右侧带高亮目标词的纸张；漂浮词签提示词与故事的关系。背景保持纸白，以深绿承载主要动作，浅绿、杏色、粉色、淡黄提供活力与模块识别。避免用装饰阻碍阅读，不依赖动效解释功能。

复习页面用左侧步骤导航和右侧宽内容区建立完整路径，填写、提示和下一动作按阅读顺序排列。个人中心四个视图共用左侧基础资料与分区导航，右侧分别呈现个人信息、账号成长、道具卡、兑换中心；积分与经验始终分开。后台改为稳定导航与高密度表格，复杂编辑用对话框，危险后果在确认前说明。以上为用户交由设计决定范围内的设计提案，具体颜色不是新增产品规则。

无外部图片、字体或服务依赖。品牌 SVG 源于 `frontend/app/presentation/components/BrandMark.vue` 的几何路径，调色遵守本期 Token；本地系统字体回退，首页纸张、纹理、徽记均为 HTML/CSS/SVG。没有使用 Figma 或生成位图资源。

## 打开原型

在产品仓库根目录执行：

```sh
python3 -m http.server 4174 --bind 127.0.0.1 --directory .planning/milestones/M002/design
```

访问 [本地原型](http://127.0.0.1:4174/prototype/?page=home)。依赖浏览器与 Python；需要 HTTP 服务读取 JSON，不能直接双击 HTML。控制条明确标为“二期交互原型 · 示例数据”，打开后可切换全部页面与场景，不属于生产产品 UI。

- `?page=…&lang=zh|en&state=…` 是可复现入口。`role=guest` 用于试用承接；默认模拟已登录学习者，管理页属于管理员示例身份。
- [copy.json](./copy.json) 是全部固定文案与动态模板来源，`static` / `templates` 映射中的 `zh.` 和 `en.` 前缀表示界面语言。原型通过 fetch 直接消费，切换语言不改变填答数据。
- [fixtures.json](./prototype/fixtures.json) 保存演示用户、运营样文、词条、奖励数值和日期；它们不是生产初始配置、真实用量、完整词库或 AI 质量样本。实际产品由 DTO 传入，不导入示例数据作为业务常量。
- 后台入口：[概览](http://127.0.0.1:4174/prototype/?page=adminhome)。后台使用独立壳层；[admin.js](./prototype/admin.js) 承载八模块导航、模型/计划/用户，[operations.js](./prototype/operations.js) 承载成长配置，[presets.js](./prototype/presets.js) 承载每条预设的草稿、预览和线上状态；消息和数据分析由 app.js 渲染。
- [theme.css](./theme.css) 是设计 Token 与实际样式；[app.js](./prototype/app.js) 是布局、标识和可操作状态来源；[追踪表](./traceability.json)在创建界面前由批准页面职责建立。

## 页面、能力与状态入口

除表中状态外，所有页面可从控制条进入 loading/error；业务数据为空时按各页职责保留操作入口。原型状态是独立演示，不代表服务端返回格式。

| 页面 | 能力 / 数据 | 原型入口 | 关键场景 | 源函数 / 区域 | 文案键 |
|---|---|---|---|---|---|
| M001 PAGE-002/003 注册/登录 | CAP-002/003/011/021；DATA-003/004/017/018 | `?page=login&role=guest` / `?page=register&role=guest` | auth-error / username-taken / admin；待收录或返回目标 | `identity.js view / #identity-form / .auth-intent` | `i.*, login, welcome` |
| M001 PAGE-005 复习库 | CAP-012/013/015/016/020/022 | `?page=library` | empty / save-error；目标词搜索/参与/删除/单篇 | `learning.js library / .library-stats / #library-query / .library-row` | `l.library.*, l.stat.*, l.search*, l.participate*, l.delete*` |
| M001 PAGE-006 详情 | CAP-014/015/016 | `?page=batch&batch=b1` | unavailable / save-error | `learning.js detail/resources / .batch-detail / .resource-grid` | `l.detail, l.snapshot, l.resources, l.readonly` |
| M001 PAGE-007 日期范围 | CAP-017/020；M002 CAP-204 | `?page=range` | empty / preview-error / preview-loading；非法日期/无匹配/可恢复 | `learning.js range/updateRange / .range-editor / #range-from / #range-to` | `l.range*, l.dates*, l.matches*, l.resume*` |
| M001 PAGE-008 会话完成 | CAP-020/022；M002 CAP-203 | 最后一批“完成” → `sessiondone` | 单批/多批完成概况，无历史答案 | `learning.js done / .session-totals` | `l.sessiondone*, l.total.*` |
| PAGE-201 复习填写 | CAP-201 / CAP-204 / CAP-206；DATA-201，原 DATA-012/013/014 | `?page=review` | normal / resume / denied；实际填写后刷新恢复 | `review / .review-layout / .slots / .hint / [data-region=passage]` | `review.*, slot, gap, previous, next, skip` |
| PAGE-202 当前批次概览 | CAP-202；DATA-201 | `?page=overview` | normal / submit-error / response-lost；从复习进入保留最新输入 | `learning.js review / .answer-row / .answer-link / #submit` | `overview.*, wordanswers, passageanswers, unanswered, submit` |
| PAGE-203 提交后总结 | CAP-203 / CAP-213；DATA-202/203/208 | `?page=summary` | 从当前批次提交进入；直接 URL 不恢复历史总结 | `learning.js review / .result-word / .review-footer` | `summary.*, correct, incorrect, restart, finish, nextbatch` |
| PAGE-204 造文工具台 | CAP-206 / CAP-208 / CAP-216；DATA-203/211，原词表、计划、生成资源 | `?page=create` | normal / noquota / nomodel / nolength / failure；生成后可停止或收录 | `generation / .settings / #generate / [data-region=generation-result]` | `create.*, random, model, style, length, explain, quota` |
| PAGE-205 首页与快速试用 | CAP-207 / CAP-218；DATA-212 | `?page=home` / `?page=explore` | 首页 normal；试用 normal / empty | `home / [data-region=hero]`；`explore / #presets` | `hero.*, explore.*, home.*, path.*, try, sample` |
| PAGE-206 个人资料 | CAP-209；DATA-204 | `?page=profile` | normal / empty / save-error | `accountShell / .account-sidebar`；`profile / #profile-form` | `profile.*, nickname, gender, i.*, lastlogin, lastlearn, welcome` |
| PAGE-207 消息列表与正文弹窗 | CAP-210；DATA-205 | `?page=notices` | normal / empty；通过 Header 打开，登录模拟触发正文 | `notices / .notice-entry / #dialog` | `notices.*, notice.*, position` |
| PAGE-208 模型和计划管理；继承 M001 PAGE-101/102 | CAP-205/206/216 + CAP-101–103；DATA-211，原 DATA-006/007/008 | `?page=models` / `?page=plans` | normal / save-error / missing-key；新增编辑启停/移除、全部模型与长度、零与不限、优先级重复 | `admin.js models/modelForm/modelImpact/plans / #plan-limit / #plan-unlimited` | `a.model.*, a.key.*, a.plan.*, a.length.*, plan.*, priority` |
| PAGE-209 平台消息管理 | CAP-210；DATA-205 | `?page=messages` | normal / save-error；编辑、预览、隐藏、提醒 | `messages / #body-zh / #body-en / #dialog` | `messages, markdown, visible, remind, preview` |
| PAGE-210 成长运营配置 | CAP-214 / CAP-215 / CAP-217；DATA-206/208/209/210 | `?page=operations` | normal / save-error；四个页签、四类道具、六档及更多 | `app.js operations/itemForm；operations.js body/handle / .tier-table` | `operations, item.*, threshold, reward*, addtier` |
| PAGE-211 用户积分管理（并入用户详情） | CAP-217；DATA-207 | `?page=credits`，或 userdetail 积分页签 | normal / save-error；非正补发拒绝、确认、来源流水 | `admin.js points / #credit-amount / #found-user` | `a.ledger, a.source.*, credit.rule, positive` |
| M001 PAGE-103 用户管理 | CAP-104–107；M002 CAP-209/214/216/217；原 DATA-003/004/006/009/012/013/015，DATA-204/207/208/209/211 | `?page=users` / `?page=userdetail` | 查询前/结果/无结果/续载；search-error/save-error/unavailable；角色差异/密码不符/只读学习库 | `admin.js users/userdetail/identity/growth/library/reader / #admin-user-query / .admin-facts` | `a.users.*, a.user.*, a.password.*, a.growth.*, a.library.*` |
| PAGE-212 热门预设管理 | CAP-218；DATA-212/214 | `?page=presets` | normal / failure / save-error；预览前后、参数失效、手动发布 | `presets.js page/handle / #preset-words / [data-action=preset-publish]` | `presets, preset.*, preview.*, publish.*, usage` |
| PAGE-213 全局监控 | CAP-219；DATA-213/214 | `?page=adminhome` / `?page=metrics` | normal / empty / delayed；概览摘要、完整分析；D30 未成熟、热力图不可用 | `admin.js home；app.js metrics/metricDetails / .metrics-grid / .chart / .stats` | `metrics.*, uv, pv, wau, failure, retention` |
| PAGE-214 账号成长 | CAP-211 / CAP-212 / CAP-213 / CAP-214；DATA-203/206/207/208/209 | `?page=growth` | normal / empty / blocked / disabled / demoted / maxlevel | `accountShell / .account-sidebar`；`growth / .growth-banner / .calendar / .achievement-grid` | `growth.*, signin.*, reward.*, claim*, maxlevel` |
| PAGE-215 积分兑换与背包 | CAP-215 / CAP-216；DATA-207/210/211 | `?page=bag` / `?page=shop` | 道具 normal / empty / covered / retired / expired / active / lower；兑换 normal / empty / insufficient | `accountShell / .account-sidebar`；`bag(false/true) / .items-grid / #dialog` | `bag.*, shop.*, card.*, covered, useby, ends, pricevalue` |
| PAGE-216 独立预设造文工作台 | CAP-218；DATA-212，原生成与认证承接资源 | `?page=trial` | normal / invalid / noquota / failure；role=guest 演示认证收录 | `generation(true) / .settings / #generate` | `preset.*, create.*, quota, guestcollect` |

## 内容顺序与动态边界

首页顺序：品牌导航（首页 / 造文工作台 / 复习库 / 复习 / 试用）→ 主标题/价值说明/造文与试用入口 → 一篇管理员示例纸张 → 简短三步学习路径。多篇预设集中在独立“试用”视图，不在首页堆叠；头像中的账号成长不进入主导航。示例始终带 `sample`，没有真实生成数量或未经证实的效果承诺。

复习顺序：页面说明与概览入口 → 进度 → `review.spell` → 字母槽位 → `review.translation` → `review.phrase` 开关 → 上一步/跳过/下一步。短文每个空宽度一致，以纹理与颜色标出同原词组；隐藏答案不写入输入的值、placeholder、aria-label 或长度。原词槽位长度则按已确认需求展示。

概览：单词答案/未作答 → 填入当前答案的短文 → 返回/提交。总结：两阶段结果 → 当次可用说明 → 完成/下一批/整批重来。错误是删除线与正确词并列，未答显示 `unanswered` 加正确词；不只靠颜色，不提供最近结果或历史回看。

个人中心：共用左侧头像、昵称/用户名、上次登录/学习时间和四项分区导航；右侧按所选视图展示。昵称为空回退用户名，修改成功同步左栏和头像入口。道具卡：积分 → 已拥有道具作用 → 状态 → 启用截止或体验结束 → 可执行动作。兑换中心：积分 → 在售道具 → 积分价格 → 兑换确认；成功留在兑换中心提示到账，可从左栏进入道具卡。计划完全覆盖模型卡时保留库存并显示指定 `covered` 文案；已经启用再被覆盖时显示原结束时间。下架退换按钮优先于自然过期状态，确认展示当前退换积分和该卡剩余授权终止的结果。

| 动态模板 | 变量和真实数据来源 | 缺值 / 格式 | 原型样例 |
|---|---|---|---|
| welcome | name 为昵称或用户名；days 为上次有效学习日与当前学习日差 | 北京时间 04:00 分界；首次/从未学习/当天分别用 welcome.first / nolearn / today，不把登录时间当学习时间 | 小涟 / 2 |
| quota / wordcount | 服务端可用次数、已选词数和上限 | 未知显示加载，0 可见并禁止调用；不以 UI 计算代替鉴权 | 5 次 / 3 个词 |
| step / slot / gap / position | 当前题号、槽位、空位、消息位置 | 从 1 开始；不包含隐藏答案 | 1 / 3 |
| reward / progress / newmastery | 当前奖励配置、经验门槛、当次新增去重词数 | 无结果不编造 0；初始等级无升级奖励 | 30 分/20 XP；260/400 |
| useby / ends | 未启用期限、每模型累计授权期限 | 明确北京时间，模型卡逐模型展示，不合并成一个截止时间 | 2026-10-17 / 09-20 与 09-23 |
| pricevalue / updated / streak | 当前积分或价格、统计更新时间、连续学习日 | 下架积分在确认与提交时读取最新值；缺失费用显示 unknown | 320；12:04；7 |

运营内容用当前界面语言，缺译回退已有另一语言；英文学习正文和释义目标语言不随界面语言自动翻译。Markdown 原型仅演示标题、段落、加粗与安全转义；生产渲染允许集合由技术方案明确，禁止脚本与不安全链接。

## 详细规则与验收

详细规则集中在 [交互规范](./interactions.md) 与 [响应式和可访问性](./responsive-accessibility.md)，不在前端交接中另写一套。以下为局部 UI 验收，产品 AC 仍是业务验收依据。

| UI 验收 ID | 来源/场景 | 必须保持 | 方法与允许差异 |
|---|---|---|---|
| UIA-PAGE-201-01/02 | CAP-201/204，错答/中断 | 非空可前进；概览不判分；恢复提示可恢复；修改其他答案不丢失 | 浏览器填写、返回、刷新；DOM 实现可变，顺序/文案/保留规则不变 |
| UIA-PAGE-202-01 | CAP-202/203，部分填空提交 | 允许留空，最终总结标错/未答并给正确答案 | 实际提交检查；业务幂等交后端验收 |
| UIA-PAGE-203-01 | CAP-203，全对/重来 | 正确项不重复显示错词；重来整批清空，离开不留历史答案 | 实际操作和本地草稿检查；直接 summary URL 显示不可恢复说明 |
| UIA-PAGE-204-01 | CAP-206/208/216 | Story/Brief 默认，模型/释义语言显式选择；随机不重复已选；额度单处显示 | 多词/无候选/超限；原型也排除当前库词；真实接口须重验 |
| UIA-PAGE-216-01 | CAP-218 | 预设只读，点击才生成，认证承接收录后才弹消息 | 浏览器；原型模拟流，不证明真实模型输出或认证幂等 |
| UIA-PAGE-214-01/02 | CAP-214 | 手动领奖、已领取禁用、不可领有原因、降级暂停升级奖励 | 点击/状态入口；奖励事务与最新配置竞争交后端 |
| UIA-PAGE-215-01/02 | CAP-215/216 | 模型全覆盖禁用，退换手动一次，高档覆盖明确损失确认 | 真实控件操作；生产需服务端重验卡状态、积分与等级 |
| UIA-PAGE-210-01/02 | CAP-217 | 四类字段隔离，新建未上架、类型固定、有历史不能删除、支持六档以上 | 创建/编辑/切页签；库存来源不能由前端猜测 |
| UIA-PAGE-211-01 | CAP-217 | 仅正数补发，无扣减或撤回入口 | 输入负数/零；真实用户查询和流水接口待技术设计 |
| UIA-PAGE-212-01 | CAP-218 | 有效预览才能发布，参数改变需重新预览，草稿不改线上 | 控件门控测试；原子版本发布由后端落实 |
| UIA-PAGE-209-01 | CAP-210 | 隐藏消息不进列表，Markdown 不执行脚本 | 浏览器操作与转义测试；生产富文本完整安全策略另验 |
| UIA-SHELL-01/02 | 本轮用户修订；CAP-209/211–216 | 头像恰好四项；共享左侧资料；右侧独立内容；个人中心无主导航成长入口 | 菜单键盘/外点关闭、四视图切换、昵称修改与空值回退 |
| UIA-PAGE-205-02 | 本轮用户修订；CAP-207/218 | 首页简洁，主导航试用进入预设浏览，再到锁定工作台；均不自动生成 | 访客实际点击和无生成状态验证 |
| UIA-PAGE-215-03 | CAP-215/216 | 兑换与道具独立视图；兑换到账后从道具卡可见 | 确认兑换并切换视图；真实积分事务待实现 |
| UIA-GLOBAL-01 | CAP-206/207 | ≤1440 版心，移动无页面横溢，减少动画偏好生效 | 320/390/1440/1920、zh/en；表格内部允许滚动 |
| UIA-GLOBAL-02 | 全局辅助技术 | 可命名控件、清晰焦点、对话框焦点限制、错误非单色 | Chromium + axe；真机和人工读屏另验 |

## 学习者继承验收

[verify-learning.cjs](./evidence/verify-learning.cjs) 中 LEARN-01–13 对应上表：导航与认证返回；注册/登录/语言；改密与注销；复习库；详情/参与/删除；日期边界；独立会话；恢复关闭与重来；多词条/匿名组/去重；多批次推进；生成收录和随机排除；访客承接；生成中断与承接丢失。期望来自 M001 产品及二期明确替换条目，不能以未写页面而把有效需求标成范围外。

## 后台补齐验收

| 验收 ID | 来源 | 可观察结果 |
|---|---|---|
| ADM-01 | 用户本轮八模块及消息独立要求 | 八项独立入口、当前项标记、独立管理员头部、退出 |
| ADM-02/03/04 | M001 CAP-101/102 + CAP-205/206 | 密钥不回显；模型完整增改启停；移除列出真实关联并允许取消；失败保留输入 |
| ADM-05 | M001 CAP-103 + CAP-216 | 四个固定计划、模型/四档长度多选、词数、滚动次数、零/不限、唯一优先级、保存确认影响，切计划不丢未保存输入 |
| ADM-06/07/08 | M001 CAP-104–106 + D2-55 | 搜索忽略大小写、续载/返回保留；只给学习者调整正式计划和重置密码；只重置指定基础计划；密码确认说明旧会话终止 |
| ADM-09/10 | CAP-217 + M001 CAP-107 | 积分仅正数补发、确认后流水；经验不联动；学习库及完整阅读只读，含原词释义/短语/标签/配置，无历史答案 |
| ADM-11 | CAP-214/217 | 动态多档与查找、双语名称/说明/称号、奖励道具及数量、引用可定位；初始等级无奖励，门槛递增 |
| ADM-12/13 | CAP-218 | 支持平台现有全部场景/长度/释义语言；草稿不改线上；已有有效预览可复用展示文字修改；参数变化重新预览；失败/取消/下架明确 |
| ADM-14 | CAP-210 + 用户消息独立要求 | 消息有独立导航、列表和双语编辑；隐藏优先、提醒开关、Markdown 安全预览 |
| ADM-15 | CAP-219 与手机后台导航 | 复习成功和当日激活单列；取消/进行中/预检拒绝不计失败率；手机当前栏目可见 |

检查脚本与结果见 [后台检查](./evidence/verify-admin.cjs) / [机器结果](./evidence/admin-results.json)。上述是原型行为，真实凭据存储、会话吊销、权限、积分事务和模型调用必须在实现阶段验证；不将模拟成功解释为后端实现。

## 自检与剩余验证

浏览器结果、截图、执行脚本及版本对应关系见 [设计自检](./validation.md)。当前是待审原型，应用前端尚未转换，API/认证/配额/积分事务、真实生成质量与监控采集未接入；不要将原型通过当成生产验收。

没有新业务问题或范围扩展。草稿跨设备/保留期、事务与并发、接口契约继续交技术设计。原型只把未提交草稿放本地演示存储，结果不持久化；这不是对生产存储的选择。数值由运营后台配置，示例不冻结。
