---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-21
date: 2026-09-20
---

# M002 UI/UX 交接 · designer-tony

输入 [M002-PRODUCT-03](./product.md) / [TRANSITION-M002-006](../reviews/product-title-revision.md)，Profile consumer-ai-web@1.0.0，revision `b5badf88cd7194400c3d4d0e9395e7c98490dc26`。仍为 uiux-design，整稿待审。

用户要求 Toast 淡入淡出，原话与范围见 [UI21-reception.json](../design/evidence/UI21-reception.json)。采用纯透明度变化，淡入 300ms→欢迎完整可读十秒→淡出 300ms；普通反馈中间五秒。替代旧进入位移动画与直接隐藏，保持 UI20 天数强调和消息上层显示。没有新增业务或待确认假设。

- [登录原型](http://127.0.0.1:4174/prototype/?page=login&role=guest&lang=zh&v=M002-UI-21)。开启常规动态效果后登录观察完整过程；减少动效时直接显示/隐藏。
- [设计规格](../design/design-spec.md) 欢迎提示与反馈层级 / TOAST19；[交互](../design/interactions.md)、[响应式](../design/responsive-accessibility.md)。PAGE-003 / CAP-209 与 PAGE-207 沿用原映射，25 PAGE / 28 视图 / 49 CAP / 31 活跃 DATA 不变。
- [app.js](../design/prototype/app.js) 的 toast / hideToast / toastMotion：单一动画时间线、完成信号后隐藏、替换取消旧动画、减少动效即时响应；[theme.css](../design/theme.css) 的 --toast-fade 为 300ms，移除 toast-enter。文案、天数计算与通知触发不变。
- [验证](../design/validation.md) 与原始浏览器报告：实际透明度帧、十秒停留、翻页/关闭/重开、短屏、反馈替换及减少动效。首次验证暴露计时器提前截断淡出，已改为等待动画完成；详见原报告和当前结果。

[当前冻结包](../design/evidence/M002-UI-21.tar.gz) / [清单](../design/evidence/M002-UI-21-manifest.json) / [当前指针](../design/evidence/design-manifest.json)；[UI-20 原件](../design/evidence/M002-UI-20-manifest.json) 保留。591 个受保护原件不变。仅就地更新当前设计，未改正式应用或控制面、未提交 Git/切换阶段。

下一步继续设计审阅；CAP-209 同日专门文案仍需接入。生产浏览器兼容、真机/Safari/人工读屏、独立 QA 与新会话交接未验证；其他既有页面与规则继续有效。CR-001/002、CR039-L1、CR042-L1、AI-QUALITY-90 保持。模型用量未知，无本轮阻塞项。
