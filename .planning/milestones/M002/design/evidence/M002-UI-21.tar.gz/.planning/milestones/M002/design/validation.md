---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-21
date: 2026-09-20
---

# UI-21 设计验证

范围为 PAGE-003 / PAGE-207 的 TOAST19 动效，输入 PRODUCT-03。用户要求见 [接收记录](./evidence/UI21-reception.json)，[UI-20 快照](./evidence/M002-UI-20.tar.gz) 保留。

运行 `node .planning/milestones/M002/design/evidence/verify-ui21.cjs`，[当前浏览器报告](./evidence/UI21-browser-results.json) 覆盖两组：

- 实际 requestAnimationFrame 帧序列记录透明度、动画时间与顶层承载，验证 300ms 淡入、十秒完整可读停留、300ms 淡出。消息翻页、关闭和重开保持同一个动画对象；退出帧仍位于 modal 上层，透明度接近零后才隐藏并清除避让。普通反馈使用同一动效，中间停留五秒。
- 320×568 短屏保留 24px 天数，提示与操作分离；运行中开启减少动效会取消动画并保留内容。减少动效下新反馈直接显示；连续保存取消旧动画、仅保留一个新动画，最新内容正常。

实际视觉检查 [手机](./evidence/UI21-welcome-320.png)、[桌面完整显示](./evidence/UI21-welcome-steady-1440.png) 和 [桌面淡出中间帧](./evidence/UI21-welcome-exit-midpoint-1440.png)。中间帧截图为暂停在退出中点的视觉示意；连续帧记录才是实际动效证据，不能以截图证明时序。

## 修正与证据边界

[首次报告](./evidence/UI21-first-browser-results.json) 与 [第二次报告](./evidence/UI21-second-browser-results.json) 在短暂退出窗口之后才读取顶层状态，跨浏览器调用已越过隐藏时刻；改为同帧记录。随后 [第三次报告](./evidence/UI21-third-browser-results.json) 暴露动画首帧晚于计时器启动的问题：墙钟定时器可能在透明度仍约 0.47 时截断淡出。现改为动画 finished 信号再隐藏；新反馈取消的旧动画不能触发清理。断言按动画时间划分阶段，并要求退出接近透明；原报告和对应脚本保留。最终完整重跑两组，结果以当前报告为准。

运行 `python3 .planning/milestones/M002/design/evidence/verify-ui21-static.py`，[静态报告](./evidence/UI21-static-results.json) 核对当前文案、JS、版本、路径、25 PAGE / 28 视图 / 49 CAP / 31 活跃 DATA 与 591 个受保护原件。[冻结包](./evidence/M002-UI-21.tar.gz) / [清单](./evidence/M002-UI-21-manifest.json) / [当前指针](./evidence/design-manifest.json)，冻结后校验见 `evidence/UI21-freeze-results.json`。

只修改设计原型和交付文档；无正式应用/产品/CR/控制面变更、Git 提交或真实 AI 调用。未重跑中英文全布局/axe/其他页面完整流程，未验证真机/Safari/人工读屏、独立 QA 与新会话交接。同日专门欢迎文案仍待接入 CAP-209。模型实际用量未知，整体设计仍待审。
