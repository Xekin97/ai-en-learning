---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-24
design_version: M002-UI-24
approval: pending_new_visual_review
date: 2026-10-01
---

# M002 设计交接 · designer-tony

**当前交付为 UI24：继承 UI23 五项追加设计，完成消息列表布局优化，等待用户视觉审阅。** 输入 [PRODUCT04](./product.md)，来源 [CR025](../changes/CR-025.md) 及用户对消息列表的后续反馈，接收门保持 [TRANSITION-M002-062](../reviews/product-design-062.md)。UI22/H01 的验收记录与 M002 原 UAT/收尾记录保持；当前阶段仍为设计，正式应用尚未应用这些追加视觉。

先读 [前端差异及 M001 继承表](../design/frontend-delta.md)，再按验收 ID 定位 [设计规格](../design/design-spec.md)、[交互](../design/interactions.md)、[响应式](../design/responsive-accessibility.md)、[文案](../design/copy.json) 与 [主题](../design/theme.css)。同版交付证据为 [验证结果](../design/validation.md)、[当前清单](../design/evidence/design-manifest.json)、[UI24 完整快照](../design/evidence/M002-UI-24.tar.gz)。

## 当前可审阅原型

- [消息](http://127.0.0.1:4186/prototype/?page=notices&lang=zh&v=M002-UI-24)：UI24 标题与列表共用居中 880px 栏、同一纸面细分隔、日期/标题/箭头三列，手机日期上置。点击沿用 UI23 固定标题/操作、正文独立滚动的阅读弹窗及暖白深绿 Markdown。
- [首页](http://127.0.0.1:4186/prototype/?page=home&lang=zh&v=M002-UI-24)：继承 Why Wordweave 三项优势，原叠卡、动效与入口保留。
- [精选](http://127.0.0.1:4186/prototype/?page=explore&lang=zh&v=M002-UI-24) 与 [预设管理](http://127.0.0.1:4186/prototype/?page=presets&lang=zh&v=M002-UI-24)：继承同批样本词义、预设语言、过期/无预览状态。
- [学习](http://127.0.0.1:4186/prototype/?page=create&lang=zh&v=M002-UI-24)：继承可操作的新选择器；全站普通选择型下拉统一，正式应用定位见差异表中的 9 文件 / 19 处。

UI24 仅新增 UIA-PAGE-207-LIST24。原型源为 app.js `notices()` 与 theme.css `.notices-page`；正式应用定位为 [notices.vue](../../../../frontend/app/pages/notices.vue)。每条为完整按钮，长标题换行，time/datetime 日期与装饰箭头分离；保持可见性、提醒优先和时间排序、消息对应关系、原弹窗及关闭回焦。不引入未读状态、摘要、列表内滚动、分页或新文案。

## 验证与接收

权限已恢复，暂存补丁已应用到产品目录内的原型；4186 现为 UI24。1440/1920/390/320px × 中英文，以及长标题、空态、Enter 打开和 Escape 关闭回焦共 41 项 Chromium 检查通过，三张截图已检视。历史权限失败与 UI23 测试保留，不混同当前验证。静态检查与冻结摘要见验证文档；真实 AI 调用 0、生产文件改动 0，实际 token 用量未知。

frontend-bob 后续按设计接收现有契约与组件边界，frontend-claire 落实界面。最小范围为消息列表/阅读布局、Markdown 作用域样式、现有预设学习资源展示、统一选择器及首页文案，没有新增 API/DB 字段要求。原型的 DOM 扫描适配器、模拟生成、夹具与 Marked 解析器不作为生产实现；正式 Markdown 白名单保持。其他一期/二期能力完整继承，详见差异表。

当前等待新增视觉审阅；此前对应用改稿和恢复测试的授权已执行，不自动转写为视觉验收。设计接受后按既有前端实施与 QA 常设授权推进必要接收和落实，无需重复索取相同许可。CR025 保持 open，Profile 与锁定 agt revision 不变，控制面及产品文档保持原样。
