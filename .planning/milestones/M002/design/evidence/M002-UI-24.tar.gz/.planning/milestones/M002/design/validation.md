---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-24
design_version: M002-UI-24
approval: pending_new_visual_review
date: 2026-10-01
---

# UI24 消息列表验证

PAGE-207 / CAP-210 / DATA-205 / UIA-PAGE-207-LIST24 改稿已写入本目录原型：居中共享 880px 阅读栏、同一纸面内的分隔行、日期/标题/箭头响应式排列。copy.json、夹具和其他页面功能保持 UI23。当前状态为待用户视觉审阅；本报告不代替正式应用 QA 或设计批准。

## 浏览器与视觉

[执行脚本](./evidence/ui24/browser.mjs) / [完整结果](./evidence/ui24/browser.json)：Chromium 本地原型 41 项检查全部通过，无页面或控制台错误。访问 [当前消息原型](http://127.0.0.1:4186/prototype/?page=notices&lang=zh&v=M002-UI-24)。

| 覆盖 | 结果 |
|---|---|
| 1440/1920/390/320px × 中英文 | 标题与列表同宽对齐，桌面居中且最大 880px，每条占满列表，无页面横向溢出；手机日期在标题上方。 |
| 键盘与消息映射 | Enter 打开对应消息，Escape 关闭后焦点回到原条目；日期使用 time/datetime。 |
| 长标题与空态 | 标题完整换行，与箭头分列且不截断；空态保留页面标题并无消息条目。长标题为测试时注入 DOM 的边界样本，未改真实夹具。 |
| 人工逐图检视 | 三张截图的构图、字号层级、分隔与窄屏换行均符合设计意图，无需新增改动。 |

截图：[1440 中文](./evidence/ui24/01-desktop-1440.png)、[320 英文长标题](./evidence/ui24/02-mobile-long-title-320.png)、[1920 英文长标题](./evidence/ui24/03-wide-1920.png)。截图摄于键盘关闭消息回焦后，首行浅绿背景与内描边表示焦点，不表示未读或选中状态。消息较少时保留自然页面高度，不增加装饰性空白或固定列表高度。

## 一致性与交付

[静态检查](./evidence/UI24-static.json) 核验 JS 语法、文档链接/版本、25 个 PAGE / 28 个视图 / 49 个 CAP 继承、UI23 原件保留、工作流和产品文档摘要不变，以及现有前后端 575 个文件摘要不变。本轮只变更原型及其设计文档，不运行无关的生产构建或单元测试。

当前冻结文件为 [UI24 清单](./evidence/M002-UI-24-manifest.json)、[完整快照](./evidence/M002-UI-24.tar.gz) 和 [摘要复核](./evidence/UI24-freeze.json)。UI23 已验证的消息阅读壳、Markdown、预设释义、统一选择器和首页介绍继承自 [UI23 清单](./evidence/M002-UI-23-manifest.json) 与 [UI23 快照](./evidence/M002-UI-23.tar.gz)；其旧检查和失败记录不覆盖、不重新声称为本轮执行。

## 历史阻塞与实际范围

早先只允许临时目录写入且 Chromium 启动被 MachPortRendezvousServer 权限拒绝，记录保留在 [首次失败](./evidence/ui24/browser-block.json)、[权限复查](./evidence/ui24/permission-recheck-after-user.json) 及 [暂存静态检查](./evidence/ui24/staging-check.json)。用户恢复完整访问权限后，对照原 UI23 摘要应用补丁并完成上述实际浏览器检查，原阻塞已解除。补丁是应用前暂存记录；最终源文件以 UI24 清单为准。

仅验证本地 Chromium 原型；未声称真机、其他浏览器或人工读屏通过。UI24 未新增 API、数据字段、正文摘要、未读状态、分页或业务决定。原型保留原生按钮的 Space 行为，本轮专门执行的打开键为 Enter。旧 UAT、CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX 原有限制不变。

新增截图 3 张，符合本轮预算；真实 AI 调用 0，生产代码改动 0，无阶段迁移、发布、Git 提交或新的视觉批准。实际模型 token 用量未知。
