---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-05
date: 2026-09-18
---

# 二期设计规格 · M002-UI-05

## 当前目标与有效范围

接收 [M002-PRODUCT-02](../handoffs/product.md) 的完整产品基线；批准及角色交接以 [TRANSITION-M002-004](../reviews/product-revision.md) 为准。当前设计处于待审，不代表用户已批准 UI-05 或授权切换技术阶段。设计不再要求下游从一期与二期旧稿自行拼接需求；当前能力、数据、页面和 AI 边界分别以 `../product/abilities.md`、`data-assets.md`、`pages/index.md`、`ai-behavior.md` 为准。

本次按 [M002-CR-001](../changes/M002-CR-001.md) 接收与修正：保留注册登录、复习库、日期范围、批次详情、独立会话和完整后台配置，同时采用二期概览提交、成长道具、消息与预设。25 个有效 PAGE、28 个视图与 48 个 CAP 的映射在 [traceability.json](./traceability.json)；被替代页面编号不当作遗漏，也不继续作为当前路由来源。

产品已批准；当前整套设计仍待审。UI-04 在制品已冻结为 [接收前快照](./evidence/M002-UI-04-WIP-before-05.tar.gz)，旧 UI-03.1 验证只证明旧版。撤回的 `product-baseline-draft/` 不构成输入。UI-05 当前包与逐文件 SHA 见 [design-manifest.json](./evidence/design-manifest.json)，未提交 Git。批准产品、CR 与流程控制文件均不由本设计角色修改。

## 设计表达与内容优先级

沿用已确认阅读质感：暖白纸面、深绿文字、浅绿/杏色词签，字母与纸张传达学习主题。系统无衬线承担界面，衬线承担短文；1440px 版心容纳工作台与后台，但阅读栏保留适合连续阅读的宽度。复习的输入、释义、短语依次左对齐。首页只保留概括、一个示例和学习路径，多篇预设放在“试用”。

个人中心头像依次进入个人信息、账号成长、道具卡、兑换中心，四视图共享左侧资料。成长默认每类展示当前档，其余档位可展开；等级奖励单列为逐级可领条目。后台八模块为概览、数据分析、模型管理、计划管理、用户管理、成长运营、消息管理、首页预设；模型和计划各有完整编辑页，消息是独立模块。

视觉资产仅使用现有主题、内联编织标识 SVG、CSS 纸面与词签。没有外部图片、外部字体、Figma 或待替换占位图；界面只显示当前语言品牌“词涟”或“WordWeave”。动画为进入、聚焦反馈和首页轻浮动，减少动效时静止。

## 启动、来源与演示边界

工作目录为本文件所在 `design/`，运行 `python -m http.server 4174 --bind 127.0.0.1`，访问 [首页](http://127.0.0.1:4174/prototype/?page=home&lang=zh&v=M002-UI-05)。不能双击 HTML：模块与文案使用同源 fetch。

原型入口 `prototype/index.html`、布局及导航 `prototype/app.js`；`identity.js` 为认证，`learning.js` 为学习，`admin.js` 为模型/计划/用户，`operations.js` 为成长配置，`presets.js` 为预设，`growth.js` 为账号成长，`benefits.js` 为卡片确认和组合权益示例。统一文案为 [copy.json](./copy.json)，Token/实际样式为 [theme.css](./theme.css)，业务示例在 `prototype/fixtures.json`。

URL 使用 `page`、`lang=zh|en`、`role=guest|learner`、`state`；页脚“二期交互原型”控制条可切页和状态，不属于生产界面。这里的角色参数仅用于设计审阅，不是生产权限方案。控制条放在内容后，避免遮挡操作。

夹具时刻固定为 2026-09-17 12:00 北京时间。只有学习草稿/最小事实用本地 sessionStorage 模拟；认证、成长、卡片、配置、额度为本页内存演示，刷新不证明服务端持久化。模型是示例名称，预览是确定样文，无真实 AI、账号、监控请求。后台无限预览的次数与前台生成分别示意。

## 页面、区域与验收

表中 PAGE 全部属于当前 M002 基线，包括被继承保留的编号。每一行是可观察验收，固定文案键引用共享源；详细状态在交互文件。前端可调整组件与 DOM 组织，但不能改变内容顺序、作用、文案或业务分支。

| 当前页面 / 验收 ID | 原型入口与状态 | 实际源与区域 | 文案键 | 必须保持的结果 |
|---|---|---|---|---|
| PAGE-002 注册<br>UIA-PAGE-002-01 | `?page=register`<br>username-taken / auth-error；承接与登录互跳 | identity.js · #identity-form / .auth-intent | `i.*` | 用户名、密码、确认密码、规则、提交、登录入口；不增加邮箱/手机；成功先承接当前短文，再提醒正文。 |
| PAGE-003 登录<br>UIA-PAGE-003-01 | `?page=login`<br>auth-error / admin；来源页返回 | identity.js · #identity-form / .auth-intent | `login / i.* / welcome` | 通用认证错误；管理员进入后台，学习者返回原意图；Enter 可提交，密码不落浏览器存储。 |
| PAGE-005 学习记录<br>UIA-PAGE-005-01 | `?page=library`<br>empty / save-error；搜索/续载/删除 | learning.js · .library-stats / #library-query / .library-row | `l.library* / l.stat.* / l.search*` | 六项全库统计→目标词搜索→旧到新批次；直接复习、详情、参与开关、删除均保留。返回保留查询与续载；累计成长不因删批次回退。 |
| PAGE-006 批次详情<br>UIA-PAGE-006-01 | `?page=batch`<br>?batch=b1；unavailable / save-error | learning.js · .batch-detail / .resource-grid | `l.detail / l.snapshot / l.resources` | 整篇原文、标签、全部原词释义/短语、配置快照、参与状态及成功次数只读；直接复习与删除明确。 |
| PAGE-007 复习范围<br>UIA-PAGE-007-01 | `?page=range`<br>preview-error / preview-loading；非法日期/零命中 | learning.js · .range-editor / #range-from / #range-to | `l.range* / l.dates* / l.matches*` | 最近七天且首尾包含；只筛参与批次；未知数量用横线；编辑不丢焦点。存在未完成范围时可以恢复或确认另开。 |
| PAGE-008 复习会话容器与结束<br>UIA-PAGE-008-01 | `?page=sessiondone`<br>最后一批提交后完成→sessiondone | learning.js · .session-totals | `l.sessiondone* / l.total.*` | 保留本轮完成/成功/失败最小概况，能回库或日期选择；不给历史逐题答案入口。 |
| PAGE-103 用户管理<br>UIA-PAGE-103-01 | `?page=users` / `?page=userdetail`<br>search-error / save-error / unavailable | admin.js · #admin-user-query / .admin-facts | `a.users.* / a.user.* / a.password.* / a.library.*` | 用户名定位、续载、返回保留；详情四分区：资料计划、等级成长、积分、只读学习记录。管理员身份不出现学习者动作。 |
| PAGE-201 复习填写<br>UIA-PAGE-201-01 | `?page=review`<br>?batch=b3；resume / denied / multibatch | learning.js · .review-context / .slots / .hint / [data-region=passage] | `review.* / slot / gap / previous / next / skip` | 拼写标题→字母槽→解释→短语开关；非空前进、不即时判对；短文固定宽空与稳定匿名分组；前退和概览保留输入。 |
| PAGE-202 当前批次概览<br>UIA-PAGE-202-01 | `?page=overview`<br>submit-error / response-lost | learning.js · .answer-row / .answer-link / #submit | `overview.* / wordanswers / passageanswers / submit` | 当前批次词答列表＋填入用户答案的短文；点击回对应位置编辑；全空也可提交；失败可重试，响应丢失先确认状态且不重复结算。 |
| PAGE-203 提交后总结<br>UIA-PAGE-203-01 | `?page=summary`<br>必须由提交进入；直接地址不给历史答案 | learning.js · .result-word / .review-footer | `summary.* / newmastery / restart / nextbatch / finish` | 正确文字标色，错误/未答划线并邻接正确词；重来清本批草稿，下一批前进。离开后的逐题总结不保留。 |
| PAGE-204 造文工具台<br>UIA-PAGE-204-01 | `?page=create`<br>noquota / nomodel / nolength / failure / save-error | app.js generation · .settings / #generate / [data-region=generation-result]；benefits.js | `create.* / random / b.* / quota` | 配置可折叠；模型和释义语言显式选，Story/Brief 合法时默认；固定词库、去重、上限及随机避开当前库；完整结果再收录。取消扣次，系统失败返还原来源。 |
| PAGE-205 简洁首页<br>UIA-PAGE-205-01 | `?page=home`<br>normal；中英文/减少动效 | app.js home · [data-region=hero] / .path | `hero.* / path.* / sample` | 简洁价值介绍＋造文/试用入口＋一篇带示例标识的 AI 短文；主导航首页、造文、复习库、日期复习、试用，无成长主导航。 |
| PAGE-206 个人资料<br>UIA-PAGE-206-01 | `?page=profile`<br>save-error；改密/注销两次确认 | app.js profile/accountShell · .account-sidebar / #profile-form；identity.js | `profile.* / nickname / gender / i.*` | 头像四项分区共用左资料右内容；昵称空回退用户名；用户名/基础计划只读。改密需当前/新/确认，注销需密码及最终确认。 |
| PAGE-207 消息列表与正文弹窗<br>UIA-PAGE-207-01 | `?page=notices`<br>empty；明确登录后提醒正文 | app.js notices/noticeDialog · .notice-entry / #dialog | `notices.* / notice.* / position` | 列表提醒优先再按时间倒序；登录直接打开对应提醒正文，多条上一条/下一条；隐藏优先，无已读红点。 |
| PAGE-208 模型管理、计划管理（两个独立模块）<br>UIA-PAGE-208-01 | `?page=models` / `?page=plans`<br>missing-key / save-error；引用移除/优先级冲突 | admin.js models/plans · .admin-credential / #plan-limit / #plan-unlimited | `a.model.* / a.key.* / a.plan.* / priority` | 模型、计划两个独立导航。全局密钥脱敏/替换，模型名称说明原始ID启停移除；四个固定计划的模型、长度、词上限、零/不限次数及唯一优先级全量编辑。 |
| PAGE-209 平台消息管理<br>UIA-PAGE-209-01 | `?page=messages`<br>save-error；显示/提醒独立 | app.js messages · #body-zh / #body-en / #dialog | `a.messages* / markdown / visible / remind` | 独立一级消息管理；列表→双语 Markdown→预览→显示/提醒开关→保存；失败保留输入。 |
| PAGE-210 成长运营配置<br>UIA-PAGE-210-01 | `?page=operations`<br>save-error；四页签/多档/奖励引用 | operations.js；app.js itemForm · .tier-table / #item-type | `operations / item.* / reward* / a.tier.*` | 签到与经验、等级、四类成就、四类道具；动态多档含名称说明称号/奖励/启停；道具类型固定、默认未上架，有历史或引用不能删。 |
| PAGE-211 用户管理内的积分操作<br>UIA-PAGE-211-01 | `?page=credits`<br>save-error；非正数/对象确认 | admin.js points · #credit-amount / #found-user | `a.ledger / a.source.* / credit.rule / positive` | 用户详情积分区域及兼容独立视图：余额、来源流水、正数补发确认；不提供扣分、撤回或改经验。 |
| PAGE-212 热门预设管理<br>UIA-PAGE-212-01 | `?page=presets`<br>failure / save-error；预览失效/发布前后 | presets.js · #preset-words / [data-action=preset-publish] | `presets / preset.* / preview.* / publish.*` | 每条草稿、有效预览、线上快照独立；全部受支持配置、不受访客词上限；无限预览但独立计量；改参数需新预览再手动发布。 |
| PAGE-213 数据分析<br>UIA-PAGE-213-01 | `?page=metrics`<br>empty / delayed；观察中/无来源 | app.js metrics/metricDetails · .metrics-grid / .chart | `metrics.* / uv / pv / wau / retention` | 流量、漏斗、失败、留存、WAU、频次、生成收录、管理员预览指标；分母/排除项可见，D30 未成熟不报零；Clarity 不采私有内容。 |
| PAGE-214 账号成长<br>UIA-PAGE-214-01 | `?page=growth`<br>blocked / disabled / demoted / maxlevel / claim-error | growth.js · .growth-banner / .calendar / .achievement-group / [data-level] | `growth.* / signin.* / reward.* / g.*` | 经验/等级与积分分开；签到自动、补签选择确认；四类成就默认展示当前档，可展开全档；成就/逐级奖励手动整份领取，称号仅个人中心。 |
| PAGE-215 道具卡、兑换中心（两个视图）<br>UIA-PAGE-215-01 | `?page=bag` / `?page=shop`<br>covered / retired / expired / active / lower / insufficient | app.js bag；benefits.js · .items-grid / .benefit-end / #dialog | `bag.* / shop.* / card.* / b.* / covered` | 道具与兑换两视图；兑换确认扣分、使用确认结果；模型逐个累时、计划同档续期/高覆低/低拒绝、次数沿用原期限；下架退积分用实时配置且一次。 |
| PAGE-216 独立预设造文工作台<br>UIA-PAGE-216-01 | `?page=trial`<br>role=guest；invalid / noquota / failure | app.js generation(true) · .settings / #generate | `preset.* / create.* / quota / guestcollect` | 试用选择后独立锁定工作台；全部参数只读且需手动生成；配置优先但仍扣身份所属次数；完整生成后沿原收录/注册复习链。 |
| PAGE-217 独立试用目录<br>UIA-PAGE-217-01 | `?page=explore`<br>empty；role=guest | app.js explore · #presets / .preset-card | `explore.* / home.presetdesc / try / sample` | 头部试用入口→多篇已发布示例→我也试试→锁定工作台；无结果给普通工作台入口。 |
| PAGE-218 后台概览<br>UIA-PAGE-218-01 | `?page=adminhome`<br>empty | admin.js home · .admin-launch-grid / .metrics-grid | `a.adminhome / a.overview.* / updated` | 后台八模块概览及指标摘要，详细指标进入数据分析；管理员壳不混学习者菜单。 |

## 动态内容与格式

| 文案键 / 变量 | 含义、缺值和格式 | 检查条件 |
|---|---|---|
| `welcome` / name、days | 昵称空时用户名；距上次有效学习的学习日差，不取上次登录。无学习用 `g.welcome.new`，不显示 NaN。 | 明确登录、首次注册、有/无学习、04:00 边界。 |
| `progress` / current、target | 累计经验与下级门槛；满级用 `maxlevel` 并保留累计经验。 | 260/300 为夹具，奖励/配置变化后重算，不写死 Lv.3。 |
| `b.quota` / plan、extra | 当前有效计划剩余与已启用额外次数；无限明确文字，不能把 0 当无限。 | 模型卡不增加次数；体验续期不清已用量；预设仍按当前身份扣次。 |
| `useby`、`ends` / date；`b.extension` / days、date | 获得后的启用期限与逐模型/计划体验结束分开；原型用北京时间 YYYY-MM-DD HH:mm。 | 部分重叠逐模型累时，期限内启用给足时长。 |
| `reward` / points、xp；`pricevalue` / count | 领取时配置的奖励/价格；模型退换读取当前下架积分。业务数字为变量。 | 整份奖励不可用时积分/经验也不提前发；已完成退换金额不追改。 |
| `slot`、`gap` | 字母或空位序号，无答案；短文空固定宽、同原词不同词形共享匿名组。 | 多词条空格/标点分组；辅助名称不能泄露答案。 |
| 运营标题、消息、释义、短文 | 双语内容缺一种时回退原文；UI 切换不翻译 AI 内容。未知指标用暂无样本/观察中/未知。 | 长标题/空列表/隐藏通知/未成熟留存。 |

## 详细规则与实现自由

状态、动作和异常的完整规范见 [interactions.md](./interactions.md)；断点、输入、键盘、对话框、动效和字号规则见 [responsive-accessibility.md](./responsive-accessibility.md)。分组表格允许内部横滚，页面不得整体溢出；日期编辑器沿用 1080/1081px 边界，工作台折叠用 1100px，不混为一个断点。

本稿的组件拆分和状态变量不是后端设计。前端接收后需将共享文案、Token 与模块区域映射进正式框架；数据层使用批准 API/DTO，不复制 fixtures 或设计内存逻辑作为生产权益算法。模型卡按稳定模型身份关联，原型用名称只是可读夹具。服务端对额度、奖励、掌握去重、下架资格、密码/权限及删除执行最终校验与幂等。

## 设计自检与接续

实际浏览器方法、当前结果、逐图人工检查和未覆盖范围见 [validation.md](./validation.md)。接收前保护清单见 [UI05-reception.json](./evidence/UI05-reception.json)，最终摘要见版本清单。此前 UI-04 旧规格引用旧批准、试用目录/后台概览合用旧 PAGE、固定奖励样例的问题由此版替代。

CR 的产品补正已有独立批准；本角色仅提交设计接收和覆盖证据，不自行关闭 CR 或推进阶段。需经本稿设计审阅后由守门器登记；不把未执行的技术/独立 QA/新会话交接称为完成。M001 遗留 CR039-L1、CR042-L1、AI-QUALITY-90 保持原状态。
