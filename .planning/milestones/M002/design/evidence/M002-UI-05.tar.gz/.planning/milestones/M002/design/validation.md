---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-05
date: 2026-09-18
---

# UI-05 设计验证

输入是经 TRANSITION-M002-004 批准的 M002-PRODUCT-02。以下是当前本地设计原型自检，不是正式应用、真实 AI、后端权限或数据库事务验收；设计仍待审。

## 浏览器执行结果

使用项目现有 Playwright Chromium 与 axe-core，无新增依赖。命令从产品仓库根目录运行，原型服务根目录为 `design/`，端口 4174。

| 证据与复现命令（design/evidence 下） | 当前结果 | 验证重点 |
|---|---|---|
| `node verify-ui05-learning.cjs` → [UI05-learning-results.json](./evidence/UI05-learning-results.json) | 13 项 PASS；70 页面/语言/宽度组合无页面溢出；7 页 axe 无报告违规 | 注册登录、账号生命周期、六项库统计、查询与返回、详情参与删除、日期预览、独立草稿/恢复、字母/匿名短文、去重掌握、批次推进、完整收录、访客认领、取消/离开。 |
| `node verify-ui05-admin.cjs` → [UI05-admin-results.json](./evidence/UI05-admin-results.json) | 15 项 PASS；20 页面/宽度组合无溢出；8 页 axe 无报告违规 | 八独立模块、密钥、模型增改启停/移除、四计划完整配置、用户搜索与四分区、基础计划重置、重置密码、正数补发、只读库、多档配置、预设发布、独立消息、指标。 |
| `node verify-ui05-growth.cjs` → [UI05-growth-results.json](./evidence/UI05-growth-results.json) | 8 项 PASS；80 页面/语言/宽度组合无溢出；8 页 axe 无报告违规 | 配置驱动逐级/成就整份手动领奖、阻断原因、补签反馈、逐模型累时、计划续期和模型覆盖、库存参数快照/实时下架积分、计划与额外次数、取消计数、响应丢失不重复结算。 |
| `node verify-ui05-followup.cjs` → [UI05-followup-results.json](./evidence/UI05-followup-results.json) | 4 项 PASS；额外检查 12 个壳层路由 | Enter 登录、模拟注销清理、八后台与四个人视图、手机多词条/短文/总结。最后重跑包含当前步骤自动滚到可见区。 |
| [UI05-tablet-final.json](./evidence/UI05-tablet-final.json) | 768px 英文 8 路由 PASS | 最后仅调整词签留白与复习步骤定位后定向复核；最终 tablet 截图已替换。 |
| `python verify-ui05-static.py` → [UI05-static-results.json](./evidence/UI05-static-results.json) | 以机器结果为准 | 当前页面/视图、48 CAP、31 活跃 DATA、替代数据排除、文案与源码语法、受保护输入摘要。 |

合计 40 项操作检查、170 组常规响应式组合、23 次页面 axe 检查。各最终报告无 JavaScript 错误。另有 12 路由壳层和 8 次最终平板定向检查，不混进 170 组。宽度范围为 320、390、768、1080、1081、1440、1600px；语言 zh/en 的具体覆盖以每份报告为准，不声称全视图与全宽度的笛卡尔积均已测。

首次成长矩阵在 768px 英文导航出现溢出，原报告 [UI05-growth-first-results.json](./evidence/UI05-growth-first-results.json) 保留。学习者导航改为 ≤1100px 双行并保持导航自身可滚，整套对应矩阵重跑通过。首次后台检查出现本地 `ERR_SOCKET_NOT_CONNECTED`，导致预设入口等待超时；原报告 [UI05-admin-first-results.json](./evidence/UI05-admin-first-results.json) 保留，独立重跑全部 15 项通过。未据此修改产品规则或隐藏失败。静态校验另外找到后台停用态缺少 `disabled` 双语文案键，已补入共享文案；初次结果保留在 `UI05-static-first-results.json`，随后检查通过。

## 实际图像检查

已读取真实浏览器截图，并对照源与文案检查：

- 首页 [1440px](./evidence/UI05-home-1440.png) 与 [768px 英文](./evidence/UI05-home-768-en.png)：任务/试用入口明确；纸面示例与词签分层，平板导航和装饰不遮正文。
- [登录 390px](./evidence/UI05-login-390.png)、[复习库 390px](./evidence/UI05-library-390.png)、[日期 1440px](./evidence/UI05-range-1440.png)：一期页面保持完整，统计/日期结果/下一动作分层可读。
- [多词条](./evidence/UI05-multiword-390.png)、[短文匿名空](./evidence/UI05-passage-390.png)、[提交总结](./evidence/UI05-summary-390.png)：字母与空格分组、固定宽短文空、原词组符号、划线纠错、完成和重来均可见。步骤条定位当前阶段，横滚不挤主内容。
- [账号成长桌面](./evidence/UI05-growth-1440.png) / [手机](./evidence/UI05-growth-390.png)：左侧资料共享；日历、四类成就折叠与逐级手动奖励区分。道具示例检查了参数、启用期限和按钮。
- [模型](./evidence/UI05-models-1440.png)、[计划](./evidence/UI05-plans-1440.png)：八模块、密钥配置、全模型表与四计划全部字段可见，没有只画二期新增开关。

原 followup 手机截图曾在进入动画尚未结束时采样；已改为 reduced-motion 的确定截图并重跑，没有把瞬时低透明度误作配色缺陷。默认动画仍由 theme.css 保留。页脚审阅控件移到内容之后，避免覆盖卡片和操作。

## 与实现/独立验证的边界

- 原型固定时间与少量夹具，只演示用户可见状态和代表性组合；不运行 04:00/滚动 24h 的真实时间推进，不证明全量词库、批次游标、跨账户、跨设备、并发、持久化、原子结算或全部卡组合正确。
- 真实认证、会话吊销、密码/密钥处理、用户删除、首次掌握稳定身份、模型正式下架资格永久保留、奖励/兑换幂等、并发退款与额度返还由后续技术方案/实现及 QA 验证。不得将 prototype 内存模型或示例日期/数值移作生产业务常量。
- 未接 AI、Clarity、埋点或真实运营数据；原型样文不是 AI ≥90% 质量证明。CR039-L1、CR042-L1、AI-QUALITY-90 保持一期原状。
- 未执行真机 Safari、软键盘、人工读屏和 200% 缩放检查；正式前端按 responsive-accessibility.md 补齐。axe 零报告不是完整 WCAG 合规声明。
- 独立新会话交接测试未执行；本轮静态链接/编号/摘要检查和本人浏览器自检不冒充第二角色接收。没有待用户裁定的新产品分歧，没有修改批准产品或替守门器关闭 CR。

## 版本与追踪

最终设计包为 `evidence/M002-UI-05.tar.gz`，文件 SHA 及证据清单见 [design-manifest.json](./evidence/design-manifest.json)。接收前 37 个批准输入/流程文件保护摘要见 [UI05-reception.json](./evidence/UI05-reception.json)；静态验证证明其未变。旧 UI-04 WIP 及更早版本原件保留，当前规格不继续累加旧版正文。
