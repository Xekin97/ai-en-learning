---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-14
date: 2026-09-18
---

# UI-14 设计验证

范围为 PAGE-205 / MOTION14：用户认可交叉叠卡后，新增整卡轻浮与前后换层过渡，保留两篇单段短文及原布局。产品仍为 PRODUCT-03，设计整稿待审；[UI-13 冻结包](./evidence/M002-UI-13.tar.gz) 与旧证据保持。

## 真实动效与交互

运行 `node .planning/milestones/M002/design/evidence/verify-ui14.cjs`；[最终报告](./evidence/UI14-browser-results.json) 四组均通过：

1. 实际比较相隔 1.3 秒的两卡 translate，确认错相轻浮；真实等待首个 8 秒换层，记录中间 transform、暂停的漂浮及结束后的恢复。鼠标进入后移出，再等 8.5 秒，位置/动画时间/层级保持，证明阅读后停止本次自动。
2. 手动换层及快速 Tab / Shift+Tab 以最新选择为准；运行中启用减少动效取消所有卡片动画并保留目标层级，手动即时切换。语言重绘保持阅读停止；离开首页无残留纸卡动画，再入重新开始。
3. 320/390px 中英文、768px 中文、1440px 英文共 6 个布局，点按卡片后逐帧采样约 750ms，整个换层过程无页面横溢、旋转边角未越界。两篇/12 个词签保持。390px 中文、1440px 英文两个 axe 无违规。
4. 页面内程序滚动验证叠卡离屏时暂停，回到视口后未开始阅读则恢复。后台标签页隐藏分支仅审源码，未宣称真实后台切换通过。

[首次报告](./evidence/UI14-first-browser-results.json) 与 [首次脚本](./evidence/verify-ui14-first.cjs) 保留。两组首次超时是 locator.hover/tap 等待目标几何位置稳定，而目标正在持续漂浮。改为读取可见标题坐标后发送真实鼠标/触摸输入，仅重跑失败两组：`UI14_RETRY=1 node .planning/milestones/M002/design/evidence/verify-ui14.cjs`；通过组从首次结果保留，最终报告记录合并来源。产品代码未因测试定位修正而改变。

## 实际视觉与证据

已打开 [桌面换层中间帧](./evidence/UI14-turn-midpoint-1440.png) 和 [手机阅读状态](./evidence/UI14-reading-390.png)：两篇构图保持，换层轻微分开并回位，手机选中后全文在最上层且没有横溢。[阅读停稳](./evidence/UI14-reading-1440.png) 和 [真实时间录屏](./evidence/UI14-motion-1440.webm) 一并保存；首次失败录屏也保留。静态截图仅说明布局，时序结论来自运行观察和逐帧数据。

## 一致性与边界

运行 `python3 .planning/milestones/M002/design/evidence/verify-ui14-static.py`，[静态报告](./evidence/UI14-static-results.json) 核对追踪、双语、模块语法、当前文档/链接、样文和 453 个受保护输入/历史原件。[当前冻结包](./evidence/M002-UI-14.tar.gz) / [清单](./evidence/M002-UI-14-manifest.json) 包含新 home-motion.js，[当前指针](./evidence/design-manifest.json) 同步。

未改产品、业务夹具、正式应用或控制面，未调用真实 AI、未提交 Git、未推进阶段。本轮不重复验证其他页面。物理设备/iOS Safari、人工读屏、缩放、后台标签页真实切换和生产接口未验证；模拟触摸/axe 不替代完整可访问性验收。独立新会话交接未执行，模型用量未知。
