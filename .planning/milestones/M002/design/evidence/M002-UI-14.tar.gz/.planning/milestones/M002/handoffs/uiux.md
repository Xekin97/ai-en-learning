---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-14
date: 2026-09-18
---

# M002 UI/UX 交接 · designer-tony

输入为 [M002-PRODUCT-03](./product.md) / [TRANSITION-M002-006](../reviews/product-title-revision.md)，Profile consumer-ai-web@1.0.0 / revision `b5badf88cd7194400c3d4d0e9395e7c98490dc26`。当前 uiux-design，设计整稿仍待审。

用户认可两篇叠卡后要求增加漂浮和切换，原话与范围见 [UI14-reception.json](../design/evidence/UI14-reception.json)。本版保留两篇全文与构图，增加错相轻浮、8 秒空闲自动换层和手动换层过渡。阅读交互后停止本次自动动效；减少动效保持静态。旧“只静态/瞬时换层”规则失效，本次授权不等于整里程碑批准。

- [当前首页](http://127.0.0.1:4174/prototype/?page=home&role=guest&lang=zh&v=M002-UI-14)。
- [设计规格](../design/design-spec.md) 的 STACK13 / MOTION14；参数及中断规则在 [交互](../design/interactions.md)、[响应式](../design/responsive-accessibility.md) 和 [主题](../design/theme.css)。
- 新增 [home-motion.js](../design/prototype/home-motion.js)，由 [app.js](../design/prototype/app.js) 的 HM.afterRender() 装配并清理；保留 [fixtures.json](../design/prototype/fixtures.json) 和 [copy.json](../design/copy.json) 内容。
- [验证](../design/validation.md)：真实时间与连续帧、手动/自动/中断、偏好切换、页面清理及可访问性。首次自动化因等待移动目标静止而超时，原报告保留；修正坐标定位后仅重跑相关组，产品代码未因此改动。

25 PAGE、28 视图、49 CAP、31 活跃 DATA 保持，无新业务或生成操作。前端需同时接收 CSS 漂浮和 JS 换层控制，不能仅复制静态 transform 或把漂浮覆盖旋转；保留最新手动选择、阅读停止、运行时减少动效以及旧实例清理。手机真机/iOS Safari 仍需实现阶段补测。

[当前冻结包](../design/evidence/M002-UI-14.tar.gz) / [冻结清单](../design/evidence/M002-UI-14-manifest.json) / [当前指针](../design/evidence/design-manifest.json)；[UI-13 原件](../design/evidence/M002-UI-13-manifest.json) 保留。未改产品、正式应用、CR 或工作流，未提交 Git、未调用真实 AI、未推进阶段。

下一步继续设计审阅；阶段批准与正式交接由守门器处理。CR-001/002、CR039-L1、CR042-L1、AI-QUALITY-90 保持原状态。生产服务、真机/Safari/人工读屏/缩放及独立新会话交接未验证；模型用量未知。没有阻塞业务问题。
