---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
version: M002-UI-27
status: user_requested_increment
date: 2026-10-01
---

# 搜词加载态局部交付

用户本轮明确要求优化Searching UI；UI27仅修改WORD-LOADING27，沿[规格](../design/design-spec.md)、[交互](../design/interactions.md)、[响应式](../design/responsive-accessibility.md)同步原型/CSS。普通工作台及后台预设共享50px紧凑状态行、16px主题色spinner、原准确中英文文案；慢请求250ms后才显示，reduced-motion静止。文案和API无新字段，原UI26其他批准保持，不代签新增用户视觉验收。

原型入口 /prototype/?page=create&lang=en&state=word-loading 或 page=presets，输入任意词查看慢加载。设计先核对两处窄屏/桌面，再由frontend-bob接收最小映射，由frontend-claire连同CR028搜索fixture修复实施；用户前端实施/QA常设授权适用，不重复请示。CR026不变。
