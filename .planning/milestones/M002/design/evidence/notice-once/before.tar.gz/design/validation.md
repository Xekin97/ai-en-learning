# UI27 搜词加载态自检

由用户本轮请求驱动，仅WORD-LOADING27；原型和主题同步，copy不变。普通台1440英文/后台390中文两项状态行检查通过，高50px/文字14px、spinner存在、reduced-motion禁动画；见[结果](evidence/search-loading27/results.json)。状态行在input下方浮层，不增加页面常驻空白，原型仅模拟已经等待的慢请求。原完整选词区截图不包含绝对定位浮层，另补两张popup局部图用于实际视觉核对，未把未显示的加载行当作视觉证据。前端需实现250ms阈值及真异步取消检查。

旧UI26细节和自检保存在[evidence/search-loading27/before.tar.gz](evidence/search-loading27/before.tar.gz)，原冻结批准保持。当前用户请求授权本次可逆优化，新增视觉由本轮实际交付供用户核对，不伪称用户已逐图批准。无新API/业务规则或真实模型调用。
