---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-22
date: 2026-09-20
---

# UI-22 设计验证

范围为 PAGE-006 / SETTINGS22 的生成设置显示及共用的试用配置摘要。输入 PRODUCT-03，用户要求与先前 UI21 验收意见见 [接收记录](./evidence/UI22-reception.json)，[UI-21 快照](./evidence/M002-UI-21.tar.gz) 保留。

运行 `node .planning/milestones/M002/design/evidence/verify-ui22.cjs`，[当前浏览器报告](./evidence/UI22-browser-results.json) 两组通过：

- 1440px 中英文、900px 中文、320px 中英文五个布局：模型、场景/篇幅/释义语言及成功复习次数正确，只读区域无表单控件；完整正文、标题编辑、参与开关、复习和删除入口仍在。页面无横向溢出，320px 英文 axe 无违规，无运行错误。
- 测试覆盖历史长模型及已不属于当前枚举的场景/篇幅/语言，快照原值完整保留且窄屏不溢出；独立试用台共享显示仍为只读，已知枚举翻译正确。源 fixtures.json 未变。

首次后组误用不存在的 page=preset，未抵达试用工作台而超时；实际路由是 page=trial。修正测试后通过 `UI22_RETRY=1 node .planning/milestones/M002/design/evidence/verify-ui22.cjs` 仅重跑后组，继承前组通过记录。[首次报告](./evidence/UI22-first-browser-results.json) 与 [首次脚本](./evidence/verify-ui22-first.cjs) 保留，没有用修改界面掩盖失败。

实际打开检查 [桌面中文](./evidence/UI22-batch-1440-zh.png) 与 [手机英文](./evidence/UI22-batch-320-en.png)：模型卡突出、信息行对齐，统计以分隔线分组；旧界面见 [修改前](./evidence/UI22-before-1440.png)。其他布局、历史长值截图随证据保留。

运行 `python3 .planning/milestones/M002/design/evidence/verify-ui22-static.py`，[静态报告](./evidence/UI22-static-results.json) 核对当前文案、JS、路径、版本、25 PAGE / 28 视图 / 49 CAP / 31 活跃 DATA，以及 610 个受保护原件。[冻结包](./evidence/M002-UI-22.tar.gz) / [清单](./evidence/M002-UI-22-manifest.json) / [当前指针](./evidence/design-manifest.json)，冻结后摘要检查见 `evidence/UI22-freeze-results.json`。

仅调整设计原型与交付文档；未改正式应用/产品/CR/控制面，未提交 Git、调用真实 AI 或迁移阶段。未重跑标题编辑/复习/删除完整行为、Toast 动效与其他页面流程；真机/Safari/人工读屏、独立 QA 和新会话交接未验证。CAP-209 同日专门欢迎文案仍待接入；既有开放事项保持，模型实际用量未知。用户对 UI21 的验收意见保留，本轮新增局部调整待审。
