---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-25
design_version: M002-UI-25
approval: pending_new_visual_review
date: 2026-10-01
---

# UI25 用户文案验证

范围：UIA-GLOBAL-COPY25、UIA-PAGE-207-COPY25 / D2-89。仅修改用户端固定文案、无用说明节点及对应留白；消息/复习/权益行为不变，CR026 的一次提醒范围仍未确定。本报告是 Chromium 原型检查，不代表正式前端 QA 或设计批准。

## 实际结果

[浏览器检查](./evidence/ui25/browser.json) 113 项通过：18 个用户视图 × 中英文 × 1440/320px 页面冒烟；消息无提醒标签、正文映射、Escape 关闭回焦；后台显示/提醒开关仍可用；审阅工具默认隐藏且 `inspect=1` 可开启；日期、恢复、删除、卡片到期/扣次和错误反馈仍存在。无控制台/页面错误，无页面级横向溢出。

逐图检视时发现试用台仍有重复的锁定配置徽标及只读情况下无意义的已选上限，已移除。普通工作台仍可选词并显示上限，试用台仅显示实际单词数量。针对此次修订执行 [8 项复验](./evidence/ui25/trial-recheck.json)，覆盖普通/试用工作台、中英文及宽/窄屏，全部通过。首批其他视图的结果复用，因为后续仅改变锁定试用分支和新增数量模板；源码前件保存在 evidence/ui25/app-before-trial-refinement.js。

静态自检见 [UI25-static](./evidence/UI25-static.json)：文案 JSON/参数、JS、引用、页面与能力追踪、冻结原件以及当前产品/控制面与正式前后端摘要。具体文案变化见 [完整清单](./evidence/ui25/copy-audit.json)，其中记录删除、改写和新增；不把后台运行配置或用户消息正文机械删去。

## 视觉证据

[消息 1440](./evidence/ui25/01-notices-1440.png)：日期和标题在共用栏对齐，无内部标签，去标签后的行高紧凑。[日期复习 320 英文](./evidence/ui25/03-range-320.png)：新说明完整换行，计数区无排除规则说明，无多余空节点。[最终试用 1440](./evidence/ui25/04-trial-final-1440.png)：仅学习单词与实际数量，生成设置清晰，无配置锁定徽标。

[试用修订前截图](./evidence/ui25/02-trial-1440.png) 保留以说明发现的问题，不作为最终外观。计划 3 张、实际 4 张并均已检视，追加原因是对可见残留标签修复后的必要确认，未因此重复截图其他已通过页面。

## 执行边界与交付

首次脚本在等待主内容时超时，因原脚本未在异常前保存页面位置，无法归因，记录和脚本保留在 [首次执行记录](./evidence/ui25/browser-first-attempt.json)。增加逐项结果与异常定位后重新执行通过，无业务预期放宽；不把首次超时报告成通过。

当前来源为 [UI25 清单](./evidence/M002-UI-25-manifest.json)、[快照](./evidence/M002-UI-25.tar.gz)、[摘要核对](./evidence/UI25-freeze.json)。旧 UI24 原件及其检查保留，不运行旧验证脚本覆盖历史。无真机/其他浏览器/人工读屏声明；无真实 AI、发布或 Git 提交，正式前后端未改，token unknown。旧 CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX 不变。
