---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-25
design_version: M002-UI-25
approval: pending_new_visual_review
date: 2026-10-01
---

# M002 设计交接 · designer-tony

当前 UI25 执行 [D2-89](../decisions/product-decisions.md#d2-89) 用户文案清理，来源 [064](../reviews/copy-design-064.md)，继承 PRODUCT04/UI24。一次提醒的 **CR026 / D2-88-LOCAL-SCOPE 仍 OPEN**，该分支不在本次设计输入内，不将 PRODUCT05 全稿视为已确认或自行决定记录范围。

原始设计入口：[规格](../design/design-spec.md)、[前端差异](../design/frontend-delta.md)、[copy.json](../design/copy.json)、[交互](../design/interactions.md)、[响应式](../design/responsive-accessibility.md)、[文案清单](../design/evidence/ui25/copy-audit.json)。[消息预览](http://127.0.0.1:4186/prototype/?page=notices&lang=zh&v=M002-UI-25) 默认不显示原型审阅工具，需要时加 `inspect=1`。

当前范围：用户消息去提醒类别标签；用户端内部术语改为自然操作/结果文案；移除日期复习内部排除说明、完成页重复副标题和试用配置锁定徽标；试用词数只显示实际数量。后台操作所需的显示/提醒配置、用户必要扣次/到期/覆盖/删除/恢复提示保持。无 API/数据库/业务行为改动；本次不修改正式前端。

验证与同版来源：[报告](../design/validation.md)、[当前清单](../design/evidence/design-manifest.json)、[UI25 快照](../design/evidence/M002-UI-25.tar.gz)。18 个用户视图中英文/1440/320px 及必要反馈共 113 项浏览器检查通过；试用残留标签修订后，普通/试用台另外 8 项定向复验通过，4 张截图均已检视，早先超时原件保留。UI24 原始快照保留；此前批准仅证明对应旧版，新视觉待审。

下一具体动作：用户审阅 UI25；前端随后按准确文案和区域差异接收，遵循原有实施/QA 常设授权。CR026 待用户回答缓存范围后由 product-maya 继续，不因文案修订将其关闭或隐式批准。真实模型调用 0，token unknown。
