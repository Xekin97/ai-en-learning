---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-08
date: 2026-09-18
---

# UI-08 设计验证

来源为用户明确要求给试用页增加释义语言 Tab。对应 UIA-PAGE-217-06 / PAGE-217 / CAP-218 / DATA-212；在 PRODUCT-03 已发布配置上筛选，不修改产品、控制面或正式应用。

## 操作与静态检查

按规格启动 4174 原型；从产品仓库根运行 `node .planning/milestones/M002/design/evidence/verify-ui08.cjs`，结果见 [UI08-browser-results.json](./evidence/UI08-browser-results.json)。4 组检查通过：

1. 默认全部、分类数量、完整匹配内容及源预设身份；英语筛选后的“我也试试”进入第二个预设的 Model B / English 配置，进入不生成且访客额度保持 3。
2. 日语零匹配可回全部；全部无预设仍有普通造文入口；切换界面语言保持释义语言筛选和原标题。
3. Tab 单停靠点、方向键/Home/End、激活后焦点保持；320/390/1440px 无页面横溢；390px 英文空态及 1440px 中文全部状态各一次 axe 无报告违规。
4. 切换筛选重置第一项并暂停；单项禁用切换/自动；回全部明确恢复后，实际等待验证再次自动移动。

无 JavaScript 运行错误。仅验证本轮相关交互；UI-07 的全样文、发布和触摸仿真证据继续归属旧版，未计入本版数量。

首次脚本使用 browser.newPage 创建隐式上下文，axe 要求显式 browser.newContext，导致辅助检查未执行；改用显式上下文后重跑通过，没有为通过检查改产品规则。原 [首次报告](./evidence/UI08-first-browser-results.json)、[首次脚本](./evidence/verify-ui08-first.cjs)、失败截图保留；首次其他三组已通过。

运行 `python3 .planning/milestones/M002/design/evidence/verify-ui08-static.py`，见 [UI08-static-results.json](./evidence/UI08-static-results.json)：核对 25 PAGE、28 视图、49 CAP、31 活跃 DATA、追加 UIA、文案配对/引用、模块语法、当前版本/相对链接与受保护文件摘要。

## 实际视觉

已打开 [桌面全部](./evidence/UI08-tabs-1440.png)、[手机英语筛选](./evidence/UI08-filtered-390.png)、[手机英文空态](./evidence/UI08-empty-390-en.png) 截图。Tab 位于导语和轮播之间，选中项/数量可辨；手机完整配置和全文保留，英文 Tab 可横滚并保持当前项可见，空态能直接回全部。减少动效截图显示手动浏览，正常自动由操作检查证明。

## 未验证范围与交接

未调用真实 API/AI，未验证服务端筛选/分页、发布并发、生产权限/持久化/计量，也未测物理手机、Safari、人工读屏和 200% 缩放。axe 不代表完整 WCAG 声明。原型第二条夹具改成英语释义以展示分类，日语演示零匹配，未修改生产数据。独立新会话交接未执行。

CR-001/002 由守门器接收，不由设计关闭；CR039-L1、CR042-L1、AI-QUALITY-90 保持原状态。当前待审，没有 Git 提交或阶段切换。

当前源与本轮证据冻结为 [M002-UI-08.tar.gz](./evidence/M002-UI-08.tar.gz)，[冻结清单](./evidence/M002-UI-08-manifest.json) 与 [design-manifest.json](./evidence/design-manifest.json) 定位本版。用户原话、旧源和保护摘要见 [UI08-reception.json](./evidence/UI08-reception.json)；[UI-07 原包](./evidence/M002-UI-07.tar.gz) 及证据保持原件。
