---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-08
date: 2026-09-18
---

# M002 UI/UX 交接 · designer-tony

## 当前输入与确认

沿用 [M002-PRODUCT-03](./product.md) 与 [TRANSITION-M002-006](../reviews/product-title-revision.md)，Profile 保持 consumer-ai-web@1.0.0 / revision `b5badf88cd7194400c3d4d0e9395e7c98490dc26`。用户于 2026-09-18 进一步明确要求“试用这里，加个释义语言的 tab 筛选吧”，原话保存于 [UI08-reception.json](../design/evidence/UI08-reception.json)。这是 CAP-218 / PAGE-217 / DATA-212 的设计呈现修订，无待确认业务假设。

UI-08 在 UI-07 横向阅读卡上增加全部/中文/英语/日语 Tab 和匹配数量，默认全部；筛选后回首项并暂停自动，无匹配可回全部，切 UI 语言保持筛选。配置和全文来自同一已发布对象，筛选位置与源预设身份分离，避免进入错误工作台。保留单标题、无预设说明、手动发布、锁定工作台、进入不生成/不扣次和注册收录。批次标题编辑、私人复习库/日期复习/登录注册、头像四个人视图、完整八后台及独立消息继续继承。未使用撤回的产品草稿。

## 产物与定位

当前 **M002-UI-08 / awaiting_user_review**，设计唯一详细入口为 [design-spec.md](../design/design-spec.md)，其表格连接 [追踪](../design/traceability.json)、[交互](../design/interactions.md)、[响应式/可访问性](../design/responsive-accessibility.md)、[文案](../design/copy.json)、[主题](../design/theme.css)。

- [用户侧试用预览](http://127.0.0.1:4174/prototype/?page=explore&role=guest&lang=zh&v=M002-UI-08)：每卡展示词条、模型、场景、长度、释义语言与完整分段正文，提供暂停/继续、前后、计数、键盘和触控。普通模式每 8 秒自动切换；减少动效仅手动。UIA-PAGE-217-06 是本轮接收验收，03/04/05 继续继承。
- 主要来源为 `prototype/gallery.js`，由 app.js 接入；fixtures 的 `sampleText` 为完整原型样文，presets.js 将预览正文与配置作为同一快照发布。原型使用统一 copy.json，HTML 与主题都已同步版本。正式前端按规格转换，不以演示定时器/夹具作为 API 或业务实现。
- [M002-UI-08.tar.gz](../design/evidence/M002-UI-08.tar.gz) 与 [冻结清单](../design/evidence/M002-UI-08-manifest.json) 对应本版，当前入口为 [design-manifest.json](../design/evidence/design-manifest.json)。旧 [UI-07 清单](../design/evidence/M002-UI-07-manifest.json) 和快照原地保留。
- [validation.md](../design/validation.md) 记录本轮 4 组操作、320/390/1440px 布局、2 次 axe 及逐图检查的原始报告；不将 UI-07 全量结果计入本版。实际自动暂停/恢复有运行检查，非仅截图声明。

## 完整性与整理

25 PAGE、28 视图、49 CAP、31 活跃 DATA 映射保持，追加本轮 UIA；DATA-015 继续被替代，不恢复历史逐题答案。源码、文案、规则与验收同步；无筛选列表的还原预期由本版替代，前端/QA 应按本版重建该区域，其余职责保持。

产品、CR、审核、流程及旧设计证据摘要检查见 [静态报告](../design/evidence/UI08-static-results.json)，接收前摘要见接收记录。未修改正式应用或控制面，未提交 Git、未调用真实 AI。当前入口结构未改，原文保存在 UI-07 包中；新会话独立交接未执行，本角色自检不冒充独立接收。模型用量未知。

## 未决事项与下一动作

- [M002-CR-001](../changes/M002-CR-001.md) / [M002-CR-002](../changes/M002-CR-002.md) 仍由守门器接收设计证据并按原条件登记，设计不自行关闭。
- **设计整稿待审**：本版原型和规格就绪；用户审阅后由守门器登记批准和正式交接，不把产品批准或本次调整请求视为设计已批准。
- **CR039-L1、CR042-L1、AI-QUALITY-90**：保持当前产品引用的一期开放/未验证状态，后续 QA 接续原报告。
- **技术/QA**：真实所有权、跨设备/并发、发布原子性、生产迁移与服务、物理手机/Safari/读屏/缩放、独立交接未验证，按验证文件与 UIA 补齐；不复制角色开关、样例凭据或硬编码数据作为生产方案。

下一动作是审阅 M002-UI-08，再正式登记接收。本交接不标设计批准、不切换阶段。
