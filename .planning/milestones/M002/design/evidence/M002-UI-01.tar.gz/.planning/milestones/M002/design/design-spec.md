---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-01
date: 2026-09-17
---

# 二期设计规格 · M002-UI-01

## 当前目标与有效范围

用户在二期产品阶段批准并进入 UI/UX 后，进一步回复“批准”，授权开始本次设计。产品批准来源为 [TRANSITION-M002-002](../reviews/product-planning.md)，完整规则见 [CAP-201–219](../product/abilities.md)；产品文件摘要已冻结，不由设计改写。

本版本覆盖 PAGE-201–216 的二期增量。设计本身待用户审阅，未批准实施、未切换技术阶段。原型是本地示例，不连接账号、AI、积分或监控服务，不证明业务事务已实现。设计源冻结于 `evidence/M002-UI-01.tar.gz`，逐文件摘要见 [版本清单](./evidence/design-manifest.json)。

保留品牌名称词涟 / WordWeave、编织标识及 DEC-019 阅读质感。二期替代一期窄版心、居中复习、每题即时判对及单一收尾流程；新范围内不得套回这些旧行为。未受本期改变的登录、词库、复习日期选择、单篇入口、密码校验和账号删除策略继续引用 [M001 交接](../../M001/handoffs/uiux.md)。旧 1080px 日期选择断点仍仅适用于其原页面，本期造文配置使用自己的 1100px 断点，不重写旧日期控件。

## 设计表达

以“故事带来记忆”为主线。首页是大字号双栏编辑式构图：左侧价值与主动作，右侧带高亮目标词的纸张；漂浮词签提示词与故事的关系。背景保持纸白，以深绿承载主要动作，浅绿、杏色、粉色、淡黄提供活力与模块识别。避免用装饰阻碍阅读，不依赖动效解释功能。

复习页面用左侧步骤导航和右侧宽内容区建立完整路径，填写、提示和下一动作按阅读顺序排列。个人中心把成长进度、签到、奖励分层呈现，积分与经验始终分开；背包先看已有道具，再切换兑换。后台改为稳定导航与高密度表格，复杂编辑用对话框，危险后果在确认前说明。以上为用户交由设计决定范围内的设计提案，具体颜色不是新增产品规则。

无外部图片、字体或服务依赖。品牌 SVG 源于 `frontend/app/presentation/components/BrandMark.vue` 的几何路径，调色遵守本期 Token；本地系统字体回退，首页纸张、纹理、徽记均为 HTML/CSS/SVG。没有使用 Figma 或生成位图资源。

## 打开原型

在产品仓库根目录执行：

```sh
python3 -m http.server 4174 --bind 127.0.0.1 --directory .planning/milestones/M002/design
```

访问 [本地原型](http://127.0.0.1:4174/prototype/?page=home)。依赖浏览器与 Python；需要 HTTP 服务读取 JSON，不能直接双击 HTML。控制条明确标为“二期交互原型 · 示例数据”，打开后可切换全部页面与场景，不属于生产产品 UI。

- `?page=…&lang=zh|en&state=…` 是可复现入口。`role=guest` 用于试用承接；默认模拟已登录学习者，管理页属于管理员示例身份。
- [copy.json](./copy.json) 是全部固定文案与动态模板来源，`static` / `templates` 映射中的 `zh.` 和 `en.` 前缀表示界面语言。原型通过 fetch 直接消费，切换语言不改变填答数据。
- [fixtures.json](./prototype/fixtures.json) 保存演示用户、运营样文、词条、奖励数值和日期；它们不是生产初始配置、真实用量、完整词库或 AI 质量样本。实际产品由 DTO 传入，不导入示例数据作为业务常量。
- [theme.css](./theme.css) 是设计 Token 与实际样式；[app.js](./prototype/app.js) 是布局、标识和可操作状态来源；[追踪表](./traceability.json)在创建界面前由批准页面职责建立。

## 页面、能力与状态入口

除表中状态外，所有页面可从控制条进入 loading/error；业务数据为空时按各页职责保留操作入口。原型状态是独立演示，不代表服务端返回格式。

| 页面 | 能力 / 数据 | 原型入口 | 关键场景 | 源函数 / 区域 | 文案键 |
|---|---|---|---|---|---|
| PAGE-201 复习填写 | CAP-201 / CAP-204 / CAP-206；DATA-201，原 DATA-012/013/014 | `?page=review` | normal / resume / denied；实际填写后刷新恢复 | `review / .review-layout / .slots / .hint / [data-region=passage]` | `review.*, slot, gap, previous, next, skip` |
| PAGE-202 当前批次概览 | CAP-202；DATA-201 | `?page=overview` | normal / submit-error / response-lost；从复习进入保留最新输入 | `review / .answer-row / .answer-link / #submit` | `overview.*, wordanswers, passageanswers, unanswered, submit` |
| PAGE-203 提交后总结 | CAP-203 / CAP-213；DATA-202/203/208 | `?page=summary` | normal / success / multibatch；直接进入为演示结果，不是历史入口 | `review / .result-word / .review-footer` | `summary.*, correct, incorrect, restart, finish, nextbatch` |
| PAGE-204 造文工具台 | CAP-206 / CAP-208 / CAP-216；DATA-203/211，原词表、计划、生成资源 | `?page=create` | normal / noquota / nomodel / nolength / failure；生成后可停止或收录 | `generation / .settings / #generate / [data-region=generation-result]` | `create.*, random, model, style, length, explain, quota` |
| PAGE-205 首页与快速试用 | CAP-207 / CAP-218；DATA-212 | `?page=home` | normal / empty | `home / [data-region=hero] / #presets` | `hero.*, home.*, path.*, try, sample` |
| PAGE-206 个人资料 | CAP-209；DATA-204 | `?page=profile` | normal / empty / save-error | `profile / #profile-form` | `profile.*, nickname, gender, lastlogin, lastlearn, welcome` |
| PAGE-207 消息列表与正文弹窗 | CAP-210；DATA-205 | `?page=notices` | normal / empty；通过 Header 打开，登录模拟触发正文 | `notices / .notice-entry / #dialog` | `notices.*, notice.*, position` |
| PAGE-208 模型和计划管理 | CAP-205 / CAP-206 / CAP-216；DATA-211，原 DATA-006/008 | `?page=models` | normal / save-error；移除确认、优先级重复反馈 | `models / .data-table / .form-grid` | `models, model.remove.*, plan.*, priority` |
| PAGE-209 平台消息管理 | CAP-210；DATA-205 | `?page=messages` | normal / save-error；编辑、预览、隐藏、提醒 | `messages / #body-zh / #body-en / #dialog` | `messages, markdown, visible, remind, preview` |
| PAGE-210 成长运营配置 | CAP-214 / CAP-215 / CAP-217；DATA-206/208/209/210 | `?page=operations` | normal / save-error；四个页签、四类道具、六档及更多 | `operations / .tabs / .data-table / itemForm` | `operations, item.*, threshold, reward*, addtier` |
| PAGE-211 用户积分管理 | CAP-217；DATA-207 | `?page=credits` | normal / save-error；非正补发拒绝 | `credits / #credit-amount / #found-user` | `credits, credit.rule, positive, base.*` |
| PAGE-212 热门预设管理 | CAP-218；DATA-212/214 | `?page=presets` | normal / failure / save-error；预览前后、参数失效、手动发布 | `presets / #preset-words / [data-action=preset-publish]` | `presets, preset.*, preview.*, publish.*, usage` |
| PAGE-213 全局监控 | CAP-219；DATA-213/214 | `?page=metrics` | normal / empty / delayed；D30 未成熟、热力图不可用 | `metrics / .metrics-grid / .chart / .stats` | `metrics.*, uv, pv, wau, failure, retention` |
| PAGE-214 个人中心学习成长 | CAP-211 / CAP-212 / CAP-213 / CAP-214；DATA-203/206/207/208/209 | `?page=growth` | normal / empty / blocked / disabled / demoted / maxlevel | `growth / .growth-banner / .calendar / .achievement-grid` | `growth.*, signin.*, reward.*, claim*, maxlevel` |
| PAGE-215 积分兑换与背包 | CAP-215 / CAP-216；DATA-207/210/211 | `?page=bag` | normal / empty / covered / retired / expired / active / lower / insufficient | `bag / .tabs / .items-grid / #dialog` | `bag.*, card.*, covered, useby, ends, pricevalue` |
| PAGE-216 独立预设造文工作台 | CAP-218；DATA-212，原生成与认证承接资源 | `?page=trial` | normal / invalid / noquota / failure；role=guest 演示认证收录 | `generation(true) / .settings / #generate` | `preset.*, create.*, quota, guestcollect` |

## 内容顺序与动态边界

首页顺序：品牌导航 → 主标题/价值说明/造文与试用入口 → 管理员示例纸张 → 三步学习路径 → 多篇预设。示例始终带 `sample`，没有真实生成数量或未经证实的效果承诺。

复习顺序：页面说明与概览入口 → 进度 → `review.spell` → 字母槽位 → `review.translation` → `review.phrase` 开关 → 上一步/跳过/下一步。短文每个空宽度一致，以纹理与颜色标出同原词组；隐藏答案不写入输入的值、placeholder、aria-label 或长度。原词槽位长度则按已确认需求展示。

概览：单词答案/未作答 → 填入当前答案的短文 → 返回/提交。总结：两阶段结果 → 当次可用说明 → 完成/下一批/整批重来。错误是删除线与正确词并列，未答显示 `unanswered` 加正确词；不只靠颜色，不提供最近结果或历史回看。

背包：积分 → 背包/兑换页签 → 道具作用 → 状态 → 启用截止或体验结束 → 可执行动作。计划完全覆盖模型卡时保留库存并显示指定 `covered` 文案；已经启用再被覆盖时显示原结束时间。下架退换按钮优先于自然过期状态，确认展示当前退换积分和该卡剩余授权终止的结果。

| 动态模板 | 变量和真实数据来源 | 缺值 / 格式 | 原型样例 |
|---|---|---|---|
| welcome | name 为昵称或用户名；days 为上次有效学习日与当前学习日差 | 北京时间 04:00 分界；首次/从未学习/当天分别用 welcome.first / nolearn / today，不把登录时间当学习时间 | 小涟 / 2 |
| quota / wordcount | 服务端可用次数、已选词数和上限 | 未知显示加载，0 可见并禁止调用；不以 UI 计算代替鉴权 | 5 次 / 3 个词 |
| step / slot / gap / position | 当前题号、槽位、空位、消息位置 | 从 1 开始；不包含隐藏答案 | 1 / 3 |
| reward / progress / newmastery | 当前奖励配置、经验门槛、当次新增去重词数 | 无结果不编造 0；初始等级无升级奖励 | 30 分/20 XP；260/400 |
| useby / ends | 未启用期限、每模型累计授权期限 | 明确北京时间，模型卡逐模型展示，不合并成一个截止时间 | 2026-10-17 / 09-20 与 09-23 |
| pricevalue / updated / streak | 当前积分或价格、统计更新时间、连续学习日 | 下架积分在确认与提交时读取最新值；缺失费用显示 unknown | 320；12:04；7 |

运营内容用当前界面语言，缺译回退已有另一语言；英文学习正文和释义目标语言不随界面语言自动翻译。Markdown 原型仅演示标题、段落、加粗与安全转义；生产渲染允许集合由技术方案明确，禁止脚本与不安全链接。

## 详细规则与验收

详细规则集中在 [交互规范](./interactions.md) 与 [响应式和可访问性](./responsive-accessibility.md)，不在前端交接中另写一套。以下为局部 UI 验收，产品 AC 仍是业务验收依据。

| UI 验收 ID | 来源/场景 | 必须保持 | 方法与允许差异 |
|---|---|---|---|
| UIA-PAGE-201-01/02 | CAP-201/204，错答/中断 | 非空可前进；概览不判分；恢复提示可恢复；修改其他答案不丢失 | 浏览器填写、返回、刷新；DOM 实现可变，顺序/文案/保留规则不变 |
| UIA-PAGE-202-01 | CAP-202/203，部分填空提交 | 允许留空，最终总结标错/未答并给正确答案 | 实际提交检查；业务幂等交后端验收 |
| UIA-PAGE-203-01 | CAP-203，全对/重来 | 正确项不重复显示错词；重来整批清空，离开不留历史答案 | 实际操作和本地草稿检查；直接 summary URL 仅演示夹具 |
| UIA-PAGE-204-01 | CAP-206/208/216 | Story/Brief 默认，模型/释义语言显式选择；随机不重复已选；额度单处显示 | 多词/无候选/超限；候选排除当前学习库由真实接口实现 |
| UIA-PAGE-216-01 | CAP-218 | 预设只读，点击才生成，认证承接收录后才弹消息 | 浏览器；原型模拟流，不证明真实模型输出或认证幂等 |
| UIA-PAGE-214-01/02 | CAP-214 | 手动领奖、已领取禁用、不可领有原因、降级暂停升级奖励 | 点击/状态入口；奖励事务与最新配置竞争交后端 |
| UIA-PAGE-215-01/02 | CAP-215/216 | 模型全覆盖禁用，退换手动一次，高档覆盖明确损失确认 | 真实控件操作；生产需服务端重验卡状态、积分与等级 |
| UIA-PAGE-210-01/02 | CAP-217 | 四类字段隔离，新建未上架、类型固定、有历史不能删除、支持六档以上 | 创建/编辑/切页签；库存来源不能由前端猜测 |
| UIA-PAGE-211-01 | CAP-217 | 仅正数补发，无扣减或撤回入口 | 输入负数/零；真实用户查询和流水接口待技术设计 |
| UIA-PAGE-212-01 | CAP-218 | 有效预览才能发布，参数改变需重新预览，草稿不改线上 | 控件门控测试；原子版本发布由后端落实 |
| UIA-PAGE-209-01 | CAP-210 | 隐藏消息不进列表，Markdown 不执行脚本 | 浏览器操作与转义测试；生产富文本完整安全策略另验 |
| UIA-GLOBAL-01 | CAP-206/207 | ≤1440 版心，移动无页面横溢，减少动画偏好生效 | 320/390/1440/1920、zh/en；表格内部允许滚动 |
| UIA-GLOBAL-02 | 全局辅助技术 | 可命名控件、清晰焦点、对话框焦点限制、错误非单色 | Chromium + axe；真机和人工读屏另验 |

## 自检与剩余验证

浏览器结果、截图、执行脚本及版本对应关系见 [设计自检](./validation.md)。当前是待审原型，应用前端尚未转换，API/认证/配额/积分事务、真实生成质量与监控采集未接入；不要将原型通过当成生产验收。

没有新业务问题或范围扩展。草稿跨设备/保留期、事务与并发、接口契约继续交技术设计。原型只把未提交草稿放本地演示存储，结果不持久化；这不是对生产存储的选择。数值由运营后台配置，示例不冻结。
