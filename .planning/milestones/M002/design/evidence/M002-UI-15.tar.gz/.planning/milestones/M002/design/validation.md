---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-15
date: 2026-09-18
---

# UI-15 设计验证

范围为 PAGE-216 / SETTINGS15：优化独立试用台左侧配置展示，保留只读配置与显式生成。产品输入 PRODUCT-03，整体设计待审；[UI-14 冻结包](./evidence/M002-UI-14.tar.gz) 和历史证据保持。

## 浏览器与视觉

运行 `node .planning/milestones/M002/design/evidence/verify-ui15.cjs`，[结果](./evidence/UI15-browser-results.json) 三组均通过：

- 320/390/768/1440px 中英文共 8 个布局无页面横溢；四项值与当前语言一致，配置无可编辑控件；原生 details 可用 Enter 收起/展开且开始生成可达。390px 中文、1440px 英文两个 axe 无违规。
- 精选中选择英语释义预设，进入正确标题、Model B 及配置；进入不生成且额度仍为 3。切换英文后参数显示正确；显式生成完成后仍保留配置，访客收录进入认证。预设失效、额度不足、无模型、无长度均保持禁用生成。
- 测试中仅通过响应拦截注入长模型名，320px 正确换行无横溢；未修改真实夹具。普通造文台四个选择器可编辑，随机选词入口保持。

实际打开检查 [桌面](./evidence/UI15-trial-1440-zh.png)、[手机](./evidence/UI15-trial-390-zh.png) 和 [平板](./evidence/UI15-trial-768-zh.png)，与 [修改前](./evidence/UI15-trial-before-1440.png) 对照：模型形成重点区域，其余三行对齐；平板为横向摘要，手机纵排，图标与标签配合。右侧词语/开始生成/结果区域沿用原有顺序。其他 320px 中英文截图一并保存。

## 一致性与交付边界

[文案变更](./evidence/UI15-copy-changes.json) 仅新增配置标题，并记录复用的场景/长度/语言文案键；预设底层值与模型名称不变。新样式均作用于 `.trial-settings`，不改普通造文的选择器样式。

运行 `python3 .planning/milestones/M002/design/evidence/verify-ui15-static.py`，[静态报告](./evidence/UI15-static-results.json) 核对追踪、双语、模块语法、版本/链接及 471 个受保护输入/历史原件。[UI-15 冻结包](./evidence/M002-UI-15.tar.gz) / [清单](./evidence/M002-UI-15-manifest.json) 保存完整来源，[当前指针](./evidence/design-manifest.json) 同步。

仅验证本次呈现及相关原型流程，未重跑首页动效或其他后台业务。未修改产品、正式应用、工作流、CR 或业务夹具，未提交 Git、未调用真实 AI。生产 API、物理设备/iOS Safari、人工读屏和缩放未验证；模拟流程与 axe 不等于生产验收。独立新会话交接未执行，模型用量未知。
