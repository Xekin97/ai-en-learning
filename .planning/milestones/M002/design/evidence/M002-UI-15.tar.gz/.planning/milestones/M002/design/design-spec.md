---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-15
date: 2026-09-18
---

# 二期设计规格 · M002-UI-15

## 当前目标与有效范围

本轮用户要求优化试用独立造文台左侧配置展示。designer-tony 将原无层级定义列表改为模型重点区域与三行配置摘要，统一对齐、图标和本地化值，记录见 [UI15-reception.json](./evidence/UI15-reception.json)。旧默认缩进和中文界面直接显示 Story/Brief 的方式退出当前标准，原 [UI-14 冻结包](./evidence/M002-UI-14.tar.gz) / [清单](./evidence/M002-UI-14-manifest.json) 保留。

本轮限定 PAGE-216 配置呈现；普通造文台选择器、试用只读规则、标题/词条/生成与收录流程，以及首页叠卡动效和其他设计继续有效。无新增业务范围，整体设计仍待审阅。

当前设计 **M002-UI-15 / awaiting_user_review** 接收已批准的 [M002-PRODUCT-03](../handoffs/product.md)，正式交接为 [TRANSITION-M002-006](../reviews/product-title-revision.md)。沿用 [CR-002](../changes/M002-CR-002.md)、D2-81/82 的本人批次标题编辑和热门预设单标题/去说明；[CR-001](../changes/M002-CR-001.md) 的完整继承继续有效。25 个当前 PAGE、28 个视图和 49 个 CAP 见 [traceability.json](./traceability.json)。产品正文分别为 `../product/abilities.md`、`data-assets.md`、`pages/index.md` 和 `ai-behavior.md`。

旧 UI-05 的批次标题只读/双语故事标题夹具、预设中英文标题和说明控件及展示已失效，由本版替换。原 UI-05 可从 [修订前快照](./evidence/M002-UI-05-before-06.tar.gz) 恢复，原 [冻结清单](./evidence/M002-UI-05-manifest.json) 与证据保持。登录注册、复习库、日期范围、独立会话、完整后台和其他二期规则继续保留；不采用撤回的 `product-baseline-draft/`。

设计整稿仍待审，不把产品批准当设计批准。当前完整快照与逐文件摘要见 [design-manifest.json](./evidence/design-manifest.json)；未提交 Git。产品、CR、批准与工作流控制文件不由设计修改。

## 设计表达与内容优先级

保留原有阅读主题：暖白纸面、深绿文字、浅绿/杏色词签，字母与纸张传达学习主题。系统无衬线承担界面，衬线承担短文；1440px 版心容纳工作台与后台，但阅读栏保留适合连续阅读的宽度。复习的输入、释义、短语依次左对齐。首页只保留概括、两篇叠放示例和学习路径，多篇预设放在“精选”。

个人中心头像依次进入个人信息、账号成长、道具卡、兑换中心，四视图共享左侧资料。成长默认每类展示当前档，其余档位可展开；等级奖励单列为逐级可领条目。后台八模块为概览、数据分析、模型管理、计划管理、用户管理、成长运营、消息管理、首页预设；模型和计划各有完整编辑页，消息是独立模块。

视觉资产使用现有品牌标识、CSS 纸面/词签及本地 Iconify Lucide SVG。图标资源、许可与映射见下节；没有外部图片、外部字体、Figma 或待替换占位图；界面只显示当前语言品牌“词涟”或“WordWeave”。首页叠卡增加克制漂浮与前后交换，阅读时停止自动动效；减少动效时保留静态构图。

## UI-15 试用配置展示

**UIA-PAGE-216-SETTINGS15 / PAGE-216 / CAP-218 / DATA-212**：独立预设造文台左栏使用 `.settings.trial-settings` 原生 details，默认展开；标题为 `trial.config.title`，配锁图标、可访问的锁定状态和折叠箭头。内部 `trialConfiguration(pre)` 先显示 `.trial-model` 的模型图标、标签与名称，再以 `.trial-config-facts / .trial-config-row` 显示场景、长度、释义语言，标签/值统一对齐，分隔线建立层级。

模型名保持发布值；场景、长度和释义语言显示使用既有 `a.preset.style/length/language.*` 文案键，不修改预设存储值和生成配置。全文标题、已选词和开始生成位置保持。所有配置是语义定义列表，无输入、选择框、虚假禁用控件或新增说明墙。右侧沿用现有词条和生成状态。

宽屏保留 310px 左列；761–1100px 配置在内容上方，模型与三项摘要横向布局；≤760px 模型在上、三行配置在下。长模型名/值自然换行，不能靠截断或隐藏适配。保持 details 键盘展开/收起、预设来源身份、显式生成、额度不足/失效禁用及生成后收录认证承接。验证中英文、320/390/768/1440px，及普通造文配置仍可编辑。

## UI-13 两篇交叉叠卡

**UIA-PAGE-205-STACK13 / PAGE-205 / CAP-001/003/021/207 / DATA-018/212**：首页使用两篇各自完整的单段英文故事，标题分别为 A story around the corner. 与 A garden worth growing.，正文分别 49 / 46 词。每篇各有 6 个目标词签及正文高亮，两篇合计 8 个不同目标词。每卡保留示例标识、场景/长度、独立标题、词签、一个正文段落及一个双语释义；源为 `fixtures.hero.stories`、app.js `home()`、`.home-card-stack / .home-paper-back / .home-paper-front`。中英文 UI 共用英文短文。

以相对定位、负边距、层级和相反旋转角构成前后交叉叠放：后卡浅杏纸面、前卡暖白纸面，移除旧绿色大底板。两篇均为真实正文，默认允许后卡下部被遮挡；悬停、点按或 Tab 聚焦对应卡时将其置顶完整阅读，不截断、不复制正文；自动动效与切换按 MOTION14 执行。键盘按后卡、前卡顺序访问，焦点圈可见。样文不生成、不扣次。

>1100px 介绍/叠卡两列；≤1100px 单列；手机保留叠卡但收小角度与水平偏移，防止横溢。正文桌面 18px、手机 17px，与卡片密度配合；不设固定正文高度和内部纵向滚动。详细数值以 theme.css 为准。STACK13 替代 SAMPLE12；旧 SAMPLE12 只在 UI-12 冻结包解释其历史验收。当前验证覆盖中英文、320/390/768/1440px、真实重叠、完整阅读及焦点/点按置顶。

## UI-14 叠卡漂浮与切换

**UIA-PAGE-205-MOTION14 / PAGE-205 / CAP-001/003/021/207 / DATA-018/212**：沿用 STACK13 的两篇全文、词签、字号、角度与布局。新增 [home-motion.js](./prototype/home-motion.js)，由 app.js `HM.afterRender()` 装配/销毁；theme.css `.home-paper` 漂浮动画与 `data-motion / data-top / data-switching` 驱动呈现。详情仅在交互文档维护。

两卡 6 秒缓动漂浮、最多上移 6px，前后错开 3 秒；空闲且在视口中时等待 8 秒交换前后层级，过渡约 640ms，卡片先轻微分开再回到原错位。不会改变正文、DOM 顺序或键盘焦点。用户鼠标进入、点按、滚轮或聚焦阅读后，本次首页访问停止漂浮和自动换层；手动选择仍有过渡。语言重绘保持阅读状态；离开首页再入重新开始。减少动效关闭漂浮、自动换层及切换动画，手动直接置顶；离屏/后台暂停，卸载清理动画和定时器。

验收用真实等待/连续帧验证移动与换层，不用静态截图替代；检查阅读后稳定、快速连续选择、运行时减少动效、窄屏整个过渡不横溢、页面重绘/离开后的清理。动效不触发播报、生成或计量，不提供暂停/继续按钮。静态 STACK13 验收仍保留内容和构图部分。

## UI-11 导航与阅读中断

主导航中文均为两字，顺序与路由固定如下；英文使用自然的单词，不为字数一致强行缩写。

| 中文 / 英文 | 路由 | 页面与用途 |
|---|---|---|
| 首页 / Home | home | PAGE-205 · 产品概括与示例 |
| 精选 / Picks | explore | PAGE-217 · 浏览预设、进入试用 |
| 学习 / Learn | create | PAGE-204 · 自选词与生成短文 |
| 复习 / Review | range | PAGE-007 · 日期范围与复习入口 |
| 书架 / Library | library | PAGE-005 · 用户收录的短文 |

导航、页标题、收录、返回和登录承接文案统一使用“书架”，页面标题为“我的书架”。功能仍对应原私人复习库，保留统计、搜索、参与开关、删除和复习入口。后台模块及头像四项菜单保持。trial 高亮精选；batch 高亮书架；review/overview/summary/sessiondone 高亮复习。

下列 NAV11 共用验收：中英文顺序/标签正确；访客和学习者均保持五项；点击进入对应现有路由，私有页保留认证与返回意图；当前分区高亮；320/390/1440px 无页面横溢。

| 验收 ID | 页面 |
|---|---|
| UIA-PAGE-002-NAV11 | PAGE-002 · register |
| UIA-PAGE-003-NAV11 | PAGE-003 · login |
| UIA-PAGE-005-NAV11 | PAGE-005 · library |
| UIA-PAGE-006-NAV11 | PAGE-006 · batch |
| UIA-PAGE-007-NAV11 | PAGE-007 · range |
| UIA-PAGE-008-NAV11 | PAGE-008 · sessiondone |
| UIA-PAGE-201-NAV11 | PAGE-201 · review |
| UIA-PAGE-202-NAV11 | PAGE-202 · overview |
| UIA-PAGE-203-NAV11 | PAGE-203 · summary |
| UIA-PAGE-204-NAV11 | PAGE-204 · create |
| UIA-PAGE-205-NAV11 | PAGE-205 · home |
| UIA-PAGE-206-NAV11 | PAGE-206 · profile |
| UIA-PAGE-207-NAV11 | PAGE-207 · notices |
| UIA-PAGE-214-NAV11 | PAGE-214 · growth |
| UIA-PAGE-215-NAV11 | PAGE-215 · bag / shop |
| UIA-PAGE-216-NAV11 | PAGE-216 · trial |
| UIA-PAGE-217-NAV11 | PAGE-217 · explore |

**UIA-PAGE-217-CAR11**：轮播控制区只有上一条、位置计数、下一条，不渲染播放/暂停控件或“手动浏览”等状态文案。多条内容初始每 8 秒自动切换，用户鼠标进入阅读区域、控件获焦、触摸、滚轮、筛选或手动切换后，本次访问停止自动；移开鼠标或切换界面语言也不恢复。离开目录再进入可重新自动，筛选和位置保留。页面隐藏/区域不在视口时停止计时；减少动效仅手动瞬间定位。完整配置、全文、语言 Tab、空/单条状态、键盘/触控及对应预设跳转保持。完整规则见交互文档。

## 首页骨架与统一图标

首页左侧为 AI 学习定位、价值标题、简短说明和学习/精选双入口，右侧按 STACK13 展示两篇交叉叠卡，分别呈现词签、正文与释义。底部保留三个紧凑步骤，首页不新增成长入口或运营内容。公开固定样文无模型请求、额度消耗或私人学习信息。

| 区域 / 验收 | 来源与文案 | 可观察结果 |
|---|---|---|
| UIA-PAGE-205-HOME10 · `.home-hero` | app.js `home()`；`hero.eyebrow/title/desc/cta/secondary` | 左侧两行标题和两个真实导航；>1100px 双列，≤1100px 单列。点击图标部分也能导航。 |
| 首页示例 · `.home-example` | `hero.sample`、fixtures.hero.stories / dictionary；`.home-card-stack / .home-word-row / .home-paper / .home-word-meaning` | 两篇单段示例，每篇 6 词、高亮和释义；交叉叠放并可置顶阅读，标明示例且不生成。词签为静态文本。 |
| 简洁步骤 · `.home-path` | `hero.steps / path.*` | 选词、阅读、拼写复习；图标、标题、简短说明成组，手机纵排。 |
| 图标原始资产 | [lucide.json](./prototype/assets/lucide.json)、[icons.js](./prototype/icons.js)、[来源说明](./prototype/assets/README.md)、[许可](./prototype/assets/lucide-LICENSE.txt) | 来自 [Iconify Lucide](https://icon-sets.iconify.design/lucide/)，本地 SVG，不用字符或字体兜底，不依赖在线图标请求。 |

图标映射：身份/空态为 book-open / inbox / file-pen-line；道具按补签/次数/模型/计划使用 calendar-check / ticket / bot / gem；成就按签到/掌握/复习/短文使用 calendar-check / brain / clipboard-check / notebook-pen。头像四菜单与后台八模块用 `icons.js` 的 routeIcons；随机/添加/保存等按钮使用 actionIcons。图库箭头、删除词、展开箭头和答案编辑使用 SVG；保留文字和已有 aria-label。品牌标识继续使用原始专用 SVG，不把品牌当通用图标替换。

短文复习的匿名分组使用圆/菱/三角/方/星/六边形 SVG，仍按会话稳定随机映射，颜色/边线继续辅助区分。输入可访问名称使用 `groupname.*`，不将 SVG 标签拼进读屏名称。数字、数量乘号和正常标点不属于图标替换。

### 共享图标验收追踪

每条 ICON10 共用：图标映射语义正确；有文字或可访问名称；SVG 不单独获焦；点击 SVG 本身与按钮同效；新图标不撑破小屏布局。原页面的业务验收与 COPY09 继续有效。

| 验收 ID | 页面 / 视图 |
|---|---|
| UIA-PAGE-002-ICON10 | PAGE-002 · register |
| UIA-PAGE-003-ICON10 | PAGE-003 · login |
| UIA-PAGE-005-ICON10 | PAGE-005 · library |
| UIA-PAGE-006-ICON10 | PAGE-006 · batch |
| UIA-PAGE-007-ICON10 | PAGE-007 · range |
| UIA-PAGE-008-ICON10 | PAGE-008 · sessiondone |
| UIA-PAGE-103-ICON10 | PAGE-103 · users / userdetail |
| UIA-PAGE-201-ICON10 | PAGE-201 · review |
| UIA-PAGE-202-ICON10 | PAGE-202 · overview |
| UIA-PAGE-203-ICON10 | PAGE-203 · summary |
| UIA-PAGE-204-ICON10 | PAGE-204 · create |
| UIA-PAGE-205-ICON10 | PAGE-205 · home |
| UIA-PAGE-206-ICON10 | PAGE-206 · profile |
| UIA-PAGE-207-ICON10 | PAGE-207 · notices |
| UIA-PAGE-208-ICON10 | PAGE-208 · models / plans |
| UIA-PAGE-209-ICON10 | PAGE-209 · messages |
| UIA-PAGE-210-ICON10 | PAGE-210 · operations |
| UIA-PAGE-211-ICON10 | PAGE-211 · credits |
| UIA-PAGE-212-ICON10 | PAGE-212 · presets |
| UIA-PAGE-213-ICON10 | PAGE-213 · metrics |
| UIA-PAGE-214-ICON10 | PAGE-214 · growth |
| UIA-PAGE-215-ICON10 | PAGE-215 · bag / shop |
| UIA-PAGE-216-ICON10 | PAGE-216 · trial |
| UIA-PAGE-217-ICON10 | PAGE-217 · explore |
| UIA-PAGE-218-ICON10 | PAGE-218 · adminhome |

## UI-09 文案与布局收敛

普通页面只保留任务标题、必要上下文和操作反馈；移除重复的“词涟 / 开始学习”面包屑、无帮助的规则复述、重复额度总数和试用操作说明。中英文精简记录见 [文案差异](./evidence/UI09-copy-changes.json)。复杂后台规则使用原生“规则说明”折叠区；保存影响、删除后果和覆盖/扣次等确认仍明确显示。删减的是表达冗余，不删页面能力、字段、失败状态或确认后果。

认证使用一个最大 920px 的完整纸面区域：左侧阅读介绍，右侧标题、表单和账号切换；右侧所有控件同宽同起点。手机普通登录/注册仅保留表单，待收录短文/来源返回/承接丢失的必要上下文仍保留。用户名和密码规则只在注册显示并用 aria-describedby 关联；登录保留原校验、错误提示和 Enter 提交。

后台字段使用一致标签、输入高度和行距；搜索按钮与输入底边对齐，计划/消息/预设等编辑页使用清晰的保存区。双列在手机变单列，表格仅在自身容器内横滚。计划规则页可展开查看，提交时再次明确影响；不把所有风险提醒全局折叠。

用户主内容随内容决定高度，删除 75vh 强制撑高、过大的空态和重复上下边距。页标题与内容之间 20–24px，纸面内边距桌面 24px/手机 18px；正文字号、行高与可点击区域保持可读。复习仅在步骤导航保留概览入口，任意题仍可进入概览；保留字母槽→释义→短语顺序。试用全文不截断，生成工作台以预设标题作为唯一主标题，避免重复标题区。

### 全站新增视觉验收

所有条目共用：中英文文案可理解；无重复标题/无决策价值的规则墙；字段与按钮有一致对齐；390/768/1440px 不产生页面横溢。内容型长页不要求压成一屏。此表是本角色验收目标，用户视觉批准仍待审。

| 验收 ID | 当前页面 | 本轮重点 |
|---|---|---|
| UIA-PAGE-002-COPY09 | PAGE-002 · register | 统一认证表面、同宽对齐、注册提示及必要承接上下文 |
| UIA-PAGE-003-COPY09 | PAGE-003 · login | 统一认证表面、同宽对齐、注册提示及必要承接上下文 |
| UIA-PAGE-005-COPY09 | PAGE-005 · library | 共享标题、文案层级、内容驱动高度与响应式间距 |
| UIA-PAGE-006-COPY09 | PAGE-006 · batch | 共享标题、文案层级、内容驱动高度与响应式间距 |
| UIA-PAGE-007-COPY09 | PAGE-007 · range | 共享标题、文案层级、内容驱动高度与响应式间距 |
| UIA-PAGE-008-COPY09 | PAGE-008 · sessiondone | 共享标题、文案层级、内容驱动高度与响应式间距 |
| UIA-PAGE-103-COPY09 | PAGE-103 · users / userdetail | 字段、搜索和保存区对齐，说明按需展开，操作后果保留 |
| UIA-PAGE-201-COPY09 | PAGE-201 · review | 复习核心操作优先，概览可达，结果提示不重复 |
| UIA-PAGE-202-COPY09 | PAGE-202 · overview | 复习核心操作优先，概览可达，结果提示不重复 |
| UIA-PAGE-203-COPY09 | PAGE-203 · summary | 复习核心操作优先，概览可达，结果提示不重复 |
| UIA-PAGE-204-COPY09 | PAGE-204 · create | 共享标题、文案层级、内容驱动高度与响应式间距 |
| UIA-PAGE-205-COPY09 | PAGE-205 · home | 共享标题、文案层级、内容驱动高度与响应式间距 |
| UIA-PAGE-206-COPY09 | PAGE-206 · profile | 共享标题、文案层级、内容驱动高度与响应式间距 |
| UIA-PAGE-207-COPY09 | PAGE-207 · notices | 共享标题、文案层级、内容驱动高度与响应式间距 |
| UIA-PAGE-208-COPY09 | PAGE-208 · models / plans | 字段、搜索和保存区对齐，说明按需展开，操作后果保留 |
| UIA-PAGE-209-COPY09 | PAGE-209 · messages | 字段、搜索和保存区对齐，说明按需展开，操作后果保留 |
| UIA-PAGE-210-COPY09 | PAGE-210 · operations | 字段、搜索和保存区对齐，说明按需展开，操作后果保留 |
| UIA-PAGE-211-COPY09 | PAGE-211 · credits | 共享标题、文案层级、内容驱动高度与响应式间距 |
| UIA-PAGE-212-COPY09 | PAGE-212 · presets | 字段、搜索和保存区对齐，说明按需展开，操作后果保留 |
| UIA-PAGE-213-COPY09 | PAGE-213 · metrics | 共享标题、文案层级、内容驱动高度与响应式间距 |
| UIA-PAGE-214-COPY09 | PAGE-214 · growth | 共享标题、文案层级、内容驱动高度与响应式间距 |
| UIA-PAGE-215-COPY09 | PAGE-215 · bag / shop | 共享标题、文案层级、内容驱动高度与响应式间距 |
| UIA-PAGE-216-COPY09 | PAGE-216 · trial | 配置和完整短文保留，消除重复标题与操作介绍 |
| UIA-PAGE-217-COPY09 | PAGE-217 · explore | 配置和完整短文保留，消除重复标题与操作介绍 |
| UIA-PAGE-218-COPY09 | PAGE-218 · adminhome | 共享标题、文案层级、内容驱动高度与响应式间距 |

## 启动、来源与演示边界

工作目录为本文件所在 `design/`，运行 `python -m http.server 4174 --bind 127.0.0.1`，访问 [首页](http://127.0.0.1:4174/prototype/?page=home&lang=zh&v=M002-UI-15)。不能双击 HTML：模块与文案使用同源 fetch。

原型入口 `prototype/index.html`、横向预设阅读与轮播 `gallery.js`、布局及导航 `prototype/app.js`；`identity.js` 为认证，`learning.js` 为学习，`admin.js` 为模型/计划/用户，`operations.js` 为成长配置，`presets.js` 为预设，`growth.js` 为账号成长，`benefits.js` 为卡片确认和组合权益示例。统一文案为 [copy.json](./copy.json)，Token/实际样式为 [theme.css](./theme.css)，业务示例在 `prototype/fixtures.json`。

URL 使用 `page`、`lang=zh|en`、`role=guest|learner`、`state`；页脚“二期交互原型”控制条可切页和状态，不属于生产界面。这里的角色参数仅用于设计审阅，不是生产权限方案。控制条放在内容后，避免遮挡操作。

夹具时刻固定为 2026-09-17 12:00 北京时间。本人批次（含修改后标题）、学习草稿和最小事实用隔离的 `ww-m002-learning-ui06` sessionStorage 模拟；认证、成长、卡片、配置、额度为本页内存演示，刷新不证明服务端持久化。模型是示例名称，预览是确定样文，无真实 AI、账号、监控请求。后台无限预览的次数与前台生成分别示意。

## 页面、区域与验收

表中 PAGE 全部属于当前 M002 基线，包括被继承保留的编号。每一行是可观察验收，固定文案键引用共享源；详细状态在交互文件。前端可调整组件与 DOM 组织，但不能改变内容顺序、作用、文案或业务分支。

| 当前页面 / 验收 ID | 原型入口与状态 | 实际源与区域 | 文案键 | 必须保持的结果 |
|---|---|---|---|---|
| PAGE-002 注册<br>UIA-PAGE-002-01 | `?page=register`<br>username-taken / auth-error；承接与登录互跳 | identity.js · #identity-form / .auth-intent | `i.*` | 用户名、密码、确认密码、规则、提交、登录入口；不增加邮箱/手机；成功先承接当前短文，再提醒正文。 |
| PAGE-003 登录<br>UIA-PAGE-003-01 | `?page=login`<br>auth-error / admin；来源页返回 | identity.js · #identity-form / .auth-intent | `login / i.* / welcome` | 通用认证错误；管理员进入后台，学习者返回原意图；Enter 可提交，密码不落浏览器存储。 |
| PAGE-005 学习记录<br>UIA-PAGE-005-01 | `?page=library`<br>empty / save-error；搜索/续载/删除 | learning.js · .library-stats / #library-query / .library-row | `l.library* / l.stat.* / l.search*` | 六项全库统计→目标词搜索→旧到新批次；显示当前标题，自定义标题下保留目标词条；直接复习、详情、参与开关、删除均保留。返回保留查询与续载；累计成长不因删批次回退。 |
| PAGE-006 批次详情<br>UIA-PAGE-006-01 | `?page=batch`<br>?batch=b1；unavailable / save-error / title-denied | learning.js · .batch-detail / .batch-title-header / #batch-title-form / .resource-grid | `l.detail / l.title.* / l.snapshot / l.resources` | 标题在文章顶部显示并可由本人编辑/保存/取消；整篇原文、标签、原词释义/短语和配置快照仍只读；参与开关、直接复习与删除保持。 |
| PAGE-007 复习范围<br>UIA-PAGE-007-01 | `?page=range`<br>preview-error / preview-loading；非法日期/零命中 | learning.js · .range-editor / #range-from / #range-to | `l.range* / l.dates* / l.matches*` | 最近七天且首尾包含；只筛参与批次；未知数量用横线；编辑不丢焦点。存在未完成范围时可以恢复或确认另开。 |
| PAGE-008 复习会话容器与结束<br>UIA-PAGE-008-01 | `?page=sessiondone`<br>最后一批提交后完成→sessiondone | learning.js · .session-totals | `l.sessiondone* / l.total.*` | 保留本轮完成/成功/失败最小概况，能回库或日期选择；不给历史逐题答案入口。 |
| PAGE-103 用户管理<br>UIA-PAGE-103-01 | `?page=users` / `?page=userdetail`<br>search-error / save-error / unavailable | admin.js · #admin-user-query / .admin-facts | `a.users.* / a.user.* / a.password.* / a.library.*` | 用户名定位、续载、返回保留；详情四分区：资料计划、等级成长、积分、只读学习记录。管理员身份不出现学习者动作。 |
| PAGE-201 复习填写<br>UIA-PAGE-201-01 | `?page=review`<br>?batch=b3；resume / denied / multibatch | learning.js · .review-context / .slots / .hint / [data-region=passage] | `review.* / slot / gap / previous / next / skip` | 拼写标题→字母槽→解释→短语开关；非空前进、不即时判对；短文固定宽空与稳定匿名分组；前退和概览保留输入。 |
| PAGE-202 当前批次概览<br>UIA-PAGE-202-01 | `?page=overview`<br>submit-error / response-lost | learning.js · .answer-row / .answer-link / #submit | `overview.* / wordanswers / passageanswers / submit` | 当前批次词答列表＋填入用户答案的短文；点击回对应位置编辑；全空也可提交；失败可重试，响应丢失先确认状态且不重复结算。 |
| PAGE-203 提交后总结<br>UIA-PAGE-203-01 | `?page=summary`<br>必须由提交进入；直接地址不给历史答案 | learning.js · .result-word / .review-footer | `summary.* / newmastery / restart / nextbatch / finish` | 正确文字标色，错误/未答划线并邻接正确词；重来清本批草稿，下一批前进。离开后的逐题总结不保留。 |
| PAGE-204 造文工具台<br>UIA-PAGE-204-01 | `?page=create`<br>noquota / nomodel / nolength / failure / save-error | app.js generation · .settings / #generate / [data-region=generation-result]；benefits.js | `create.* / random / b.* / quota` | 配置可折叠；模型和释义语言显式选，Story/Brief 合法时默认；固定词库、去重、上限及随机避开当前库；完整结果再收录。取消扣次，系统失败返还原来源。 |
| PAGE-205 简洁首页<br>UIA-PAGE-205-01 | `?page=home`<br>normal；中英文/减少动效 | app.js home · [data-region=hero] / .home-path | `hero.* / path.* / sample` | 简洁价值介绍＋造文/试用入口＋两篇带示例标识的 AI 短文；主导航首页、精选、学习、复习、书架，无成长主导航。 |
| PAGE-206 个人资料<br>UIA-PAGE-206-01 | `?page=profile`<br>save-error；改密/注销两次确认 | app.js profile/accountShell · .account-sidebar / #profile-form；identity.js | `profile.* / nickname / gender / i.*` | 头像四项分区共用左资料右内容；昵称空回退用户名；用户名/基础计划只读。改密需当前/新/确认，注销需密码及最终确认。 |
| PAGE-207 消息列表与正文弹窗<br>UIA-PAGE-207-01 | `?page=notices`<br>empty；明确登录后提醒正文 | app.js notices/noticeDialog · .notice-entry / #dialog | `notices.* / notice.* / position` | 列表提醒优先再按时间倒序；登录直接打开对应提醒正文，多条上一条/下一条；隐藏优先，无已读红点。 |
| PAGE-208 模型管理、计划管理（两个独立模块）<br>UIA-PAGE-208-01 | `?page=models` / `?page=plans`<br>missing-key / save-error；引用移除/优先级冲突 | admin.js models/plans · .admin-credential / #plan-limit / #plan-unlimited | `a.model.* / a.key.* / a.plan.* / priority` | 模型、计划两个独立导航。全局密钥脱敏/替换，模型名称说明原始ID启停移除；四个固定计划的模型、长度、词上限、零/不限次数及唯一优先级全量编辑。 |
| PAGE-209 平台消息管理<br>UIA-PAGE-209-01 | `?page=messages`<br>save-error；显示/提醒独立 | app.js messages · #body-zh / #body-en / #dialog | `a.messages* / markdown / visible / remind` | 独立一级消息管理；列表→双语 Markdown→预览→显示/提醒开关→保存；失败保留输入。 |
| PAGE-210 成长运营配置<br>UIA-PAGE-210-01 | `?page=operations`<br>save-error；四页签/多档/奖励引用 | operations.js；app.js itemForm · .tier-table / #item-type | `operations / item.* / reward* / a.tier.*` | 签到与经验、等级、四类成就、四类道具；动态多档含名称说明称号/奖励/启停；道具类型固定、默认未上架，有历史或引用不能删。 |
| PAGE-211 用户管理内的积分操作<br>UIA-PAGE-211-01 | `?page=credits`<br>save-error；非正数/对象确认 | admin.js points · #credit-amount / #found-user | `a.ledger / a.source.* / credit.rule / positive` | 用户详情积分区域及兼容独立视图：余额、来源流水、正数补发确认；不提供扣分、撤回或改经验。 |
| PAGE-212 热门预设管理<br>UIA-PAGE-212-01 | `?page=presets`<br>failure / save-error；预览失效/发布前后 | presets.js · #preset-title / #preset-words / [data-action=preset-publish] | `presets / preset.* / preview.* / publish.*` | 每条仅一个标题，无说明字段；草稿、有效预览、线上快照独立；全部受支持配置、不受访客词上限；无限预览但独立计量；改参数需新预览再手动发布。 |
| PAGE-213 数据分析<br>UIA-PAGE-213-01 | `?page=metrics`<br>empty / delayed；观察中/无来源 | app.js metrics/metricDetails · .metrics-grid / .chart | `metrics.* / uv / pv / wau / retention` | 流量、漏斗、失败、留存、WAU、频次、生成收录、管理员预览指标；分母/排除项可见，D30 未成熟不报零；Clarity 不采私有内容。 |
| PAGE-214 账号成长<br>UIA-PAGE-214-01 | `?page=growth`<br>blocked / disabled / demoted / maxlevel / claim-error | growth.js · .growth-banner / .calendar / .achievement-group / [data-level] | `growth.* / signin.* / reward.* / g.*` | 经验/等级与积分分开；签到自动、补签选择确认；四类成就默认展示当前档，可展开全档；成就/逐级奖励手动整份领取，称号仅个人中心。 |
| PAGE-215 道具卡、兑换中心（两个视图）<br>UIA-PAGE-215-01 | `?page=bag` / `?page=shop`<br>covered / retired / expired / active / lower / insufficient | app.js bag；benefits.js · .items-grid / .benefit-end / #dialog | `bag.* / shop.* / card.* / b.* / covered` | 道具与兑换两视图；兑换确认扣分、使用确认结果；模型逐个累时、计划同档续期/高覆低/低拒绝、次数沿用原期限；下架退积分用实时配置且一次。 |
| PAGE-216 独立预设造文工作台<br>UIA-PAGE-216-01 | `?page=trial`<br>role=guest；invalid / noquota / failure | app.js generation(true) / trialConfiguration · .trial-settings / #generate | `preset.* / create.* / quota / guestcollect` | 展示已发布的单一标题（不随 UI 语言变），无预设说明；试用选择后独立锁定工作台；全部参数只读且需手动生成；配置优先但仍扣身份所属次数；完整生成后沿原收录/注册复习链。 |
| PAGE-217 独立试用目录<br>UIA-PAGE-217-01 | `?page=explore`<br>empty / single；role=guest | gallery.js · .preset-gallery / .gallery-track / .gallery-config / .gallery-passage | `explore.* / gallery.* / model / style / length / explain / words / try` | 先按释义语言 Tab 筛选，再横向自动滚动多篇预设；完整词条/模型/场景/长度/释义语言和已发布完整样文；阅读时停止自动/手动/触控。单标题无说明；我也试试进入对应锁定台，无结果给普通台入口。 |
| PAGE-218 后台概览<br>UIA-PAGE-218-01 | `?page=adminhome`<br>empty | admin.js home · .admin-launch-grid / .metrics-grid | `a.adminhome / a.overview.* / updated` | 后台八模块概览及指标摘要，详细指标进入数据分析；管理员壳不混学习者菜单。 |

## 继承的标题交互验收与来源

| 验收 ID | 页面、区域及操作 | 必须保持 | 允许差异与检查 |
|---|---|---|---|
| UIA-PAGE-005-02 | library / `.library-row`，从详情改名后返回 | 当前标题、原目标词条、六项统计、旧到新顺序；仍只搜目标词，保留查询与已加载范围 | 组件结构可变；浏览器操作及文本/顺序断言 |
| UIA-PAGE-006-02 | batch / `.batch-title-header`、`#batch-title-form`；点击编辑 | 标题→编辑按钮；编辑时标签/输入→辅助提示→就地错误（如有）→保存/取消；空白拒绝、保存持久、取消不改；文案 `l.title.*` 与 `cancel` | 不增加标题字符数产品限制；长标题换行，输入可水平编辑；桌面/手机与键盘检查 |
| UIA-PAGE-006-03 | `state=save-error` / `title-denied`；编辑后保存 | 失败保留输入和已存值，焦点回输入；恢复 normal 可重试。无权/已删除不重建；输入中的标记按文本显示 | 原型只模拟失败，无真实权限验证；生产使用服务端校验 |
| UIA-PAGE-006-04 | 新旧、参与/暂停批次；360/390/768/1440px | 短标题与很长标题均可读；保存/取消可触达；UI 语言切换和刷新保持已存标题；正文资源不变 | 字形随系统可变，布局与功能不得丢失；axe 与实际截图分别记录 |
| UIA-PAGE-103-02 | userdetail → 学习记录 → 只读阅读弹窗 | 当前用户夹具读取与本人库相同标题；列表和阅读一致，管理员无标题编辑入口；其他账号夹具独立 | 不将角色演示当权限方案；真实跨账号请求待实现验证 |
| UIA-PAGE-212-02 | presets / `#preset-title`、`.article`；改标题/保存/发布 | 单输入 `preset.name`，提示 `preset.namehint`；无语言分栏或预设说明。仅标题变化复用有效样文，线上直到手动发布才变 | 可以拆组件；准确文案、单值及发布状态不可变 |
| UIA-PAGE-212-03 | 标题留空、新建、更改生成参数 | 空白拒绝；新建与参数变更需新有效预览；标题文字不改变预览参数签名 | 预览为模拟样文，不代表 AI 品质通过 |
| UIA-PAGE-217-02 / UIA-PAGE-216-02 | explore / `.preset-card h2` → trial / `main h1` | 展示同一已发布标题和样文，无预设说明；切语言标题不变，进入台不生成，配置仍锁定 | 保留必要配置和样文提示；重复操作指引按 COPY09 删除，不恢复预设说明字段 |
| UIA-PAGE-216-03 | trial → 生成 → 收录 → 本人改名 → 复习 | 新批次标题默认仍为目标词连接；私人改名不回写预设。提交前复习不显示可能含答案的标题；复习草稿规则保持 | 浏览器模拟链；真实 AI、持久化、并发/服务端权限另验 |

标题编辑继续沿用 UI-06：未新增页面或改主导航。文章顶部使用与正文一致的阅读字号，编辑表单就地展开以保留上下文；手机编辑按钮移至标题下方，保存/取消并排。过渡为即时状态切换，保存等待态与服务器反馈对应，原型 450ms 仅用于演示。主题、固定文案与详细状态分别由各单一来源维护。

## 试用目录呈现验收 · UI-07

用户本轮三点原话由 `evidence/UI07-reception.json` 保存，属于当前设计呈现指令。PAGE-217 / CAP-218 / DATA-212 的完整样文和配置来自同一已发布对象，不从编辑草稿拼装；新增 `gallery.js` 管理轮播生命周期。样例 `sampleText` 明确表示完整正文，不再用 excerpt 摘要冒充全文；样例文本仅为原型夹具，没有真实 AI 调用。

| 验收 ID | 区域与顺序 | 必须保持 / 检查方法 |
|---|---|---|
| UIA-PAGE-217-03 | 标题与导语→轮播控制→横向卡片；卡内 `.gallery-config` 为序号/预设标题→模型/场景/长度/释义语言→完整词条→我也试试；`.gallery-paper` 为全文标记→完整分段正文→样文说明 | 不折叠、截断或用摘要替代正文；模型是展示名称，场景/长度/语言标签本地化；标题和英文正文不随 UI 语言改变。依据夹具逐字段/逐段断言并查看真实截图。 |
| UIA-PAGE-217-04 | PAGE-217 横向阅读与 UI-11 中断规则 | 每 8 秒自动；控件仅前后与计数，任意阅读/交互停止本次自动，离开再入可重启。减少动效/隐藏/离屏关闭或暂停；单条禁用切换，空态无定时器；触控和方向键/Home/End 保留。当前验收以 CAR11 为准。 |
| UIA-PAGE-217-05 | PAGE-212 保存草稿/发布→目录→我也试试→PAGE-216 | 草稿不影响展示，发布同步更新完整正文与配置；点击对应卡跳对应预设，进入不生成、不扣次，配置不可编辑。以浏览器实际操作和对象/内容对照验证。 |

这是横向分页式自动滚动，保留下一卡边缘提示。宽屏配置与正文并列，手机配置在前、全文在后，不固定正文高度。详细中断规则、时序与键盘约束分别在交互、响应式文档；组件拆分可变，正文完整性及操作结果不可变。前端/QA 接收时替换 UI-06 双列摘要卡预期，其余批次标题及页面行为保持。

## 释义语言筛选验收 · UI-08

**UIA-PAGE-217-06 / PAGE-217 / CAP-218 / DATA-212**：在页面标题/导语之后、轮播控制之前增加 `.gallery-language-tabs`。顺序为全部、中文、英语、日语，显示每类已发布预设数量，默认全部；语言来自预设的释义语言，不从正文或 UI 语言推断。当前支持的语言与预设配置一致，后续平台语言变化由实现共用配置来源。

选择 Tab 后只显示匹配的完整预设，将位置重置为第一项并暂停自动；多条转为手动浏览，单条禁用前后/自动。零匹配保留 Tab，显示 `gallery.filter.empty / emptydesc` 和 `gallery.filter.reset`，可一键回全部；全目录无内容沿用普通造文入口。切换中英文 UI 保持筛选条件，仅翻译标签；标题/正文/配置不改。筛选后“我也试试”按原发布对象索引跳转，不能使用筛选后位置选错预设。

Tab 使用 tablist/tab/tabpanel、选中态与单一 Tab 停靠点；左右方向键循环、Home/End 首尾，激活后焦点留在对应 Tab，窄屏自动让当前 Tab 可见。保留横向滚动，页面不溢出。浏览器检查筛选数量、全文、空态、语言切换、焦点、正确预设/额度、单条和离开再入后的自动行为；在 320/390/1440px 核对布局及 axe。原型第二条夹具改为英语释义以演示筛选，日语演示空态；没有生产内容修改或新增预设。

## 动态内容与格式

| 文案键 / 变量 | 含义、缺值和格式 | 检查条件 |
|---|---|---|
| `welcome` / name、days | 昵称空时用户名；距上次有效学习的学习日差，不取上次登录。无学习用 `g.welcome.new`，不显示 NaN。 | 明确登录、首次注册、有/无学习、04:00 边界。 |
| `progress` / current、target | 累计经验与下级门槛；满级用 `maxlevel` 并保留累计经验。 | 260/300 为夹具，奖励/配置变化后重算，不写死 Lv.3。 |
| `b.quota` / plan、extra | 当前有效计划剩余与已启用额外次数；无限明确文字，不能把 0 当无限。 | 模型卡不增加次数；体验续期不清已用量；预设仍按当前身份扣次。 |
| `useby`、`ends` / date；`b.extension` / days、date | 获得后的启用期限与逐模型/计划体验结束分开；原型用北京时间 YYYY-MM-DD HH:mm。 | 部分重叠逐模型累时，期限内启用给足时长。 |
| `reward` / points、xp；`pricevalue` / count | 领取时配置的奖励/价格；模型退换读取当前下架积分。业务数字为变量。 | 整份奖励不可用时积分/经验也不提前发；已完成退换金额不追改。 |
| `slot`、`gap` | 字母或空位序号，无答案；短文空固定宽、同原词不同词形共享匿名组。 | 多词条空格/标点分组；辅助名称不能泄露答案。 |
| 批次标题、预设标题 | 各对象一个普通文本值；默认批次标题为原目标词顺序以 ` · ` 连接。UI 切换不翻译、不取另一语言标题。 | 自定义长标题、标记字符、刷新；私人标题与公开预设独立。 |
| 消息、成就、道具等其他运营内容；AI 学习内容 | 既有双语运营内容缺一种时回退原文；AI 内容保持生成时语言。未知指标用暂无样本/观察中/未知。 | 空列表/隐藏通知/未成熟留存。 |

## 详细规则与实现自由

状态、动作和异常的完整规范见 [interactions.md](./interactions.md)；断点、输入、键盘、对话框、动效和字号规则见 [responsive-accessibility.md](./responsive-accessibility.md)。分组表格允许内部横滚，页面不得整体溢出；日期编辑器沿用 1080/1081px 边界，工作台折叠用 1100px，不混为一个断点。

本稿的组件拆分和状态变量不是后端设计。前端接收后需将共享文案、Token 与模块区域映射进正式框架；数据层使用批准 API/DTO，不复制 fixtures 或设计内存逻辑作为生产权益算法。模型卡按稳定模型身份关联，原型用名称只是可读夹具。服务端对额度、奖励、掌握去重、下架资格、密码/权限及删除执行最终校验与幂等。

## 设计自检与接续

实际浏览器方法、当前结果、逐图人工检查和未覆盖范围见 [validation.md](./validation.md)。接收前保护清单见 [UI15-reception.json](./evidence/UI15-reception.json)，最终摘要见版本清单。此前 UI-04 旧规格引用旧批准、试用目录/后台概览合用旧 PAGE、固定奖励样例的问题由此版替代。

CR 的产品补正已有独立批准；本角色仅提交设计接收和覆盖证据，不自行关闭 CR 或推进阶段。需经本稿设计审阅后由守门器登记；不把未执行的技术/独立 QA/新会话交接称为完成。M001 遗留 CR039-L1、CR042-L1、AI-QUALITY-90 保持原状态。
