---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-19
date: 2026-09-20
---

# UI-19 设计验证

范围为 PAGE-003 / PAGE-207 的 TOAST19：欢迎提示与消息弹窗并行时的显示层级，以及共享反馈的焦点、位置和时限。输入 PRODUCT-03；[UI-18 快照](./evidence/M002-UI-18.tar.gz) 保留。用户要求与保护清单见 [接收记录](./evidence/UI19-reception.json)。

## 浏览器与视觉

运行 `node .planning/milestones/M002/design/evidence/verify-ui19.cjs`，[浏览器报告](./evidence/UI19-browser-results.json) 四组首次通过：

- 320×568、390×844、1440×900，中英文共 6 个布局，欢迎内容正确且在消息遮罩之上；提示留在视口内，与消息操作保持间距。320px 中文与 1440px 英文两次 axe 无违规；浏览器辅助功能树中 status 未被忽略。焦点保持在消息关闭按钮。
- 消息翻页、Escape 关闭、重新打开均保持唯一提示和原文本，不延长原有 5000ms 定时器。轮询观察消失约 5223ms；提示消失后消息继续打开，清除临时避让空间。
- 桌面缩至短手机屏、普通入场动画均保持水平居中与控件可用；消息下一步、关闭操作正常。
- 个人信息保存反馈正常；书架删除失败时保留数据和弹窗，错误提示显示在顶层，Escape 后焦点回到删除入口，提示继续显示剩余时间。

未发现运行错误。实际打开检查 [桌面中文](./evidence/UI19-welcome-1440-zh.png) 与 [短屏中文](./evidence/UI19-welcome-320-zh.png)：提示清晰、不受背景模糊影响；手机三颗底部按钮保持单行，未被提示覆盖。其余尺寸和英文截图随证据保存；无语言后缀截图为调整窄屏按钮前的诊断记录。

## 一致性与边界

原生手动 popover 承载同一个 status 节点；消息打开时移入 dialog，翻页前暂存、渲染后恢复，关闭后回到 body。提示不接收点击、不抢焦点。消息仍在登录后按原有 250ms 打开，欢迎仍展示 5 秒。短屏仅在碰撞时为消息留出空间，窄屏按钮缩小水平内边距。

运行 `python3 .planning/milestones/M002/design/evidence/verify-ui19-static.py`，[静态报告](./evidence/UI19-static-results.json) 核对 25 PAGE、28 视图、49 CAP、31 活跃 DATA、UIA、双语文案、JS 语法、路径与版本，560 个受保护输入/旧证据保持。[冻结包](./evidence/M002-UI-19.tar.gz) / [清单](./evidence/M002-UI-19-manifest.json) / [当前指针](./evidence/design-manifest.json) 对应同一交付；冻结后结果在 `evidence/UI19-freeze-results.json` 核对逐文件摘要及链接。

同日再次登录目前仍显示 0 天，专门的同日文案分支是已知待补项，本次不视为完成。未改登录、学习天数或消息业务规则，未修改正式应用/产品/CR/控制面，未提交 Git、调用真实 AI 或迁移阶段。未重跑首页/复习/后台完整流程；生产浏览器支持与降级、真机/Safari、人工读屏、独立 QA 与新会话交接未验证。模型实际用量未知。整稿仍待用户审阅。
