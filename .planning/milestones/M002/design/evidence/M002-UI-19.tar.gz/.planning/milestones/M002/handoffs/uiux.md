---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-19
date: 2026-09-20
---

# M002 UI/UX 交接 · designer-tony

输入为 [M002-PRODUCT-03](./product.md) / [TRANSITION-M002-006](../reviews/product-title-revision.md)，Profile consumer-ai-web@1.0.0 / revision `b5badf88cd7194400c3d4d0e9395e7c98490dc26`。当前仍 uiux-design，整稿待审。

用户要求提高欢迎提示层级，使其显示在消息之上；原话/范围/保护清单见 [UI19-reception.json](../design/evidence/UI19-reception.json)。本版将共享提示放入浏览器顶层，消息保持即时打开，欢迎保持 5 秒。手机短屏自动留出显示空间，消息翻页和关闭不延长提示时间。

- [查看登录原型](http://127.0.0.1:4174/prototype/?page=login&role=guest&lang=zh&v=M002-UI-19)，登录后同时出现欢迎与提醒消息。
- [设计规格](../design/design-spec.md) TOAST19；[交互](../design/interactions.md)、[响应式](../design/responsive-accessibility.md)、[主题](../design/theme.css)、[文案](../design/copy.json)。
- [app.js](../design/prototype/app.js) 的 toast / syncToastLayer / positionToast / dialog 负责时限、顶层和碰撞处理；[index.html](../design/prototype/index.html) 声明手动 popover 与 status。节点在当前 dialog 内可避免被模态背景的 inert 规则排除；关闭时回到 body，不抢焦点。
- [验证](../design/validation.md)：6 个中英文布局、2 次 axe、四组行为全部通过；检查辅助功能树中的 status 暴露，以及短屏布局、翻页、关闭、重开、保存和删除失败反馈。

25 PAGE、28 视图、49 CAP、31 活跃 DATA 保持，新增两项 TOAST19 设计验收映射。UI-18 书架、UI-17 个人中心与其他 M001/M002 流程继续有效。本次不改欢迎内容分支；同日再次登录仍显示 0 天，专门同日文案待补。前端需根据正式浏览器支持范围确定 popover 的适配方式，保留提示的辅助功能语义及模态期间可感知性；不要复制原型会话夹具作为生产状态。

[当前冻结包](../design/evidence/M002-UI-19.tar.gz) / [清单](../design/evidence/M002-UI-19-manifest.json) / [当前指针](../design/evidence/design-manifest.json)；[UI-18 原件](../design/evidence/M002-UI-18-manifest.json) 保留。560 个受保护原件未变，未改正式应用/控制面、未提交 Git 或切换阶段。当前文档就地更新，历史证据未覆盖。

下一步继续设计审阅，正式迁移由守门器按用户授权处理。CR-001/002、CR039-L1、CR042-L1、AI-QUALITY-90 保持。生产浏览器兼容与降级、真机/Safari/人工读屏、独立 QA 与新会话交接未验证；模型用量未知。
