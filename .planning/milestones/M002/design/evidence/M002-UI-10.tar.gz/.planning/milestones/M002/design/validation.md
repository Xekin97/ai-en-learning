---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-10
date: 2026-09-18
---

# UI-10 设计验证

范围是用户要求的首页整体观感和 Iconify 图标替换，对应 UIA-PAGE-205-HOME10 与各页 ICON10。产品仍为 PRODUCT-03，当前设计待审。UI-09 的认证/后台对齐和功能基线继续继承，原 [UI-09 冻结包](./evidence/M002-UI-09.tar.gz) 不改写。

## 浏览器、交互与图标

从产品根运行 `node .planning/milestones/M002/design/evidence/verify-ui10.cjs`；最新 [结果](./evidence/UI10-browser-results.json) 记录 6 组检查：

1. 首页中英文固定示例、3 个词与正文高亮/释义一致，访客两个入口可用，进入不生成；无外部资源请求。
2. 点击 SVG/path 本身可打开个人/后台导航、随机加词/删除、图库前后切换，文字和可访问名称保留。
3. 复习答案铅笔返回对应输入，短文匿名形状分组保留；输入用本地化图形名，不读 SVG 标签。
4. 首页正常模式实际观察词签位移、hover 暂停，减少动效无动画。
5. 28 个视图桌面中文，以及 390px 英文的 11 个相关视图、320px 英文首页、768px 中文首页，共 41 个布局无横溢；图标非独立焦点，无无名称的图标按钮。
6. 首页桌面中文/320px 英文、手机登录/造文、桌面道具/模型、手机英语试用共 7 个 axe 检查。

[首次报告](./evidence/UI10-first-browser-results.json) 和 [脚本](./evidence/verify-ui10-first.cjs) 保留。发现并修正两项：Iconify 的 `trash-2` 为别名，映射改为原数据的 `trash`；道具标题由 h3 改 h2，补齐标题层级并保持字号。另一个失败是测试从概览返回编辑后错误地连续“跳过”；原交互会先返回概览，改用已有短文步骤入口检查图形。后续只重新验证失败及受影响组，定向结果和合并依据随报告保存。

首次截图采集在首个页面等待超时，诊断重载成功且无运行错误；未捕获到该次超时的确切资源原因，不声称由产品修复解决。之后同一采集脚本完成。

## 实际视觉

`capture-ui10.cjs` 保存 [布局数据](./evidence/UI10-layout-results.json) 及截图。实际打开检查：

- [桌面首页](./evidence/UI10-home-1440-zh.png)：文案和示例形成两列，选词、正文、释义关系清晰，删除散落装饰与大圆背景。
- [手机首页](./evidence/UI10-home-390-zh.png)、[平板英文](./evidence/UI10-home-768-en.png)：正文、词签、按钮保留，自动换行，无遮挡；390px 首页主内容约 1040px，UI-09 为 1089px。
- [道具卡](./evidence/UI10-bag-1440-zh.png)：四类道具使用日历、票券、模型、宝石图标，个人分区有统一图标，含义仍由标题说明。
- 登录、造文、模型、成长、试用已保存相应截图；不以截图数量替代用户视觉评价。

## 素材、静态与边界

图标来自 [Iconify Lucide](https://icon-sets.iconify.design/lucide/)，[来源与摘要](./evidence/UI10-assets.json)、本地数据和许可随设计交付。运行页面仅读取本地 SVG 数据，没有远程字体、图标运行库或 CDN 请求。

运行 `python3 .planning/milestones/M002/design/evidence/verify-ui10-static.py`；[静态报告](./evidence/UI10-static-results.json) 检查 PAGE/CAP/DATA/UIA、双语、模块语法、图标来源、字符图标移除、元数据/链接与受保护摘要。继承的 371 个产品/控制面/旧证据原件保持。

当前源和资源冻结为 [M002-UI-10.tar.gz](./evidence/M002-UI-10.tar.gz) / [清单](./evidence/M002-UI-10-manifest.json)，[当前清单](./evidence/design-manifest.json) 指向本版。未修改正式应用、产品、工作流状态，未提交 Git、未调用真实 AI、未切换阶段。

未测生产 API、物理手机、Safari、人工读屏或 200% 缩放；axe 不等于完整 WCAG 认证。独立新会话交接未执行，模型用量未知。CR-001/002 与原开放验证事项仍由原责任角色接续。
