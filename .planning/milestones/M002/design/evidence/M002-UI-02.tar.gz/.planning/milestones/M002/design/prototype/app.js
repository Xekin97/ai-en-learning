const [COPY, F, TRACE] = await Promise.all(
  ["../copy.json", "fixtures.json", "../traceability.json"].map((u) =>
    fetch(u).then((r) => {
      if (!r.ok) throw Error(u);
      return r.json();
    }),
  ),
);
const $ = (s) => document.querySelector(s),
  $$ = (s) => [...document.querySelectorAll(s)],
  esc = (v) =>
    String(v ?? "").replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c],
    );
const params = new URLSearchParams(location.search);
let lang = params.get("lang") === "en" ? "en" : "zh",
  scene = params.get("state") || "normal",
  page = params.get("page") || "home";
const routes = {
  home: "PAGE-205",
  explore: "PAGE-205",
  create: "PAGE-204",
  review: "PAGE-201",
  overview: "PAGE-202",
  summary: "PAGE-203",
  profile: "PAGE-206",
  notices: "PAGE-207",
  models: "PAGE-208",
  messages: "PAGE-209",
  operations: "PAGE-210",
  credits: "PAGE-211",
  presets: "PAGE-212",
  metrics: "PAGE-213",
  growth: "PAGE-214",
  bag: "PAGE-215",
  shop: "PAGE-215",
  trial: "PAGE-216",
};
let S = {
  guest: params.get("role") === "guest",
  nickname: F.user.name,
  gender: "",
  points: F.user.points,
  xp: F.user.xp,
  step: 0,
  words: ["", "", ""],
  gaps: ["", "", "", ""],
  hint: false,
  selected: [...F.presets[0].words],
  model: "",
  explain: "",
  style: "story",
  length: "brief",
  quota: 5,
  generation: "idle",
  output: "",
  preset: 0,
  claimed: [],
  levelClaimed: false,
  signed: false,
  inventory: F.items.map((x, i) => ({ type: i, status: "unused" })),
  items: structuredClone(F.items),
  optab: "itemsettings",
  tiers: 4,
  models: ["Model A", "Model B"],
  message: 0,
  preview: false,
  published: false,
  previewUsage: 0,
  noticeIndex: 0,
  returnOverview: false,
  submitted: false,
};
let timer = null,
  opener = null,
  toastTimer;
const formMemory = new Map();
function rememberForm() {
  const values = {};
  $$("#main input[id],#main textarea[id],#main select[id]").forEach(
    (el) => (values[el.id] = el.type === "checkbox" ? el.checked : el.value),
  );
  formMemory.set(page, values);
}
function restoreForm() {
  Object.entries(formMemory.get(page) || {}).forEach(([id, v]) => {
    const el = document.getElementById(id);
    if (el) {
      if (el.type === "checkbox") el.checked = v;
      else el.value = v;
    }
  });
}
const t = (k, v = {}) => {
  const key = lang + "." + k;
  const s = COPY.static[key] ?? COPY.templates[key];
  if (s == null) {
    console.error("Missing copy", key);
    return "[" + k + "]";
  }
  return s.replace(/\{(\w+)\}/g, (_, n) => String(v[n] ?? ""));
};
const L = (x) => x?.[lang] || x?.zh || x?.en || "";
const B = (k, a, cls = "", disabled = false, extra = "") =>
  `<button type="button" class="btn ${cls}" data-action="${a}" ${disabled ? "disabled" : ""} ${extra}>${esc(t(k))}</button>`;
const link = (p, k, cls = "") =>
  `<a class="${cls}" href="?page=${p}&lang=${lang}" data-go="${p}">${esc(t(k))}</a>`;
const badge = (k, cls = "") => `<span class="pill ${cls}">${esc(t(k))}</span>`;
const field = (k, id, val = "", type = "text", attrs = "") =>
  `<label class="field"><span>${esc(t(k))}</span><input id="${id}" name="${id}" type="${type}" value="${esc(val)}" ${attrs}></label>`;
const select = (k, id, opts, value = "", attrs = "") =>
  `<label class="field"><span>${esc(t(k))}</span><select id="${id}" ${attrs}>${opts
    .map((o) => {
      const [v, label] = Array.isArray(o) ? o : [o, t(o)];
      return `<option value="${esc(v)}" ${v === value ? "selected" : ""}>${esc(label)}</option>`;
    })
    .join("")}</select></label>`;
const check = (k, id, on) =>
  `<label class="field inline"><input type="checkbox" id="${id}" ${on ? "checked" : ""}><span>${esc(t(k))}</span></label>`;
const note = (k, cls = "") => `<p class="notice ${cls}">${esc(t(k))}</p>`;
const heading = (k, desc = "", actions = "") =>
  `<div class="page-head"><div><p class="eyebrow">WORDWEAVE / ${esc(t("learn"))}</p><h1 tabindex="-1">${esc(t(k))}</h1>${desc ? `<p>${esc(t(desc))}</p>` : ""}</div><div class="actions">${actions}</div></div>`;
const chips = (words) =>
  `<div class="chips">${words.map((w) => `<span class="chip">${esc(w)}</span>`).join("")}</div>`;
const mark = `<svg viewBox="0 0 44 44" fill="none" aria-hidden="true"><rect x="2" y="2" width="40" height="40" rx="14" fill="#e4efcf"/><path d="M8 24c7-13 18-14 28-5" stroke="#21654e" stroke-width="2.2" stroke-linecap="round"/><path d="M9 18c8 14 19 15 27 6" stroke="#bd6f2f" stroke-width="2.2" stroke-linecap="round"/><circle cx="12" cy="20.5" r="2.2" fill="#21654e"/><circle cx="32" cy="22" r="2.2" fill="#bd6f2f"/></svg>`;
const empty = (title = "empty", desc = "", action = "") =>
  `<div class="empty"><div class="seal" aria-hidden="true">∿</div><h2>${esc(t(title))}</h2>${desc ? `<p>${esc(t(desc))}</p>` : ""}${action}</div>`;
function toast(k, v = {}) {
  $("#toast").textContent = t(k, v);
  $("#toast").classList.add("visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $("#toast").classList.remove("visible"), 5000);
}
function dialog(title, body, actions = "") {
  opener = document.activeElement;
  $("#dialog").innerHTML =
    `${B("close", "close", "quiet dialog-close", false, `aria-label="${esc(t("close"))}"`)}<h2 id="dialog-title">${esc(t(title))}</h2>${body}<div class="dialog-actions">${actions || B("close", "close")}</div>`;
  if (!$("#dialog").open) $("#dialog").showModal();
}
$("#dialog").addEventListener("close", () => {
  if (opener?.isConnected) opener.focus();
  else $("h1")?.focus();
});
function close() {
  $("#dialog").close();
}
function markdown(s) {
  return esc(s)
    .split("\n\n")
    .map((p) =>
      p.startsWith("## ")
        ? `<h2>${p.slice(3).replace(/\n/g, "<br>")}</h2>`
        : `<p>${p.replace(/\n/g, "<br>")}</p>`,
    )
    .join("")
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
}
const accountViews = ["profile", "growth", "bag", "shop"];
function accountLinks() {
  return accountViews
    .map(
      (p) =>
        `<a href="?page=${p}&lang=${lang}" data-go="${p}" ${page === p ? 'aria-current="page"' : ""}>${esc(t(p))}</a>`,
    )
    .join("");
}
function header() {
  return `<header class="topbar"><div class="container header-inner"><a class="brand" href="?page=home" data-go="home">${mark}${esc(t("brand"))}</a><nav class="nav" aria-label="${esc(t("mainnav"))}">${["home", "create", "review", "explore"].map((p) => link(p, p)).join("")}</nav><div class="header-actions">${B(lang === "zh" ? "english" : "chinese", "language", "quiet", false, `aria-label="${esc(t("language"))}"`)}${link("notices", "notices", "btn quiet")}${S.guest ? B("login", "login", "primary") : `<details class="account-dropdown"><summary aria-label="${esc(t("accountmenu"))}"><span class="avatar" aria-hidden="true">${esc((S.nickname || F.user.username).slice(0, 1))}</span><span class="user-name">${esc(S.nickname || F.user.username)}</span><span class="dropdown-chevron" aria-hidden="true">⌄</span></summary><nav class="account-popover" aria-label="${esc(t("accountmenu"))}">${accountLinks()}</nav></details>`}</div></div></header>`;
}
function accountShell(content) {
  const name = S.nickname || F.user.username;
  return `<div class="account-layout"><aside class="account-sidebar" aria-label="${esc(t("accountinfo"))}"><div class="account-identity"><div class="avatar profile-avatar" aria-hidden="true">${esc(name[0])}</div><div><h2>${esc(name)}</h2><p class="muted">@${esc(F.user.username)}</p></div></div><dl class="account-facts"><div><dt>${esc(t("lastlogin"))}</dt><dd>${esc(F.user.lastLogin)}</dd></div><div><dt>${esc(t("lastlearn"))}</dt><dd>${scene === "empty" ? "—" : esc(F.user.lastLearn)}</dd></div></dl><nav class="account-nav" aria-label="${esc(t("accountnav"))}">${accountLinks()}</nav></aside><div class="account-content">${content}</div></div>`;
}
function home() {
  return `<section class="hero" data-region="hero"><div><p class="eyebrow">${esc(t("hero.eyebrow"))}</p><h1>${esc(t("hero.title"))}</h1><p class="hero-desc">${esc(t("hero.desc"))}</p><div class="actions">${link("create", "hero.cta", "btn primary")}${link("explore", "hero.secondary", "btn quiet")}</div><p class="muted" style="margin-top:20px;font-size:13px">${esc(t("hero.note"))}</p></div><div class="hero-visual"><div class="orb" aria-hidden="true"></div><span class="floating one" aria-hidden="true">resilient</span><span class="floating two" aria-hidden="true">wander</span><span class="floating three" aria-hidden="true">weave</span><article class="story-sheet"><span class="eyebrow">AI / ${esc(t("sample"))}</span><h2 class="sheet-title">${esc(F.hero.title)}</h2><p class="story-text">${F.hero.parts.map((x) => (typeof x === "string" ? esc(x) : `<mark>${esc(x.word)}</mark>`)).join("")}</p><div class="chips"><span class="chip">Story</span><span class="chip">Brief</span></div></article></div></section><section class="path">${["choose", "read", "review"].map((x, i) => `<div class="path-item"><b>0${i + 1}</b><div><h3>${esc(t("path." + x))}</h3><p>${esc(t("path." + x + ".desc"))}</p></div></div>`).join("")}</section>`;
}
function explore() {
  return `${heading("explore.title", "home.presetdesc")}${scene === "empty" ? empty("explore.empty", "explore.emptydesc", link("create", "create", "btn primary")) : `<div class="cards" id="presets">${F.presets.map((p, i) => `<article class="preset-card"><span class="pill">${esc(L(p.label))}</span><h2>${esc(L(p.title))}</h2><p class="story-text">${esc(p.excerpt)}</p>${chips(p.words)}<div class="actions">${B("try", "try:" + i, "primary")}${badge("sample")}</div></article>`).join("")}</div>`}`;
}

function generation(locked) {
  const pre = F.presets[S.preset];
  const words = locked ? pre.words : S.selected;
  const unavailable =
    scene === "noquota" || scene === "invalid" || scene === "nomodel";
  let result = empty("create.empty", "create.emptydesc");
  if (S.generation === "running")
    result = `<div class="article"><p class="eyebrow">${esc(t("create.generating"))}</p><p class="story-text" aria-live="polite">${esc(S.output)}<span aria-hidden="true">▍</span></p>${B("cancelgen", "cancelgen")}</div>`;
  if (S.generation === "done")
    result = `<div class="article"><p class="eyebrow">${esc(t("create.done"))}</p><h2>${esc(L(pre.title))}</h2><p class="story-text">${esc(S.output)}</p>${chips(words)}${B(S.guest ? "guestcollect" : "collect", "collect", "primary")}</div>`;
  if (["failure", "cancelled"].includes(S.generation))
    result = empty(
      "create." + S.generation,
      "",
      B("retry", "generate", "primary"),
    );
  return `${heading(locked ? "preset.title" : "create.title", locked ? "preset.desc" : "create.desc", `<span class="pill">${esc(t("quota", { count: scene === "noquota" ? 0 : S.quota }))}</span>`)}${locked && scene === "invalid" ? note("preset.invaliddesc", "error") : ""}<div class="workspace"><details class="settings" ${innerWidth > 1100 || locked ? "open" : ""}><summary>${esc(t(locked ? "preset.locked" : "config"))}</summary><div class="config-fields">${
    locked
      ? `<dl>${[
          ["model", pre.model],
          ["style", pre.style],
          ["length", pre.length],
          ["explain", pre.language],
        ]
          .map(
            ([k, v]) => `<dt class="muted">${esc(t(k))}</dt><dd>${esc(v)}</dd>`,
          )
          .join("")}</dl>`
      : `${select("model", "model", [["", t("select")], ...S.models.map((x) => [x, x])], S.model, scene === "nomodel" ? "disabled" : "")}${select("style", "style", ["story"], S.style)}${select("length", "length", scene === "nolength" ? [["", t("select")], "standard"] : ["brief", "standard"], scene === "nolength" ? "" : S.length)}${select("explain", "explain", [["", t("select")], "chinese", "english"], S.explain)}`
  }</div>${locked ? "" : `<p class="muted">${esc(t("card.modelnote"))}</p><small>${esc(t("ends", { date: "Model B · 2026-09-23 12:00" }))}</small>`}</details><div><section class="panel"><div class="section-head"><div><h3>${esc(t("words"))}</h3><small>${esc(t("wordcount", { count: words.length, limit: locked ? words.length : 5 }))}</small></div>${locked ? badge("preset.locked") : B("random", "random", "small")}</div><div class="chips">${words.map((w, i) => `<span class="chip">${esc(w)}${locked ? "" : `<button class="btn quiet small" data-action="remove-word:${i}" aria-label="${esc(t("remove"))} ${esc(w)}">×</button>`}</span>`).join("")}</div>${locked ? "" : `<div class="actions"><label><span class="muted">${esc(t("wordsearch"))}</span><input id="wordsearch" list="wordlist" autocomplete="off"><datalist id="wordlist">${F.candidates.map((w) => `<option value="${w}"></option>`).join("")}</datalist></label>${B("add", "add-word")}</div>`}${scene === "noquota" ? note("noquota.desc", "warn") : scene === "nomodel" ? note("nomodel.desc", "warn") : ""}<div class="actions" style="margin-top:20px">${B("start", "generate", "primary", unavailable || S.quota === 0 || S.generation === "running" || (!locked && (!S.model || !S.explain || !words.length || !S.length)), 'id="generate"')}</div></section><section class="panel" style="margin-top:22px" data-region="generation-result">${result}</section></div></div>`;
}
function passage(mode) {
  let n = 0;
  return F.passage
    .map((part) => {
      if (typeof part === "string") return esc(part);
      const i = n++,
        a = S.gaps[i] || "";
      if (mode === "edit")
        return `<input class="gap group-${part.group}" data-gap="${i}" value="${esc(a)}" aria-label="${esc(t("gap", { index: i + 1 }))}" autocomplete="off" spellcheck="false">`;
      if (mode === "overview")
        return `<button class="answer-link group-${part.group}" data-action="edit-passage">${esc(a || t("unanswered"))}</button>`;
      return answer(a, part.answer);
    })
    .join("");
}
const correct = (a, b) => a.trim().toLowerCase() === b.toLowerCase();
function answer(a, b) {
  return correct(a, b)
    ? `<span class="result-word good">${esc(b)}<small>${esc(t("correct"))}</small></span>`
    : `<span class="result-word"><s class="bad">${esc(a || t("unanswered"))}</s><strong class="good">${esc(b)}</strong><small>${esc(t(a ? "incorrect" : "unanswered"))}</small></span>`;
}
function review() {
  if (scene === "denied")
    return empty("review.denied", "", link("home", "home", "btn"));
  const i = S.step,
    w = F.words[i];
  const overview = page === "overview",
    summary = page === "summary";
  const successful =
    F.words.every((x, i) => correct(S.words[i], x.word)) &&
    F.passage
      .filter((x) => typeof x !== "string")
      .every((x, i) => correct(S.gaps[i], x.answer));
  let content;
  if (overview || summary) {
    content = `<section class="review-paper"><h2>${esc(t("wordanswers"))}</h2>${F.words.map((w, i) => `<div class="answer-row"><span class="muted">0${i + 1}</span>${summary ? answer(S.words[i], w.word) : `<button class="answer-link" data-action="edit-word:${i}">${esc(S.words[i] || t("unanswered"))} ↗</button>`}</div>`).join("")}<h2 style="margin-top:35px">${esc(t("passageanswers"))}</h2><p class="story-text" data-region="passage">${passage(summary ? "summary" : "overview")}</p>${summary ? note("summary.note") : ""}</section><div class="review-footer">${summary ? B("restart", "restart") : B("back", "back-review")}${summary ? B(scene === "multibatch" ? "nextbatch" : "finish", scene === "multibatch" ? "restart" : "finish", "primary") : B("submit", "submit", "primary", false, 'id="submit"')}</div>`;
  } else if (i < 3) {
    content = `<section class="review-paper"><p class="eyebrow">${esc(t("step", { index: i + 1, total: 3 }))}</p><h2>${esc(t("review.spell"))}</h2><div class="slots" data-region="spelling">${[...w.word].map((_, n) => `<input class="slot" data-slot="${n}" maxlength="1" value="${esc(S.words[i][n] || "")}" aria-label="${esc(t("slot", { index: n + 1 }))}" autocapitalize="none" autocomplete="off" spellcheck="false">`).join("")}</div><section class="hint"><small>${esc(t("review.translation"))}</small><p>${esc(L(w.meaning))}</p></section><section class="hint"><div class="actions"><small>${esc(t("review.phrase"))}</small>${B(S.hint ? "hide" : "show", "hint", "quiet small", false, `aria-expanded="${S.hint}"`)}</div>${S.hint ? `<p class="story-text">${esc(w.phrase)}</p>` : ""}</section></section>${reviewFooter(!S.words[i].trim())}`;
  } else
    content = `<section class="review-paper"><p class="eyebrow">02 / ${esc(t("passageanswers"))}</p><h2>${esc(t("review.passage"))}</h2><p class="muted">${esc(t("review.passagehelp"))}</p><p class="story-text" data-region="passage">${passage("edit")}</p></section>${reviewFooter(!S.gaps.some((x) => x.trim()))}`;
  return `${heading(summary ? (successful ? "summary.good" : "summary.retry") : overview ? "overview.title" : "review.title", summary ? "summary.note" : overview ? "overview.desc" : "review.desc", summary ? "" : B("overview", "overview"))}${summary && successful ? `<p class="notice">${esc(t("newmastery", { count: 3 }))}</p>` : ""}<div class="review-layout"><aside class="review-steps">${["wordanswers", "passageanswers", "overview", ...(summary ? ["summary"] : [])].map((x, n) => `<button data-action="${summary ? "noop" : n === 0 ? "word-start" : n === 1 ? "edit-passage" : "overview"}" class="${(summary ? n === 3 : overview ? n === 2 : i < 3 ? n === 0 : n === 1) ? "current" : ""}" ${summary ? "disabled" : ""}>0${n + 1}　${esc(t(x))}</button>`).join("")}</aside><div class="review-main">${content}</div></div>`;
}
function reviewFooter(disabled) {
  return `<div class="review-footer"><div>${B("previous", "prev", "", S.step === 0)}</div><div class="actions">${B("skip", "skip", "quiet")}${B("next", "next", "primary", disabled, 'id="review-next"')}</div></div>`;
}
function saveDraft() {
  localStorage.setItem(
    "ww-m002-draft",
    JSON.stringify({ words: S.words, gaps: S.gaps, step: S.step }),
  );
  S.submitted = false;
}
function growth() {
  return `${heading("growth.title", "growth.desc", link("bag", "bag", "btn"))}<div class="growth-grid"><section class="growth-banner"><p class="eyebrow" style="color:var(--mint)">${esc(t("level"))}</p><h2 style="font:36px var(--reading)">Lv. ${scene === "demoted" ? 2 : 3}</h2><p>${scene === "maxlevel" ? esc(t("maxlevel")) : esc(t("progress", { current: S.xp, target: 400 }))}</p><div class="progress"><span style="width:65%"></span></div><div class="stats">${[
    ["points", S.points],
    ["mastered", F.user.mastered],
    ["stories", F.user.stories],
  ]
    .map(
      ([k, v]) =>
        `<div><strong>${scene === "empty" ? 0 : v}</strong><small>${esc(t(k))}</small></div>`,
    )
    .join(
      "",
    )}</div></section><section class="panel"><div class="section-head"><h2>${esc(t("signin"))}</h2>${badge(S.signed ? "signed" : "unsigned")}</div><p class="muted">${esc(t("signin.rule"))}</p><div class="calendar">${Array.from({ length: 7 }, (_, i) => `<span class="day ${i === 3 ? "missed" : i === 6 ? "today" : "signed"}">${11 + i}<br>${i === 3 ? "−" : i === 6 ? "○" : "✓"}</span>`).join("")}</div><div class="actions">${B("makeup", "makeup")}${link("create", "learn", "btn primary")}</div></section></div><section class="section"><div class="section-head"><h2>${esc(t("achievements"))}</h2><small>${esc(t("streak", { count: 7 }))}</small></div><div class="achievement-grid">${F.achievements
    .map((a, i) => {
      const blocked = ["blocked", "disabled"].includes(scene),
        done = S.claimed.includes(i),
        reached = scene !== "empty" && a.current >= a.target;
      return `<article class="achievement"><div class="medal" aria-hidden="true">${["✳", "◇", "≋", "✦"][i]}</div><h3>${esc(L(a.title))}</h3><small>${scene === "empty" ? 0 : a.current} / ${a.target}</small><div class="progress" style="width:100%"><span style="width:${Math.min(100, (a.current / a.target) * 100)}%"></span></div><p>${esc(t("reward", { points: a.points, xp: a.xp }))}</p>${blocked && reached ? note("reward." + scene, "warn") : ""}${B(done ? "claimed" : reached ? "claim" : "unreached", "claim:" + i, "primary", done || !reached || blocked)}</article>`;
    })
    .join(
      "",
    )}</div></section><section class="panel"><div class="section-head"><div><h2>${esc(t("levelrewards"))}</h2><p>Lv. 3 · ${esc(t("pricevalue", { count: 10 }))}</p></div>${B(S.levelClaimed ? "claimed" : "claimlevel", "claim-level", "primary", S.levelClaimed || ["demoted", "disabled", "blocked", "empty"].includes(scene))}</div>${["demoted", "disabled", "blocked"].includes(scene) ? note("reward." + scene, "warn") : ""}</section>`;
}
const itemDesc = (x) =>
  t(
    x.type === "model"
      ? "card.modelnote"
      : x.type === "plan"
        ? "card.plannote"
        : x.type === "count"
          ? "card.countnote"
          : "makeup.desc",
  );
function bag(shop = false) {
  return `${heading(shop ? "shop.title" : "bag.title", shop ? "shop.desc" : "bag.desc", `<span class="pill">${esc(t("pricevalue", { count: S.points }))}</span>`)}${
    scene === "empty"
      ? empty(
          shop ? "shop.empty" : "bag.empty",
          "",
          shop ? "" : link("shop", "shop", "btn primary"),
        )
      : `<div class="items-grid">${(shop
          ? S.items.map((_, i) => ({ type: i }))
          : S.inventory
        )
          .filter((x) => !shop || S.items[x.type].listed)
          .map((v, i) => {
            const x = S.items[v.type],
              retired =
                x.type === "model" &&
                scene === "retired" &&
                v.status !== "refunded",
              covered = x.type === "model" && scene === "covered",
              expired = scene === "expired",
              active = v.status === "active" || scene === "active";
            return `<article class="item"><div class="medal" aria-hidden="true">${["◷", "＋", "✧", "♧"][v.type % 4]}</div>${badge(shop ? "listed" : retired ? "retired" : expired ? "expired" : active ? "active" : v.status)}<h3>${esc(L(x.title))}</h3><p class="muted">${esc(itemDesc(x))}</p>${shop ? `<p><strong>${esc(t("pricevalue", { count: x.price }))}</strong></p>` : `<p class="muted">${esc(t(active ? "ends" : "useby", { date: active ? "2026-09-23 12:00" : "2026-10-17 12:00" }))}</p>`}${x.type === "model" && active ? `<p class="muted">Model A · 09-20 12:00<br>Model B · 09-23 12:00</p>` : ""}${covered ? note("covered", "warn") : ""}${retired ? `<p>${esc(t("pricevalue", { count: x.refund }))}</p>` : ""}${B(shop ? "redeem" : retired ? "refund" : x.type === "makeup" ? "makeup" : x.type === "count" ? "use" : "activate", (shop ? "redeem:" : retired ? "refund:" : "use:") + (shop ? v.type : i), "primary", !shop && !retired && (covered || expired || active || v.status === "refunded"))}</article>`;
          })
          .join("")}</div>`
  }`;
}
function profile() {
  return `${heading("profile.title", "profile.desc")}<section class="panel profile-form-panel"><form id="profile-form">${field("nickname", "nickname", S.nickname)}${select("gender", "gender", ["unspecified", "female", "male"], S.gender || "unspecified")}${B("save", "profile-save", "primary")}</form><hr style="border:0;border-top:1px solid var(--line);margin:28px 0"><div class="actions">${B("password", "password")}${B("logout", "logout", "quiet")}${B("deleteaccount", "delete-account", "danger")}</div></section>`;
}
function notices() {
  return `${heading("notices.title")}<section class="notice-list">${
    scene === "empty"
      ? empty()
      : F.notices
          .filter((n) => n.visible)
          .sort(
            (a, b) =>
              Number(b.remind) - Number(a.remind) ||
              b.date.localeCompare(a.date),
          )
          .map(
            (n, i) =>
              `<button class="notice-entry" data-action="notice:${F.notices.indexOf(n)}">${n.remind ? badge("notice.reminder") : ""}<h3>${esc(L(n.title))} ↗</h3><small>${n.date}</small></button>`,
          )
          .join("")
  }</section>`;
}
function noticeDialog(i) {
  const pool = F.notices
    .map((n, index) => ({ ...n, index }))
    .filter((n) => n.visible && (!S.reminderMode || n.remind))
    .sort(
      (a, b) =>
        Number(b.remind) - Number(a.remind) || b.date.localeCompare(a.date),
    );
  if (!pool.length) return;
  let at = pool.findIndex((x) => x.index === i);
  if (at < 0) at = 0;
  const n = pool[at];
  S.noticeIndex = n.index;
  dialog(
    "notices.title",
    `<p class="muted">${n.date} · ${esc(t("position", { index: at + 1, total: pool.length }))}</p><h3>${esc(L(n.title))}</h3><div class="markdown">${markdown(L(n.body))}</div>`,
    B("previous", "notice:" + pool[Math.max(0, at - 1)].index, "", at === 0) +
      B(
        "next",
        "notice:" + pool[Math.min(pool.length - 1, at + 1)].index,
        "",
        at === pool.length - 1,
      ) +
      B("close", "close", "primary"),
  );
}
function loginNotice() {
  S.reminderMode = true;
  noticeDialog(-1);
}

function admin(content) {
  return `<div class="admin-layout"><nav class="admin-nav" aria-label="${esc(t("admin"))}">${["metrics", "models", "messages", "operations", "credits", "presets"].map((p) => link(p, p, p === page ? "selected" : "")).join("")}</nav><div class="admin-main">${content}</div></div>`;
}
function models() {
  return admin(
    `${heading("models", "admin.desc")}<div class="panel"><div class="table-wrap"><table class="data-table"><thead><tr><th>${esc(t("model"))}</th><th>${esc(t("status"))}</th><th>${esc(t("edit"))}</th></tr></thead><tbody>${S.models.map((m, i) => `<tr><td>${esc(m)}</td><td>${badge("active")}</td><td>${B("remove", "model-remove:" + i, "danger small")}</td></tr>`).join("")}</tbody></table></div></div><section class="panel" style="margin-top:25px"><h2>${esc(t("plan"))}</h2>${note("plan.effect")}<div class="form-grid">${field("priority", "basic-priority", 1, "number", 'min="1"')}${field("priority", "premium-priority", 2, "number", 'min="1"')}</div><p class="muted">Basic / Premium</p>${select(
      "model",
      "plan-models",
      S.models.map((x) => [x, x]),
      "Model A",
      "multiple",
    )}${field("quota.limit", "plan-quota", 20, "number", 'min="0"')}${field("words.limit", "plan-words", 10, "number", 'min="1"')}${B("save", "plan-save", "primary")}</section>`,
  );
}
function messages() {
  const n = F.notices[S.message];
  return admin(
    `${heading("messages", "admin.desc", B("newmessage", "new-message", "primary"))}<div class="tabs">${F.notices.map((n, i) => `<button data-action="message:${i}" class="${i === S.message ? "selected" : ""}">${esc(L(n.title))}</button>`).join("")}</div><section class="panel"><div class="form-grid">${field("name.zh", "message-zh", n.title.zh)}${field("name.en", "message-en", n.title.en)}</div><div class="form-grid">${["zh", "en"].map((l) => `<label class="field"><span>${esc(t("markdown"))} · ${l}</span><textarea id="body-${l}">${esc(n.body[l] || "")}</textarea></label>`).join("")}</div><div class="actions">${check("visible", "visible", n.visible)}${check("remind", "remind", n.remind)}</div><div class="actions">${B("preview", "message-preview")}${B("save", "message-save", "primary")}</div></section>`,
  );
}
function operations() {
  let body;
  if (S.optab === "itemsettings")
    body = `<p class="muted">${esc(t("item.rule"))}</p><div class="toolbar"><input id="item-search" aria-label="${esc(t("search"))}" placeholder="${esc(t("search"))}">${select("type", "type-filter", [["", t("all")], ...F.items.map((x) => [x.type, L(x.title)])])}${select("status", "status-filter", [["", t("all")], "listed", "unlisted"])}${B("newitem", "item-new", "primary")}</div><div class="table-wrap"><table class="data-table"><thead><tr>${["name.zh", "type", "price", "status", "edit"].map((k) => `<th>${esc(t(k))}</th>`).join("")}</tr></thead><tbody>${S.items.map((x, i) => `<tr data-item-row data-name="${esc(L(x.title))}" data-type="${x.type}" data-listed="${x.listed ? "listed" : "unlisted"}"><td>${esc(L(x.title))}</td><td>${esc(L(F.items.find((y) => y.type === x.type).title))}</td><td>${x.price}</td><td>${badge(x.listed ? "listed" : "unlisted")}</td><td><div class="actions">${B("edit", "item-edit:" + i, "small")}${B(x.listed ? "unlist" : "list", "item-list:" + i, "small")}${B("refs", "item-refs:" + i, "small")}${B("delete", "item-delete:" + i, "small danger")}</div></td></tr>`).join("")}</tbody></table></div>`;
  else if (S.optab === "signsettings")
    body = `${note("sign.effect")}<div class="form-grid">${field("rewardpoints", "signpoints", 5, "number", 'min="0"')}${field("increment", "increment", 1, "number", 'min="0"')}${field("cap", "cap", 10, "number", 'min="0"')}${field("rewardxp", "signxp", 10, "number", 'min="0"')}${field("firstxp", "firstxp", 5, "number", 'min="0"')}</div>${B("save", "settings-save", "primary")}`;
  else
    body = `${note(S.optab === "levelsettings" ? "level.effect" : "achievement.effect", "warn")}${
      S.optab === "achievementsettings"
        ? select(
            "type",
            "achievement-kind",
            F.achievements.map((x) => [x.kind, L(x.title)]),
          )
        : ""
    }<div class="table-wrap"><table class="data-table"><thead><tr>${["threshold", "rewardpoints", ...(S.optab === "achievementsettings" ? ["rewardxp"] : []), "rewardcard", "enabled"].map((x) => `<th>${esc(t(x))}</th>`).join("")}</tr></thead><tbody>${Array.from({ length: S.tiers }, (_, i) => `<tr><td>${S.optab === "achievementsettings" ? `${field("name.zh", "tier-name-zh-" + i, F.achievements[0].title.zh)}${field("name.en", "tier-name-en-" + i, F.achievements[0].title.en)}` : ""}<input id="tier-threshold-${i}" aria-label="${esc(t("threshold"))} ${i + 1}" type="number" min="0" value="${(i + 1) * 100}" style="width:100px"></td><td><input id="tier-points-${i}" aria-label="${esc(t("rewardpoints"))} ${i + 1}" type="number" min="0" value="10" style="width:80px"></td>${S.optab === "achievementsettings" ? `<td><input id="tier-xp-${i}" aria-label="${esc(t("rewardxp"))} ${i + 1}" type="number" min="0" value="10" style="width:80px"></td>` : ""}<td><select aria-label="${esc(t("rewardcard"))} ${i + 1}"><option>—</option>${S.items.map((x) => `<option>${esc(L(x.title))}</option>`).join("")}</select></td><td><input aria-label="${esc(t("enabled"))} ${i + 1}" type="checkbox" checked></td></tr>`).join("")}</tbody></table></div><div class="actions" style="margin-top:20px">${B("addtier", "add-tier")}${B("save", "settings-save", "primary")}</div>`;
  return admin(
    `${heading("operations", "admin.desc")}<div class="tabs">${["signsettings", "levelsettings", "achievementsettings", "itemsettings"].map((k) => B(k, "optab:" + k, k === S.optab ? "selected" : "")).join("")}</div><section class="panel">${body}</section>`,
  );
}
function itemForm(index = -1, type = "model") {
  const x =
    index >= 0
      ? S.items[index]
      : {
          ...F.items.find((x) => x.type === type),
          title: { zh: "", en: "" },
          listed: false,
        };
  S.editItem = index;
  S.editType = x.type;
  dialog(
    index >= 0 ? "edit" : "newitem",
    `${note("item.rule")}${select(
      "type",
      "item-type",
      F.items.map((x) => [x.type, L(x.title)]),
      x.type,
      index >= 0 ? "disabled" : "",
    )}<div class="form-grid">${field("name.zh", "item-zh", x.title.zh)}${field("name.en", "item-en", x.title.en)}</div><div class="form-grid">${field("desc.zh", "item-desc-zh", x.desc?.zh || "")}${field("desc.en", "item-desc-en", x.desc?.en || "")}${field("price", "item-price", x.price, "number", 'min="0"')}${field("deadline", "item-days", x.days, "number", 'min="1"')}</div>${
      x.type === "model"
        ? `${select(
            "model",
            "item-model",
            [
              ["Model A", "Model A"],
              ["Model B", "Model B"],
            ],
            x.models?.[0] || "Model A",
            "multiple",
          )}${field("duration", "item-duration", x.duration, "number", 'min="1"')}${field("retirementpoints", "item-refund", x.refund, "number", 'min="0"')}`
        : x.type === "plan"
          ? `${select("plan", "item-plan", [["Premium", "Premium"]], x.plan)}${field("duration", "item-duration", x.duration, "number", 'min="1"')}`
          : x.type === "count"
            ? field("count", "item-count", x.count, "number", 'min="1"')
            : ""
    }${note("item.effect")}`,
    B("cancel", "close") + B("save", "item-save", "primary"),
  );
}
function credits() {
  return admin(
    `${heading("credits", "credit.rule")}<section class="panel"><div class="toolbar">${field("user", "find-user", F.user.username)}${B("lookup", "lookup")}</div><p id="found-user">${esc(S.nickname)} · ${esc(t("pricevalue", { count: S.points }))}</p><div class="form-grid">${field("amount", "credit-amount", "", "number", 'min="1"')}${field("reason", "credit-reason")}</div>${B("supplement", "credit-save", "primary")}<hr style="border:0;border-top:1px solid var(--line);margin:30px 0"><h2>${esc(t("base.reset"))}</h2>${note("base.resetnote")}${select(
      "plan",
      "base-plan",
      [
        ["Basic", "Basic"],
        ["Premium", "Premium"],
      ],
    )}${B("save", "base-save")}</section>`,
  );
}
function presets() {
  const p = F.presets[S.preset];
  return admin(
    `${heading("presets", "preview.rule", B("newpreset", "new-preset", "primary"))}<div class="tabs">${F.presets.map((p, i) => `<button data-action="preset-edit:${i}">${esc(L(p.title))}</button>`).join("")}</div><section class="panel">${badge(S.published ? "published" : S.preview ? "previewed" : "draft")}${note("preset.draftnote")}<div class="form-grid">${field("name.zh", "preset-zh", p.title.zh)}${field("name.en", "preset-en", p.title.en)}${field("words", "preset-words", p.words.join(", "), "text", "data-preset-param")}${select(
      "model",
      "preset-model",
      S.models.map((x) => [x, x]),
      p.model,
      "data-preset-param",
    )}${select("style", "preset-style", ["story"], "story", "data-preset-param")}${select("length", "preset-length", ["brief", "standard"], "brief", "data-preset-param")}${select("explain", "preset-language", ["chinese", "english"], "chinese", "data-preset-param")}</div><div class="actions">${B("save.draft", "preset-save")}${B("previewgen", "preset-preview")}${B("publish", "preset-publish", "primary", !S.preview)}${S.published ? B("unlist", "preset-unlist") : ""}</div>${S.preview ? `<section class="article"><h2>${esc(L(p.title))}</h2><p class="story-text">${esc(p.excerpt)}</p></section>` : ""}<p class="muted" style="margin-top:20px">${esc(t("usage"))} · ${S.previewUsage} · ${esc(t("unknown"))}</p></section>`,
  );
}
function metricDetails() {
  const missing = scene === "empty";
  const m = F.metrics;
  return `<section class="panel" style="margin-top:22px"><div class="section-head"><h2>${esc(t("retention"))}</h2>${select("period", "metric-period", ["days7", "days30"], "days7")}</div><svg viewBox="0 0 640 180" role="img" aria-label="${esc(t("retention"))}" style="width:100%;max-height:230px"><path d="M30 10V145H620" fill="none" stroke="#a7b7a8"/>${missing ? "" : `<path d="M30 80L120 65L210 73L300 54L390 60L480 48L590 55" stroke="#21654e" stroke-width="3" fill="none"/><path d="M30 118L120 110L210 105L300 108L390 92L480 98L590 88" stroke="#a65c31" stroke-dasharray="7 4" stroke-width="3" fill="none"/>`}<text x="40" y="172" fill="#5f6d65" font-size="12">09-11</text><text x="550" y="172" fill="#5f6d65" font-size="12">09-17</text></svg><p class="muted">D1 —　D7 ┄　D30 · ${esc(t(missing ? "nosample" : "observing"))}</p><div class="table-wrap"><table class="data-table"><tbody>${[
    ["bounce", m.bounce],
    ["gens", m.generated],
    ["savecount", m.saved],
    ["reviewfreq", m.frequency],
    ["adminusage", m.previews],
  ]
    .map(
      ([k, v]) =>
        `<tr><th>${esc(t(k))}</th><td>${missing ? esc(t("nosample")) : esc(v)}</td></tr>`,
    )
    .join(
      "",
    )}</tbody></table></div><p class="muted">${esc(t("metrics.separate"))}</p></section>`;
}
function metrics() {
  const val = scene === "empty" ? t("nosample") : null;
  return admin(
    `${heading("metrics.title", "metrics.time", `<span class="muted">${esc(t("updated", { time: "12:04" }))}</span>`)}${scene === "delayed" ? note("delayed", "warn") : ""}<div class="metrics-grid">${[
      ["uv", "1,248"],
      ["pv", "3,920"],
      ["wau", "286"],
      ["failure", "2.4%"],
    ]
      .map(
        ([k, v]) =>
          `<div class="metric"><small>${esc(t(k))}</small><strong>${esc(val || v)}</strong></div>`,
      )
      .join(
        "",
      )}</div><div class="split"><section class="panel"><h2>${esc(t("traffic"))}</h2><div class="chart" role="img" aria-label="${esc(t("traffic"))}">${[38, 50, 43, 68, 80, 56, 95].map((h, i) => `<div class="bar" style="height:${scene === "empty" ? 0 : h}%"><span>${11 + i}</span></div>`).join("")}</div><div class="answer-row"><span>${esc(t("channel"))}</span><span>UTM / Direct / Referrer</span></div></section><section class="panel"><h2>${esc(t("funnel"))}</h2>${[
      ["registered", "18.6%", 85],
      ["activated", "62.4%", 62],
      ["completed", "78.2%", 78],
    ]
      .map(
        ([k, v, w]) =>
          `<div class="answer-row"><span>${esc(t(k))}</span><strong>${esc(val || v)}</strong></div><div class="progress"><span style="width:${scene === "empty" ? 0 : w}%"></span></div>`,
      )
      .join(
        "",
      )}</section></div><section class="panel" style="margin-top:22px"><h2>${esc(t("retention"))}</h2><div class="stats">${["D1", "D7", "D30"].map((x, i) => `<div><small>${x}</small><strong>${esc(val || (i === 2 ? t("observing") : i === 1 ? "24.6%" : "41.2%"))}</strong></div>`).join("")}</div><div class="actions" style="margin-top:24px">${B("metrics.definition", "metric-info")}${B("clarity", "clarity")}</div><p class="muted" style="margin-top:20px">${esc(t("clarity.note"))}</p></section>${metricDetails()}`,
  );
}
const renderers = {
  home,
  explore,
  create: () => generation(false),
  trial: () => generation(true),
  review,
  overview: review,
  summary: review,
  growth,
  bag,
  shop: () => bag(true),
  profile,
  notices,
  models,
  messages,
  operations,
  credits,
  presets,
  metrics,
};
function render(focus = false) {
  document.documentElement.lang = lang === "zh" ? "zh-CN" : "en";
  document.title = t("brand") + " · " + (routes[page] || "");
  const content = ["loading", "error"].includes(scene)
    ? empty(
        scene,
        "",
        scene === "error" ? B("retry", "scene-normal", "primary") : "",
      )
    : (renderers[page] || home)();
  $("#app").innerHTML =
    header() +
    `<main class="container ${page === "home" ? "" : "page"}" data-page="${routes[page]}" id="main">${accountViews.includes(page) ? accountShell(content) : content}</main><footer class="container footer"><div class="actions"><span>${esc(t("footer"))}</span>${["metrics", "models", "messages", "operations", "credits", "presets"].includes(page) ? link("metrics", "admin", "btn quiet small") : ""}</div></footer>`;
  $$(".nav a").forEach((a) => {
    if (a.dataset.go === (page === "trial" ? "explore" : page))
      a.setAttribute("aria-current", "page");
  });
  restoreForm();
  renderDemo();
  if (focus) $("h1")?.focus();
}
function renderDemo() {
  const states = [
    "normal",
    "empty",
    "loading",
    "error",
    ...({
      create: ["noquota", "nomodel", "nolength", "failure"],
      trial: ["invalid", "noquota", "failure"],
      review: ["resume", "denied", "multibatch"],
      overview: ["submit-error", "response-lost"],
      summary: ["success", "multibatch"],
      growth: ["blocked", "disabled", "demoted", "maxlevel"],
      bag: ["covered", "retired", "expired", "active", "lower", "insufficient"],
      shop: ["insufficient"],
      operations: ["save-error"],
      models: ["save-error"],
      messages: ["save-error"],
      profile: ["save-error"],
      credits: ["save-error"],
      presets: ["save-error", "failure"],
      metrics: ["delayed"],
    }[page] || []),
  ];
  $("#demo").innerHTML =
    `<details class="demo-bar"><summary>${esc(t("prototype"))} · ${routes[page]}</summary><div class="demo-controls"><select id="demo-page" aria-label="Page">${Object.entries(
      routes,
    )
      .map(
        ([p, id]) =>
          `<option value="${p}" ${page === p ? "selected" : ""}>${id} · ${esc(["home", "explore", ...accountViews].includes(p) ? t(p) : TRACE.find((x) => x.page === id)?.title)}</option>`,
      )
      .join(
        "",
      )}</select><select id="demo-state" aria-label="${esc(t("scenario"))}">${states.map((x) => `<option ${scene === x ? "selected" : ""}>${x}</option>`).join("")}</select>${B("reset", "reset", "small")}</div></details>`;
}
function go(p) {
  if (["review", "overview"].includes(page) && !S.submitted) saveDraft();
  if (page === "summary" && p !== "summary") {
    S.words = ["", "", ""];
    S.gaps = ["", "", "", ""];
    S.step = 0;
    S.submitted = false;
  }
  page = p;
  scene = "normal";
  syncURL();
  render(true);
  if (p === "review") offerResume();
}
function syncURL() {
  const u = new URL(location);
  u.searchParams.set("page", page);
  u.searchParams.set("lang", lang);
  u.searchParams.set("state", scene);
  history.replaceState({}, "", u);
}
function offerResume() {
  const raw = localStorage.getItem("ww-m002-draft");
  if (raw || scene === "resume")
    dialog(
      "resume.title",
      `<p>${esc(t("resume.desc"))}</p>`,
      B("fresh", "fresh") + B("resume", "resume", "primary"),
    );
}
function resetReview() {
  S.words = ["", "", ""];
  S.gaps = ["", "", "", ""];
  S.step = 0;
  S.submitted = false;
  S.returnOverview = false;
  localStorage.removeItem("ww-m002-draft");
}
function activate(i) {
  const v = S.inventory[i],
    x = S.items[v.type];
  if (x.type === "makeup") {
    makeup();
    return;
  }
  if (x.type === "plan" && scene === "lower") {
    toast("card.lower");
    return;
  }
  if (x.type === "model") {
    dialog(
      "card.preview",
      `${note("card.modelnote")}<div class="answer-row"><strong>Model A</strong><span>+ 3 · 2026-09-20 12:00</span></div><div class="answer-row"><strong>Model B</strong><span>+ 3 · 2026-09-23 12:00</span></div>`,
      B("cancel", "close") + B("activate", "activate-confirm:" + i, "primary"),
    );
    return;
  }
  if (x.type === "plan") {
    dialog(
      "card.cover.title",
      note("card.cover.desc", "warn"),
      B("cancel", "close") + B("confirm", "activate-confirm:" + i, "primary"),
    );
    return;
  }
  v.status = "active";
  S.quota += x.count;
  render();
  toast("card.used");
}
function makeup() {
  const card = S.inventory.find(
    (x) => S.items[x.type].type === "makeup" && x.status === "unused",
  );
  dialog(
    "makeup.title",
    `<p>${esc(t("makeup.desc"))}</p>${card ? `<div class="calendar">${[11, 12, 13, 14, 15, 16].map((d) => `<button class="day ${d === 14 ? "missed" : "signed"}" data-action="makeup-day:${d}" ${d === 14 ? "" : "disabled"}>09-${d}<br>${d === 14 ? "○" : "✓"}</button>`).join("")}</div>` : note("makeup.none", "warn")}`,
    B("cancel", "close"),
  );
}
function saveFeedback(fn) {
  if (scene === "save-error") {
    toast("failed");
    return false;
  }
  fn?.();
  toast("saved");
  return true;
}
function generate() {
  if (S.quota < 1 || ["noquota", "invalid", "nomodel"].includes(scene)) return;
  S.quota--;
  S.generation = "running";
  S.output = "";
  render();
  const pre = F.presets[S.preset];
  const text = pre.excerpt;
  let n = 0;
  clearInterval(timer);
  timer = setInterval(() => {
    n += 4;
    S.output = text.slice(0, n);
    if (n >= text.length) {
      clearInterval(timer);
      S.generation = scene === "failure" ? "failure" : "done";
      if (S.generation === "failure") S.quota++;
      else if (!S.guest) {
        if (!S.signed) {
          S.signed = true;
          S.points += 5;
          S.xp += 10;
          toast("signed");
        }
      }
      render();
    } else {
      const output = $('[data-region="generation-result"] .story-text');
      if (output) output.textContent = S.output + " ▍";
    }
  }, 65);
}
async function act(a) {
  const [k, arg] = a.split(":");
  const i = Number(arg);
  switch (k) {
    case "noop":
      break;
    case "close":
      close();
      break;
    case "language":
      rememberForm();
      lang = lang === "zh" ? "en" : "zh";
      syncURL();
      render();
      break;
    case "try":
      S.preset = i;
      S.generation = "idle";
      go("trial");
      break;
    case "random": {
      if (S.selected.length >= 5) return toast("word.limit");
      const w = F.candidates.find((x) => !S.selected.includes(x));
      if (!w) return toast("random.none");
      S.selected.push(w);
      render();
      break;
    }
    case "add-word": {
      const w = $("#wordsearch").value.trim().toLowerCase();
      if (S.selected.length >= 5) return toast("word.limit");
      if (!F.candidates.includes(w) || S.selected.includes(w))
        return toast("random.none");
      S.selected.push(w);
      render();
      break;
    }
    case "remove-word":
      S.selected.splice(i, 1);
      render();
      break;
    case "generate":
      generate();
      break;
    case "cancelgen":
      clearInterval(timer);
      S.generation = "cancelled";
      render();
      break;
    case "collect":
      if (S.guest) {
        dialog(
          "guestcollect",
          `<p>${esc(t("hero.note"))}</p>`,
          B("cancel", "close") + B("login", "login-collect", "primary"),
        );
      } else {
        toast("collected");
        resetReview();
        go("review");
      }
      break;
    case "login":
      S.guest = false;
      render();
      toast("welcome", { name: S.nickname || F.user.username, days: 2 });
      loginNotice();
      break;
    case "login-collect":
      close();
      S.guest = false;
      S.signed = true;
      toast("collected");
      resetReview();
      go("review");
      setTimeout(() => loginNotice(), 250);
      break;
    case "logout":
      S.guest = true;
      go("home");
      break;
    case "hint":
      S.hint = !S.hint;
      render();
      break;
    case "prev":
      S.step = Math.max(0, S.step - 1);
      saveDraft();
      render(true);
      break;
    case "next":
    case "skip":
      if (k === "skip") {
        if (S.step < 3) S.words[S.step] = "";
        else S.gaps = ["", "", "", ""];
      }
      if (S.returnOverview || S.step === 3) {
        S.returnOverview = false;
        go("overview");
      } else {
        S.step++;
        saveDraft();
        render(true);
      }
      break;
    case "overview":
      go("overview");
      break;
    case "back-review":
      go("review");
      closeIfOpen();
      break;
    case "word-start":
      S.step = 0;
      go("review");
      closeIfOpen();
      break;
    case "edit-word":
      S.step = i;
      saveDraft();
      S.returnOverview = true;
      page = "review";
      scene = "normal";
      syncURL();
      render(true);
      break;
    case "edit-passage":
      S.step = 3;
      saveDraft();
      S.returnOverview = page === "overview";
      page = "review";
      scene = "normal";
      syncURL();
      render(true);
      break;
    case "submit": {
      const b = $("#submit");
      b.disabled = true;
      b.textContent = t("submitting");
      await new Promise((r) => setTimeout(r, 350));
      if (scene === "submit-error") {
        b.disabled = false;
        b.textContent = t("submit");
        toast("submit.error");
        return;
      }
      S.submitted = true;
      localStorage.removeItem("ww-m002-draft");
      page = "summary";
      syncURL();
      render(true);
      break;
    }
    case "restart":
    case "fresh":
      closeIfOpen();
      resetReview();
      page = "review";
      scene = "normal";
      syncURL();
      render(true);
      break;
    case "resume": {
      let d;
      try {
        d = JSON.parse(localStorage.getItem("ww-m002-draft"));
      } catch {}
      if (d) {
        S.words = d.words;
        S.gaps = d.gaps;
        S.step = d.step;
      }
      close();
      render(true);
      break;
    }
    case "finish":
      go("growth");
      break;
    case "makeup":
      makeup();
      break;
    case "makeup-day":
      S.makeupDay = i;
      dialog(
        "makeup.title",
        `<p>2026-09-${i}</p>${note("makeup.desc")}`,
        B("cancel", "close") + B("confirm", "makeup-confirm", "primary"),
      );
      break;
    case "makeup-confirm": {
      const card = S.inventory.find(
        (x) => S.items[x.type].type === "makeup" && x.status === "unused",
      );
      if (!card) return;
      card.status = "expired";
      S.points += 6;
      close();
      render();
      toast("makeup.done");
      break;
    }
    case "claim":
      if (!S.claimed.includes(i)) {
        S.claimed.push(i);
        S.points += F.achievements[i].points;
        S.xp += F.achievements[i].xp;
        render();
        toast("claim.ok");
      }
      break;
    case "claim-level":
      S.levelClaimed = true;
      S.points += 10;
      render();
      toast("claim.ok");
      break;
    case "redeem": {
      const item = S.items[i];
      if (S.points < item.price || scene === "insufficient")
        return toast("card.insufficient");
      dialog(
        "redeem",
        `<h3>${esc(L(item.title))}</h3><p>${esc(t("pricevalue", { count: item.price }))}</p>`,
        B("cancel", "close") + B("confirm", "redeem-confirm:" + i, "primary"),
      );
      break;
    }
    case "redeem-confirm": {
      const item = S.items[i];
      if (!item.listed || S.points < item.price) return;
      S.points -= item.price;
      S.inventory.push({ type: i, status: "unused" });
      close();
      render();
      toast("card.redeemed");
      break;
    }
    case "use":
      activate(i);
      break;
    case "activate-confirm":
      S.inventory[i].status = "active";
      close();
      render();
      toast("card.used");
      break;
    case "refund":
      dialog(
        "refund",
        `${note("card.refundnote")}<strong>${esc(t("pricevalue", { count: S.items[S.inventory[i].type].refund }))}</strong>`,
        B("cancel", "close") + B("confirm", "refund-confirm:" + i, "primary"),
      );
      break;
    case "refund-confirm":
      if (S.inventory[i].status !== "refunded") {
        S.points += S.items[S.inventory[i].type].refund;
        S.inventory[i].status = "refunded";
      }
      close();
      render();
      toast("card.refundok");
      break;
    case "profile-save":
      saveFeedback(() => {
        S.nickname = $("#nickname").value.trim();
        S.gender = $("#gender").value;
        formMemory.delete("profile");
        render();
      });
      break;
    case "password":
      dialog(
        "password",
        field("newpassword", "new-password", "", "password"),
        B("cancel", "close") + B("save", "password-save", "primary"),
      );
      break;
    case "password-save":
      if ($("#new-password").value) {
        close();
        toast("saved");
      }
      break;
    case "delete-account":
      dialog(
        "deleteaccount",
        note("deleteaccount.desc", "warn"),
        B("cancel", "close") + B("confirm", "delete-account-confirm", "danger"),
      );
      break;
    case "delete-account-confirm":
      localStorage.removeItem("ww-m002-draft");
      close();
      S.guest = true;
      go("home");
      break;
    case "notice":
      if (!$("#dialog").open) S.reminderMode = false;
      noticeDialog(i);
      break;
    case "model-remove":
      S.removeModel = i;
      dialog(
        "model.remove.title",
        `<h3>${esc(S.models[i])}</h3>${note("model.remove.desc", "warn")}`,
        B("cancel", "close") + B("remove", "model-confirm", "danger"),
      );
      break;
    case "model-confirm":
      if (saveFeedback(() => S.models.splice(S.removeModel, 1))) {
        close();
        render();
        toast("model.removed");
      }
      break;
    case "plan-save":
      if ($("#basic-priority").value === $("#premium-priority").value)
        return toast("plan.duplicate");
      saveFeedback();
      break;
    case "new-message":
      F.notices.push({
        title: { zh: "", en: "" },
        body: { zh: "", en: "" },
        date: "2026-09-17",
        visible: false,
        remind: false,
      });
      S.message = F.notices.length - 1;
      render();
      break;
    case "message":
      S.message = i;
      render();
      break;
    case "message-preview":
      dialog(
        "preview",
        `<div class="markdown">${markdown($("#body-" + lang).value || $("#body-" + (lang === "zh" ? "en" : "zh")).value)}</div>`,
      );
      break;
    case "message-save":
      saveFeedback(() => {
        F.notices[S.message] = {
          title: { zh: $("#message-zh").value, en: $("#message-en").value },
          body: { zh: $("#body-zh").value, en: $("#body-en").value },
          date: "2026-09-17",
          visible: $("#visible").checked,
          remind: $("#remind").checked,
        };
      });
      break;
    case "optab":
      formMemory.delete(page);
      S.optab = arg;
      render();
      break;
    case "add-tier":
      rememberForm();
      S.tiers++;
      render();
      break;
    case "settings-save":
      if ($$("#main input[type=number]").some((x) => !x.checkValidity())) {
        $$("#main input[type=number]")
          .find((x) => !x.checkValidity())
          .reportValidity();
        break;
      }
      saveFeedback(() => rememberForm());
      break;
    case "item-new":
      itemForm();
      break;
    case "item-edit":
      itemForm(i);
      break;
    case "item-save": {
      const title = {
        zh: $("#item-zh").value.trim(),
        en: $("#item-en").value.trim(),
      };
      if (!title.zh && !title.en) {
        $("#item-zh").focus();
        return;
      }
      const inputs = $$("#dialog input[type=number]");
      if (inputs.some((x) => !x.checkValidity())) {
        inputs.find((x) => !x.checkValidity()).reportValidity();
        return;
      }
      saveFeedback(() => {
        const x = {
          ...(S.editItem >= 0
            ? S.items[S.editItem]
            : F.items.find((x) => x.type === S.editType)),
          title,
          desc: { zh: $("#item-desc-zh").value, en: $("#item-desc-en").value },
          price: Number($("#item-price").value),
          days: Number($("#item-days").value),
        };
        if ($("#item-duration")) x.duration = Number($("#item-duration").value);
        if ($("#item-refund")) x.refund = Number($("#item-refund").value);
        if ($("#item-count")) x.count = Number($("#item-count").value);
        if ($("#item-model"))
          x.models = [...$("#item-model").selectedOptions].map((x) => x.value);
        if (S.editItem >= 0) S.items[S.editItem] = x;
        else S.items.push({ ...x, listed: false });
        close();
        render();
      });
      break;
    }
    case "item-list":
      saveFeedback(() => {
        S.items[i].listed = !S.items[i].listed;
        render();
      });
      break;
    case "item-refs":
      dialog(
        "refs",
        i < 4
          ? `<p>${esc(L(F.achievements[0].title))} · Lv. 3</p>`
          : note("refs.none"),
      );
      break;
    case "item-delete":
      if (i < 4) return dialog("delete", note("delete.blocked", "warn"));
      dialog(
        "delete",
        `<p>${esc(L(S.items[i].title))}</p>`,
        B("cancel", "close") +
          B("delete", "item-delete-confirm:" + i, "danger"),
      );
      break;
    case "item-delete-confirm":
      saveFeedback(() => {
        S.items.splice(i, 1);
        close();
        render();
      });
      break;
    case "lookup":
      $("#found-user").textContent =
        $("#find-user").value === F.user.username
          ? S.nickname + " · " + t("pricevalue", { count: S.points })
          : t("empty");
      break;
    case "credit-save": {
      if ($("#find-user").value !== F.user.username) return toast("empty");
      const amount = Number($("#credit-amount").value);
      if (!(amount > 0)) return toast("positive");
      saveFeedback(() => {
        S.points += amount;
        $("#credit-amount").value = "";
        $("#found-user").textContent =
          S.nickname + " · " + t("pricevalue", { count: S.points });
      });
      break;
    }
    case "base-save":
      dialog(
        "base.reset",
        note("base.resetnote", "warn"),
        B("cancel", "close") + B("confirm", "base-confirm", "primary"),
      );
      break;
    case "base-confirm":
      saveFeedback(() => {
        S.quota = 5;
        close();
      });
      break;
    case "preset-edit":
      formMemory.delete(page);
      S.preset = i;
      S.preview = false;
      S.previewText = null;
      render();
      break;
    case "new-preset":
      formMemory.delete(page);
      F.presets.push({
        ...structuredClone(F.presets[0]),
        title: { zh: "", en: "" },
      });
      S.preset = F.presets.length - 1;
      S.preview = false;
      S.published = false;
      render();
      break;
    case "preset-save":
      saveFeedback(() => rememberForm());
      break;
    case "preset-preview":
      rememberForm();
      S.previewUsage++;
      if (scene === "failure") {
        toast("create.failure");
        return;
      }
      S.previewText = F.presets[S.preset].excerpt;
      S.preview = true;
      render();
      break;
    case "preset-publish":
      if (!S.preview) return toast("preview.required");
      if (
        saveFeedback(() => {
          rememberForm();
          const p = F.presets[S.preset];
          p.title = { zh: $("#preset-zh").value, en: $("#preset-en").value };
          p.words = $("#preset-words")
            .value.split(",")
            .map((x) => x.trim())
            .filter(Boolean);
          p.model = $("#preset-model").value;
          p.length =
            $("#preset-length").value === "brief" ? "Brief" : "Standard";
          p.language =
            $("#preset-language").value === "chinese" ? "中文" : "English";
          S.published = true;
          render();
        })
      )
        toast("publish.ok");
      break;
    case "preset-unlist":
      S.published = false;
      render();
      toast("saved");
      break;
    case "metric-info":
      dialog("metrics.definition", note("metrics.rules"));
      break;
    case "clarity":
      dialog("clarity", note("clarity.unavailable"));
      break;
    case "scene-normal":
      scene = "normal";
      syncURL();
      render();
      break;
    case "reset":
      localStorage.removeItem("ww-m002-draft");
      location.href = "?page=" + page + "&lang=" + lang;
      break;
  }
}
function closeIfOpen() {
  if ($("#dialog").open) close();
}
document.addEventListener("click", (e) => {
  const el = e.target.closest("[data-go],[data-action]");
  if (!el || el.disabled) return;
  if (el.dataset.go) {
    e.preventDefault();
    go(el.dataset.go);
  } else act(el.dataset.action);
});
document.addEventListener("input", (e) => {
  const el = e.target;
  if (el.matches("[data-slot]")) {
    el.value = el.value.replace(/[^a-zA-Z]/g, "").slice(-1);
    const a = $$(".slot").map((x) => x.value || " ");
    S.words[S.step] = a.join("").trimEnd();
    saveDraft();
    $("#review-next").disabled = !S.words[S.step].trim();
    if (el.value) $$(".slot")[Number(el.dataset.slot) + 1]?.focus();
  }
  if (el.matches("[data-gap]")) {
    S.gaps[Number(el.dataset.gap)] = el.value;
    saveDraft();
    $("#review-next").disabled = !S.gaps.some((x) => x.trim());
  }
  if (el.id === "item-search") filterItems();
  if (el.hasAttribute("data-preset-param")) {
    rememberForm();
    S.preview = false;
    const b = $('[data-action="preset-publish"]');
    if (b) b.disabled = true;
  }
});
document.addEventListener("click", (e) => {
  const dropdown = $(".account-dropdown[open]");
  if (dropdown && !dropdown.contains(e.target)) dropdown.open = false;
});
document.addEventListener("focusin", (e) => {
  const dropdown = $(".account-dropdown[open]");
  if (dropdown && !dropdown.contains(e.target)) dropdown.open = false;
});
document.addEventListener("keydown", (e) => {
  const dropdown = $(".account-dropdown[open]");
  if (e.key === "Escape" && dropdown && !$("#dialog").open) {
    e.preventDefault();
    dropdown.open = false;
    dropdown.querySelector("summary").focus();
  }
});
document.addEventListener("keydown", (e) => {
  if (!e.target.matches("[data-slot]")) return;
  const slots = $$(".slot"),
    n = Number(e.target.dataset.slot);
  if (e.key === "Backspace" && !e.target.value && n > 0) {
    slots[n - 1].focus();
  }
  if (e.key === "ArrowLeft") {
    e.preventDefault();
    slots[Math.max(0, n - 1)].focus();
  }
  if (e.key === "ArrowRight") {
    e.preventDefault();
    slots[Math.min(slots.length - 1, n + 1)].focus();
  }
});
document.addEventListener("paste", (e) => {
  if (!e.target.matches("[data-slot]")) return;
  e.preventDefault();
  const text = e.clipboardData.getData("text").replace(/[^a-zA-Z]/g, "");
  const slots = $$(".slot"),
    start = Number(e.target.dataset.slot);
  for (let n = 0; n < text.length && start + n < slots.length; n++)
    slots[start + n].value = text[n];
  S.words[S.step] = slots
    .map((x) => x.value || " ")
    .join("")
    .trimEnd();
  saveDraft();
  $("#review-next").disabled = !S.words[S.step].trim();
  slots[Math.min(slots.length - 1, start + text.length)]?.focus();
});
function filterItems() {
  const name = $("#item-search").value.toLowerCase(),
    type = $("#type-filter").value,
    status = $("#status-filter").value;
  $$("[data-item-row]").forEach(
    (row) =>
      (row.hidden = !(
        row.dataset.name.toLowerCase().includes(name) &&
        (!type || row.dataset.type === type) &&
        (!status || row.dataset.listed === status)
      )),
  );
}
document.addEventListener("change", (e) => {
  const el = e.target;
  if (el.hasAttribute("data-preset-param")) {
    rememberForm();
    S.preview = false;
    const b = $('[data-action="preset-publish"]');
    if (b) b.disabled = true;
  }
  if (["model", "explain", "style", "length"].includes(el.id)) {
    S[el.id] = el.value;
    render();
  }
  if (["type-filter", "status-filter"].includes(el.id)) filterItems();
  if (el.id === "item-type") itemForm(-1, el.value);
  if (el.id === "demo-page") {
    go(el.value);
  }
  if (el.id === "demo-state") {
    scene = el.value;
    if (scene === "success") {
      S.words = F.words.map((w) => w.word);
      S.gaps = F.passage
        .filter((x) => typeof x !== "string")
        .map((x) => x.answer);
    }
    syncURL();
    render();
    if (scene === "resume") offerResume();
  }
});
if (page === "summary") {
  S.words =
    scene === "success"
      ? F.words.map((x) => x.word)
      : ["resilent", "wander", ""];
  S.gaps =
    scene === "success"
      ? F.passage.filter((x) => typeof x !== "string").map((x) => x.answer)
      : ["resilent", "wander", "weave", ""];
  S.submitted = true;
}
render();
if (page === "review") offerResume();
