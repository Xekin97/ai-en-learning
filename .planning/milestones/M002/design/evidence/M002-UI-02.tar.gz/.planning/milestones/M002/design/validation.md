---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-02
date: 2026-09-17
---

# 二期设计自检

M002-UI-02 为待用户审阅的设计原型。本记录不批准设计，不证明生产代码、接口、账号、生成质量、配额或积分事务已完成。

## 实际执行

- 在本地 HTTP 服务中运行 [浏览器检查脚本](./evidence/verify-prototype.cjs)，复用仓库已有 Playwright / axe 依赖，没有安装新包。
- 结果见 [browser-results.json](./evidence/browser-results.json)：21 项检查 PASS；18 个视图 × zh/en × 320/390/1440/1920，共 144 组，页面级横向溢出为 0；浏览器 JavaScript 错误为 0。
- Chromium 版本见机器结果 browser。首页、试用、个人信息、复习、账号成长、道具卡、兑换中心、道具后台八个代表视图运行 WCAG 2 A/AA axe 检查，无自动报告违规；不是全站人工无障碍验收。
- 本轮新增覆盖：头像四项的顺序与准确文案、Enter 展开/Tab 访问/Escape 关闭回焦/外部关闭、320/390/1440px 下拉不越界、四视图共享资料与当前项、昵称更新与空值回退、首页移除预设列表、访客试用浏览再到锁定工作台、兑换入库后跨视图可见。
- 原有实际操作覆盖：错答可前进、概览不评分、定题修改与刷新恢复、部分短文提交、总结改错、当次结果退出清理、随机选词、配置默认、预设锁定和显式生成、访客收录后提醒、奖励领取与禁用、模型卡覆盖与退换、高档覆盖确认、分类道具创建/编辑/删除保护、任意多档、保存失败保留、积分正数校验、预览发布门控、隐藏消息过滤与 Markdown 转义。
- 减少动效模拟下，首页词签 animationName 为 none；正常模式已在浏览器检查页面与原型源的一致性。交互测试不把静态截图当动画证据。

## 视觉检查

实际查看本地浏览器截图：[首页桌面](./evidence/home-1440.png)、[首页手机](./evidence/home-390.png)、[个人信息桌面](./evidence/profile-1440.png)、[个人信息手机](./evidence/profile-390.png)、[成长桌面](./evidence/growth-1440.png)、[道具卡手机](./evidence/bag-390.png)、[试用桌面](./evidence/explore-1440.png)、[头像下拉桌面](./evidence/avatar-menu-1440.png)、[头像下拉手机](./evidence/avatar-menu-390.png)。首页保留双栏价值与单篇示例，完整预设浏览单独呈现；个人中心桌面共用左栏、手机资料置顶，当前分区清晰；下拉菜单四项均可见且不越界。截图使用固定示例数据，不代表真实用户数据。底部原型控制条仅用于审阅，不进入生产。

## 已发现与修正

UI-02 首轮新增试用检查把第二篇预设的词写成了其他示例，导致断言失败；改用该预设实际词 gentle / curious / delight 后通过，未改业务夹具来迁就检查。失败结果保留 [M002-UI-02-initial-browser-results.json](./evidence/M002-UI-02-initial-browser-results.json)。以下四项属于 UI-01 已修正记录：

1. 概览返回某题后刷新：原型只保存了上一导航步骤，未更新定题入口。现在进入对应题/短文时同步保存未提交草稿位置，UIA-PAGE-201-02 回归通过。
2. 初次截图落在进入过渡中，文字处于半透明。检查脚本改为等过渡完成再拍，未用样式加深掩盖拍摄时机。
3. 320px 英文监控页的 Observing 超出三列摘要。为监控摘要使用 minmax(0,1fr) 和可换行文字，128 组复查通过；失败记录保留 [initial-browser-results.json](./evidence/initial-browser-results.json)。
4. 首轮检查脚本错误使用便捷 newPage 导致 axe 上下文关闭问题，改为显式 browser.newContext；脚本模块路径也按实际仓库层级修正。以上为检查配置修复，不是产品功能失败。

## 未覆盖与接续

- 未做真机 Safari、人工读屏、系统输入法、多词条/标点输入、200% 浏览器缩放和所有长运营内容的真实设备验证。前端实现应按 responsive-accessibility.md 补充这些验收。
- 原型为静态夹具和局部状态模拟，不连接真实后端。登录/注册、生成、领奖、补签、卡片时长和额度、管理员配置均不代表生产事务或授权已实现。服务端幂等、并发、退换资格、04:00 归日、数据留存与删除须由技术方案和后续实现/独立 QA 验证。
- 多批次、同档续期、跨月补签的完整真实数据流遵守 interactions.md 及产品 AC；当前浏览器脚本覆盖代表性呈现，不宣称覆盖每种业务排列。
- 独立新会话交接测试未执行（not_executed）；静态文件/链接核对不是接续效果测试。M001 的 CR039-L1、CR042-L1、AI-QUALITY-90 保持原状态。

## 版本与复现

设计源、文案、样式、追踪、规范、检查脚本、最终结果与截图统一保存于 `evidence/M002-UI-02.tar.gz`，逐文件 SHA-256 见 [design-manifest.json](./evidence/design-manifest.json)。UI-01 原稿及其清单继续保留；应用代码及产品批准原件未改动；这些设计产物为未提交工作区文件。没有 Git 提交、真实模型调用、数据库迁移或部署。

先按 design-spec.md 启动 HTTP 服务，再在产品仓库执行：

```sh
node .planning/milestones/M002/design/evidence/verify-prototype.cjs
```
