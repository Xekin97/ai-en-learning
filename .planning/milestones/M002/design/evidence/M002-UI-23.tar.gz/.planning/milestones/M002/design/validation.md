---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-23
design_version: M002-UI-23
approval: pending_new_visual_review
date: 2026-10-01
---

# M002 设计交付验证

UI23 是 [CR025](../changes/CR-025.md) 的五项追加设计，由 designer-tony 自检，等待用户视觉验收。输入 PRODUCT04 / TRANSITION-M002-062；旧 UI22/H01、原用户 UAT 与里程碑收尾原件保留。本报告只覆盖可运行原型及设计交接，不代表正式应用已经升级或独立 QA 通过。

## 范围与实际检查

静态服务为 `http://127.0.0.1:4186/prototype/`，根为本 design；使用现有本地 Playwright + Chromium，Node 24，默认减少动效，未发真实模型请求。除最后发现并修复的消息边界外，没有重复业务单元测试、生产构建或后台联调。

| 检查 | 实际证据 / 结果 |
|---|---|
| 首页、消息、精选、学习和后台首轮渲染 | [smoke.json](./evidence/ui23/smoke.json)：8 个主要入口无 pageerror，选择器均接管，页面无横溢；长消息正文 515px、内容 906px，具备独立滚动。 |
| 全站布局与选择器覆盖 | [boundaries-attempt2.json](./evidence/ui23/boundaries-attempt2.json)：28 视图 × 中英文 × 1440×1000 / 390×844 / 320×568，共 168 布局检查均通过；每页业务 select 数量等于统一 trigger 数量，业务区没有可见原生 select。演示工具条不属于产品 UI。 |
| 消息固定区 | 同报告：正常/长标题 × 中英文 × 三尺寸，12 组标题/底部边界与正文滚动、Escape 检查通过。后续短屏样式细化以最终复测为准。 |
| 选择器真实操作 | 同报告与 [focused.json](./evidence/ui23/focused.json)：键盘打开/首尾定位/选择/重绘回焦、Escape/Tab、实际语言切换；合成长选项列表的局部滚动/视口边界/禁用、父弹窗内 Escape 隔离。合成 fixture 只证明组件边界，不冒充某条已有业务流程。 |
| 预设与 Markdown | focused：精选三个原词均有释义；切英文 UI 保持中文样本释义；后台改日语时旧预览保留、立即提示过期并禁用发布，重新模拟预览才一起换成日语资源；新预设显示等待文案。Markdown 标题、引用、嵌套列表、表格、代码实际渲染；HTML/危险协议不激活，长代码局部横滚。 |
| 欢迎 Toast 与消息 | 首次 focused 发现 320×568 重叠；[final-boundary.json](./evidence/ui23/final-boundary.json) 12 项修复复测通过。人工看截图后进一步上移窄屏关闭按钮，避免与标题相碰；[最终复测](./evidence/ui23/final-boundary-after-close.json) 16 项通过，包含三尺寸双语正文主体比例、Toast ≥12px 间隔、短屏可见正文与关闭按钮无标题碰撞。 |
| 文档与未变更源 | [UI23-static.json](./evidence/UI23-static.json)：生产前后端交付摘要、PRODUCT04 接收快照、UI22 归档保留、25 PAGE / 28 视图 / 49 CAP、双语新文案、JS 语法、本地引用与版本一致性。 |

## 已发现问题和处理

1. 首轮脚本误把原有语言选项 `EN` 写成 `English`；第二轮又将现有日语选项误写成“日文”，并猜错英文页首文案。这是验证脚本定位错误；原 [首次错误](./evidence/ui23/boundaries-attempt1-error.json)、[第二次错误](./evidence/ui23/boundaries-attempt2-error.json) 和已保存观察保留，focused 用实际文案定向补测。未用错误定位推断产品失败，也未改产品文案迎合测试。
2. UI23 的 `inset:0` 覆盖了 UI21 欢迎避让位置。修复为消息专用 `.with-toast-space` 同时限制高度与底部 inset；保留原十秒时限与动画。focused 的失败记录保留，最终复测通过。
3. 320px 短屏截图显示关闭文字与主标题邻接过近。关闭按钮移到眉题同一行，短屏标题使用 18px，完整保留长标题；最终 geometry 与截图验证。

4. 文档检查发现跨期差异表沿用已迁移的 account.vue 路径，已指向当前 account/index.vue；保留 [首次静态结果](./evidence/UI23-static-first.json)，修正后全部本地引用复核通过。

## 视觉审阅记录

实际查看了 8 张浏览器截图：初始预算 6 张；因上述 Toast 与关闭按钮的具体问题增补 2 张复测，未扩大为重复整站截图。

- [首页桌面](./evidence/ui23/01-home-desktop.png)：原叠卡、学习路径和新增三项优势同一主题；没有新增成长入口。
- [消息桌面](./evidence/ui23/02-notice-desktop.png)、[手机长标题](./evidence/ui23/03-notice-mobile.png)：正文为主要阅读区，标题和动作分隔明确；窄屏关闭位置后以第 8 张为准。
- [精选](./evidence/ui23/04-picks-desktop.png)、[日语预设预览](./evidence/ui23/05-admin-preset.png)：词义完整，配置与正文/释义关系清楚。后台示例仍是原型模拟生成。
- [手机选择器](./evidence/ui23/06-select-mobile.png)：浅绿选中、勾选、圆角浮层与原配置风格一致。
- [Toast 避让复测](./evidence/ui23/07-toast-clearance-retest.png)、[最终短屏](./evidence/ui23/08-short-screen-final.png)：欢迎提示与固定操作分离，关闭文字不压标题。第 7 张保留已发现的关闭位置问题。

## 交付、恢复与边界

当前源与证据清单：[design-manifest.json](./evidence/design-manifest.json)；不可变交付：[UI23 清单](./evidence/M002-UI-23-manifest.json) / [UI23 快照](./evidence/M002-UI-23.tar.gz)；回改前：[UI23-before](./evidence/M002-UI-23-before.tar.gz)。冻结核对见 [UI23-freeze.json](./evidence/UI23-freeze.json)。脚本及失败/成功结果均位于 evidence/ui23，不复写 UI22/H01 历史检查。

本次未测试真实移动设备、Safari/Firefox 或人工读屏，未做新视觉用户验收、生产实现或独立 QA；浏览器支持和正式表单组件集成由下游技术/前端接收验证。原 UI22 的未变更区域不因本轮局部检查而获得新的通过声明。CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX 保持原状态；本轮不修改既有计量/权益/草稿/账号规则。

未修改正式应用、计划/模型配置、数据库或测试账号；未提交/推送/部署。未开启多 agent 或独立接收会话。实际模型 token 用量未知。当前阶段仍 uiux-design，视觉批准字段仍只指 UI22，UI23 等待用户审阅。
