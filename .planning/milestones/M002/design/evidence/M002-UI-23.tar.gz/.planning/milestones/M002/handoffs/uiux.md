---
milestone: M002
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M002-UI-23
design_version: M002-UI-23
approval: pending_new_visual_review
date: 2026-10-01
---

# M002 设计交接 · designer-tony

**当前交付为 UI23 五项追加改稿，等待用户视觉验收。** 输入 [PRODUCT04](./product.md)，来源 [CR025](../changes/CR-025.md)，接收门 [TRANSITION-M002-062](../reviews/product-design-062.md)。旧 UI22/H01 已验收记录与 M002 UAT/收尾原件保持；本版只替换五项受影响设计，未修改正式应用。Profile 和锁定 agt revision 保持。

先读 [UI22→UI23 差异及 M001 继承表](../design/frontend-delta.md)，再按验收 ID 定位 [设计规格](../design/design-spec.md)、[交互](../design/interactions.md)、[响应式](../design/responsive-accessibility.md)、[copy.json](../design/copy.json) 和 [theme.css](../design/theme.css)。[验证结果](../design/validation.md)、[当前清单](../design/evidence/design-manifest.json)、[完整快照](../design/evidence/M002-UI-23.tar.gz) 为同一交付。

## 预览与变更

- [首页](http://127.0.0.1:4186/prototype/?page=home&lang=zh&v=M002-UI-23)：Why Wordweave 三项优势，原叠卡/动效/入口保留。
- [消息](http://127.0.0.1:4186/prototype/?page=notices&lang=zh&v=M002-UI-23)：固定标题和动作、正文独立滚动；暖白深绿 Markdown。后台 `page=messages` 预览同款。
- [精选](http://127.0.0.1:4186/prototype/?page=explore&lang=zh&v=M002-UI-23) 与 [预设管理](http://127.0.0.1:4186/prototype/?page=presets&lang=zh&v=M002-UI-23)：同批样本词义、预设语言、过期/无预览状态。
- [学习](http://127.0.0.1:4186/prototype/?page=create&lang=zh&v=M002-UI-23)：可操作的新选择器；全站现有选择型下拉统一。正式应用清单为 9 文件 / 19 处。

## 接收边界

frontend-bob 后续按设计接收现有契约与组件边界；frontend-claire 在新视觉获接受后落实。最小范围为消息专用阅读布局、Markdown 作用域样式、复用现有预设学习资源、统一选择器和首页文案，没有新增 API/DB 字段要求。不要复制原型 DOM 扫描器、模拟生成、预设夹具或 Marked 解析器作为生产代码；正式 Markdown 白名单保持。其他一期/二期能力继续以已验收来源为准。

检查发现并修复短屏 Toast 避让被新 inset 覆盖的问题，新增对应复测；脚本对现有文案的两处错误假设保留失败记录后修正。具体范围、未测项及 8 张截图见验证文件，不把 Chromium 原型检查等同生产 QA/真机/人工读屏。未调用真实 AI，未改生产配置、数据、代码或控制面；未提交 Git。实际模型 token 用量未知。

下一具体动作：用户审阅这五项追加视觉。UI23 未获批准，设计角色不自行切阶段；设计接受后按既有前端实施与 QA 常设授权推进必要接收和落实，不能再次索取已授权的重复许可。CR025 保持 open，未变更范围沿用既有验收。
