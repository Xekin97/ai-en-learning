import { loadDesign, translator, esc, icon, bindPortability } from '../controller.js';

const route = (page, category, language, extra = {}) => {
  const next = new URLSearchParams({ page, category, lang: language, ...extra });
  return `?${next}`;
};

export async function enhanceConfigPortability({ page, category, language, initialState }) {
  const { copy, fixture } = await loadDesign();
  const t = translator(copy, language);
  let controller = null;
  let opener = null;
  let initialOpened = false;
  let operationsAdjusted = false;

  const nativeDialog = document.createElement('dialog');
  nativeDialog.id = 'cr313-dialog';
  nativeDialog.className = 'cr313-dialog';
  nativeDialog.setAttribute('aria-labelledby', 'portability-dialog-title');
  nativeDialog.innerHTML = '<div class="cr313-dialog-host"></div>';
  document.body.append(nativeDialog);
  const host = nativeDialog.querySelector('.cr313-dialog-host');

  const close = () => {
    if (['submitting', 'reading'].includes(controller?.state)) return;
    controller?.destroy();
    controller = null;
    nativeDialog.close();
    opener?.isConnected && requestAnimationFrame(() => opener.focus({ preventScroll: true }));
  };
  const open = (state, selectedCategory = category) => {
    opener = document.activeElement;
    controller?.destroy();
    controller = bindPortability({
      host,
      category: selectedCategory,
      state,
      t,
      data: fixture,
      embedded: true,
      outcome: new URLSearchParams(location.search).get('outcome') === 'unknown' ? 'unknown' : 'success',
      onClose: close,
    });
    if (!nativeDialog.open) nativeDialog.showModal();
  };
  nativeDialog.addEventListener('cancel', event => {
    event.preventDefault();
    close();
  });
  nativeDialog.addEventListener('click', event => {
    if (event.target === nativeDialog) close();
  });

  const rewriteInheritedNavigation = () => {
    document.querySelectorAll('.admin-nav a').forEach(link => {
      const label = link.textContent.trim();
      const href = link.getAttribute('href') || '';
      if (/page=models/.test(href) || /模型管理|Models/.test(label)) link.href = route('models', 'models', language);
      if (/page=plans/.test(href) || /计划管理|Plans/.test(label)) link.href = route('plans', 'plans', language);
      if (/page=operations/.test(href) || /成长运营|Operations|Growth/.test(label)) link.href = route('operations', 'items', language);
    });
  };

  const adjustOperationsTab = () => {
    if (page !== 'operations' || operationsAdjusted) return;
    operationsAdjusted = true;
    const desired = category === 'growth' ? 'signsettings' : 'itemsettings';
    const tab = document.querySelector(`[data-action="optab:${desired}"]`);
    if (tab && !tab.classList.contains('selected')) tab.click();
  };

  const ensureActions = () => {
    rewriteInheritedNavigation();
    adjustOperationsTab();
    const main = document.querySelector('#main .admin-main');
    const heading = main?.querySelector(':scope > .page-head');
    if (!main || !heading) return;
    let actions = heading.querySelector(':scope > .actions');
    if (!actions) {
      actions = document.createElement('div');
      actions.className = 'actions';
      heading.append(actions);
    }
    if (!actions.querySelector('[data-cr313-action]')) {
      const group = document.createElement('span');
      group.className = 'cr313-actions';
      group.setAttribute('aria-label', t('portability.actionsLabel'));
      group.innerHTML = `<button class="btn" type="button" data-cr313-action="import">${icon('upload')}${esc(t('portability.import'))}</button><button class="btn" type="button" data-cr313-action="export">${icon('download')}${esc(t('portability.export'))}</button>`;
      actions.prepend(group);
      group.addEventListener('click', event => {
        const button = event.target.closest('[data-cr313-action]');
        if (!button) return;
        open(button.dataset.cr313Action === 'export' ? 'export' : 'file');
      });
    }
    if (!main.querySelector(':scope > .cr313-demo')) {
      const demo = document.createElement('details');
      demo.className = 'cr313-demo';
      demo.innerHTML = `<summary>${esc(t('demo.title'))}<span>M002-UI-33-R1</span></summary><div><p>${esc(t('demo.help'))}</p><a class="btn quiet" href="../prototype/?category=${category}&state=${initialState === 'idle' ? 'file' : initialState}&lang=${language}">${language === 'zh' ? '打开交互原型' : 'Open interaction prototype'}</a></div>`;
      main.append(demo);
    }
    if (!initialOpened && initialState !== 'idle') {
      initialOpened = true;
      open(initialState);
    }
  };

  ensureActions();
  const observer = new MutationObserver(() => requestAnimationFrame(ensureActions));
  observer.observe(document.querySelector('#app'), { childList: true, subtree: true });
}
