---
milestone: M002
version: M002-UI-33-R1
agent_name: designer-tony
status: awaiting_user_review
date: 2026-10-15
input_version: M002-PRODUCT-09-R1
current_scope: CR-313
requested_model: gpt-5.6-sol
requested_effort: high
actual_model: unknown
---

# 配置导入导出 UI/UX 交接

## 当前可审阅原件

- 设计规格：[design-spec.md](../design/config-portability/design-spec.md)
- 交互：[interactions.md](../design/config-portability/interactions.md)
- 响应式与可访问性：[responsive-accessibility.md](../design/config-portability/responsive-accessibility.md)
- 独立交互原型：[prototype/index.html](../design/config-portability/prototype/index.html)
- 继承式正式设计：[formal/index.html](../design/config-portability/formal/index.html)
- 精确文案、局部样式、状态控制器和安全样例位于同一 config-portability 目录。

本稿属于 M002，目标为 M002-UI-33-R1。旧 M003-UI-15 的独立重画方向已失效，旧截图、报告、归档和 [历史 JS](../design/config-portability/history/M003-UI-15-independent-redraw.js) 只供恢复与问题追踪，不能作为当前实现依据。M002 发音产品08与设计32仍单独待审；本稿不批准它们，也不表示 M002 收尾。

## 继承方式

正式稿不重画管理台。模型与计划直接加载冻结的原 M003-UI-13-R4 app.js、theme.css 和原 fixture；成长与道具直接加载冻结的原 M002-UI-26 app.js、operations.js、growth.js、admin.js、theme.css、copy 和 fixture。formal/vendor 中 74 个文件与其历史原件逐字节一致。

formal/boot.js 选择对应原模块，formal/enhancer.js 只在原 page-head 操作区插入导入和导出按钮，并挂载独立原生 dialog。原模型编辑 modal、计划横向 tabs 与返修设置、成长 tabs、道具表格及编辑 modal 全由原模块继续驱动。新增 theme.css 只有 #cr313-dialog 和 .cr313 命名空间，没有全局 Token、body、btn、panel、tabs 或管理台布局规则。

旧模块的相对资源路径通过加载期临时 base 适配；加载后移除。导航链接仅回指本正式稿的三类宿主页。vendor 原件和旧 fixture 均未修改，导入差异在独立 admin-safe.json 中按原基线计算。

## 本地预览

静态服务 PID 30189，仅监听 127.0.0.1:4176，根目录为 .planning/milestones/M002/design/config-portability。

启动命令：

    python3 -m http.server 4176 --bind 127.0.0.1 --directory .planning/milestones/M002/design/config-portability

代表入口：

- 正式稿默认模型页：http://127.0.0.1:4176/formal/?page=models&category=models&portState=idle&lang=zh
- 模型逐项预览：http://127.0.0.1:4176/formal/?page=models&category=models&portState=preview&lang=zh
- 计划英文预览：http://127.0.0.1:4176/formal/?page=plans&category=plans&portState=preview&lang=en
- 道具依赖阻止：http://127.0.0.1:4176/formal/?page=operations&category=items&portState=blocked&lang=zh
- 成长英文预览：http://127.0.0.1:4176/formal/?page=operations&category=growth&portState=preview&lang=en
- 390px 英文确认：http://127.0.0.1:4176/formal/?page=models&category=models&portState=confirm&lang=en
- 独立交互原型：http://127.0.0.1:4176/prototype/?category=models&state=export&lang=zh
- 原模型只读基线：http://127.0.0.1:4176/formal/?page=models&category=models&lang=zh&inheritance=baseline

查询参数只用于设计审阅，不是生产路由。

## 已验证

[M002-UI-33-R1-browser.json](../design/config-portability/evidence/M002-UI-33-R1-browser.json) 为 12/12 PASS，provider call 0、配置写入 0、console error 0、page error 0。

定向检查证明：

- 模型 provider list 前后 outerHTML SHA256 同为 ddbf6df641cf471197d0f843e072b8245819316dbc322a44e41c819cb7eb93fa，标题位置同为 x=256、y=100；
- 计划完整 panel 前后 SHA256 同为 a6907d1e63e6fccfb4e67b556b08fcd4b181837fac1077c54bf12daecde88fe7，横向 tabs 前后 hash 相同；
- 道具完整 panel 前后 SHA256 同为 953a85e09e6c9a8e70163704cac2aa7f32cb43c0669b59912815b8bee2853f30；
- 原模型编辑 modal 保留协议、2 个自定义参数区和 2 个模型行；
- 原计划 tab、优先级 modal、内容返修配置可操作；
- 原成长 tabs 可切换，原道具编辑 modal 可打开；
- 入口在原模块重绘后仍恢复为两个，不覆盖原 action；
- 模型 preview 为 1 新增、2 更新、1 移出、1 不变，移出对象是原基线中的 Unmodified model；
- 390×844 横向溢出 0，dialog 374×828，footer 底边 837，小于视口 844，按钮均 168.5×69；
- 原型没有管理台导航，和正式设计目的明确分离。

[M002-UI-33-R1-source-check.json](../design/config-portability/evidence/M002-UI-33-R1-source-check.json) 证明 74 个 vendor 文件与原件 hash 全部相同，并验证局部样式没有 :root、body 或全局 btn 规则。9 张截图的目视结论见 [M002-UI-33-R1-visual-review.json](../design/config-portability/evidence/M002-UI-33-R1-visual-review.json)。

最终源清单见 [M002-UI-33-R1-source-manifest.json](../design/config-portability/evidence/M002-UI-33-R1-source-manifest.json)，可恢复归档为同目录 M002-UI-33-R1-source.tar.gz。旧 M003-UI-15 manifest、archive 和 checks 保持历史原样，未用于宣称本修订通过。

## 未验证边界

这些证据只证明本地设计原件的确定性视觉、交互和继承关系。真实文件选择与解析、导出文件生成、加密协议、Key 安全、权限、稳定身份映射、依赖查询、数据库原子替换、并发失效、生产 Vue、真实 UAT 与提供方行为均未验证。设计中的下载、解密和提交结果是演示，不表示能力已经实现。

## 后续路由

当前稿可交用户审阅，不能自批。用户通过后，产品 M002-PRODUCT-09-R1 与设计 M002-UI-33-R1 才可进入技术设计，定义文件格式、身份、依赖与事务、加密边界以及生产前端接收。当前未切换阶段、未实施产品。
