---
milestone: M002
version: M002-UI-33-R1
status: awaiting_user_review
---

# 响应式与可访问性

## 继承优先

管理台断点、导航、卡片、表单、tabs、表格和原 modal 全部来自冻结的原主题。R1 不覆盖通用容器、字体、按钮、panel 或表单 Token。新增规则只作用于 .cr313 命名空间与 #cr313-dialog。

## 宽度行为

- 1440px：原 192px 管理导航和正文列保持；入口与原页头操作同组。
- 1100px：继续使用原管理台窄导航；原型由两列转为单列。
- 760px：入口组换行并各自自适应；原管理台导航、表格横向滚动和表单折叠仍由原主题负责。CR-313 modal 距视口 8px，body 独立滚动，footer 固定在 modal 底部。
- 390px：计数卡为两列，确认计数为单列；footer 按钮高度至少 48px，页面横向溢出为 0。

## Modal 与触控

桌面宽度为 min(680px, 100vw - 32px)，高度不超过 100dvh - 32px。移动宽度为 100vw - 16px，高度不超过 100dvh - 16px。正文可滚动，标题和 footer 不随正文离开。按钮沿用原主题 44px 最小目标，移动 footer 实测为 69px 高；不通过缩小目标解决空间问题。

## 语义与键盘

原生 dialog 提供 modal 边界，aria-labelledby 指向业务标题。状态成功、错误与 pending 保留可见文字；错误使用 alert，读取与提交状态使用 status/live region。折叠项目使用原生 details/summary。关闭按钮先获焦，Tab 不离开 modal，关闭恢复 opener。

颜色从原主题继承；危险项同时有“移出”文字和计数，成功与错误不只依赖颜色。所有 icon 为装饰性 SVG，按钮保留文字名称。中英文共用 DOM 顺序，identity 可断行。

## 定向验证

390×844 英文确认态实测：

- document 横向溢出 0px；
- dialog 为 374×828px，位于 8,8；
- footer 底边 837px，小于 844px；
- 两个 footer 目标均为 168.5×69px。

该验证只覆盖设计原件，不代表生产实现或真实设备已验证。
