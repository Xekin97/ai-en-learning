---
milestone: M002
version: M002-UI-32-R1
agent_name: designer-tony
status: awaiting_user_review
date: 2026-10-16
input_version: M002-PRODUCT-08 plus CR-314
---

# 单词发音设计

## 当前目标与有效范围

用户确认每词一个紧凑控件，状态就地显示，并取消选词发音。[CR-314](../../changes/CR-314.md) 是对已接受产品 S402/PAGE-401/AC-401、408 的明确范围修订，未再次批准整套设计。M002 继续进行；当前仅设计，未进入技术/实现。

仍有效：[产品基线](../../product/pronunciation/overview.md) DATA-401～404、CAP-401～404、AC-401～410，所有用户免费、不扣额度、不调用大模型。保留完整工具台、已保存文章、词义与用法、现有绿色/暖白/阅读字体层次。正文高亮词、后台、复习与 explore 不增播放入口。

旧 M002-UI-32（原 M003-UI-14）的 PAGE-401 发音、独立状态卡、移动贴底菜单已失效。旧 [源清单](../../../M003/design/pronunciation/evidence/M003-UI-14-source-manifest.json) 保留；新源写入本目录，继承旧共享视觉主题与书店 fixture。修订前控制文件/交接保存在 [快照](../../reviews/evidence/pronunciation-revision-132-r1/before-revision.tar.gz)。本版源及 SHA 见 [当前清单](evidence/M002-UI-32-R1-source-manifest.json)。

## 页面、能力与内容定位

| 页面/区域 | 元素顺序与当前规则 | 追踪 | 稳定定位 |
|---|---|---|---|
| PAGE-401 选词 | 已选词为单词、删除；搜索候选为单词、添加。没有播放或播放状态 | CR-314 覆盖 S402/AC-401/408 的选词部分 | `#pron-page-401-picker` |
| PAGE-402 计划/结果 | 单词标题 + 紧凑控件；下方继续显示释义、用法 | CAP-401～404 / DATA-401～404 / AC-401～409 | `#pron-page-402-plan`、`#pron-page-402-result` 内 `[data-entry]` |
| PAGE-403 已保存文章 | 单词标题 + 同款控件；原上下文释义、用法保持 | 同上 | `#pron-page-403-library .resource-grid [data-entry]` |
| 每词播放组 | 图标 + 主状态/动作 + 小字来源/口音；有两个真实可用口音才出现右侧菜单段 | CAP-402/403/404 | `[data-pron-control]` |
| 加载、失败和恢复 | 原按钮原位换图标表现/文字；重试、继续播放和显式口音替代都使用原按钮 | AC-403～406 / CR-314 | `[data-pron-play]`、`[data-pron-label]`、`[data-pron-caption]` |
| 口音菜单 | 紧贴所属控件右下方，不改为手机底部面板 | CAP-403 / AC-404 | `.pron-menu` |

不在释义下增状态行，不显示跨词播放器或通知。读屏播报节点也在对应控件内。播放图标不独立成为第二个操作目标。

## 设计表达与真源

每词控件固定高度和宽度，主状态与辅助来源在按钮内上下排布；不同状态不改变词卡高度。播放使用轻微图标脉动和浅绿底，失败使用浅暖色与明确的重试文字。未知口音标为英语；已知口音使用实际资源标签。切换到浏览器时原控件显示浏览器来源，不额外加提示卡。

- 布局、颜色、尺寸和动效真源：[theme.css](theme.css)。本控件主按钮为 120×44px，可用双口音才增加 44px 菜单段；正文/词义沿既有基线。
- 精确中英文文案：[copy.json](copy.json)。`pron.compact.*` 为控件内短文案；`pron.status*`、`pron.playWord/replayWord/chooseAccent` 为包含目标词的完整可访问名称/说明。标题说明只补充细节，可见状态本身足以操作。
- 动态 `{word}` 对应 DATA-401 当前原词；缺词不渲染控件。`{source}` 和 `{accent}` 来自当前实际路径/资源；未知口音不补造英美标签。变量经文本转义。原型固定词不是生产配置。
- 图标在 [controller.js](controller.js)，实现映射现有 AppIcon 的 volume/chevron/check。继承共享主题内已有字体，无新图片/外部字体。
- 状态、取消和 Motion：[interactions.md](interactions.md)；窄屏、键盘和读屏：[responsive-accessibility.md](responsive-accessibility.md)。

## 打开与复现

产品仓库根目录运行 `python3 -m http.server 4175 --bind 127.0.0.1 --directory .planning/milestones`。目前服务已运行。正式设计入口为 <http://127.0.0.1:4175/M002/design/pronunciation/formal/?page=result&lang=zh>；交互原型为 <http://127.0.0.1:4175/M002/design/pronunciation/prototype/>。两者用途不同，前端布局以正式稿为准。

| 场景 | 参数或入口 | 观察 |
|---|---|---|
| 选词移除验证 | `formal/?page=picker&lang=zh` | 完整工具台，搜索/已选词无发音 |
| 计划词义 | `formal/?page=plan&lang=zh` | 六个词的就地控件 |
| 生成完成 | `formal/?page=result&lang=zh` | 四段短文、六词释义、紧凑控件 |
| 已保存文章 | `formal/?page=library&lang=en` | 既有文章与学习卡 |
| 降级及异常 | 上述入口加 `scenario=fallback|gesture|unavailable|accent` | 点词播放；口音失败场景点 gentle；原位继续/重试 |
| 双口音菜单 | 加 `menu=1` 或点 gentle 右侧菜单 | 菜单贴控件；键盘上下键/Escape |
| 长词布局 | `page=plan|library&lang=en&longwords=1` | communication/pronunciation 压力样例，仅替换设计目标词，不代表文章真实用法 |
| 交互原型 | `prototype/?lang=zh` | wander 词典、gentle 浏览器回退、steady 失败；不冒充完整产品页 |

正式稿读取共享 `M003/design/fixtures/ui13-r3-bookshop.json` 的最后一个 `generation.validated` 结果，文章与释义来自已有样例，切换界面语言不重写样例内容。等待 `#app:not([aria-busy])`；布局取动画稳定帧。底部演示面板默认收起，不进入产品。所有延时仅为状态演示，没有实际音频/API。

## 实现约束与验收

保留既有稳定验收 ID，以下是本版有效规则。

| ID | 必须结果与来源 | 检查与充分证据 |
|---|---|---|
| UIA-M003-439 | PAGE-401 没有播放/口音/语音状态，选词语义保持；CR-314 覆盖旧正向规则 | 搜索与已选区域负断言；产品实现再验添加/删除 |
| UIA-M003-440 | PAGE-402 计划、结果和 PAGE-403 每个词一个紧凑控件，正确绑定目标 | 三处数量/名称/点击目标；同词控件结构复用 |
| UIA-M003-441 | 词典成功不启浏览器；不可用时有限地回退一次并显示真实来源 | 设计状态验证；真实 adapter 序列待技术/实现 |
| UIA-M003-442 | 只有真实可选口音；选定口音失败不能静默改用另一口音 | 单/双/未知 fixture；原按钮显式替代；菜单局部锚定 |
| UIA-M003-443 | 全页只一条活动播放；跨词取消、晚到隔离、同词从头重播、离页/组件移除取消 | 设计跨词和重播序列；真实取消需实现证据 |
| UIA-M003-444 | 无声音/手势/失败有有限终态；原按钮重试或继续，无永久加载 | 五种演示状态；真实时间界限由 OPEN-403 定义 |
| UIA-M003-445 | 游客/普通/付费免费，不扣造文次数，不触发模型 | 后续权益/请求/额度证据；设计不增升级入口 |
| UIA-M003-446 | 发音不阻塞生成、保存、阅读，不改文章/释义/配置，不存永久记录 | 产品实现并发与应用模型检查 |
| UIA-M003-447 | 当前词可访问名称；polite 仅在控件内；菜单键盘与回焦；触控≥44px | 键盘操作、DOM 与 bounds；减少动效 |
| UIA-M003-448 | 基线完整页面、词义与学习卡保持；长词可换行；无横溢 | 1440/390 代表截图和 320 长词检查；字体抗锯齿非硬门槛 |
| UIA-M003-449 | 真实许可、网络/音频、设备需独立证据 | OPEN-401～403；设计演示不能充当 |
| UIA-M003-450 | 不扩大正文、explore、后台、复习、全文/短语朗读范围 | 使用处清单/负断言 |
| UIA-M002-451 | 所有播放状态及后续操作都在本词控件内，切换不撑开卡片 | 原位 state/caption、无外部状态节点；同视口卡片 bounds 前后变化小于 0.01 CSS px，仅容纳浮点舍入，不允许可见位移 |

实现可以复用组件/调整 DOM，不得另造状态面板、改精确文案、删词义用法或用实验台替换正式界面。

## 自检与未决事项

当前浏览器报告：[M002-UI-32-R1-browser.json](evidence/M002-UI-32-R1-browser.json)，复现脚本及四张代表截图同目录。检查当前正式稿四种页面、中文/英文界面、1440/390、局部状态/恢复、取消/重播、键盘、320 长词与 reduced motion。记录首次失败及诊断，汇总 18/18 通过（run-02 的 17 项通过，加唯一待定触控 bounds 项的定向复验），无页面/请求错误，无外部提供方请求。4 张代表截图已实际目视。

真实音频/网络/声学质量/许可、设备语音和生产取消仍未验证：OPEN-401 backend-alex，OPEN-402 backend-alex + frontend-bob，OPEN-403 frontend-bob。没有需要重问用户的交互假设。发音产品代码及已验收 CR313/UAT 不在本次设计修改中。新版待审，后续交接从本规格和 CR-314 读取，不拼接旧稿。
