# M002-UI-32-R1 交互与 Motion

有效范围以 [design-spec.md](design-spec.md) / CR-314 为准。所有状态在 `[data-pron-control]` 内更新；没有 `.pron-status-slot`、独立状态卡、全局播放器。PAGE-401 不参与播放。

| 状态 / 触发 | 原按钮表现（copy.json 键） | 下一动作 |
|---|---|---|
| idle | `pron.compact.play`，辅助实际口音/英语 | 点击准备当前词 |
| preparing | `pron.compact.preparing`，图标轻微脉动 | 成功进入播放；有限失败/手势终态；新词取消本次 |
| playing | `pron.compact.playing`，辅助实际来源/口音 | 同词点击从头重播；其他词取代；结束进入 complete |
| complete | `pron.compact.replay`，保留实际来源 | 点击重新播放 |
| error | `pron.compact.retry` + `pron.compact.unavailable` | 原按钮重试，不增第二个按钮 |
| gesture | `pron.compact.continue` + `pron.compact.gesture` | 原按钮再次手势播放；不自动无限重试 |
| accent | `pron.compact.useUS` + `pron.compact.ukUnavailable`（设计代表例） | 用户点击原按钮明确改用可用美音；不静默替代 |

口音失败的英→美只是设计 fixture。产品必须从技术确认的实际可用资源产生对应文案/可选项；无替代资源则进入 error。显示英美标签必须有真实来源依据；未知英语声音仅标英语。词典→浏览器回退在原控件辅助文本切换来源，完整说明用于该按钮 title/读屏名，不另开提示。

同页播放只有一个拥有者。新词/同词重播会取消上一请求和声音；晚到结果不能抢播。旧控件回 idle，取消文案不留在其他词或页面。离页、对应词条移除或计划区域替换要取消真实音频/语音；原型用序号和定时器模拟，页面卸载清理。生产中止语义仍由技术实现验证。

有至少两个可用口音时显示菜单段；点击或 Enter/Space 展开并聚焦当前项；上下键、Home/End 移动；选择后更新当前项并播放、焦点回原播放按钮。Escape 关闭并回菜单触发器；外点和焦点离开关闭。菜单始终锚定当前控件，不转成移动底部面板。

主控件尺寸不随状态变化，不动画卡片高度。颜色 160ms，图标 920ms 轻微脉动，菜单 180ms 淡入/小位移，缓动见 theme.css。输入/目标切换即时生效；状态变化不排队，不逐字播报，不改变焦点位置。prefers-reduced-motion 停止脉动和过渡，仍保留状态文字。

确定性演示准备 420ms，播放 1800ms；仅便于检查，不是产品性能或超时承诺。真实等待上限、voices 延后和手势链由 OPEN-403 设计。原型无音频与网络提供方调用。
