---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: awaiting_user_review
result: cr020_implemented_pending_qa
---

# 前端实施计划

## 已确认基础与当前任务

[TRANSITION-M002-045](../reviews/verification-rework-045.md)授权[CR020/F17](../changes/CR-020.md)修复，输入[QA17交接](../handoffs/verification.md)及PRODUCT03/UI22/H01/FE02。菜单外部点击/焦点移出关闭、Escape回头像、选择分区后聚焦标题都是批准交互，无新的语义假设。

**持续授权（2026-09-28）**：用户明确“前端相关实现问题一律批准”。后续已确认需求内的前端实施、修复及必要验证直接执行，不逐项重复请求批准；产品范围变化仍交相应角色确认，开发自检不替代独立QA或最终UAT。

FE2-R20（implemented_pending_qa）：补齐共享AppHeader的关闭与焦点处理，保持四入口文案/顺序/资源、原生展开与路由。利用Nuxt已完成渲染后的route同步落焦；同页选择也可落焦，保留Ctrl/Meta等浏览器链接行为。只操作已存在的右侧标题，不增加新控件或API。

## 所有权、顺序及风险

frontend-claire单工作区串行。单一共享组件与直接行为验证紧密相关，无并行收益，不新建worktree、不委派、不清理任何现有改动。风险low：界面事件/焦点，不改身份数据、账务、契约或持久化。

所有权：AppHeader.vue、新增account-menu.test.ts、本角色三份当前文档及frontend-cr020证据。先保存原件/保护摘要，再实现和针对实际失败的组件测试，随后修改文件lint/格式、全项目类型、隔离生产构建和双语桌面/手机四分区浏览器验证；先核对代表区域再覆盖其余入口。其他应用和全部专业/控制原件保持。

## 基线与接续

frontend-cr019的282源文件匹配，QA17的85份原证据匹配；[inputs](evidence/frontend-cr020/inputs.json)、[改前归档](evidence/frontend-cr020/before-owned.tar.gz)可恢复。CR001沿042、CR002/019沿044及其他旧限定关闭保持。CR020需修复后独立复验；QA17整体FAIL及[剩余覆盖](../verification/coverage-matrix.md)、UAT未执行、CR039-L1、CR042-L1、AI-QUALITY-90、历史W01保留。

04:00、本机草稿、基础/体验分账、90天及USER-COMPAT-001/USER-CLAIM-DELETE-001不变。不改控制面、不提交/部署/调用真实AI，仅停止自建服务。开发完成条件是相关检查通过、证据与源码对应及前端交接可复验；不以本计划改变阶段或宣布QA通过。

开发完成：7项组件行为测试、修改文件lint/格式、全项目类型、隔离生产构建及8组双语手机/桌面四分区原型对照全部通过，运行告警/错误0，自建服务停止。[验证报告](frontend-validation.md#cr020)和[交接](../handoffs/frontend-implementation.md)提供源码、构建与复验入口。
