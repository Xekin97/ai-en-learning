---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: awaiting_user_review
result: cr020_implemented_pending_qa
date: 2026-09-28
---

# 前端实施与开发验证

**CR020/F17菜单交互已修复，目标开发自检通过，待独立QA。** 当前实施授权为[045](../reviews/verification-rework-045.md)；用户本轮明确“前端相关实现问题一律批准”，同一已确认范围的前端修复/验证不再逐项请求批准。开发结果不替代独立QA或UAT；正式状态以控制面为准。

<a id="cr020"></a>
## 当前返工：CR020 / FE2-R20

依据[CR020](../changes/CR-020.md)、CAP209/D2-77、UI22/H01 NAV11及FE02，在[AppHeader.vue](../../../../frontend/app/presentation/components/AppHeader.vue)补齐共享头像下拉：点击外部或focusin移出关闭；Escape关闭后聚焦summary；选择个人分区后等待Nuxt目标route完成渲染，再聚焦既有`.account-content h1`，设置tabindex=-1而不增加顺序停靠点。同一分区重复选择也落焦，Ctrl/Meta/Shift/Alt等修饰点击保留NuxtLink原生导航语义，卸载移除document监听。

只有一个生产组件变化，新增[组件行为测试](../../../../frontend/tests/unit/account-menu.test.ts)。四项文案/图标/顺序、CSS、账号数据、权限和API均未改。未把此修复扩展为全站导航重构或新增状态平台。

### 设计接收与转换

读取UI22交互/响应式、prototype/app.js的header、accountShell、render及click/focusin/Escape处理、theme.css的account-dropdown/account-popover及copy.json四项文案；实际在生产浏览器与批准原型中执行同条件操作。继续复用已有SVG与文案转换。Nuxt4.5.2本地路由实现用于核对目标route与完成渲染的时机，不新增外部依赖。

| 检查 | 开发结果与原始证据 |
|---|---|
| 组件测试 | [unit](evidence/frontend-cr020/unit.log)：7项通过。内部/外部焦点、外部点击、Escape恢复、异步页面/同页选择落焦、Ctrl/Meta点击不移动当前页焦点、其他路由胜出时清除待落焦意图 |
| 静态检查 | [checks](evidence/frontend-cr020/checks.json)：修改文件ESLint/Prettier及全项目Nuxt类型检查通过；没有依赖层变化，不机械复跑无关全量检查 |
| 生产构建 | [build](evidence/frontend-cr020/build.log)通过；[位置](evidence/frontend-cr020/build-location.json)与[444份编译摘要](evidence/frontend-cr020/build-source.json)可供独立QA复用 |
| 浏览器交互 | [8组PASS](evidence/frontend-cr020/browser-results.json)：Chromium/WebKit × 中英 × 320/1440。生产与UI22原型各执行四项菜单顺序/完整键盘遍历、Enter/Space、Escape回头像、外部点击、焦点离开、四个分区及当前页重复选择后的标题焦点和aria-current。WebKit采用Alt+Tab访问链接 |
| 异步渲染 | 每组生产成长GET延迟300ms，标题出现后落焦仍正确；未替换API返回结构，也未用任意长sleep冒充就绪 |
| 视觉 | [visual-check](evidence/frontend-cr020/visual-check.json)：人工核对中320 WebKit与英1440 Chromium的菜单成对截图；四项SVG、文案、面板大小/间距/对齐保持。合成昵称不同，未宣称整页像素等价 |
| 环境与清理 | [runtime](evidence/frontend-cr020/runtime.json)：当前生产Nuxt+既有契约mock+批准原型。全部样本warning/error/pageerror为0，四个自建服务停止，provider0；没有新Go/DB、真机或人工读屏结论 |

[源码283文件](evidence/frontend-cr020/source.json)、[源码归档](evidence/frontend-cr020/frontend-source.tar.gz)、[差异](evidence/frontend-cr020/source-diff.patch)、[复现说明](evidence/frontend-cr020/README.md)、[manifest](evidence/frontend-cr020/manifest.json)绑定当前修复。没有修改或覆盖QA17的失败证据。

<a id="cr019"></a>
<a id="cr017"></a>
<a id="cr018"></a>
<a id="cr016"></a>
<a id="cr014"></a>
<a id="cr015"></a>
<a id="cr012"></a>
<a id="cr010"></a>
<a id="cr009"></a>
<a id="cr008"></a>
## 历史返工与接续边界

CR019编辑图标沿[原开发证据](evidence/frontend-cr019/manifest.json)及QA16独立复验，由044限定关闭；CR002也沿044、CR001沿042、CR017/018与FE2-R16-W1沿041、CR016及更早限定关闭保持。当前CR020仍OPEN、implemented_pending_qa。QA17整体FAIL和完整剩余覆盖、最终UAT未执行、CR039-L1、CR042-L1、AI-QUALITY-90、历史未定位W01保持。

改前AppHeader和三份前端正文存[before-owned](evidence/frontend-cr020/before-owned.tar.gz)，旧锚点保留。原CR019的三份当前文档可按原hash恢复，其余43份证据原样保留；QA17全部85份、后端、批准源、旧CR及实施期间控制面不变。单工作区串行，无委派/运行时换模/提交/部署，新会话交接实验未执行，input/token unknown。以下全量开发证据只证明各自原版本和声明范围。

## 交付范围与继承

已实现 FE2-I01–05：首页叠卡与动画、精选完整预设与语言筛选、普通/固定配置造文台、登录注册及游客承接、可改标题的个人书架、按日期和单篇复习、本机草稿及可修改概览、临时答案总结、个人四视图、签到/手动领奖/四类道具/兑换、消息及欢迎反馈、后台八模块。后台保留模型增改启停移除、四基础计划全字段和优先级、用户搜索/学习记录/密码/基础权益调整，消息管理独立。

实现入口为 [frontend/app](../../../../frontend/app)、[运行说明](../../../../frontend/README.md)。沿用 [49 CAP / 25 PAGE / 28 视图映射](../technical/frontend-traceability.json)，不另改上游编号或批准语义。[路由静态核验](evidence/frontend-route-coverage.json) 无缺失，静态存在不冒充行为通过。原有范围复习与认证的生命周期、游标、额度、UTF-16 span 测试继续保留；M001 精确文案、CSS 数值及旧判分协议由 UI22/M002 替代，旧测试原路径保留，继承对应关系见 [浏览器回归索引](../../../../frontend/tests/e2e/README.md)。

关键边界：答案只在本浏览器 IndexedDB，身份/会话/attempt 隔离；提交之前不调用判分。comparison 不进 SSR、持久层或重试回执。积分/经验十进制字符串；签到自动，成就/级奖手动；基础与体验额度读取独立事实。普通/预设生成与管理员预览各用真实契约；预览无用户额度补丁。运营初始空配置不导入原型价格、等级奖励或库存。北京时间 04:00 和滚动额度由后台决定。

## 设计接收与工程转换

设计真源：[UI22/H01](../handoffs/uiux.md)、[M001 差异 FDE-01–09](../design/frontend-delta.md)、copy.json、theme.css、prototype 源文件。`scripts/sync-design.mjs` 转换 1364 条双语静态/模板文案，转义 i18n 的 `@`/`|`，生成 Lucide 及继承图标和两篇固定公共样文；保留资源许可证。工程补充 CSS 只处理真实表单、布局边界、键盘焦点、读屏和状态。

[转换核验](evidence/frontend-design-conversion.json)：重复生成结果逐字节一致；静态 copy/show 调用无缺失文案键。输入 hash 在 [source-manifest](../../../../frontend/design/source-manifest.json)。未升级依赖或导入运营 fixture 到生产。

代表区域检查包含中英首页、普通生成、短文详情、手机复习结果、成长/道具、后台模型/计划/用户/运营/消息/预设及登录。先核对内容顺序/状态，再检查断点、表单与横向溢出。当前开发截图位于 evidence/frontend-*.png。截图中操作后的淡入中间帧、滚动后离屏 skip-link 在 fullPage 合成中的位置，不作为静态设计基准；最终定态图另存 frontend-visual-final-*。没有以更新截图掩盖业务差异。

## 此前整体检查及适用版本

所有命令在产品根目录运行；Node24 调用前缀为 `npm exec --yes --package=node@24 -- pnpm --dir frontend`。未创建提交，交付版本见 [最终 manifest](evidence/frontend-final-manifest.json) 与 [源码快照](evidence/frontend-source.tar.gz)。64 项全量与真服务/三引擎之后只有用户积分 label helper 和 #points 入口增量，最终 8 项后台回归覆盖该差异；未机械重跑无关测试。

| 检查 | 原始证据 | 结果/范围 |
| --- | --- | --- |
| 单元与契约 | [unit-final](evidence/frontend-unit-final.log) | 27 文件、289 项通过；含严格 envelope、字符串大数、保存行映射、预览 token、SSE 终态和继承生命周期 |
| TypeScript | [typecheck-handoff](evidence/frontend-typecheck-handoff.log) | 通过；最终用户积分来源 label 和 hash 入口也完成类型检查 |
| ESLint | [lint-handoff](evidence/frontend-lint-handoff.log) | 通过，包括最后增量 |
| 边界 | [boundaries-final](evidence/frontend-boundaries-final.log) | 241 模块、270 依赖，无违规 |
| 格式 | [format-handoff](evidence/frontend-format-handoff.log) | 通过，包括最后增量 |
| 生产构建 | [build-handoff](evidence/frontend-build-handoff.log) | 成功，包含最终 hash 入口；构建体积 5.01 MB / gzip 1.2 MB（不等于首页下载量） |
| 桌面/手机业务 E2E | [e2e-final-1](evidence/frontend-e2e-final-1.log) | 64 项通过，针对生产构建；后续仅用户积分文案 helper 与 hash 入口改动，目标回归单列 |
| 后台补充回归 | [admin-core-handoff](evidence/frontend-admin-core-handoff.log) | 8 项通过，含桌面/手机直接 #points 入口与无 hydration 错误 |
| 真实 Go / SQL / 浏览器 | [real-smoke-final-2](evidence/frontend-real-smoke-final-2.log) | 八模块 DTO、原子级别配置、独立预览发布、访客生成注册承接、改标题、复习提交/刷新、个人及日期页面通过；当次本地模型调用 2，真实 AI 调用 0 |
| 跨引擎与 Axe | [browser-matrix-final-2](evidence/frontend-browser-matrix-final-2.log) | Chromium / Firefox / WebKit 全通过；每引擎 9 宽度、15 私有路由；无 serious/critical Axe 项、无 pageerror |
| 工作区保护 | [protection-final](evidence/frontend-protection-final.json) | 5106 个受保护文件无变化/缺失；后端、批准设计/API及控制面保留 |

真实联调是独立临时 PG18、Go 服务、生产 Nuxt 和同源本地代理，不是生产 Nginx/Linux。初始成长未启用时后台按既定契约返回 503；测试库配置首级和已生效签到规则后显式 activate-growth。模拟供应商始终绑定 loopback，未使用真实模型密钥。重现和停服入口见 frontend README；私有临时凭据不进入快照。

## FE2-V01–20 证据定位与验证边界

| 验收 | 已有开发证据 | 仍由独立 QA/运行环境验证 |
| --- | --- | --- |
| V01–02 | strict-contracts、quota/span/token/private-state 等 unit；SSR 两身份隔离 browser；边界检查 | 更大并发、生产缓存与策略配置 |
| V03–05 | 半填/错误/空题、随时概览修改、一次总结、重来、刷新恢复确认、两标签 CAS、超长粘贴、丢响应 GET 收据；实际 API 提交 | 本轮存储定向开发检查见 CR-005；独立 QA、真机 IME/软键盘、BFCache、删除重放全矩阵 |
| V06 | SSE parser/reducer/lifecycle unit；普通/预设/管理员独立流 browser/真服务 | 生产代理中断、负载和浏览器后台挂起组合 |
| V07–08 | 中英认证往返意图、错误重试、注销双确认、注册 claim、六统计/标题/日期预览与错误保留；原有范围 lifecycle unit | 超长真实库连续滚动、全量人工流程与各种输入法 |
| V09 | 大数字显示、手动领奖、整份奖励、计划覆盖确认、下架价变化必须重新预览 browser；后台分账真实 API | 各类卡组合/过期跨 04:00 的完整业务矩阵与运营数据验收 |
| V10–11 | 八后台模块；模型影响确认、计划冲突/优先级交换、正数补分/base 重置、只读库；预设完整分页/语言/独立预览/发布/取消 | 多管理员更长并发、真实大数据与运营流程走查 |
| V12–15 | 欢迎 10s/300ms/24px、对话框 top layer、消息净化与翻页；首页自动切换/人工停止/reduce；断点/三引擎检查记录 | 人工读屏、真实移动端、浏览器 200% 缩放、全部 UIA 逐态设计验收。字号放大探测不冒充真实 zoom |
| V16 | 空样本/观察中/不可用/0/延迟分支；事件白名单/同 ID 重试与页面去重，无私有 Clarity 脚本 | 真实渠道、历史留存和 90 天运行数据 |
| V17 | 同源生产构建、静态资源、cookie/locale、no-store、实际后端成套读取 | Nginx/CSP、Linux 部署、旧标签维护提示及回滚演练 |
| V18–20 | 管理原始双语/null/codepoint/plaintext；六档/隐藏脏行/422 行定位/一次整体保存；管理员独立选项与缺凭据/503；真实多行等级写入 | 产品/质量角色对全部并发/失败分支的独立验收；开发结果不自动关闭 CR004 的运行验收 |

## 故障经验和未决事项

保留全部 frontend-* 原始失败日志。开发服务未刷新新路由导致首次 404，重启后恢复；表单 `type=number` 使 v-model 成为 number，时长解析已兼容 string/number；原生 fieldset 最小宽度造成移动表格越界，已约束最小宽度；表格滚动区已加键盘焦点。未知写入先 GET，对新建对象不按名称猜 ID，不自动重放。生产编译可以接受的模板内类型断言曾被 formatter 拒绝，已提取为脚本 helper。

跨引擎测试必须等页面资源和过渡稳定再检查静态几何/对比度。快速连续硬导航会中断 Nuxt 的异步 middleware 预取，Firefox 将其记录为旧页面 import 错误；原始日志保留，测试等待 networkidle 后再切换尺寸/页面，不过滤 pageerror。

CR001已由042按原继承范围关闭；CR002/019仍OPEN，待质量角色复验标题图标及完成接收；CR039-L1、CR042-L1、AI-QUALITY-90 保留原状态。没有真实 AI 新评测、部署、正式数据迁移或自动阶段推进。尚未执行新会话交接测试；静态链接/保护检查不能冒充独立接收验收。
