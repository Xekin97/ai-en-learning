<script setup lang="ts">
import type { AppFailure, ModelProtocol } from "@application/shared/models";
import type { ModelRemovalImpact } from "@application/admin/configuration";
import {
  modelDraft,
  modelConfiguration,
  needsConnectionKey,
  type EditableModel,
} from "@application/admin/model-draft";
import { mergeEdited } from "@application/admin/growth-drafts";
import { normalizeFailure } from "@application/shared/failure";
definePageMeta({ middleware: "admin", layout: "admin" });
const admin = useAdminStore(),
  { copy } = useDesignCopy(),
  session = useSessionStore();
const modelOpen = ref(false),
  discardOpen = ref(false),
  testing = ref(false),
  testMessage = ref("");
const form = reactive(modelDraft());
const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v));
const baseline = ref(clone(form)),
  unknownCreate = ref(false),
  conflicted = ref(false);
const failure = shallowRef<AppFailure | null>(null),
  impact = shallowRef<ModelRemovalImpact | null>(null);
const busy = computed(
  () =>
    admin.state.value.status === "saving" ||
    admin.state.value.status === "loading",
);
const models = computed(() =>
  admin.state.value.models.filter((m) => !m.retiredAt),
);
const keyRequired = computed(() =>
  needsConnectionKey(form, admin.state.value.connections),
);
const protocolKey = (p: ModelProtocol) =>
  ({
    openai_chat: "chat",
    openai_responses: "responses",
    anthropic_messages: "anthropic",
  })[p];
let testEpoch = 0;
await usePageLoader("admin-models", () => admin.loadModels());
useLocalizedHead("admin.models");
function openModel(model?: EditableModel) {
  failure.value = null;
  testMessage.value = "";
  testing.value = false;
  testEpoch++;
  Object.assign(form, modelDraft(model, admin.state.value.modelRevision));
  baseline.value = clone(form);
  unknownCreate.value = false;
  conflicted.value = false;
  modelOpen.value = true;
}
function selectConnection() {
  const c = admin.state.value.connections.find(
    (c) => c.id === form.connectionChoice,
  );
  if (c)
    Object.assign(form, {
      connectionName: c.name,
      protocol: c.protocol,
      baseUrl: c.baseUrl,
      apiKey: "",
    });
}
function discardModel() {
  testEpoch++;
  testing.value = false;
  testMessage.value = "";
  form.apiKey = "";
  baseline.value.apiKey = "";
  modelOpen.value = false;
  discardOpen.value = false;
}
function closeModel() {
  if (busy.value) return;
  if (JSON.stringify(form) !== JSON.stringify(baseline.value))
    discardOpen.value = true;
  else discardModel();
}
function validForm() {
  return (
    (
      document.getElementById("model-form") as HTMLFormElement | null
    )?.reportValidity() ?? false
  );
}
async function testConnection(model?: EditableModel) {
  if (testing.value || busy.value || (!model && !validForm())) return;
  const epoch = session.epoch.value,
    token = ++testEpoch;
  testing.value = true;
  testMessage.value = "gm.testing";
  failure.value = null;
  try {
    await admin.testModelConnection(
      modelConfiguration(
        model ? modelDraft(model) : form,
        admin.state.value.connections,
      ),
    );
    if (token === testEpoch && epoch === session.epoch.value)
      testMessage.value = "gm.test.ok";
  } catch (error) {
    if (token !== testEpoch || epoch !== session.epoch.value) return;
    const problem = normalizeFailure(error);
    testMessage.value =
      (
        {
          model_connection_auth: "gm.testing.auth",
          model_connection_protocol: "gm.testing.format",
          model_connection_rate_limited: "gm.rate",
          credential_missing: "gm.missingkey",
        } as Record<string, string>
      )[problem.code] ?? "gm.test.fail";
  } finally {
    if (token === testEpoch) testing.value = false;
  }
}
async function refreshDraft() {
  const epoch = session.epoch.value;
  await admin.loadModels();
  if (epoch !== session.epoch.value || admin.state.value.failure) return;
  if (form.modelId) await admin.ensureModels([form.modelId]);
  const remote = admin.state.value.models.find((m) => m.id === form.modelId);
  if (form.modelId && !remote) return;
  const current = modelDraft(remote, admin.state.value.modelRevision);
  Object.assign(form, mergeEdited(baseline.value, clone(form), current), {
    expectedRevision: current.expectedRevision,
  });
  baseline.value = clone(current);
  conflicted.value = false;
  failure.value = null;
}
async function saveModel() {
  if (busy.value || unknownCreate.value || conflicted.value) return;
  const epoch = session.epoch.value;
  try {
    await admin.saveModelDraft({
      ...modelConfiguration(form, admin.state.value.connections),
      modelId: form.modelId,
    });
    if (epoch !== session.epoch.value) return;
    discardModel();
    await admin.loadModels();
  } catch (error) {
    if (epoch !== session.epoch.value) return;
    failure.value = normalizeFailure(error);
    conflicted.value = failure.value.code === "revision_conflict";
    if (
      !form.modelId &&
      (failure.value.status === null || (failure.value.status ?? 0) >= 500)
    )
      unknownCreate.value = true;
  }
}
async function remove(model: { id: string }) {
  failure.value = null;
  impact.value = await admin.previewRemoval(model.id);
}
function closeRemoval() {
  if (busy.value) return;
  if (impact.value) admin.clearRemoval(impact.value.model.id);
  impact.value = null;
}
async function confirmRemoval() {
  if (!impact.value) return;
  try {
    await admin.removeModel(impact.value.model.id, impact.value.revision);
    closeRemoval();
    await admin.loadModels();
  } catch (error) {
    failure.value = normalizeFailure(error);
  }
}
watch(
  () => JSON.stringify(form),
  () => {
    testEpoch++;
    testing.value = false;
    testMessage.value = "";
  },
);
watch(session.epoch, () => {
  discardModel();
  impact.value = null;
  failure.value = null;
});
onBeforeUnmount(() => {
  discardModel();
  if (impact.value) admin.clearRemoval(impact.value.model.id);
});
</script>
<template>
  <div>
    <div class="page-head">
      <div>
        <h1>{{ copy("gm.title") }}</h1>
        <p>{{ copy("gm.subtitle") }}</p>
      </div>
      <button class="btn primary" :disabled="busy" @click="openModel()">
        {{ copy("gm.add") }}
      </button>
    </div>
    <AppError :failure="admin.state.value.failure" />
    <p v-if="testMessage && !modelOpen" class="notice" role="status">
      {{ copy(testMessage) }}
    </p>
    <section class="generic-model-list" :aria-label="copy('gm.title')">
      <article
        v-for="model in models"
        :key="model.id"
        class="generic-model-row"
      >
        <div class="generic-model-symbol"><AppIcon name="bot" /></div>
        <div class="generic-model-copy">
          <div class="generic-model-title">
            <h2>{{ model.displayName }}</h2>
            <span class="pill">{{
              copy(model.enabled ? "gm.active" : "gm.inactive")
            }}</span>
          </div>
          <code>{{ model.connection.name }}/{{ model.providerModelId }}</code>
          <p class="generic-model-meta">
            <span>{{ model.connection.baseUrl }}</span
            ><span>{{
              copy("gm." + protocolKey(model.connection.protocol))
            }}</span
            ><span>{{
              model.connection.maskedHint ||
              copy(
                model.connection.credentialConfigured
                  ? "gm.key.configured"
                  : "gm.key.missing",
              )
            }}</span>
          </p>
          <p v-if="model.description" class="generic-model-description">
            {{ model.description }}
          </p>
        </div>
        <div class="generic-model-actions">
          <button
            class="btn quiet small"
            :disabled="busy || testing"
            @click="testConnection(model)"
          >
            {{ copy(testing ? "gm.testing" : "gm.test") }}
          </button>
          <button class="btn small" :disabled="busy" @click="openModel(model)">
            {{ copy("a.edit") }}
          </button>
          <button
            class="btn danger quiet small"
            :disabled="busy"
            @click="remove(model)"
          >
            {{ copy("a.remove") }}
          </button>
        </div>
      </article>
      <div v-if="!models.length && !busy" class="generic-model-empty">
        <AppIcon name="bot" />
        <h2>{{ copy("gm.empty") }}</h2>
        <p>{{ copy("gm.empty.help") }}</p>
        <button class="btn primary" @click="openModel()">
          {{ copy("gm.add") }}
        </button>
      </div>
    </section>
    <button
      v-if="admin.state.value.nextModelCursor"
      class="btn"
      :disabled="busy"
      @click="admin.loadModels(true)"
    >
      {{ copy("a.more") }}
    </button>
    <AppDialog
      id="admin-model"
      :open="modelOpen"
      :title="copy(form.modelId ? 'gm.edit' : 'gm.add')"
      @close="closeModel"
    >
      <AppError :failure="failure" />
      <p v-if="unknownCreate" class="notice warn">{{ copy("gm.unknown") }}</p>
      <div v-if="conflicted" class="notice warn">
        <p>{{ copy("gm.conflict") }}</p>
        <button class="btn" :disabled="busy" @click="refreshDraft">
          {{ copy("gm.refresh") }}
        </button>
      </div>
      <form id="model-form" @submit.prevent="saveModel">
        <fieldset class="generic-model-form" :disabled="busy">
          <label class="field"
            ><span>{{ copy("gm.name") }}</span
            ><input
              v-model="form.displayName"
              name="displayName"
              maxlength="200"
              required
          /></label>
          <label class="field"
            ><span>{{ copy("gm.id") }}</span
            ><input
              v-model="form.providerModelId"
              name="providerModelId"
              maxlength="500"
              required
              :placeholder="copy('gm.id.placeholder')"
          /></label>
          <p class="field-help">{{ copy("gm.id.help") }}</p>
          <label class="field"
            ><span>{{ copy("gm.connection") }}</span
            ><AppSelect
              v-model="form.connectionChoice"
              @change="selectConnection"
              ><option value="new">{{ copy("gm.new.connection") }}</option>
              <option
                v-for="c in admin.state.value.connections"
                :key="c.id"
                :value="c.id"
              >
                {{ c.name }} · {{ copy("gm." + protocolKey(c.protocol)) }}
              </option></AppSelect
            ></label
          >
          <div class="generic-connection-fields">
            <label class="field"
              ><span>{{ copy("gm.provider") }}</span
              ><input
                v-model="form.connectionName"
                name="connectionName"
                maxlength="200"
                :placeholder="copy('gm.provider.placeholder')"
            /></label>
            <label class="field"
              ><span>{{ copy("gm.protocol") }}</span
              ><AppSelect v-model="form.protocol"
                ><option value="openai_chat">{{ copy("gm.chat") }}</option>
                <option value="openai_responses">
                  {{ copy("gm.responses") }}
                </option>
                <option value="anthropic_messages">
                  {{ copy("gm.anthropic") }}
                </option></AppSelect
              ></label
            >
            <p class="field-help">
              {{ copy("gm." + protocolKey(form.protocol) + ".help") }}
            </p>
            <label class="field"
              ><span>{{ copy("gm.url") }}</span
              ><input
                v-model="form.baseUrl"
                name="baseUrl"
                type="url"
                maxlength="2048"
                required
                placeholder="https://api.example.com/v1"
            /></label>
            <p class="field-help">{{ copy("gm.url.help") }}</p>
            <label class="field"
              ><span>{{ copy("gm.key") }}</span
              ><input
                v-model="form.apiKey"
                name="apiKey"
                type="password"
                maxlength="8192"
                autocomplete="new-password"
                :required="keyRequired"
                :placeholder="copy(keyRequired ? 'gm.key' : 'gm.key.keep')"
            /></label>
            <p class="field-help">
              {{
                copy(
                  keyRequired && form.originalConnectionId
                    ? "gm.missingkey"
                    : "gm.key.help",
                )
              }}
            </p>
            <p v-if="form.originalConnectionId" class="field-help">
              {{ copy("gm.changed.connection") }}
            </p>
          </div>
          <details class="generic-model-advanced">
            <summary>{{ copy("gm.advanced") }}</summary>
            <label class="field"
              ><span>{{ copy("gm.output") }}</span
              ><input
                v-model="form.maxOutputTokens"
                type="number"
                name="maxOutputTokens"
                min="1"
                max="1048576"
                step="1"
            /></label>
            <p class="field-help">{{ copy("gm.output.help") }}</p>
            <label class="check"
              ><input
                v-model="form.outputMode"
                type="checkbox"
                true-value="json_schema"
                false-value="prompt"
                :disabled="form.protocol === 'anthropic_messages'"
              />{{ copy("gm.structured") }}</label
            >
            <p class="field-help">{{ copy("gm.structured.help") }}</p>
            <label class="field"
              ><span>{{ copy("gm.description") }}</span
              ><input
                v-model="form.description"
                name="description"
                maxlength="1000"
            /></label>
          </details>
          <label class="check"
            ><input v-model="form.enabled" type="checkbox" />{{
              copy("gm.enable")
            }}</label
          >
          <p v-if="testMessage" class="notice" role="status">
            {{ copy(testMessage) }}
          </p>
          <p class="field-help">{{ copy("gm.test.note") }}</p>
        </fieldset>
      </form>
      <template #footer>
        <button
          class="btn quiet"
          :disabled="busy || testing"
          @click="testConnection()"
        >
          {{ copy(testing ? "gm.testing" : "gm.test") }}
        </button>
        <button class="btn" :disabled="busy" @click="closeModel">
          {{ copy("cancel") }}
        </button>
        <button
          class="btn primary"
          type="submit"
          form="model-form"
          :disabled="busy || unknownCreate || conflicted"
        >
          {{ copy("gm.save") }}
        </button>
      </template>
    </AppDialog>
    <AppDialog
      id="model-discard"
      :open="discardOpen"
      :title="copy('gm.unsaved')"
      @close="discardOpen = false"
      ><template #footer
        ><button class="btn" @click="discardOpen = false">
          {{ copy("gm.keep") }}</button
        ><button class="btn danger" @click="discardModel">
          {{ copy("gm.discard") }}
        </button></template
      ></AppDialog
    >
    <AppDialog
      id="model-removal"
      :open="impact !== null"
      :title="copy('model.remove.title')"
      @close="closeRemoval"
      ><template v-if="impact"
        ><h3>{{ impact.model.displayName }}</h3>
        <p class="notice warn">{{ copy("model.remove.desc") }}</p>
        <AppError :failure="failure" />
        <dl class="admin-facts">
          <div>
            <dt>{{ copy("a.plans") }}</dt>
            <dd>
              <p v-for="group in impact.affectedGroups" :key="group.code">
                {{ copy("a.plan." + group.code) }} ·
                {{ group.remainingEnabledModels
                }}{{
                  group.remainingEnabledModels === 0
                    ? " · " + copy("a.model.last")
                    : ""
                }}
              </p>
              <span v-if="!impact.affectedGroups.length">—</span>
            </dd>
          </div>
          <div>
            <dt>{{ copy("itemsettings") }}</dt>
            <dd>{{ impact.affectedItemDefinitions }}</dd>
          </div>
          <div>
            <dt>{{ copy("bag") }}</dt>
            <dd>{{ impact.affectedOwnedCards }}</dd>
          </div>
          <div>
            <dt>{{ copy("a.presets") }}</dt>
            <dd>{{ impact.affectedPresets }}</dd>
          </div>
        </dl>
        <p class="notice">{{ copy("a.model.removeimpact") }}</p></template
      ><template #footer
        ><button class="btn" :disabled="busy" @click="closeRemoval">
          {{ copy("cancel") }}</button
        ><button class="btn danger" :disabled="busy" @click="confirmRemoval">
          {{ copy("a.remove") }}
        </button></template
      ></AppDialog
    >
  </div>
</template>
