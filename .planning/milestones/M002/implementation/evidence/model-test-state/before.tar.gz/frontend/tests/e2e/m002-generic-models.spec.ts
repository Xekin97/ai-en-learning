import { test, expect } from "@playwright/test";
import { readFileSync } from "node:fs";
import { selectValue } from "./select-control";
const source = JSON.parse(
  readFileSync(
    new URL(
      "../../../.planning/milestones/M002/design/copy.json",
      import.meta.url,
    ),
    "utf8",
  ),
);
for (const lang of ["en", "zh"]) {
  const t = (key: string) => source.static[lang + "." + key] as string;
  test.describe("UI29 " + lang, () => {
    test.beforeEach(async ({ context, request, baseURL }) => {
      await request.post("http://127.0.0.1:38084/api/v1/__test/admin-reset");
      await context.addCookies([
        { name: "wordweave_session", value: "admin", url: baseURL! },
        {
          name: "wordweave_ui_locale",
          value: lang === "en" ? "en-US" : "zh-CN",
          url: baseURL!,
        },
      ]);
    });
    test("configuration, protocol retention, explicit tests, save and secret-safe edit", async ({
      page,
    }, info) => {
      const errors: string[] = [];
      page.on("pageerror", (e) => errors.push(e.message));
      const tests: string[] = [];
      const saves: Record<string, unknown>[] = [];
      page.on("request", (r) => {
        if (r.url().endsWith("/admin/model-connection-test"))
          tests.push(r.url());
        if (r.url().endsWith("/admin/models") && r.method() === "POST")
          saves.push(r.postDataJSON());
      });
      await page.goto("/admin/models");
      await page.waitForFunction(
        () => document.documentElement.dataset.appReady === "true",
      );
      await expect(page.locator(".generic-model-row")).toHaveCount(1);
      await expect(
        page.getByRole("heading", { name: t("gm.title"), exact: true }),
      ).toBeVisible();
      await page
        .getByRole("button", { name: t("gm.add"), exact: true })
        .click();
      const dialog = page.locator("#admin-model"),
        form = page.locator("#model-form");
      await form.locator('[name="displayName"]').fill("Custom service");
      await form.locator('[name="providerModelId"]').fill("Vendor/Exact-ID");
      await form.locator('[name="connectionName"]').fill("Private provider");
      await form
        .locator('[name="baseUrl"]')
        .fill("https://provider.example/custom/v1/");
      await form.locator('[name="apiKey"]').fill("bad-key");
      for (const protocol of [
        "openai_responses",
        "anthropic_messages",
        "openai_chat",
      ]) {
        await selectValue(form.locator("select").nth(1), protocol);
        await expect(form.locator('[name="providerModelId"]')).toHaveValue(
          "Vendor/Exact-ID",
        );
        await expect(form.locator('[name="baseUrl"]')).toHaveValue(
          "https://provider.example/custom/v1/",
        );
        await expect(form.locator('[name="apiKey"]')).toHaveValue("bad-key");
      }
      await dialog
        .getByRole("button", { name: t("gm.test"), exact: true })
        .click();
      await expect(dialog.getByRole("status")).toHaveText(t("gm.testing.auth"));
      await form.locator('[name="apiKey"]').fill("synthetic-browser-key");
      await dialog
        .getByRole("button", { name: t("gm.test"), exact: true })
        .click();
      await expect(dialog.getByRole("status")).toHaveText(t("gm.test.ok"));
      expect(tests).toHaveLength(2);
      await dialog
        .getByRole("button", { name: t("gm.save"), exact: true })
        .click();
      await expect(dialog).not.toBeVisible();
      await expect(page.locator(".generic-model-row")).toHaveCount(2);
      expect(saves).toHaveLength(1);
      expect(tests).toHaveLength(2);
      expect(saves[0]).toMatchObject({
        provider_model_id: "Vendor/Exact-ID",
        enabled: false,
        connection: {
          protocol: "openai_chat",
          base_url: "https://provider.example/custom/v1/",
          api_key: "synthetic-browser-key",
        },
      });
      expect(saves[0]).not.toHaveProperty("is_default");
      const row = page
        .locator(".generic-model-row")
        .filter({ hasText: "Custom service" });
      await row.getByRole("button", { name: t("a.edit"), exact: true }).click();
      await expect(form.locator('[name="apiKey"]')).toHaveValue("");
      await expect(form.locator('[name="apiKey"]')).not.toHaveAttribute(
        "required",
        "",
      );
      const footer = await dialog.locator(".dialog-actions").boundingBox();
      expect(footer!.y + footer!.height).toBeLessThanOrEqual(
        page.viewportSize()!.height,
      );
      await page.screenshot({
        path: `../.planning/milestones/M002/implementation/evidence/generic-models29/edit-${info.project.name}-${lang}.png`,
        fullPage: true,
      });
      expect(
        await page.evaluate(
          () => document.documentElement.scrollWidth > innerWidth,
        ),
      ).toBe(false);
      expect(
        await page.evaluate(
          () => JSON.stringify(localStorage) + JSON.stringify(sessionStorage),
        ),
      ).not.toContain("synthetic-browser-key");
      expect(errors).toEqual([]);
    });
    test("discard confirmation and revision recovery preserve deliberate edits", async ({
      page,
      request,
    }) => {
      await page.goto("/admin/models");
      await page.waitForFunction(
        () => document.documentElement.dataset.appReady === "true",
      );
      const row = page.locator(".generic-model-row");
      await expect(row).toHaveCount(1);
      await row.getByRole("button", { name: t("a.edit"), exact: true }).click();
      const dialog = page.locator("#admin-model"),
        name = dialog.locator('[name="displayName"]');
      await name.fill("Edited name");
      await dialog
        .getByRole("button", { name: t("cancel"), exact: true })
        .click();
      await page
        .locator("#model-discard")
        .getByRole("button", { name: t("gm.keep"), exact: true })
        .click();
      await expect(name).toHaveValue("Edited name");
      await request.post("http://127.0.0.1:38084/api/v1/__test/admin-conflict");
      await dialog
        .getByRole("button", { name: t("gm.save"), exact: true })
        .click();
      await expect(
        dialog.getByText(t("gm.conflict"), { exact: true }),
      ).toBeVisible();
      await dialog
        .getByRole("button", { name: t("gm.refresh"), exact: true })
        .click();
      await expect(name).toHaveValue("Edited name");
      await dialog
        .getByRole("button", { name: t("gm.save"), exact: true })
        .click();
      await expect(dialog).not.toBeVisible();
      await expect(row).toContainText("Edited name");
    });
  });
}
