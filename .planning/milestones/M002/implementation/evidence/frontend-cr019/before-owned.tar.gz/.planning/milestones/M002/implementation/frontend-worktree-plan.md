---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: awaiting_user_review
result: cr017_018_implemented_pending_qa
---

# 前端实施计划

## 已确认基础与当前任务

授权[TRANSITION-M002-039](../reviews/verification-rework-039.md)，接收[QA13](../handoffs/verification.md)、[CR017](../changes/CR-017.md)与[CR018](../changes/CR-018.md)。沿PRODUCT03/UI22/H01/DB03/BE03/FE02、API007、FE2-V02/13/14/17。CR016已由039按F12/F13限定关闭，其保护行为必须保留；当前修复没有新的产品/API/数据库选择。

| 项目 | 状态与验收 |
| --- | --- |
| FE2-R17 / CR017 | implemented_pending_qa；共享dateTime保持北京时间及中英文含义，用明确字段顺序/连接符消除运行时Intl literal差异；WebKit英文直接访问/刷新与三引擎语言对照无水合异常 |
| FE2-R18 / CR018 | implemented_pending_qa；普通失败采用既有l.title.failed，中英文逐字匹配UI22，保留冲突补充、回焦/重试/身份失效与删除保护 |
| 开发验证 | 已执行：32文件333项单元、类型/lint/格式/边界/隔离构建通过；13项标题/日期及14项共享显示有效检查通过，原夹具失败与修正保留 |
| 独立验收 | 未执行；完成后交qa-quinn按CR017/018复验，不由开发关闭CR |

## 所有权、顺序与风险

frontend-claire单工作区串行；两项均影响详情页，同批无需并行worktree或委派。风险high（共享SSR/client格式）。六份原件及受保护摘要已保存，原型/文案核对、修复和相关开发检查已完成。无分支合并或清理。

仅写use-display-formatters.ts、library/[batchId].vue、相关两份单测、本角色三文档和frontend-cr017-018证据。日期修复不增加全局缓存/新依赖/CSR回退，不改存储时刻、学习日、纯日期函数或原copy.json。调用面包括个人壳、道具、通知、后台概览及用户记录，浏览器按实际日期内容回归。先通过代表详情页再检查共享调用面。

## 基线与保留

前端基线frontend-cr016（281文件），后端backend-cr013；源码及文档原件见本轮before-owned和既有源码归档。FE2-I01–05全量实现范围与FE2-I06独立完整验收继续见[验证报告](frontend-validation.md)及[QA矩阵](../verification/coverage-matrix.md)。历史CR014/015沿036、CR012/013沿034及更早关闭保持。

CR001/002/017/018正式OPEN；FE2-R16-W1由CR017承接，未与历史W01合并。CR039-L1、CR042-L1、AI-QUALITY-90、最终UAT、真机/读屏/生产代理/04:00实时时点及完整卡组合仍保留。04:00、本机草稿、基础/体验分账、90天明细、USER-COMPAT-001、USER-CLAIM-DELETE-001不变。

无提交、部署、真实AI或控制面更新；仅停止本次自建服务。新会话交接实验未执行；input/token unknown。

当前交付：[验证报告](frontend-validation.md#cr017)、[证据及夹具说明](evidence/frontend-cr017-018/README.md)、[manifest](evidence/frontend-cr017-018/manifest.json)。下一步通过守门交qa-quinn独立复验两项；开发不关闭CR、不自动推进阶段。
