---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
version: M002-CR029-UI31
status: ready_for_verification
---

# CR029-F05 服务商工作区（UI31）

UIA-PAGE208-PROVIDER：列表以稳定provider ID展示 `.generic-provider-card`，头部连接/数量/编辑，内部全部模型名称/ID/状态/测试/移除。新增服务商直接配置新连接+多个模型；编辑已有服务商填充全部模型，可修改并继续添加，不提供复制已有连接的新增下拉和单模型编辑按钮。

严格DTO→mapper→repository→store贯通新聚合API。页面草稿独占Key，关闭清除；原位模型UUID、单项流式反馈及移除影响确认保持。409按模型UUID三方合并：本地编辑/新项保留，远端新增纳入、下架剔除；POST/PATCH保存结果不明确均阻止重复提交并保留草稿。

39文件372单测、类型/lint/边界257模块283依赖通过。16项中英×1440/390浏览器验收通过：新服务商+多模型保存、整组编辑追加并刷新保持、超过20条全量显示编辑、单项测试隔离、空新项不阻碍其他项测试、取消确认、冲突恢复、最后模型移除仍可编辑空服务商；4项补充未知保存结果保护通过。4项原型交互通过。布局/截图已查看，固定头尾和高级字段间距、服务商层级、无横溢符合UI31。生产构建日志在同目录，QA切换前确认最新完成。

首轮类型发现聚合readonly数组不匹配，改为只读EditableProvider边界并去掉重复自动导出，保留初始日志。浏览器保存使用契约HTTP fixture，真实原子性及角色隔离见后端DB/HTTP证据，不把fixture冒称真实付费服务。原型后补空服务商零条编辑及影响提示；对应实际页面已被空态用例覆盖。QA复用开发检查，补3302实际包与真实配置的两视口验证，测试拦截避免费用。

[evidence/provider-workspace31](evidence/provider-workspace31)；原UI30列表/单模型编辑证据失效，流式传输及未改学习流程证据仍有效。旧文见before-validation.tar.gz。用户UAT未代签。
