---
milestone: M002
stage: verification
role: quality/base
agent_name: qa-quinn
status: ready_for_user_acceptance
version: M002-QA-36
scope: CR029 provider workspace
date: 2026-10-02
---

# CR029-F05 服务商列表与聚合编辑（QA36）

已更新 [3302 模型管理](http://127.0.0.1:3302/admin/models)。服务商是列表和编辑主体：每组一份名称/协议/URL/脱敏Key与模型数量，下方完整展示旗下模型；“添加服务商”配置新连接及模型，“编辑服务商”修改该连接及全部既有模型，并可继续添加新模型。单模型编辑入口和新增时复用连接的下拉已替换。服务商连接修改应用于全组；单模型流式测试和移除影响确认保持。

新旧服务商/模型 UUID 与所有业务引用保留。聚合GET不受旧20条模型分页限制；保存为一个CAS事务，省略已保存模型不代表下架，跨服务商UUID拒绝。不同服务商可以使用同名模型；Key留空沿用、换目标需新Key。创建或修改结果不明时阻止重复提交，409按UUID保留本地修改/新增并加入远端新模型。

- 复用开发证据：Go单元/vet、admin整包集成、定向真实HTTP/DB与迁移检查通过；25→26模型、UUID/计划引用、密钥权限/隔离、事务内晚期失败全回滚、CAS/CSRF均覆盖。39文件372前端单测、类型/lint/依赖边界、生产构建通过；16项中英桌面手机交互和4项未知保存保护通过。4项原型主流程加1项最新空服务商分支通过，代表视觉已核对。
- 本地升级：私有备份恢复至隔离PG并迁移0016，保留ACL、测试owner使用--no-owner；60张业务表全部字段/行数/摘要一致后才切换3302。0016只新增凭据更新函数及服务商内名称唯一索引，原有模型、密文、关联和环境参数保持。[迁移与恢复](../delivery/provider-workspace-3302-20261002/README.md)。
- 实际3302桌面1440/手机390通过：真实账号、1个服务商/3个原模型分组及完整编辑，追加草稿、独立探测加载/结果、取消不保存、新建空表单、固定标题与操作/无横溢。0控制台错误，0原配置写入。探测响应拦截，真正流式解析沿QA35受控HTTP证据；0真实模型收费调用。
- QA36-F01为演练方法问题，已解决：初次--no-acl漏原权限，校验拒绝；第二次原owner review_test在隔离集群不存在，恢复拒绝。两次均未迁移原库并自动恢复旧服务。最终仅--no-owner，保留ACL，重演练通过。初次失败后误启旧版本冒烟得404，属于检查顺序错误，后续等部署PASS才运行；原证据保留于delivery/initial-rehearsal。没有放宽数据库权限校验。

证据：[实现与源码](../implementation/evidence/provider-workspace31/manifest.json)、[部署](../delivery/provider-workspace-3302-20261002/deployment.json)、[真实构建冒烟](../delivery/provider-workspace-3302-20261002/smoke.json)、[QA36](evidence/qa2-036/manifest.json)。UI31 / 0016 / TRANSITION-M002-118，CR029仍待用户验收，本QA不代签。旧QA35当前文已冻结在[快照](evidence/qa2-036/before-current-documents.tar.gz)，未改协议/学习功能证据继续有效，旧列表/编辑证据不证明UI31。

## 保留事项

| ID / 范围 | 现有结论与影响 | 来源、后续动作与完成条件 |
|---|---|---|
| QA26-MINIMAX | 两次启用校验返回 model_incompatible，保持禁用；当时绑定该模型的热门预设不能生成。原因未定位，本轮未重新查询运行状态 | [原失败](evidence/qa2-026/minimax-retry.json)、[配置核对](evidence/qa2-026/final-check.json)。需要恢复该模型时从既有失败定向排查；启用检查与关联预设实际生成通过后才能认定解决 |
| CR039-L1 | safe→safety/safely 被拒，safer 未核实 | [原约束与验收](../../M001/changes/CR-039.md#retained-limitations)。后续明确恢复词形改进时按原样本核验，不自动重启调优 |
| CR042-L1 | 未知标注反馈定位精度、多回复整包回放仍有限制 | [原约束与验收](../../M001/verification/CR-042-generation-evidence.md#retained-limitations)。按实际失败定向处理，未扩展回放平台 |
| AI-QUALITY-90 | 稳定成功率 ≥90% 仍未验证 | [AI 验证范围](ai-evaluation.md)、[一期评估](../../M001/verification/ai-evaluation.md)。需单独明确评测范围与调用授权；本次 UAT 不提供统计证明 |
| W01 | 个人页曾出现未定位的 hydration console 警告，后续定向捕获未复现；未据此宣称修复 | [QA03 原观察](evidence/qa2-003/manifest.json)。再次出现时记录具体页面、堆栈和操作，定位并定向复验 |
| 环境与人工专项 | 生产 SSE 代理、Linux 部署与容量/告警、真实设备输入法/读屏、04:00 实时时点等仍按矩阵保留证据边界 | [矩阵](coverage-matrix.md#api数据与剩余工作)。属于后续对应环境验证；用户整体 UAT 不补写未执行的专项测试 |



原保留项不因本轮修复而消失；开放CR和角色以workflow为准。未执行新会话交接测试，token unknown。
