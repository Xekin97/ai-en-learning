---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: awaiting_user_review
result: cr016_implemented_pending_qa
---

# 前端实施计划

当前授权 TRANSITION-M002-037；PRODUCT03、UI22/H01、DB03、BE03、FE02及后端既有交付保持。consumer-ai-web@1.0.0沿锁定基座，不采用当前框架2.0的Profile替换。当前正式角色frontend-claire，未更改控制面。

## 当前返工：CR016 / FE2-R16

接收[CR016](../changes/CR-016.md)、QA12 F12/F13、AC220、UIA-PAGE-006-03/API007，修复标题保存失败后的焦点与身份失效异步收尾。

| 项目 | 状态与完成条件 |
| --- | --- |
| FE2-R16 实现 | implemented_pending_qa；详情页保存返回后检查epoch和批次，失败解除disabled再回焦，输入/已存值保留 |
| FE2-R16 开发验证 | 7项新增行为测试全过；全量31文件324项单元、类型/lint/格式/边界/隔离生产构建通过；16项真实本地服务浏览器检查通过 |
| FE2-R16 独立验收 | 未执行；由qa-quinn复验503/焦点/显式重试、失效无运行异常/无写入/无假成功，以及409/取消/空白/删除边界 |
| FE2-R16-W1 | 追加观察，未解决；英文日期在WebKit与SSR的Intl格式不同，修改前构建同样复现；交QA确认路由，不与历史W01自动合并 |

证据：[当前验证](frontend-validation.md#cr016)、[复现与失败原件](evidence/frontend-cr016/README.md)、[manifest](evidence/frontend-cr016/manifest.json)。首轮15/16及503夹具头错误保留；v2更正夹具，未改生产代码或放宽console判定。16项覆盖Chromium英1440/中390、Firefox英1440、WebKit中390，不能称WebKit英文无警告。

## 工作区与所有权

修改所有权仅 frontend/app/pages/library/[batchId].vue、新增 tests/unit/library-title-editor.test.ts、本角色三文档和frontend-cr016证据。两问题同属一页异步处理，单共享工作区串行，无worktree、委派、合并或换模；风险high。先保存原件，受保护文件逐摘要核对。后端、批准产品/设计/API、QA12、CR原文和工作流控制面未改；无自动提交/部署/真实AI调用。仅停止自建服务。

## 原实施基线与保留事项

沿[FE02](../technical/frontend.md#delivery) FE2-I01–06 / FE2-V01–20。I01–05已实现壳与首页、普通/预设生成、登录注册承接、书架/按日期复习、本机草稿及概览修改、四个人视图、成长/道具/消息和八后台模块；I06开发检查已完成，独立完整验收仍由覆盖矩阵记录，不能因本次局部通过宣称整体完成。

CR014/015沿036限定关闭，开发原件在frontend-cr014-015；CR012/013沿034，CR011沿031、CR010沿029、CR009沿027、CR007/008沿025、CR005/006沿022保持。原计划/报告/交接在本轮before-owned.tar.gz，历史锚点保留于验证报告。

CR001/002/016正式OPEN；CR001限定关闭仅为QA建议。本轮不关闭CR或推进阶段。CR039-L1、CR042-L1、AI-QUALITY-90、历史W01及新增FE2-R16-W1有待办去向。原FE2-V04/09/13–17的真机、人工读屏、生产代理、04:00/完整卡组合等边界不清空。

有效约束继续保留：M001需求继承、标题单字段/个人可编辑、北京时间04:00、本浏览器草稿、基础与体验分账、90天分析明细、USER-COMPAT-001及USER-CLAIM-DELETE-001。没有新增业务问题或产品重新选型。

下一步通过守门交qa-quinn接收本修复、复验CR016并判定FE2-R16-W1；当前仍implementation/frontend-claire。新会话独立交接实验未执行；input/token unknown。
