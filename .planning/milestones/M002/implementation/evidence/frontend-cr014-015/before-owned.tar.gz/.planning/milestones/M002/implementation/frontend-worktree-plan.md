---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: awaiting_user_review
result: cr012_implemented_pending_qa
---

# 前端实施计划

输入与授权：TRANSITION-M002-016 / 017 / 032，PRODUCT-03、UI-22/H01、FE-02、BE-03 及后端实施交接。当前正式角色 frontend-claire；没有待重选业务问题，不改批准产品、设计、API、后端或控制面。准确原件见 frontend-inputs.json 与 frontend-before.tar.gz。

## 当前返工：CR-012 / FE2-R12

授权 TRANSITION-M002-032，接收 [CR012](../changes/CR-012.md)、QA06 F08、backend-cr013。按 CAP012–014 / PAGE005/006 / UIA-PAGE-005-LIBRARY18 与 FE02，修复详情页返回书架的滚动位置；保留搜索、已加载范围、原行焦点、直接进入及历史后退。无待确认业务假设。

FE2-R12 已实施、开发检查通过，待独立QA。已记录原始失败，在书架路由进入时决定是否接管滚动，避免 Nuxt 的默认页顶滚动覆盖恢复；目标行从路由参数识别，兼容不自动聚焦链接的输入方式。已验证两语言 × 320/390/768/1440px × 页面返回/历史后退，另覆盖标题/详情入口、直接进入、长标题/多词、无结果/空库、删除原行回退和运行时。

所有权：library/index.vue、直接相关回归脚本、本角色三份文档与 frontend-cr012 证据；单工作区串行，页面与导航验证相互依赖，无并行收益，不委派、不建 worktree。风险 normal。先归档 before-owned；后端、上游、QA06、CR、控制面和旧证据受保护。相关类型/lint/格式/边界/309项单元/隔离构建检查通过，27项真实浏览器检查有通过证据；已整理交接并停止自建服务，保留原预览，无提交或部署。

CR010 已由029按 QA05 V01–V04限定关闭，CR011由031限定关闭；CR013已实现待独立QA，前端不改它的实现或状态。

## 原实施基线

沿用 [FE-02](../technical/frontend.md#delivery) 的 FE2-I01–06 / FE2-V01–20。I01–06 已完成本角色实施及开发自检，源码/证据已冻结，等待角色交接；逐项结果见 [frontend-validation.md](frontend-validation.md)。不将局部测试写成独立验收通过。

| ID | 当前落点 | 状态 |
| --- | --- | --- |
| FE2-I01 | UI22 copy/theme/icon、壳、对话框、10 秒欢迎与动画 | 已实施；三引擎开发检查通过 |
| FE2-I02 | 普通/预设生成、认证/承接、可编辑书架及日期复习 | 已实施；契约 mock 与真实服务链路通过 |
| FE2-I03 | 可改答案复习、本机 IDB CAS、临时对照和收据 | 已实施；本机恢复/双标签/丢响应开发回归通过 |
| FE2-I04 | 个人四视图、成长、道具/兑换和消息 | 已实施；对应开发回归通过 |
| FE2-I05 | 后台八模块、运营原子表单、预设独立预览 | 已实施；最终用户积分 hash 入口及后台 8 项回归通过 |
| FE2-I06 | 全局检查、生产构建、真服务、浏览器/可访问性、交接 | 开发检查与交接完成；历次返工沿原证据；当前 CR012 待独立复验 |

## 工作区与所有权

单工作区串行，未创建 worktree 或委派代理。frontend-claire 负责 frontend/**、本计划、frontend-validation.md、frontend-implementation.md 和 frontend-* 证据；后端、批准产品/设计/API 和控制面保持受保护。没有自动提交、部署或真实 AI 调用。

原始失败日志永久保留，通过/失败及对应代码版本在验证报告和最终 manifest 定位。旧 M001 精确视觉与协议规格原路径保留，运行选择和继承映射见 frontend/tests/e2e/README.md，不机械运行已替代的旧判分接口。

## 接收验收边界

CR012 保持 OPEN，已实现待 qa-quinn 独立复验，CR013同时接收。CR009沿027限定关闭。CR001/002、CR039-L1、CR042-L1、AI-QUALITY-90 保持原状态。FE2-V04/09/13–17 的真机、人工读屏、生产代理、时序组合和独立 UIA 仍需质量角色按报告补验；不把它们清空或改成已通过。当前角色和正式阶段不由本计划修改。
