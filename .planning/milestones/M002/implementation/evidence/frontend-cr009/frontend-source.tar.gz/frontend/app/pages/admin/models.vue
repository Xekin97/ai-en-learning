<script setup lang="ts">
import type { AdminModelModel, AppFailure } from "@application/shared/models";
import type { ModelRemovalImpact } from "@application/admin/configuration";
import { mergeEdited } from "@application/admin/growth-drafts";
import { normalizeFailure } from "@application/shared/failure";
definePageMeta({ middleware: "admin", layout: "admin" });
const admin = useAdminStore(),
  { copy } = useDesignCopy(),
  session = useSessionStore();
const keyOpen = ref(false),
  modelOpen = ref(false),
  key = ref(""),
  keyRevision = ref("");
const form = reactive({
  modelId: null as string | null,
  displayName: "",
  description: "",
  openRouterModelId: "",
  enabled: true,
  expectedRevision: null as string | null,
});
const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v));
const baseline = ref(clone(form)),
  remote = ref<typeof form | null>(null),
  unknownCreate = ref(false);
const modelFields = (
  m: Pick<
    AdminModelModel,
    | "id"
    | "revision"
    | "displayName"
    | "description"
    | "openRouterModelId"
    | "enabled"
  >,
) => ({
  modelId: m.id,
  expectedRevision: m.revision,
  displayName: m.displayName,
  description: m.description ?? "",
  openRouterModelId: m.openRouterModelId,
  enabled: m.enabled,
});
const failure = shallowRef<AppFailure | null>(null),
  impact = shallowRef<ModelRemovalImpact | null>(null);
const busy = computed(
  () =>
    admin.state.value.status === "saving" ||
    admin.state.value.status === "loading",
);
await usePageLoader("admin-models", () => admin.loadModels());
useLocalizedHead("admin.models");
function openKey() {
  key.value = "";
  keyRevision.value = admin.state.value.credential?.revision ?? "";
  failure.value = null;
  keyOpen.value = true;
}
function closeKey() {
  if (busy.value) return;
  key.value = "";
  keyOpen.value = false;
}
function openModel(
  model?: Pick<
    AdminModelModel,
    | "id"
    | "displayName"
    | "description"
    | "openRouterModelId"
    | "enabled"
    | "revision"
  >,
) {
  failure.value = null;
  Object.assign(form, {
    modelId: model?.id ?? null,
    displayName: model?.displayName ?? "",
    description: model?.description ?? "",
    openRouterModelId: model?.openRouterModelId ?? "",
    enabled: model?.enabled ?? true,
    expectedRevision: model?.revision ?? null,
  });
  baseline.value = clone(form);
  remote.value = null;
  unknownCreate.value = false;
  modelOpen.value = true;
}
async function saveKey() {
  try {
    await admin.saveCredential(key.value, keyRevision.value);
    key.value = "";
    keyOpen.value = false;
  } catch (error) {
    failure.value = normalizeFailure(error);
    await admin.loadModels();
    keyRevision.value =
      admin.state.value.credential?.revision ?? keyRevision.value;
  }
}
async function saveModel() {
  if (busy.value || unknownCreate.value) return;
  const epoch = session.epoch.value;
  if (remote.value) {
    Object.assign(
      form,
      mergeEdited(baseline.value, clone(form), remote.value),
      { expectedRevision: remote.value.expectedRevision },
    );
    baseline.value = clone(remote.value);
    remote.value = null;
  }
  try {
    await admin.saveModelDraft({
      ...form,
      description: form.description.trim() || null,
    });
    if (epoch === session.epoch.value) modelOpen.value = false;
  } catch (error) {
    if (epoch !== session.epoch.value) return;
    failure.value = normalizeFailure(error);
    const savedId = admin.state.value.lastSavedModelId;
    if (savedId) form.modelId = savedId;
    const uncertain =
      failure.value.status === null || (failure.value.status ?? 0) >= 500;
    if (!form.modelId && uncertain) unknownCreate.value = true;
    await admin.loadModels();
    if (epoch !== session.epoch.value) return;
    while (
      form.modelId &&
      !admin.state.value.models.some((m) => m.id === form.modelId) &&
      admin.state.value.nextModelCursor &&
      !admin.state.value.failure
    ) {
      await admin.loadModels(true);
      if (epoch !== session.epoch.value) return;
    }
    const current = admin.state.value.models.find((m) => m.id === form.modelId);
    if (current) remote.value = modelFields(current);
  }
}

async function remove(model: Pick<AdminModelModel, "id">) {
  failure.value = null;
  impact.value = await admin.previewRemoval(model.id);
}
function closeRemoval() {
  if (busy.value) return;
  if (impact.value) admin.clearRemoval(impact.value.model.id);
  impact.value = null;
}
async function confirmRemoval() {
  if (!impact.value) return;
  try {
    await admin.removeModel(impact.value.model.id, impact.value.revision);
    closeRemoval();
    await admin.loadModels();
  } catch (error) {
    failure.value = normalizeFailure(error);
    const id = impact.value?.model.id;
    closeRemoval();
    await admin.loadModels();
    if (id) admin.clearRemoval(id);
  }
}
watch(session.epoch, () => {
  key.value = "";
  keyOpen.value = false;
  modelOpen.value = false;
  impact.value = null;
  failure.value = null;
});
onBeforeUnmount(() => {
  key.value = "";
  if (impact.value) admin.clearRemoval(impact.value.model.id);
});
</script>
<template>
  <div>
    <div class="section-head">
      <h1>{{ copy("a.models") }}</h1>
      <button class="btn primary" :disabled="busy" @click="openModel()">
        {{ copy("a.model.new") }}
      </button>
    </div>
    <AppError :failure="admin.state.value.failure" />
    <section class="panel admin-credential">
      <div>
        <h2>OpenRouter</h2>
        <p>{{ copy("a.key.shared") }}</p>
        <span class="pill">{{
          copy(
            admin.state.value.credential?.configured
              ? "a.key.configured"
              : "a.key.missing",
          )
        }}</span
        ><code
          v-if="admin.state.value.credential?.configured"
          class="masked-key"
          >{{ admin.state.value.credential.maskedHint }}</code
        >
      </div>
      <button class="btn" :disabled="busy" @click="openKey">
        {{ copy("a.key.replace") }}
      </button>
    </section>
    <section class="panel">
      <div class="table-wrap" tabindex="0">
        <table class="data-table">
          <thead>
            <tr>
              <th
                v-for="label in [
                  'a.model.name',
                  'a.provider',
                  'a.references',
                  'a.status',
                  'a.actions',
                ]"
                :key="label"
              >
                {{ copy(label) }}
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="model in admin.state.value.models.filter(
                (m) => !m.retiredAt,
              )"
              :key="model.id"
            >
              <td>
                <strong>{{ model.displayName }}</strong
                ><small class="admin-cell-copy">{{ model.description }}</small>
              </td>
              <td>
                <code>{{ model.openRouterModelId }}</code>
              </td>
              <td>
                {{
                  model.assignedGroupCodes
                    .map((code) => copy("a.plan." + code))
                    .join(" / ") || "—"
                }}
              </td>
              <td>
                <span class="pill">{{
                  copy(model.enabled ? "a.model.active" : "a.model.inactive")
                }}</span>
              </td>
              <td>
                <div class="actions">
                  <button
                    class="btn small"
                    :disabled="busy"
                    @click="openModel(model)"
                  >
                    {{ copy("a.edit") }}</button
                  ><button
                    class="btn danger small"
                    :disabled="busy"
                    @click="remove(model)"
                  >
                    {{ copy("a.remove") }}
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <p
        v-if="!admin.state.value.models.some((m) => !m.retiredAt)"
        class="notice"
      >
        {{ copy("a.models.empty") }}
      </p>
      <button
        v-if="admin.state.value.nextModelCursor"
        class="btn"
        :disabled="busy"
        @click="admin.loadModels(true)"
      >
        {{ copy("a.more") }}
      </button>
    </section>
    <AppDialog
      id="admin-key"
      :open="keyOpen"
      :title="copy('a.key.replace')"
      @close="closeKey"
      ><p class="notice">{{ copy("a.key.private") }}</p>
      <AppError :failure="failure" />
      <form id="key-form" @submit.prevent="saveKey">
        <label class="field"
          ><span>{{ copy("a.key.input") }}</span
          ><input
            v-model="key"
            type="password"
            autocomplete="new-password"
            required
            :disabled="busy"
        /></label>
      </form>
      <template #footer
        ><button class="btn" :disabled="busy" @click="closeKey">
          {{ copy("cancel") }}</button
        ><button
          class="btn primary"
          type="submit"
          form="key-form"
          :disabled="busy"
        >
          {{ copy("a.save") }}
        </button></template
      ></AppDialog
    >
    <AppDialog
      id="admin-model"
      :open="modelOpen"
      :title="copy(form.modelId ? 'a.model.edit' : 'a.model.new')"
      @close="!busy && (modelOpen = false)"
      ><AppError :failure="failure" />
      <dl v-if="remote" class="admin-facts notice">
        <div>
          <dt>{{ copy("a.model.name") }}</dt>
          <dd>{{ remote.displayName }}</dd>
        </div>
        <div>
          <dt>{{ copy("a.model.description") }}</dt>
          <dd>{{ remote.description || "—" }}</dd>
        </div>
        <div>
          <dt>{{ copy("a.provider") }}</dt>
          <dd>{{ remote.openRouterModelId }}</dd>
        </div>
        <div>
          <dt>{{ copy("a.status") }}</dt>
          <dd>{{ copy(remote.enabled ? "enabled" : "disabled") }}</dd>
        </div>
      </dl>
      <form id="model-form" @submit.prevent="saveModel">
        <fieldset :disabled="busy">
          <label class="field"
            ><span>{{ copy("a.model.name") }}</span
            ><input v-model="form.displayName" required /></label
          ><label class="field"
            ><span>{{ copy("a.model.description") }}</span
            ><input v-model="form.description" /></label
          ><label class="field"
            ><span>{{ copy("a.provider") }}</span
            ><input v-model="form.openRouterModelId" required /></label
          ><label class="check"
            ><input v-model="form.enabled" type="checkbox" />{{
              copy("a.model.enable")
            }}</label
          >
          <p class="notice">{{ copy("a.model.enablednote") }}</p>
        </fieldset>
      </form>
      <template #footer
        ><button class="btn" :disabled="busy" @click="modelOpen = false">
          {{ copy("cancel") }}</button
        ><button
          class="btn primary"
          form="model-form"
          type="submit"
          :disabled="busy || unknownCreate"
        >
          {{ copy("a.save") }}
        </button></template
      ></AppDialog
    >
    <AppDialog
      id="model-removal"
      :open="impact !== null"
      :title="copy('model.remove.title')"
      @close="closeRemoval"
      ><template v-if="impact"
        ><h3>{{ impact.model.displayName }}</h3>
        <p class="notice warn">{{ copy("model.remove.desc") }}</p>
        <AppError :failure="failure" />
        <dl class="admin-facts">
          <div>
            <dt>{{ copy("a.plans") }}</dt>
            <dd>
              <p v-for="group in impact.affectedGroups" :key="group.code">
                {{ copy("a.plan." + group.code) }} ·
                {{ group.remainingEnabledModels
                }}{{
                  group.remainingEnabledModels === 0
                    ? " · " + copy("a.model.last")
                    : ""
                }}
              </p>
              <span v-if="!impact.affectedGroups.length">—</span>
            </dd>
          </div>
          <div>
            <dt>{{ copy("itemsettings") }}</dt>
            <dd>{{ impact.affectedItemDefinitions }}</dd>
          </div>
          <div>
            <dt>{{ copy("bag") }}</dt>
            <dd>{{ impact.affectedOwnedCards }}</dd>
          </div>
          <div>
            <dt>{{ copy("a.presets") }}</dt>
            <dd>{{ impact.affectedPresets }}</dd>
          </div>
        </dl>
        <p class="notice">{{ copy("a.model.removeimpact") }}</p></template
      ><template #footer
        ><button class="btn" :disabled="busy" @click="closeRemoval">
          {{ copy("cancel") }}</button
        ><button class="btn danger" :disabled="busy" @click="confirmRemoval">
          {{ copy("a.remove") }}
        </button></template
      ></AppDialog
    >
  </div>
</template>
