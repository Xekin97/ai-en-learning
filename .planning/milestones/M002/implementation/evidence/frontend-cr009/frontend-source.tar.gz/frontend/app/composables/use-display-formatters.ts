import type {
  GroupCode,
  MeaningLanguage,
  PassageLength,
  Scenario,
} from "@application/shared/models";

export function useDisplayFormatters() {
  const { t, locale } = useI18n();
  const { copy } = useDesignCopy();
  return {
    meaning: (value: MeaningLanguage) =>
      copy(
        `a.preset.language.${{ zh: "中文", en: "English", ja: "日本語" }[value]}`,
      ),
    meaningDescription: (value: MeaningLanguage) =>
      t(`enum.meaningDescription.${value}`),
    scenario: (value: Scenario) =>
      copy(
        `a.preset.style.${{ story: "Story", discussion: "Discussion", business: "Business", news: "News" }[value]}`,
      ),
    scenarioDescription: (value: Scenario) =>
      t(`enum.scenarioDescription.${value}`),
    length: (value: PassageLength) =>
      copy(
        `a.preset.length.${{ short: "Brief", medium: "Standard", long: "Extended", xlong: "Deep Dive" }[value]}`,
      ),
    group: (value: GroupCode) => t(`enum.group.${value}`),
    adminDate: (value: string) => value.slice(0, 10),
    integer: (value: number) =>
      new Intl.NumberFormat(locale.value, {
        notation: "standard",
        maximumFractionDigits: 0,
      }).format(value),
    dateTime: (value: string) =>
      new Intl.DateTimeFormat(locale.value, {
        dateStyle: "medium",
        timeStyle: "short",
        timeZone: "Asia/Shanghai",
      }).format(new Date(value)),
    date: (value: string) =>
      new Intl.DateTimeFormat(locale.value, { dateStyle: "medium" }).format(
        new Date(value),
      ),
  };
}
