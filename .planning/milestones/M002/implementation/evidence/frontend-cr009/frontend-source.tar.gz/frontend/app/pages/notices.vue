<script setup lang="ts">
const session = useSessionStore(),
  notices = useNoticesStore();
const { copy, language } = useDesignCopy();
const format = useDisplayFormatters();
await session.load();
if (session.actor.value?.kind === "account")
  await usePageLoader("notices", () => notices.load());
watch(language, () => {
  if (session.actor.value?.kind === "account") void notices.load();
});
useHead({ title: () => copy("notices.title") });
</script>
<template>
  <div>
    <div class="page-head">
      <h1>{{ copy("notices.title") }}</h1>
    </div>
    <template v-if="session.actor.value?.kind === 'account'"
      ><AppError :failure="notices.state.value.failure" /><button
        v-if="notices.state.value.failure"
        class="btn"
        type="button"
        @click="notices.load()"
      >
        {{ copy("retry") }}
      </button>
      <section class="notice-list">
        <button
          v-for="notice in notices.state.value.items"
          :key="notice.id"
          class="notice-entry"
          type="button"
          @click="notices.open(notice.id)"
        >
          <span v-if="notice.remind" class="pill">{{
            copy("notice.reminder")
          }}</span>
          <h3>{{ notice.title }}<AppIcon name="chevron-right" /></h3>
          <small>{{ format.dateTime(notice.publishedAt) }}</small>
        </button>
      </section>
      <p
        v-if="
          !notices.state.value.items.length &&
          !notices.state.value.pending &&
          !notices.state.value.failure
        "
        class="empty"
      >
        {{ copy("empty") }}
      </p>
      <button
        v-if="notices.state.value.nextCursor"
        class="btn"
        type="button"
        :disabled="notices.state.value.pending"
        @click="notices.load(true)"
      >
        {{ $t("common.loadMore") }}
      </button></template
    ><NuxtLink v-else class="btn primary" to="/login?redirect=/notices">{{
      copy("login")
    }}</NuxtLink>
  </div>
</template>
