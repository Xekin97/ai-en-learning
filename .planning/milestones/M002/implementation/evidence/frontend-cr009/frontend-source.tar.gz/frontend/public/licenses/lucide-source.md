# UI-10 icon assets

Selected SVG data from the Iconify Lucide collection: https://icon-sets.iconify.design/lucide/

Downloaded on 2026-09-18 from the public Iconify API (`https://api.iconify.design/lucide.json?icons=…`). The selected names and exact paths are in `lucide.json`; `../icons.js` renders local SVG. The browser makes no request to Iconify, npm or a third-party CDN. No font glyph substitution.

Lucide license and notices: `lucide-LICENSE.txt`, fetched from https://raw.githubusercontent.com/lucide-icons/lucide/main/LICENSE . Preserve this notice with redistribution. Asset data uses original 24×24 geometry and currentColor.

Usage: 18–20px for buttons/navigation, 27px for empty/card states, 44px for authentication illustration. SVGs are decorative (`aria-hidden`, not focusable); text and button accessible names retain meaning. Shape icons in review remain anonymous, stable groups with localized shape names. The brand mark remains the existing bespoke SVG.
