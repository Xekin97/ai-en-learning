<script setup lang="ts">
const session = useSessionStore();
const account = useAccountStore();
const route = useRoute();
const { copy } = useDesignCopy();
const locale = useApplicationLocale();
const dropdown = ref<HTMLDetailsElement | null>(null);
const navigation = [
  { path: "/", key: "home" },
  { path: "/explore", key: "explore" },
  { path: "/create", key: "create" },
  { path: "/review", key: "range" },
  { path: "/library", key: "library" },
];
const accountLinks = [
  { path: "/account", key: "profile", icon: "user" },
  { path: "/account/growth", key: "growth", icon: "trophy" },
  { path: "/account/items", key: "bag", icon: "shopping-bag" },
  { path: "/account/exchange", key: "shop", icon: "store" },
] as const;
const name = computed(() =>
  session.actor.value?.kind === "account"
    ? (account.state.value.account?.displayName ?? session.actor.value.username)
    : "",
);
function active(path: string) {
  if (path === "/explore" && route.path.startsWith("/trial/")) return "page";
  return route.path === path ||
    (path !== "/" && route.path.startsWith(path + "/"))
    ? "page"
    : undefined;
}
watch(
  () => route.fullPath,
  () => {
    if (dropdown.value) dropdown.value.open = false;
  },
);
</script>
<template>
  <header class="topbar">
    <div class="container header-inner">
      <NuxtLink class="brand" to="/"><BrandMark />{{ copy("brand") }}</NuxtLink>
      <nav class="nav" :aria-label="copy('mainnav')">
        <NuxtLink
          v-for="item in navigation"
          :key="item.path"
          :to="item.path"
          :aria-current="active(item.path)"
          >{{ copy("nav." + item.key) }}</NuxtLink
        >
      </nav>
      <div class="header-actions">
        <button
          class="btn quiet"
          type="button"
          :aria-label="copy('language')"
          @click="
            locale.change(locale.locale.value === 'zh-CN' ? 'en-US' : 'zh-CN')
          "
        >
          {{ copy(locale.locale.value === "zh-CN" ? "english" : "chinese") }}
        </button>
        <template v-if="session.actor.value?.kind === 'account'">
          <NuxtLink
            v-if="session.isAdmin.value"
            class="btn quiet"
            to="/admin"
            >{{ copy("admin") }}</NuxtLink
          >
          <template v-else>
            <NuxtLink class="btn quiet" to="/notices">{{
              copy("notices")
            }}</NuxtLink>
            <details
              ref="dropdown"
              class="account-dropdown"
              @keydown.esc="dropdown && (dropdown.open = false)"
            >
              <summary :aria-label="copy('accountmenu')">
                <span class="avatar" aria-hidden="true">{{
                  name.slice(0, 1)
                }}</span
                ><span class="user-name">{{ name }}</span
                ><AppIcon name="chevron-down" class="dropdown-chevron" />
              </summary>
              <nav class="account-popover" :aria-label="copy('accountmenu')">
                <NuxtLink
                  v-for="item in accountLinks"
                  :key="item.path"
                  :to="item.path"
                  :aria-current="route.path === item.path ? 'page' : undefined"
                  ><AppIcon :name="item.icon" />{{ copy(item.key) }}</NuxtLink
                >
              </nav>
            </details>
          </template>
        </template>
        <template v-else
          ><NuxtLink class="btn primary" to="/login">{{
            copy("login")
          }}</NuxtLink
          ><NuxtLink class="btn quiet" to="/register">{{
            copy("i.register")
          }}</NuxtLink></template
        >
      </div>
    </div>
  </header>
</template>
