<script setup lang="ts">
const props = defineProps<{ id: string; open: boolean; title: string }>();
const emit = defineEmits<{ close: [] }>();
const dialog = ref<HTMLDialogElement | null>(null);
const feedback = useFeedbackStore();
let opener: HTMLElement | null = null;
async function syncOpen() {
  await nextTick();
  const el = dialog.value;
  if (!el) return;
  if (props.open && !el.open) {
    opener =
      document.activeElement instanceof HTMLElement
        ? document.activeElement
        : null;
    el.showModal();
    feedback.modal(el, true);
  }
  if (!props.open && el.open) {
    feedback.modal(el, false);
    await nextTick();
    el.close();
    if (opener?.isConnected) opener.focus();
  }
}
watch(() => props.open, syncOpen);
onMounted(syncOpen);
onBeforeUnmount(() => {
  if (dialog.value) feedback.modal(dialog.value, false);
});
function backdrop(event: MouseEvent) {
  if (event.target === event.currentTarget) emit("close");
}
</script>
<template>
  <Teleport to="body"
    ><dialog
      :id="id"
      ref="dialog"
      :aria-labelledby="`${id}-dialog-title`"
      @cancel.prevent="emit('close')"
      @click="backdrop"
    >
      <button
        class="btn quiet dialog-close"
        type="button"
        :aria-label="$t('common.close')"
        @click="emit('close')"
      >
        <AppIcon name="x" />
      </button>
      <h2 :id="`${id}-dialog-title`">{{ title }}</h2>
      <div class="dialog-body"><slot /></div>
      <div class="dialog-actions"><slot name="footer" /></div></dialog
  ></Teleport>
</template>
