<script setup lang="ts">
import { authenticationFeedbackFor } from "@runtime/session/authentication-feedback";
const events = authenticationFeedbackFor(useNuxtApp());
const notices = useNoticesStore();
const { copy, language } = useDesignCopy();
watch(
  events.reminders,
  (value) => {
    if (value > 0) void notices.load(false, true);
  },
  { immediate: true },
);
watch(language, () => {
  if (notices.state.value.open) {
    if (notices.state.value.reminders) void notices.load(false, true);
    else if (notices.selected.value)
      void notices.open(notices.selected.value.id);
  }
});
</script>
<template>
  <AppDialog
    id="platform-notice"
    :open="notices.state.value.open"
    :title="notices.selected.value?.title ?? copy('notices')"
    @close="notices.close"
    ><SafeNoticeBody
      v-if="notices.selected.value"
      :notice="notices.selected.value"
    /><AppError :failure="notices.state.value.failure" /><template #footer
      ><template v-if="notices.state.value.dialog.length > 1"
        ><button
          class="btn"
          type="button"
          :disabled="notices.state.value.index === 0"
          @click="notices.move(-1)"
        >
          {{ copy("previous") }}</button
        ><span
          >{{ notices.state.value.index + 1 }} /
          {{ notices.state.value.dialog.length }}</span
        ><button
          class="btn"
          type="button"
          :disabled="
            notices.state.value.index === notices.state.value.dialog.length - 1
          "
          @click="notices.move(1)"
        >
          {{ copy("next") }}
        </button></template
      ><button class="btn" type="button" @click="notices.close">
        {{ copy("close") }}
      </button></template
    ></AppDialog
  >
</template>
