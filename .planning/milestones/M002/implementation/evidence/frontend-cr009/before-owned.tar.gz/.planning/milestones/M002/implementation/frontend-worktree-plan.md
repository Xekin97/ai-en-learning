---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: awaiting_user_review
result: cr008_implemented_pending_qa
---

# 前端实施计划

输入与授权：TRANSITION-M002-016 / 017 / 023，PRODUCT-03、UI-22/H01、FE-02、BE-03 及后端实施交接。当前正式角色 frontend-claire；没有待重选业务问题，不改批准产品、设计、API、后端或控制面。准确原件见 frontend-inputs.json 与 frontend-before.tar.gz。

## 当前返工：CR-008 / FE2-R08

TRANSITION-M002-023 已激活 frontend-claire，接收 [CR-008](../changes/CR-008.md) / QA2-F04。依据 D2-51、CAP-215/217、API-204/206、UI22 PAGE-210，仅修复模型卡编辑器隐藏已有下架引用造成原生 required 拦截的问题。既有下架模型显示名称及 copy.json 的 retired 状态；新建/新增引用仍排除下架模型，保留非空、revision、保存失败及冲突处理。

FE2-R08 开发自检完成，待独立 QA：已保留并标注既有下架模型引用，未放开新引用和空选择。真实生产前端 + Go/PG 的 7 项检查通过，覆盖页面改价持久化、退款新旧预览、幂等结算、混合模型/320px、新建与清空校验、冲突重试及移除后不可重新加入。299 项既有单测、类型/lint/格式/边界/构建通过。详见 [当前验证](frontend-validation.md#cr008)和 [当前 manifest](evidence/frontend-cr008/manifest.json)。

单工作区串行，责任为 ItemDefinitions.vue、定向测试及本角色计划/报告/交接。保护记录 [frontend-cr008/before.json](evidence/frontend-cr008/before.json)，原文可从 before-owned.tar.gz 恢复。风险 high（权益配置/下架退积分）；不派生代理、不改后端、批准稿、QA 原件、CR 或控制面，不切换模型。无需 worktree/合并，验证后清理本轮自建服务。

CR005/006 已经 QA 独立复验并在 TRANSITION-M002-022 关闭；旧交付保留于 frontend-cr005。后端 CR007 已实施待 QA，本轮不重复开发。

## 原实施基线

沿用 [FE-02](../technical/frontend.md#delivery) 的 FE2-I01–06 / FE2-V01–20。I01–06 已完成本角色实施及开发自检，源码/证据已冻结，等待角色交接；逐项结果见 [frontend-validation.md](frontend-validation.md)。不将局部测试写成独立验收通过。

| ID | 当前落点 | 状态 |
| --- | --- | --- |
| FE2-I01 | UI22 copy/theme/icon、壳、对话框、10 秒欢迎与动画 | 已实施；三引擎开发检查通过 |
| FE2-I02 | 普通/预设生成、认证/承接、可编辑书架及日期复习 | 已实施；契约 mock 与真实服务链路通过 |
| FE2-I03 | 可改答案复习、本机 IDB CAS、临时对照和收据 | 已实施；本机恢复/双标签/丢响应开发回归通过 |
| FE2-I04 | 个人四视图、成长、道具/兑换和消息 | 已实施；对应开发回归通过 |
| FE2-I05 | 后台八模块、运营原子表单、预设独立预览 | 已实施；最终用户积分 hash 入口及后台 8 项回归通过 |
| FE2-I06 | 全局检查、生产构建、真服务、浏览器/可访问性、交接 | 开发检查与交接完成；首轮 QA 返工后待独立复验 |

## 工作区与所有权

单工作区串行，未创建 worktree 或委派代理。frontend-claire 负责 frontend/**、本计划、frontend-validation.md、frontend-implementation.md 和 frontend-* 证据；后端、批准产品/设计/API 和控制面保持受保护。没有自动提交、部署或真实 AI 调用。

原始失败日志永久保留，通过/失败及对应代码版本在验证报告和最终 manifest 定位。旧 M001 精确视觉与协议规格原路径保留，运行选择和继承映射见 frontend/tests/e2e/README.md，不机械运行已替代的旧判分接口。

## 接收验收边界

CR007/008 保持 OPEN，待 qa-quinn 独立复验。CR001/002、CR039-L1、CR042-L1、AI-QUALITY-90 保持原状态。FE2-V04/09/13–17 的真机、人工读屏、生产代理、时序组合和独立 UIA 仍需质量角色按报告补验；不把它们清空或改成已通过。当前角色和正式阶段不由本计划修改。
