---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: awaiting_user_review
result: cr008_implemented_pending_qa
date: 2026-09-21
---

# 前端实施与开发验证

本报告是 frontend-claire 的开发自检，不代替质量角色验收。有效输入：PRODUCT-03、UI22/H01、DB-03、BE-03、FE-02；本轮授权 TRANSITION-M002-023，承接 TRANSITION-M002-016/017 的整体交付。正式阶段仍为 implementation，不修改守门状态。输入原件和工作区保护基线见 [frontend-inputs.json](evidence/frontend-inputs.json)。

<a id="cr008"></a>
## 当前返工：CR-008 / QA2-F04

**已有模型卡的下架积分无法从后台保存已修复，开发检查通过，待 QA 独立复验。** 接收 [CR-008](../changes/CR-008.md)、D2-51、CAP-215/217、API-204/206、UI22 PAGE-210。当前版本以 [frontend-cr008/manifest](evidence/frontend-cr008/manifest.json)、[source.json](evidence/frontend-cr008/source.json)及可恢复源码为准。

ItemDefinitions.vue 的模型选择列表现在保留 baseline 中已有的下架引用，并在模型名称后直接复用 copy.json 的 retired 文案。筛选依据已保存的定义，不依据任意草稿选中值；新建卡及已经保存移除的引用不能再新增下架模型。required、非空校验、类型字段、revision、冲突后显式重试及成功/失败反馈不变。生产修改仅该组件两处；新增真实服务回归脚本 m002-retired-card.mjs。API、后端、数据库定义、批准设计、文案源、样式和依赖均未改。

已打开并检查 UI22/H01 的运营模型卡编辑原型，读取 app.js/itemForm、theme.css 的表单/对话框规则及准确 copy；相关 API 条款明确“不能新引用下架模型”，允许保留旧引用。原型的静态可用模型 fixture 不覆盖这条既定业务规则。本修复沿用现有布局与多选控件，不重新设计表单。

| 本轮检查 | 结果与证据 |
| --- | --- |
| 单元 | [28 文件 / 299 项通过](evidence/frontend-cr008/unit.log)；沿用既有行为/契约单测，本轮关键 UI 行为由真实浏览器检查 |
| 类型、代码、边界、格式 | [typecheck](evidence/frontend-cr008/typecheck.log)、[lint-final](evidence/frontend-cr008/lint-final.log)、[boundaries](evidence/frontend-cr008/boundaries.log)、[format-final](evidence/frontend-cr008/format-final.log)通过；241 模块、270 依赖无违规 |
| 生产构建 | [build](evidence/frontend-cr008/build.log)成功，独立临时输出，不覆盖原预览；5.22 MB / gzip 1.22 MB 为服务构建总量 |
| 真实页面与服务 | [7 项全部通过](evidence/frontend-cr008/real-final/results.json)、[运行日志](evidence/frontend-cr008/real-final.log)。生产 Nuxt + Go + 独立 PG18，实际 Chromium 表单发出 PUT；20→35，刷新持久、模型 ID 不变；旧退款预览 409 preview_stale，新预览 35，实际仅到账一次；混合模型保存、320px、全新卡不含下架引用、空选择拦截、409 草稿保留和显式重试、移除引用后禁止再次新增 |
| 视觉与文案 | [原型](evidence/frontend-cr008/prototype-model-editor.png)、[1440px](evidence/frontend-cr008/real-final/retired-editor-1440.png)、[320px](evidence/frontend-cr008/real-final/mixed-editor-320.png)。已有引用可见且选中，状态精确复用 retired；表单布局未变。文档/对话框无横向溢出，无 pageerror。窄屏原生多选框内长选项保持浏览器自身裁切/滚动行为，不宣称全部长文本同时完整可见 |
| 工作区保护 | 5834 个受保护文件无变更；后端 CR007 当前 285 文件、QA 原件、CR、旧证据和控制面不变。见 [manifest](evidence/frontend-cr008/manifest.json) |

脚本及复现步骤见 [README](evidence/frontend-cr008/README.md)和 [m002-retired-card.mjs](../../../../frontend/tests/integration/m002-retired-card.mjs)。测试模型与签到生效规则仅在新建隔离数据库初始化；模型 enabled 以测试 SQL 设置，兼容性探针不在本项范围。请求仍走真实 API、真实表单、真实事务，没有契约 mock 或真实 AI 调用。退款后余额从兑换后的 195 变为 230；同一幂等键重复返回原收据。本轮未重验 CR007 注销路径。

保留全部原始失败：real-first 在 fixture 模型未启用时被 reward_unavailable 拒绝，未进入目标 UI；real-second 已有 5 项通过，新建用例遗漏非空说明被 422 拒绝，冲突用例错误期待 warn 而实际为既有 app-error。补齐有效 fixture、按实际错误状态及服务端当前值断言后 7 项通过。两次脚本快照与日志保留；未为获取通过改产品规则、错误样式或后端。

<a id="cr005"></a>
## 已关闭返工与接续边界

CR005/006 已由 QA 独立复验并在 TRANSITION-M002-022 正式关闭；原 CR005 的 299 单测、24 浏览器检查及完整说明保留在 [历史 manifest](evidence/frontend-cr005/manifest.json)和本次 [修改前文档快照](evidence/frontend-cr008/before-owned.tar.gz)，不再作为当前待修项。后端 CR007 为 implemented_pending_qa；本轮 CR008 同状态，两项仍 OPEN，由 qa-quinn 独立接收并更新 QA 结论。

本轮只做 Chromium 桌面/320px 定向验证，没有重新跑 Firefox/WebKit、真机、人工读屏、分页模型大目录、生产代理和完整 UIA；此前全量开发覆盖保留，不宣称本轮重验。CR001/002、CR039-L1、CR042-L1、AI-QUALITY-90 及 QA02 整体 FAIL 不由开发自检清除。隔离 API/数据库/生产前端已停止，原预览保留。没有部署、提交、生产迁移或角色推进。

以下为此前整体交付与证据；当前源码入口使用 frontend-cr008。

## 交付范围与继承

已实现 FE2-I01–05：首页叠卡与动画、精选完整预设与语言筛选、普通/固定配置造文台、登录注册及游客承接、可改标题的个人书架、按日期和单篇复习、本机草稿及可修改概览、临时答案总结、个人四视图、签到/手动领奖/四类道具/兑换、消息及欢迎反馈、后台八模块。后台保留模型增改启停移除、四基础计划全字段和优先级、用户搜索/学习记录/密码/基础权益调整，消息管理独立。

实现入口为 [frontend/app](../../../../frontend/app)、[运行说明](../../../../frontend/README.md)。沿用 [49 CAP / 25 PAGE / 28 视图映射](../technical/frontend-traceability.json)，不另改上游编号或批准语义。[路由静态核验](evidence/frontend-route-coverage.json) 无缺失，静态存在不冒充行为通过。原有范围复习与认证的生命周期、游标、额度、UTF-16 span 测试继续保留；M001 精确文案、CSS 数值及旧判分协议由 UI22/M002 替代，旧测试原路径保留，继承对应关系见 [浏览器回归索引](../../../../frontend/tests/e2e/README.md)。

关键边界：答案只在本浏览器 IndexedDB，身份/会话/attempt 隔离；提交之前不调用判分。comparison 不进 SSR、持久层或重试回执。积分/经验十进制字符串；签到自动，成就/级奖手动；基础与体验额度读取独立事实。普通/预设生成与管理员预览各用真实契约；预览无用户额度补丁。运营初始空配置不导入原型价格、等级奖励或库存。北京时间 04:00 和滚动额度由后台决定。

## 设计接收与工程转换

设计真源：[UI22/H01](../handoffs/uiux.md)、[M001 差异 FDE-01–09](../design/frontend-delta.md)、copy.json、theme.css、prototype 源文件。`scripts/sync-design.mjs` 转换 1364 条双语静态/模板文案，转义 i18n 的 `@`/`|`，生成 Lucide 及继承图标和两篇固定公共样文；保留资源许可证。工程补充 CSS 只处理真实表单、布局边界、键盘焦点、读屏和状态。

[转换核验](evidence/frontend-design-conversion.json)：重复生成结果逐字节一致；静态 copy/show 调用无缺失文案键。输入 hash 在 [source-manifest](../../../../frontend/design/source-manifest.json)。未升级依赖或导入运营 fixture 到生产。

代表区域检查包含中英首页、普通生成、短文详情、手机复习结果、成长/道具、后台模型/计划/用户/运营/消息/预设及登录。先核对内容顺序/状态，再检查断点、表单与横向溢出。当前开发截图位于 evidence/frontend-*.png。截图中操作后的淡入中间帧、滚动后离屏 skip-link 在 fullPage 合成中的位置，不作为静态设计基准；最终定态图另存 frontend-visual-final-*。没有以更新截图掩盖业务差异。

## 此前整体检查及适用版本

所有命令在产品根目录运行；Node24 调用前缀为 `npm exec --yes --package=node@24 -- pnpm --dir frontend`。未创建提交，交付版本见 [最终 manifest](evidence/frontend-final-manifest.json) 与 [源码快照](evidence/frontend-source.tar.gz)。64 项全量与真服务/三引擎之后只有用户积分 label helper 和 #points 入口增量，最终 8 项后台回归覆盖该差异；未机械重跑无关测试。

| 检查 | 原始证据 | 结果/范围 |
| --- | --- | --- |
| 单元与契约 | [unit-final](evidence/frontend-unit-final.log) | 27 文件、289 项通过；含严格 envelope、字符串大数、保存行映射、预览 token、SSE 终态和继承生命周期 |
| TypeScript | [typecheck-handoff](evidence/frontend-typecheck-handoff.log) | 通过；最终用户积分来源 label 和 hash 入口也完成类型检查 |
| ESLint | [lint-handoff](evidence/frontend-lint-handoff.log) | 通过，包括最后增量 |
| 边界 | [boundaries-final](evidence/frontend-boundaries-final.log) | 241 模块、270 依赖，无违规 |
| 格式 | [format-handoff](evidence/frontend-format-handoff.log) | 通过，包括最后增量 |
| 生产构建 | [build-handoff](evidence/frontend-build-handoff.log) | 成功，包含最终 hash 入口；构建体积 5.01 MB / gzip 1.2 MB（不等于首页下载量） |
| 桌面/手机业务 E2E | [e2e-final-1](evidence/frontend-e2e-final-1.log) | 64 项通过，针对生产构建；后续仅用户积分文案 helper 与 hash 入口改动，目标回归单列 |
| 后台补充回归 | [admin-core-handoff](evidence/frontend-admin-core-handoff.log) | 8 项通过，含桌面/手机直接 #points 入口与无 hydration 错误 |
| 真实 Go / SQL / 浏览器 | [real-smoke-final-2](evidence/frontend-real-smoke-final-2.log) | 八模块 DTO、原子级别配置、独立预览发布、访客生成注册承接、改标题、复习提交/刷新、个人及日期页面通过；当次本地模型调用 2，真实 AI 调用 0 |
| 跨引擎与 Axe | [browser-matrix-final-2](evidence/frontend-browser-matrix-final-2.log) | Chromium / Firefox / WebKit 全通过；每引擎 9 宽度、15 私有路由；无 serious/critical Axe 项、无 pageerror |
| 工作区保护 | [protection-final](evidence/frontend-protection-final.json) | 5106 个受保护文件无变化/缺失；后端、批准设计/API及控制面保留 |

真实联调是独立临时 PG18、Go 服务、生产 Nuxt 和同源本地代理，不是生产 Nginx/Linux。初始成长未启用时后台按既定契约返回 503；测试库配置首级和已生效签到规则后显式 activate-growth。模拟供应商始终绑定 loopback，未使用真实模型密钥。重现和停服入口见 frontend README；私有临时凭据不进入快照。

## FE2-V01–20 证据定位与验证边界

| 验收 | 已有开发证据 | 仍由独立 QA/运行环境验证 |
| --- | --- | --- |
| V01–02 | strict-contracts、quota/span/token/private-state 等 unit；SSR 两身份隔离 browser；边界检查 | 更大并发、生产缓存与策略配置 |
| V03–05 | 半填/错误/空题、随时概览修改、一次总结、重来、刷新恢复确认、两标签 CAS、超长粘贴、丢响应 GET 收据；实际 API 提交 | 本轮存储定向开发检查见 CR-005；独立 QA、真机 IME/软键盘、BFCache、删除重放全矩阵 |
| V06 | SSE parser/reducer/lifecycle unit；普通/预设/管理员独立流 browser/真服务 | 生产代理中断、负载和浏览器后台挂起组合 |
| V07–08 | 中英认证往返意图、错误重试、注销双确认、注册 claim、六统计/标题/日期预览与错误保留；原有范围 lifecycle unit | 超长真实库连续滚动、全量人工流程与各种输入法 |
| V09 | 大数字显示、手动领奖、整份奖励、计划覆盖确认、下架价变化必须重新预览 browser；后台分账真实 API | 各类卡组合/过期跨 04:00 的完整业务矩阵与运营数据验收 |
| V10–11 | 八后台模块；模型影响确认、计划冲突/优先级交换、正数补分/base 重置、只读库；预设完整分页/语言/独立预览/发布/取消 | 多管理员更长并发、真实大数据与运营流程走查 |
| V12–15 | 欢迎 10s/300ms/24px、对话框 top layer、消息净化与翻页；首页自动切换/人工停止/reduce；断点/三引擎检查记录 | 人工读屏、真实移动端、浏览器 200% 缩放、全部 UIA 逐态设计验收。字号放大探测不冒充真实 zoom |
| V16 | 空样本/观察中/不可用/0/延迟分支；事件白名单/同 ID 重试与页面去重，无私有 Clarity 脚本 | 真实渠道、历史留存和 90 天运行数据 |
| V17 | 同源生产构建、静态资源、cookie/locale、no-store、实际后端成套读取 | Nginx/CSP、Linux 部署、旧标签维护提示及回滚演练 |
| V18–20 | 管理原始双语/null/codepoint/plaintext；六档/隐藏脏行/422 行定位/一次整体保存；管理员独立选项与缺凭据/503；真实多行等级写入 | 产品/质量角色对全部并发/失败分支的独立验收；开发结果不自动关闭 CR004 的运行验收 |

## 故障经验和未决事项

保留全部 frontend-* 原始失败日志。开发服务未刷新新路由导致首次 404，重启后恢复；表单 `type=number` 使 v-model 成为 number，时长解析已兼容 string/number；原生 fieldset 最小宽度造成移动表格越界，已约束最小宽度；表格滚动区已加键盘焦点。未知写入先 GET，对新建对象不按名称猜 ID，不自动重放。生产编译可以接受的模板内类型断言曾被 formatter 拒绝，已提取为脚本 helper。

跨引擎测试必须等页面资源和过渡稳定再检查静态几何/对比度。快速连续硬导航会中断 Nuxt 的异步 middleware 预取，Firefox 将其记录为旧页面 import 错误；原始日志保留，测试等待 networkidle 后再切换尺寸/页面，不过滤 pageerror。

CR001/002 保持 OPEN，待质量角色按一期继承和标题变化关闭；CR039-L1、CR042-L1、AI-QUALITY-90 保留原状态。没有真实 AI 新评测、部署、正式数据迁移或自动阶段推进。尚未执行新会话交接测试；静态链接/保护检查不能冒充独立接收验收。
