---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: awaiting_user_review
result: cr010_implemented_pending_qa
---

# 前端实施计划

输入与授权：TRANSITION-M002-016 / 017 / 027，PRODUCT-03、UI-22/H01、FE-02、BE-03 及后端实施交接。当前正式角色 frontend-claire；没有待重选业务问题，不改批准产品、设计、API、后端或控制面。准确原件见 frontend-inputs.json 与 frontend-before.tar.gz。

## 当前返工：CR-010 / FE2-R10

授权TRANSITION-M002-027，接收 [CR010](../changes/CR-010.md) 与 [QA04](../verification/report.md)。按CAP219 / PAGE213 / UIA-COPY09、UI22/H01、API209修复30天图表整页溢出，无新业务假设。CR009已由027按T01–07限定关闭，旧实现和失败见frontend-cr009证据，不重开。

FE2-R10 已完成实施及开发检查：在analytics.vue限定网格轨道最小尺寸、柱条收缩、稠密日期刻度及英文未知指标卡字号；保持全部每日柱、title和可读明细表，不改API/数值/状态，不用整页隐藏溢出来掩盖。检查代表性320/1440px图表，再覆盖7/30天、中英文、空/观察状态及其余直接相关尺寸。同页 WebKit 自验发现最近更新时间的 Intl 分隔符水合差异，使用现有 NuxtTime/I18nT 处理；保留文案、时区与时间值，不改共用格式化工具。

任务边界为analytics.vue、一份真实浏览器回归脚本及本角色三份文档/新证据。单工作区串行；布局、测试和证据共用一个页面，无独立并行收益，不创建worktree、不委派、不切模型。风险normal。原件先归档于frontend-cr010/before-owned.tar.gz，QA04/CR/上游/控制面受保护。无需合并；完成后清理自建服务，保留既有预览。

完成结果：生产构建与适用静态检查通过，真实Go/PG驱动7/30日序列，在320/390/1280/1440px无文档横溢；全部日点/表格数值保留、日期不互相遮挡、桌面两列与手机单列可读，相关状态/语言/键盘自验。26 项真实浏览器检查通过，详细结果见 frontend-validation.md#cr010 与 frontend-cr010/manifest.json。交付后仍须独立QA，本角色不关闭CR或切阶段。

## 原实施基线

沿用 [FE-02](../technical/frontend.md#delivery) 的 FE2-I01–06 / FE2-V01–20。I01–06 已完成本角色实施及开发自检，源码/证据已冻结，等待角色交接；逐项结果见 [frontend-validation.md](frontend-validation.md)。不将局部测试写成独立验收通过。

| ID | 当前落点 | 状态 |
| --- | --- | --- |
| FE2-I01 | UI22 copy/theme/icon、壳、对话框、10 秒欢迎与动画 | 已实施；三引擎开发检查通过 |
| FE2-I02 | 普通/预设生成、认证/承接、可编辑书架及日期复习 | 已实施；契约 mock 与真实服务链路通过 |
| FE2-I03 | 可改答案复习、本机 IDB CAS、临时对照和收据 | 已实施；本机恢复/双标签/丢响应开发回归通过 |
| FE2-I04 | 个人四视图、成长、道具/兑换和消息 | 已实施；对应开发回归通过 |
| FE2-I05 | 后台八模块、运营原子表单、预设独立预览 | 已实施；最终用户积分 hash 入口及后台 8 项回归通过 |
| FE2-I06 | 全局检查、生产构建、真服务、浏览器/可访问性、交接 | 开发检查与交接完成；历次返工沿原证据；当前 CR010 待独立复验 |

## 工作区与所有权

单工作区串行，未创建 worktree 或委派代理。frontend-claire 负责 frontend/**、本计划、frontend-validation.md、frontend-implementation.md 和 frontend-* 证据；后端、批准产品/设计/API 和控制面保持受保护。没有自动提交、部署或真实 AI 调用。

原始失败日志永久保留，通过/失败及对应代码版本在验证报告和最终 manifest 定位。旧 M001 精确视觉与协议规格原路径保留，运行选择和继承映射见 frontend/tests/e2e/README.md，不机械运行已替代的旧判分接口。

## 接收验收边界

CR010 保持 OPEN，实施后由 qa-quinn 独立复验。CR009沿027限定关闭。CR001/002、CR039-L1、CR042-L1、AI-QUALITY-90 保持原状态。FE2-V04/09/13–17 的真机、人工读屏、生产代理、时序组合和独立 UIA 仍需质量角色按报告补验；不把它们清空或改成已通过。当前角色和正式阶段不由本计划修改。
