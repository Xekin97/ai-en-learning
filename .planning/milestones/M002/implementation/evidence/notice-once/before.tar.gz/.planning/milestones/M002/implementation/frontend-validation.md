---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: ready_for_verification
version: M002-FE-UI27-SEARCH
date: 2026-10-01
---

# 搜词与加载状态修复

<a id="search27"></a>
用户报告的固定adapt/adaptive来自3311契约mock忽略q；正式后端已按词表查询。本次测试端改为读取现有13860条词库，按大小写不敏感匹配、前缀优先/长度/词序返回并校验上限，完整短语不拆分。词库只由本地测试服务读取，不打包进浏览器；未修改正式后端查询或真实数据。

WordPicker补齐设计样式钩子，加载行高50px、文字14px、主题色旋转环；等待250ms仍未完成才显示，原180ms网络防抖不变。换词/清空/离开清理定时器；忙状态可访问、减少动态效果时停转，旧候选不能误选。普通工具台与管理台预设共用。设计来源[UI27](../design/evidence/search-loading27/manifest.json)为用户明确要求的局部优化，未代签新视觉验收。

[9项实际HTTP](evidence/frontend-search27/http.json)、[6项双引擎浏览器](evidence/frontend-search27/browser-results.json)、[1项错误/空态/重试/词数上限回归](evidence/frontend-search27/regression.json)通过。覆盖garden/learn不同结果、大小写/完整短语/无结果/上限，1440英文普通台、390中文后台、320英文普通台，慢请求/清空/迟到响应、快速结果无闪现、减弱动态效果、无横向溢出及pageerror。两张局部图已与原型人工比对。设计另有2项几何/动效检查；不混算生产浏览器场景。

[类型/目标lint/24项既有搜索与生成生命周期单测](evidence/frontend-search27/checks.json)、新增浏览器脚本lint及[生产构建](evidence/frontend-search27/build.log)通过。未机械重跑未受影响的全部352单测。真实设备输入法/读屏沿既有边界保留。

[完整源](evidence/frontend-search27/source.json)、[准确变化](evidence/frontend-search27/changes.json)、[交付绑定](evidence/frontend-search27/manifest.json)。原文/原源在before.tar.gz中；旧UI26/页头证据不覆盖。3311已使用本次3310构建和38080词表测试服务；3302真实模型环境未改，0真实AI调用。下一步QA仅补后台真实测试服务搜完整短语→保存→刷新，复用本轮加载与竞态证据。CR026及旧限制保留。
