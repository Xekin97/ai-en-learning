---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: awaiting_user_review
result: cr014_cr015_implemented_pending_qa
---

# 前端实施计划

输入与授权：TRANSITION-M002-016 / 017 / 034，PRODUCT-03、UI-22/H01、FE-02、BE-03 及后端实施交接。当前正式角色 frontend-claire；没有待重选业务问题，不改批准产品、设计、API、后端或控制面。准确原件见 frontend-inputs.json 与 frontend-before.tar.gz。

## 当前返工：CR014/015 / FE2-R14/15

授权 TRANSITION-M002-034，接收QA07 F10/F11和[CR014](../changes/CR-014.md)/[CR015](../changes/CR-015.md)。沿 UI22/UI18、FE02、API007、CAP012/013/015、PAGE005/006落实既有交互，无新产品解释。CR012/013已由034限定关闭。

状态：implemented_pending_qa。先保留原件和源码，补充状态测试并记录原缺陷；再修改书架搜索/加载更多完成后的焦点、参与组件重新启用后的焦点，以及成功参与修改后的权威全库统计读取。异步统计使用请求序号和现有身份epoch避免迟到响应覆盖；不手算全库数量，不改列表查询/加载范围或日期会话快照。

所有权：frontend/app/pages/library/index.vue、presentation/components/BatchParticipation.vue、runtime/stores/library.ts，直接相关单元/浏览器测试、本角色三份文档与frontend-cr014-015证据。页面与状态依赖紧密，单工作区串行，无委派/worktree/合并需求；保留共享脏工作区。风险high（私有异步状态与缓存）；不改API、后端、产品、设计、QA或控制面。

开发验证已完成：30文件317项单元、类型/lint/格式/边界/隔离构建通过；三引擎21项浏览器全过，局部Axe0违规。证据入口为[当前验证](frontend-validation.md#cr014)及frontend-cr014-015/manifest.json。

验收：搜索/清除回输入，加载更多回首个新增标题，参与切换回原checkbox；双向/筛选/无筛选/失败/重试/连续操作的全库统计与后端一致。代表性320/390/768/1440双语及三引擎浏览器，详情共享开关、原返回行为、准确六统计标签/顺序、错误状态和无横向溢出。执行必要类型/lint/格式/边界/单元及隔离生产构建。独立QA另行接收；不重跑无关全量UIA。原件已归档before-owned，临时服务结束后停，仅处理本轮启动的进程。

## 原实施基线

沿用 [FE-02](../technical/frontend.md#delivery) 的 FE2-I01–06 / FE2-V01–20。I01–06 已完成本角色实施及开发自检，源码/证据已冻结，等待角色交接；逐项结果见 [frontend-validation.md](frontend-validation.md)。不将局部测试写成独立验收通过。

| ID | 当前落点 | 状态 |
| --- | --- | --- |
| FE2-I01 | UI22 copy/theme/icon、壳、对话框、10 秒欢迎与动画 | 已实施；三引擎开发检查通过 |
| FE2-I02 | 普通/预设生成、认证/承接、可编辑书架及日期复习 | 已实施；契约 mock 与真实服务链路通过 |
| FE2-I03 | 可改答案复习、本机 IDB CAS、临时对照和收据 | 已实施；本机恢复/双标签/丢响应开发回归通过 |
| FE2-I04 | 个人四视图、成长、道具/兑换和消息 | 已实施；对应开发回归通过 |
| FE2-I05 | 后台八模块、运营原子表单、预设独立预览 | 已实施；最终用户积分 hash 入口及后台 8 项回归通过 |
| FE2-I06 | 全局检查、生产构建、真服务、浏览器/可访问性、交接 | 开发检查与交接完成；历次返工沿原证据；当前 CR014/015 待独立复验 |

## 工作区与所有权

单工作区串行，未创建 worktree 或委派代理。frontend-claire 负责 frontend/**、本计划、frontend-validation.md、frontend-implementation.md 和 frontend-* 证据；后端、批准产品/设计/API 和控制面保持受保护。没有自动提交、部署或真实 AI 调用。

原始失败日志永久保留，通过/失败及对应代码版本在验证报告和最终 manifest 定位。旧 M001 精确视觉与协议规格原路径保留，运行选择和继承映射见 frontend/tests/e2e/README.md，不机械运行已替代的旧判分接口。

## 接收验收边界

CR014/015正式OPEN，完成实施后交qa-quinn独立复验；CR012/013按034限定关闭。其余历史关闭与CR001/002、CR039-L1、CR042-L1、AI-QUALITY-90保持。QA07整体FAIL与矩阵未完成项不由开发清空；FE2-V04/09/13–17的真机、人工读屏、生产代理等仍待独立覆盖。无提交、部署、真实AI调用或阶段迁移。
