## 当前页头语言修复（072 / frontend-claire，开发通过）

用户指出UI26页头未同步，范围UIA-GLOBAL-SELECT23/FE3-V03：AppHeader/admin两处真实消费、LocaleSwitch及旧局部样式。单工作区顺序处理，不委派；保留所有无关修改。设计采用原型app.js localeControl与admin.js header、theme .locale-control、语言名称中文/EN和copy language。无需新产品决定或接口。

开发前证据为reproduction.json；浏览器前计划：访客/学习者/管理员两套页头，1440/390/320代表视口，Chromium/WebKit；检查准确样式/标签、展开选项、方向键/Enter/Escape、偏好写入/刷新、无横溢。最多4张页头局部视觉，复用其他UI26已验结果。实施/构建及18场景+2回归已通过，3311本轮预览已更新；3302原正式模型入口未授权切换，不改数据库/模型。范围外CR026与旧遗留保留。

## 当前 UI26 增量（069 / frontend-claire）

按批准UI26/FE04实施FE3-I01–06，具体来源/接口/验收见technical/frontend.md#ui26。共享CSS、copy、组件顺序在本工作区实现；不委派、不建worktree，不动现有未提交无关工作。先代表性普通台与后台预设，再替换其余原生选择器（盘点18单选+1多选）；保留BE4修复与原UAT流程。

当前implemented_developer_verified，FE3-I01–06完成，待质量接收。浏览器前范围：FE3-V01文案/版本静态与运行；V02/03选择器键盘、必填、19处与窄屏/弹窗；V04/05消息结构几何/滚动/Markdown；V06/09两处选词及请求乱序/退出；V07释义同快照；V08首页与受影响文案。复用未改业务测试；代表构图最多6张，需要时才追加失败截图。浏览器模拟不能替代真机/读屏。先使用现有契约mock，后定向真实API；不调用正式模型。原源见implementation/evidence/frontend-ui26/before.tar.gz。

# CR024前端实施计划

frontend-claire单工作区负责[CR024](../changes/CR-024.md)，仅GenerationWorkspace模板，还原UI22资料区。无并行工作树、无委派；已有未提交修改与用户数据保留。原型/CSS/文案复用，不新增产品规则。

开发已验证：1440中文/390英文普通和预设4项完成结果/收录检查通过，目标lint/格式、类型和生产构建通过，必要视觉已对照。小型模板修复未新增单测；手机原型初次方法错误原件保留，修正只补验手机。下一步QA定向验证实际结果与放弃操作，不重跑开发检查；详见[交付](frontend-validation.md)及[范围](evidence/frontend-cr024/inputs.json)。
