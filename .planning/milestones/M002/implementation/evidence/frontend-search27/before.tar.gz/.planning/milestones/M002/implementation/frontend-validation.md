---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: ready_for_verification
version: M002-FE-UI26-HEADER
date: 2026-10-01
---

# UI26 页头语言选择修复

<a id="ui26"></a>
用户指出的偏差成立：[修改前实际页头与原型](evidence/frontend-header-locale/reproduction.json)。LocaleSwitch之前虽替换为AppSelect，但AppHeader与admin布局均仍使用旧button；此前按原生select数量做盘点未发现未挂载组件，QA28在页头范围存在漏验，不能将其19个模板定义计数解释为所有实际页头通过。CR025按072仅重开该问题。

已将两个页头接入LocaleSwitch，直接使用UI26 `.locale-control`、中文/EN选项、copy(language)及共享AppSelect；移除旧组件装饰/样式覆盖，继续调用既有locale控制器，cookie/账号偏好与API002协议保持。生产业务仅4文件改动，两个原有浏览器场景改用可见下拉操作，补充真实消费点回归。[改前快照](evidence/frontend-header-locale/before.tar.gz)、[准确增量](evidence/frontend-header-locale/changes.json)。无新增产品规则、依赖或单测镜像。

[18场景PASS](evidence/frontend-header-locale/browser-results.json)：Chromium/WebKit ×访客/学习者/管理员 ×1440/390/320；与运行UI26原型逐项比较尺寸、文字、颜色/背景、圆角、字号和内边距；检查打开/键盘选择/Escape/鼠标选择、cookie、账号PUT偏好请求、刷新保留、无横向溢出及pageerror。[2项回归PASS](evidence/frontend-header-locale/regression.json)：界面切换不改预设释义语言、不多发PV。类型、目标lint、格式与[生产构建](evidence/frontend-header-locale/build.log)通过。其他352单测与UI26业务沿未变依赖复用，未机械重跑。

静态视觉保存原型/实现1440与320两组局部图，已人工检查。初次截图在箭头收起过渡中，原件first-*保留；最终仅静态截图使用animations:disabled完成有限过渡，交互过程仍实操。首次原型探测地址误指设计目录首页，修正为/prototype/后记录真实对照，未修改验收期望。

[完整源码](evidence/frontend-header-locale/source.json)、[归档](evidence/frontend-header-locale/source.tar.gz)、[manifest](evidence/frontend-header-locale/manifest.json)。本构建已更新到 http://127.0.0.1:3311 （契约数据）；3302真实模型入口未改。UI26其余已验结果继续引用[原交付](evidence/frontend-ui26/manifest.json)，旧正文在before.tar.gz内。下一步qa-quinn复核本次漏验补齐与语言切换不丢后台未保存表单，按常设授权登记关闭；CR026未决与旧限制保留。
