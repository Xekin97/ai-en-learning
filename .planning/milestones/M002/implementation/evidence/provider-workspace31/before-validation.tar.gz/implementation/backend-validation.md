---
milestone: M002
stage: implementation
role: backend-implementer/base
agent_name: backend-ethan
version: M002-CR029-BE07
status: ready_for_verification
---

## CR029-F03/F04 服务商批量与流式测试

新增 POST /api/v1/admin/models/batch：共用一个连接，1–100 项模型在同一个配置 CAS 事务中保存；重名冲突和任意输入失败整体回滚，连接只保存一次，无上游调用。模型 ID 保留大小写与斜杠，显示名称可省略。无需数据库迁移。

模型显式测试始终请求 stream:true；严格校验 SSE MIME、协议文本增量及成功终止。普通 JSON、假 SSE、空文本流、中途断流、Anthropic 只有完整初始块均不算通过。三协议有真实本地 HTTP fixture，提前只收到文本时保持等待结束。不会以 TCP 分包次数作为判定标准。

目标 Go 单元、隔离 PostgreSQL admin/HTTP 集成及 vet 均通过；批量同连接成功、第二行冲突全量回滚、过期版本、无孤立连接均验证。日志见 [provider-batch30](evidence/provider-batch30)。沿用此前未改路径的全包证据；没有付费调用。

# CR029 通用模型实现

CAP101/102、DATA007/008、[模型API契约](../technical/api/model-connections.md)已落地。0015迁移保留模型UUID及关联；连接/加密凭据分表；CAS配置事务中完成模型与凭据保存；换连接复制写入，不改变其他模型。三协议Gateway统一生成、管理员预览、显式轻量测试；旧全局管理路由移除。私有运行快照固定当前请求的模型/连接/密钥；权限、额度、取消退款、词法与内容校验沿用。

`go test ./...`、`go vet ./...`通过；隔离PostgreSQL的admin/generation/postgres整包集成通过；新增HTTP三协议配置/探测用例通过。HTTP完整包最终回归通过（138.764s），包含三协议实际HTTP探测、流终止与错误、安全/用量/原流程回归。测试上游均为本地受控HTTP，无真实模型收费调用。

PromptVersion更新为m002-v1-r1，仅记录三协议请求及明确schema提示的变化；ValidatorVersion未变，质量达标率仍未验证。指纹覆盖实际三协议的初次/探测/续写/纠错请求与输出模式。

证据在[evidence/generic-models29](evidence/generic-models29)。原回归失败、定位与修复记录全部保留；新测试没有用放宽产品预期规避失败。迁移演练和3302环境验证由QA交接补充，不以开发单测冒称新UAT已通过。

## 历史交付记录（以下结论仅适用于当时版本）

# CR026 后端实现

DATA205/CAP210/API205/207：新增0014迁移remind_once非空布尔默认false，现有消息行为保持。Input、存储扫描/保存和公开Notice投影贯通；原visible/remind、分页、鉴权、Markdown净化、发布时刻和revision原子更新不变。没有服务端个人提醒历史。

隔离的临时PostgreSQL新建测试库执行全部迁移；4项notice测试-race通过，含默认/开关往返/重复编辑冲突/隐藏与提醒过滤；go vet notices/httpapi通过。证据[backend-checks](evidence/notice-once/backend-checks.json)、backend-tests.log。3302 UAT库未迁移；新版本部署必须先迁移再启新后端，回滚应用可保留字段。无真实AI调用。

[旧文原件](evidence/notice-once/before.tar.gz)保留，上一CR027源及结果仍有效；当前精确增量见manifest。QA补实际HTTP契约连接，不能把服务层通过冒称整条前后端真实集成通过。

## QA31-F01 修复

真实HTTP发现通用配置校验把缺失remind_once作为required拒绝；改为独立请求DTO，只有新字段omitempty，输出模型仍总是返回boolean。其他原必填字段、类型校验保持。5项输入用例与httpapi vet通过，原失败保留在verification/evidence/qa2-031/initial-http.log。无需改变产品/接口默认false约定。[最终源](evidence/notice-once/manifest-final.json)，交QA重跑原HTTP用例；前端/DB/service无变化，不重复其测试。


### QA迁移演练修正

原库备份的隔离恢复演练发现0015的UPDATE触发ai_models.updated_at改写；原库尚未迁移，旧服务已恢复。修正为添加列时给既有行json_schema默认值，再将新行默认改为prompt，不执行UPDATE。新增升级回归核对既有模型全部原字段、时间和密钥密文逐值一致；该用例及全新库迁移检查通过（2.187s）。QA须用修正后的二进制重新演练并比较原数据；此前HTTP与前端运行行为未变，无需机械重跑。
