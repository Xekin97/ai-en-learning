---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: ready_for_verification
version: M002-FE-UI26
date: 2026-10-01
---

# UI26 增量开发验证

<a id="ui26"></a>
按 [FE04](../technical/frontend.md#ui26) / 已批准 UI26 实现 FE3-I01–06。CR025 与 UI25/26 的文案、选词纳入本次，CR026 的只提醒一次缓存范围不在本轮实现。后端独立交付见 [BE4](backend-validation.md#cr027)。原 CR024 验证及旧交接保存在 [before](evidence/frontend-ui26/before.tar.gz)，其未变业务继续继承。

- `AppSelect` 接管9文件19处，盘点纠正为18单选+1原模型卡多选；保留原始值、默认/禁用/必填、表单事件及多选语义。原生 select 仅作为组件内部校验代理，视觉/键盘交互使用统一组件。[盘点](evidence/frontend-ui26/inventory.json)。
- 普通工作台/后台预设共用 `WordPicker` 与词库搜索控制器；完整词条数组不按空格/逗号拆分，候选唯一、上限/随机按原权限，后台不套学习者上限；防乱序、取消、会话切换与卸载残留。
- 消息独立正文滚动、可见标题/操作、Markdown主题与后台预览共用壳；居中880px列表、去提醒类别。首页 Why 区域及批准文案同步；预设释义来自同一结果快照，配置变化保留当前页的旧预览提示，刷新不伪造已丢失预览。

## 实际结果

| 范围 | 结果与原件 |
|---|---|
| FE3-V01/03 设计接收/文案/所有下拉盘点 | source-manifest 指向UI26；准确copy映射、删除键消费同步，19处/9文件盘点通过；运行双语由下列浏览器覆盖 |
| FE3-V02–08 跨引擎实际交互/布局 | [13项PASS](evidence/frontend-ui26/browser-results.json)：Chromium/WebKit/Firefox ×1440/390/320，中英代表状态；滚动、焦点、键盘、旧预览/多词/多选/首页/释义，无pageerror |
| 原业务受影响回归 | [13项PASS](evidence/frontend-ui26/regression.json)：真实界面操作+契约替身，普通/预设生成收录、模型移除、计划冲突/排序、用户读取、成长/道具、预设预览发布，不改变原请求字段 |
| FE3-V04/06/07 补充边界 | [4项PASS+1初始方法失败](evidence/frontend-ui26/focused.json)，修正遗漏query的拦截匹配后[该项PASS](evidence/frontend-ui26/focused-retest.json)：搜索失败→空→重试/满额、三种释义及界面切语言、消息翻页归零、后台净化预览、欢迎浮层10秒及淡入淡出既有时长 |
| FE3-V09 生命周期与业务单测 | 新增搜索竞态/退出/失败回退3项；全36文件352项PASS，见 [test-final.log](evidence/frontend-ui26/test-final.log)。后端真实隔离HTTP/race覆盖三角色与零业务副作用，见BE4；前端浏览器使用契约替身，无付费AI调用 |
| 工程与构建 | [类型/lint/边界均0](evidence/frontend-ui26/delivery-static-checks.json)、格式通过、补充测试lint0；[生产构建成功](evidence/frontend-ui26/build.log)，版本见 [build-source](evidence/frontend-ui26/build-source.json) |

上述31个最终浏览器场景通过，修复/方法重试不重复计数。视觉构图与实际滚动分别核验，见 [visual](evidence/frontend-ui26/visual-check.json)。测试不宣称每种视口都跑完整业务矩阵；真机输入法、读屏、生产代理/部署、真实AI质量沿原未验范围保留。

## 原失败及处理

原始失败日志保留在同一目录：最初误用模型标签、初始动画尚未结束即量几何，改测试方法；Safari按钮指针激活不自动聚焦，实际修复消息入口/预览和下拉打开时明确聚焦，三引擎复验通过。开发服务器出现两个动态导入错误，原因未证明；改用稳定生产构建核验后无pageerror，不宣称定位了开发服务器根因。初次直连Nitro未配置客户端API反代，导致保存未落库；按既有生产测试拓扑加同源反代后再验，原失败保留。三语case初次未匹配带query的列表URL，修正拦截后只复验该项。无修改产品期望或跳过断言。

## 交付和环境

[完整源清单](evidence/frontend-ui26/source.json)、[源码包](evidence/frontend-ui26/source.tar.gz)、[本轮变更](evidence/frontend-ui26/changed-source-files.json)、[manifest](evidence/frontend-ui26/manifest.json)。独立可运行预览 `http://127.0.0.1:3311`（3310生产前端 + 38080契约替身）。用户原3302正式模型测试环境、数据库、模型配置未改；该预览不等于更新/部署3302。下一步 qa-quinn 对源/证据和新增边界定向验收，复用已通过的开发检查；CR025/027仍待正式质量记录与限定关闭，旧UAT不冒充本轮新UAT。
