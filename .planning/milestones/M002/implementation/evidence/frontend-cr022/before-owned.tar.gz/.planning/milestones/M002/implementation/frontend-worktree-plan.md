# CR021 前端实施计划

frontend-claire依据TRANSITION-M002-048、CR021及UI22/H01处理F18–20；用户持续批准实施及QA交接。本轮无新增产品决定。单工作区串行，现有修改保留，不委派、不建worktree、不提交或清理其他工作。

| 任务 | 文件/责任 | 验收 |
|---|---|---|
| F18领奖回焦 | account/growth.vue；growth-focus.test.ts | 成就成功回同组summary、等级成功回本档h3，保留展开，异步更新后正确落焦；失败不当成功处理 |
| F19原生select高度 | assets/css/application.css | 明确46px实际高度，保留原生外观/选项/键盘，WebKit320中英及其他视口检查 |
| F20账号余额横溢 | assets/css/application.css | 个人区标题行允许内容换行；英文768合法大积分完整且无页面横溢 |

已读取设计UI17/UI09、原型growth.js、theme.css和相关页面。样式补充在生产语义层application.css，不修改设计真源或生成theme.css。控件height诊断与余额实际边界在QA19 supplement；API/数据模型与积分结算不变。

先实现目标改动，再做目标组件行为测试、修改文件lint/format、Nuxt类型检查和隔离构建；运行QA19失败范围对应的开发浏览器回归并查看修复截图。完成后交qa-quinn独立复验，连续执行不重新请求批准。历史前端计划与正文保存在frontend-cr021/before-owned.tar.gz；CR020已沿047关闭，旧原件保持。
