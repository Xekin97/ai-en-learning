---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: awaiting_user_review
result: cr009_implemented_pending_qa
---

# 前端实施计划

输入与授权：TRANSITION-M002-016 / 017 / 025，PRODUCT-03、UI-22/H01、FE-02、BE-03 及后端实施交接。当前正式角色 frontend-claire；没有待重选业务问题，不改批准产品、设计、API、后端或控制面。准确原件见 frontend-inputs.json 与 frontend-before.tar.gz。

## 当前返工：CR-009 / FE2-R09

TRANSITION-M002-025 已正式返回 implementation / frontend-claire，接收 [CR009](../changes/CR-009.md)。依据 CAP217/AC217、D2-41/51/74、API101/206 与 UI22 PAGE-210；无新增业务假设。风险 high（权益配置数据丢失），单工作区串行，无委派、worktree 或换模。

FE2-R09 已实施并通过开发检查，待独立 QA：在现有 admin store 按需续载，直到已有模型引用全部可用；编辑器未加载完整引用时禁改模型/禁保存，失败保留输入并复用错误/重试文案。普通模型选项仍可分页。冲突读取的新定义同样补齐引用后才允许管理员明确重试；保留下架引用限制、required、revision 和实时退款规则。

责任文件：admin.ts、ItemDefinitions.vue、相关单元/真实浏览器回归以及本角色计划/报告/交接。跨页引用/改价、显式移除、新卡限制、页失败重试、真实 409 与会话/请求迟到均有测试；309 单测、12 项真实浏览器联调、类型/lint/格式/边界/隔离构建通过。记录 [当前验证](frontend-validation.md#cr009)及 [manifest](evidence/frontend-cr009/manifest.json)。不会修改产品/设计/API、后端、QA 原件、CR 原文或控制面。

原件与保护见 [before.json](evidence/frontend-cr009/before.json)及 before-owned.tar.gz。无需合并；验证后停止本轮自建服务，原预览保留。CR007/008 已于 025 限定关闭，CR005/006 维持 022 关闭；本轮只处理新 CR009。

## 原实施基线

沿用 [FE-02](../technical/frontend.md#delivery) 的 FE2-I01–06 / FE2-V01–20。I01–06 已完成本角色实施及开发自检，源码/证据已冻结，等待角色交接；逐项结果见 [frontend-validation.md](frontend-validation.md)。不将局部测试写成独立验收通过。

| ID | 当前落点 | 状态 |
| --- | --- | --- |
| FE2-I01 | UI22 copy/theme/icon、壳、对话框、10 秒欢迎与动画 | 已实施；三引擎开发检查通过 |
| FE2-I02 | 普通/预设生成、认证/承接、可编辑书架及日期复习 | 已实施；契约 mock 与真实服务链路通过 |
| FE2-I03 | 可改答案复习、本机 IDB CAS、临时对照和收据 | 已实施；本机恢复/双标签/丢响应开发回归通过 |
| FE2-I04 | 个人四视图、成长、道具/兑换和消息 | 已实施；对应开发回归通过 |
| FE2-I05 | 后台八模块、运营原子表单、预设独立预览 | 已实施；最终用户积分 hash 入口及后台 8 项回归通过 |
| FE2-I06 | 全局检查、生产构建、真服务、浏览器/可访问性、交接 | 开发检查与交接完成；首轮 QA 返工后待独立复验 |

## 工作区与所有权

单工作区串行，未创建 worktree 或委派代理。frontend-claire 负责 frontend/**、本计划、frontend-validation.md、frontend-implementation.md 和 frontend-* 证据；后端、批准产品/设计/API 和控制面保持受保护。没有自动提交、部署或真实 AI 调用。

原始失败日志永久保留，通过/失败及对应代码版本在验证报告和最终 manifest 定位。旧 M001 精确视觉与协议规格原路径保留，运行选择和继承映射见 frontend/tests/e2e/README.md，不机械运行已替代的旧判分接口。

## 接收验收边界

CR009 保持 OPEN，实施后由 qa-quinn 独立复验。CR001/002、CR039-L1、CR042-L1、AI-QUALITY-90 保持原状态。FE2-V04/09/13–17 的真机、人工读屏、生产代理、时序组合和独立 UIA 仍需质量角色按报告补验；不把它们清空或改成已通过。当前角色和正式阶段不由本计划修改。
