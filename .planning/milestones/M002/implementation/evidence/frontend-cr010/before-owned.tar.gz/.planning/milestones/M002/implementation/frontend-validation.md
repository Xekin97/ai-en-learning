---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: awaiting_user_review
result: cr009_implemented_pending_qa
date: 2026-09-21
---

# 前端实施与开发验证

本报告为开发自检，非独立质量验收。当前授权 TRANSITION-M002-025；有效基线 PRODUCT-03、UI22/H01、DB03、BE03、FE02。CR007/008 已由 QA03 独立复验并经 025 限定关闭；当前只处理 CR009，阶段仍 implementation / frontend-claire。

<a id="cr009"></a>
## 当前返工：CR009 / QA2-F05

**模型卡已有引用的跨页遗漏/丢失已修复，开发检查通过，待独立 QA。** 来源为 [CR009](../changes/CR-009.md)、CAP217/AC217、D2-41/51/74、API101/206、UI22 PAGE-210。当前 [manifest](evidence/frontend-cr009/manifest.json)、[源码](evidence/frontend-cr009/source.json)、[源码快照](evidence/frontend-cr009/frontend-source.tar.gz)与[增量](evidence/frontend-cr009/source-diff.patch)共同定位 276 文件版本。

### 实现与确认边界

- admin store 新增按需补齐引用的只读动作，沿原 API→mapper→应用模型链读取；从当前游标续载到所有已有引用可用即停止，去重重叠页，余下普通目录仍可分页。
- 编辑器同时保护原定义、当前输入及冲突后已读定义引用。引用未补齐时禁模型选择/保存，其他输入保留；错误与重试复用现有文案，成功补齐不自动保存。新卡和保存后移除的旧引用仍不能新选下架模型，非空/required 不变。
- 模型目录因全局配置 revision 变化返回 409，或契约非法 cursor 422 时，仅重新从第一页读一次；未找到、重复游标或再次过期显式失败，不无限重试。会话 epoch/请求版本继续阻止迟到响应。
- 保存 409 保留编辑，补齐新服务定义中的引用；管理员再次明确保存才按原 mergeEdited 规则采用未编辑字段的新值。没有重放写请求、改 API、放宽后端资格、改变已发卡快照或积分语义。

无新增产品假设；风险 high（权益配置丢失），单工作区串行，无 worktree、子代理或换模。仅两份应用文件与两份测试变更；批准文案、样式、设计/API、后端、QA/CR 与控制面不改。

### 开发检查与版本对应

| 检查 | 结果与证据 |
|---|---|
| 单元 | [29 文件 / 309 项通过](evidence/frontend-cr009/unit-verified.log)，新增 10 项：按引用止步、页重叠、部分失败/重试、缺失身份、循环游标、409/422 重读、连续失效停止、目录已读尽后的新引用、会话和请求过期 |
| 静态检查 | [类型](evidence/frontend-cr009/typecheck-verified.log)、[lint](evidence/frontend-cr009/lint-verified.log)、[格式](evidence/frontend-cr009/format-verified.log)通过；[边界](evidence/frontend-cr009/boundaries.log)241 模块 / 270 依赖，无新增导入违规 |
| 生产构建 | [build-verified](evidence/frontend-cr009/build-verified.log)成功；独立临时 Nuxt 输出，当前地址记录于 build-location.json，不覆盖原预览 |
| 跨页真实联调 | [FE9-01–05 全过](evidence/frontend-cr009/pagination-verified/results.json)，50 余模型跨三页：后页唯一引用改价；真实 Meta+鼠标增选不丢引用；显式移除/新卡下架限制；320px 请求失败保留输入、禁保存、重试；409 后服务端新增后页下架引用，补齐后明确再次保存 |
| 原问题回归 | [FE8-01–07 全过](evidence/frontend-cr009/retired-verified/results.json)：同页/混合卡改价持久、旧退款预览失效/新金额35/幂等、新建和空选择校验、409 草稿保留、移除引用后禁重新新增 |
| 实际控件与布局 | [UI22 原型](evidence/frontend-cr009/prototype-editor.png)、[1440px](evidence/frontend-cr009/pagination-verified/later-reference-1440.png)、[320px 已补齐](evidence/frontend-cr009/pagination-verified/later-reference-320.png)、[网络失败](evidence/frontend-cr009/pagination-verified/reference-load-failure-320.png)。姓名/下架标记/已选状态与错误重试已核对，文档和对话框无横向溢出；长选项仍为原生多选框内部裁切/滚动，未新增样式或宣称全 UIA 通过 |

真实生产 Nuxt + Go/PG18 + Chromium，共 12 项通过，无 pageerror。提供方调用为 0；旧退款脚本只对隔离库设置模型可用性和成长规则。未把开发检查代替 QA 或用户 UAT，未重新执行真机/读屏、跨引擎和生产代理/完整 UIA。

### 原始失败与限定结论

[pagination-first](evidence/frontend-cr009/pagination-first/results.json)首次 4 过/1 败：新定义的后页引用遇到旧目录游标。[第二次](evidence/frontend-cr009/pagination-final/results.json)仍 4 过/1 败：只处理 422 不足。[定向响应](evidence/frontend-cr009/conflict-diagnostic-v2/debug.json)确认实际 GET 返回 409 revision_conflict；补齐该读取恢复后最终全过。两次原结果及对应旧构建位置保留，未修改预期或删除失败。

诊断准备首次因道具说明为空收到 422，属于 fixture 错误，原脚本/日志在 conflict-diagnostic；补上合法说明后取得上面的真实响应。首次 lint 仅发现新增脚本两个未用变量，移除后通过。所有最终检查按 verified 文件定位，旧名称中的 final 不代表当前通过版本。

复现方法见 [README](evidence/frontend-cr009/README.md)，新回归脚本 [m002-paginated-card.mjs](../../../../frontend/tests/integration/m002-paginated-card.mjs)。重跑须新输出目录/新隔离库，不覆盖原件。

<a id="cr008"></a>
## 已关闭返工与接续边界

CR007/008 已在 [025](../reviews/verification-rework-025.md)按 QA03 限定关闭；CR008 原修复证据仍在 [frontend-cr008](evidence/frontend-cr008/manifest.json)，其旧正文可由 [before-owned](evidence/frontend-cr009/before-owned.tar.gz)恢复。CR005/006 维持 022 的关闭。CR009 为 implemented_pending_qa，正式 OPEN，须 qa-quinn 按原问题单独立复验后再由守门决定关闭。

QA03 整体 FAIL、CR001/002、CR039-L1、CR042-L1、AI-QUALITY-90 及其余未覆盖范围保持；QA03 原件不改。后端 CR007 不重复开发。保护与源码归档核对见 manifest；本角色文档收敛到当前入口，不重写历史证据。专用服务停止，原预览保留，无提交或部署，新会话独立交接实验未执行，运行输入/token unknown。

以下为此前整体交付与证据，当前源码入口使用 frontend-cr009。

## 交付范围与继承

已实现 FE2-I01–05：首页叠卡与动画、精选完整预设与语言筛选、普通/固定配置造文台、登录注册及游客承接、可改标题的个人书架、按日期和单篇复习、本机草稿及可修改概览、临时答案总结、个人四视图、签到/手动领奖/四类道具/兑换、消息及欢迎反馈、后台八模块。后台保留模型增改启停移除、四基础计划全字段和优先级、用户搜索/学习记录/密码/基础权益调整，消息管理独立。

实现入口为 [frontend/app](../../../../frontend/app)、[运行说明](../../../../frontend/README.md)。沿用 [49 CAP / 25 PAGE / 28 视图映射](../technical/frontend-traceability.json)，不另改上游编号或批准语义。[路由静态核验](evidence/frontend-route-coverage.json) 无缺失，静态存在不冒充行为通过。原有范围复习与认证的生命周期、游标、额度、UTF-16 span 测试继续保留；M001 精确文案、CSS 数值及旧判分协议由 UI22/M002 替代，旧测试原路径保留，继承对应关系见 [浏览器回归索引](../../../../frontend/tests/e2e/README.md)。

关键边界：答案只在本浏览器 IndexedDB，身份/会话/attempt 隔离；提交之前不调用判分。comparison 不进 SSR、持久层或重试回执。积分/经验十进制字符串；签到自动，成就/级奖手动；基础与体验额度读取独立事实。普通/预设生成与管理员预览各用真实契约；预览无用户额度补丁。运营初始空配置不导入原型价格、等级奖励或库存。北京时间 04:00 和滚动额度由后台决定。

## 设计接收与工程转换

设计真源：[UI22/H01](../handoffs/uiux.md)、[M001 差异 FDE-01–09](../design/frontend-delta.md)、copy.json、theme.css、prototype 源文件。`scripts/sync-design.mjs` 转换 1364 条双语静态/模板文案，转义 i18n 的 `@`/`|`，生成 Lucide 及继承图标和两篇固定公共样文；保留资源许可证。工程补充 CSS 只处理真实表单、布局边界、键盘焦点、读屏和状态。

[转换核验](evidence/frontend-design-conversion.json)：重复生成结果逐字节一致；静态 copy/show 调用无缺失文案键。输入 hash 在 [source-manifest](../../../../frontend/design/source-manifest.json)。未升级依赖或导入运营 fixture 到生产。

代表区域检查包含中英首页、普通生成、短文详情、手机复习结果、成长/道具、后台模型/计划/用户/运营/消息/预设及登录。先核对内容顺序/状态，再检查断点、表单与横向溢出。当前开发截图位于 evidence/frontend-*.png。截图中操作后的淡入中间帧、滚动后离屏 skip-link 在 fullPage 合成中的位置，不作为静态设计基准；最终定态图另存 frontend-visual-final-*。没有以更新截图掩盖业务差异。

## 此前整体检查及适用版本

所有命令在产品根目录运行；Node24 调用前缀为 `npm exec --yes --package=node@24 -- pnpm --dir frontend`。未创建提交，交付版本见 [最终 manifest](evidence/frontend-final-manifest.json) 与 [源码快照](evidence/frontend-source.tar.gz)。64 项全量与真服务/三引擎之后只有用户积分 label helper 和 #points 入口增量，最终 8 项后台回归覆盖该差异；未机械重跑无关测试。

| 检查 | 原始证据 | 结果/范围 |
| --- | --- | --- |
| 单元与契约 | [unit-final](evidence/frontend-unit-final.log) | 27 文件、289 项通过；含严格 envelope、字符串大数、保存行映射、预览 token、SSE 终态和继承生命周期 |
| TypeScript | [typecheck-handoff](evidence/frontend-typecheck-handoff.log) | 通过；最终用户积分来源 label 和 hash 入口也完成类型检查 |
| ESLint | [lint-handoff](evidence/frontend-lint-handoff.log) | 通过，包括最后增量 |
| 边界 | [boundaries-final](evidence/frontend-boundaries-final.log) | 241 模块、270 依赖，无违规 |
| 格式 | [format-handoff](evidence/frontend-format-handoff.log) | 通过，包括最后增量 |
| 生产构建 | [build-handoff](evidence/frontend-build-handoff.log) | 成功，包含最终 hash 入口；构建体积 5.01 MB / gzip 1.2 MB（不等于首页下载量） |
| 桌面/手机业务 E2E | [e2e-final-1](evidence/frontend-e2e-final-1.log) | 64 项通过，针对生产构建；后续仅用户积分文案 helper 与 hash 入口改动，目标回归单列 |
| 后台补充回归 | [admin-core-handoff](evidence/frontend-admin-core-handoff.log) | 8 项通过，含桌面/手机直接 #points 入口与无 hydration 错误 |
| 真实 Go / SQL / 浏览器 | [real-smoke-final-2](evidence/frontend-real-smoke-final-2.log) | 八模块 DTO、原子级别配置、独立预览发布、访客生成注册承接、改标题、复习提交/刷新、个人及日期页面通过；当次本地模型调用 2，真实 AI 调用 0 |
| 跨引擎与 Axe | [browser-matrix-final-2](evidence/frontend-browser-matrix-final-2.log) | Chromium / Firefox / WebKit 全通过；每引擎 9 宽度、15 私有路由；无 serious/critical Axe 项、无 pageerror |
| 工作区保护 | [protection-final](evidence/frontend-protection-final.json) | 5106 个受保护文件无变化/缺失；后端、批准设计/API及控制面保留 |

真实联调是独立临时 PG18、Go 服务、生产 Nuxt 和同源本地代理，不是生产 Nginx/Linux。初始成长未启用时后台按既定契约返回 503；测试库配置首级和已生效签到规则后显式 activate-growth。模拟供应商始终绑定 loopback，未使用真实模型密钥。重现和停服入口见 frontend README；私有临时凭据不进入快照。

## FE2-V01–20 证据定位与验证边界

| 验收 | 已有开发证据 | 仍由独立 QA/运行环境验证 |
| --- | --- | --- |
| V01–02 | strict-contracts、quota/span/token/private-state 等 unit；SSR 两身份隔离 browser；边界检查 | 更大并发、生产缓存与策略配置 |
| V03–05 | 半填/错误/空题、随时概览修改、一次总结、重来、刷新恢复确认、两标签 CAS、超长粘贴、丢响应 GET 收据；实际 API 提交 | 本轮存储定向开发检查见 CR-005；独立 QA、真机 IME/软键盘、BFCache、删除重放全矩阵 |
| V06 | SSE parser/reducer/lifecycle unit；普通/预设/管理员独立流 browser/真服务 | 生产代理中断、负载和浏览器后台挂起组合 |
| V07–08 | 中英认证往返意图、错误重试、注销双确认、注册 claim、六统计/标题/日期预览与错误保留；原有范围 lifecycle unit | 超长真实库连续滚动、全量人工流程与各种输入法 |
| V09 | 大数字显示、手动领奖、整份奖励、计划覆盖确认、下架价变化必须重新预览 browser；后台分账真实 API | 各类卡组合/过期跨 04:00 的完整业务矩阵与运营数据验收 |
| V10–11 | 八后台模块；模型影响确认、计划冲突/优先级交换、正数补分/base 重置、只读库；预设完整分页/语言/独立预览/发布/取消 | 多管理员更长并发、真实大数据与运营流程走查 |
| V12–15 | 欢迎 10s/300ms/24px、对话框 top layer、消息净化与翻页；首页自动切换/人工停止/reduce；断点/三引擎检查记录 | 人工读屏、真实移动端、浏览器 200% 缩放、全部 UIA 逐态设计验收。字号放大探测不冒充真实 zoom |
| V16 | 空样本/观察中/不可用/0/延迟分支；事件白名单/同 ID 重试与页面去重，无私有 Clarity 脚本 | 真实渠道、历史留存和 90 天运行数据 |
| V17 | 同源生产构建、静态资源、cookie/locale、no-store、实际后端成套读取 | Nginx/CSP、Linux 部署、旧标签维护提示及回滚演练 |
| V18–20 | 管理原始双语/null/codepoint/plaintext；六档/隐藏脏行/422 行定位/一次整体保存；管理员独立选项与缺凭据/503；真实多行等级写入 | 产品/质量角色对全部并发/失败分支的独立验收；开发结果不自动关闭 CR004 的运行验收 |

## 故障经验和未决事项

保留全部 frontend-* 原始失败日志。开发服务未刷新新路由导致首次 404，重启后恢复；表单 `type=number` 使 v-model 成为 number，时长解析已兼容 string/number；原生 fieldset 最小宽度造成移动表格越界，已约束最小宽度；表格滚动区已加键盘焦点。未知写入先 GET，对新建对象不按名称猜 ID，不自动重放。生产编译可以接受的模板内类型断言曾被 formatter 拒绝，已提取为脚本 helper。

跨引擎测试必须等页面资源和过渡稳定再检查静态几何/对比度。快速连续硬导航会中断 Nuxt 的异步 middleware 预取，Firefox 将其记录为旧页面 import 错误；原始日志保留，测试等待 networkidle 后再切换尺寸/页面，不过滤 pageerror。

CR001/002 保持 OPEN，待质量角色按一期继承和标题变化关闭；CR039-L1、CR042-L1、AI-QUALITY-90 保留原状态。没有真实 AI 新评测、部署、正式数据迁移或自动阶段推进。尚未执行新会话交接测试；静态链接/保护检查不能冒充独立接收验收。
