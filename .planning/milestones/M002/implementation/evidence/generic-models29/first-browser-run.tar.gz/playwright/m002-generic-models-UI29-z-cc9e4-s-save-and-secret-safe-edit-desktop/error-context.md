# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: m002-generic-models.spec.ts >> UI29 zh >> configuration, protocol retention, explicit tests, save and secret-safe edit
- Location: tests/e2e/m002-generic-models.spec.ts:12:3

# Error details

```
Error: Channel closed
```

```
Error: locator.fill: Test ended.
Call log:
  - waiting for locator('#model-form').locator('[name="displayName"]')
    - locator resolved to <input value="" required="" maxlength="200" name="displayName"/>
    - fill("Custom service")
  - attempting fill action
    2 × waiting for element to be visible, enabled and editable
      - element is not visible
    - retrying fill action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and editable
      - element is not visible
    - retrying fill action
      - waiting 100ms
    23 × waiting for element to be visible, enabled and editable
       - element is not visible
     - retrying fill action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "跳到主要内容" [ref=e4] [cursor=pointer]:
    - /url: "#admin-main"
  - banner [ref=e5]:
    - generic [ref=e6]:
      - link "词涟 管理台" [ref=e7] [cursor=pointer]:
        - /url: /admin
        - text: 词涟
        - generic [ref=e14]: 管理台
      - generic [ref=e15]:
        - generic [ref=e16]:
          - generic [ref=e17]: 切换界面语言
          - generic [ref=e18]:
            - combobox
            - combobox "切换界面语言" [ref=e19] [cursor=pointer]:
              - generic [ref=e20]: 中文
        - generic [ref=e23]: 管理员
        - button "退出管理台" [ref=e24] [cursor=pointer]
  - main [ref=e25]:
    - generic [ref=e26]:
      - navigation "管理台" [ref=e27]:
        - link "概览" [ref=e28] [cursor=pointer]:
          - /url: /admin
        - link "数据分析" [ref=e35] [cursor=pointer]:
          - /url: /admin/analytics
        - link "模型管理" [ref=e38] [cursor=pointer]:
          - /url: /admin/models
        - link "计划管理" [ref=e44] [cursor=pointer]:
          - /url: /admin/plans
        - link "用户管理" [ref=e50] [cursor=pointer]:
          - /url: /admin/users
        - link "成长运营" [ref=e55] [cursor=pointer]:
          - /url: /admin/growth
        - link "消息管理" [ref=e60] [cursor=pointer]:
          - /url: /admin/notices
        - link "首页预设" [ref=e65] [cursor=pointer]:
          - /url: /admin/presets
      - generic [ref=e71]:
        - generic [ref=e72]:
          - generic [ref=e73]:
            - heading "模型服务" [level=1] [ref=e74]
            - paragraph [ref=e75]: 连接你的模型服务，让词语展开更多可能。
          - button "添加通用模型" [active] [ref=e76] [cursor=pointer]
        - region "模型服务" [ref=e77]:
          - article [ref=e78]:
            - generic [ref=e85]:
              - generic [ref=e86]:
                - heading "Admin model" [level=2] [ref=e87]
                - generic [ref=e88]: 已启用
              - code [ref=e89]: Demo service/mock/admin-model
              - paragraph [ref=e90]:
                - generic [ref=e91]: https://models.example/v1
                - generic [ref=e92]: OpenAI Chat Completions
                - generic [ref=e93]: ••••demo
              - paragraph [ref=e94]: Shared model
            - generic [ref=e95]:
              - button "测试连接" [ref=e96] [cursor=pointer]
              - button "编辑" [ref=e97] [cursor=pointer]
              - button "移除" [ref=e98] [cursor=pointer]
  - contentinfo [ref=e99]: 一点点学习，也会泛起涟漪。
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import { readFileSync } from "node:fs";
  3   | import { selectValue } from "./select-control";
  4   | const source = JSON.parse(
  5   |   readFileSync(
  6   |     new URL(
  7   |       "../../../.planning/milestones/M002/design/copy.json",
  8   |       import.meta.url,
  9   |     ),
  10  |     "utf8",
  11  |   ),
  12  | );
  13  | for (const lang of ["en", "zh"]) {
  14  |   const t = (key: string) => source.static[lang + "." + key] as string;
  15  |   test.describe("UI29 " + lang, () => {
  16  |     test.beforeEach(async ({ context, request, baseURL }) => {
  17  |       await request.post("http://127.0.0.1:38084/api/v1/__test/admin-reset");
  18  |       await context.addCookies([
  19  |         { name: "wordweave_session", value: "admin", url: baseURL! },
> 20  |         {
      |                                               ^ Error: locator.fill: Test ended.
  21  |           name: "wordweave_ui_locale",
  22  |           value: lang === "en" ? "en-US" : "zh-CN",
  23  |           url: baseURL!,
  24  |         },
  25  |       ]);
  26  |     });
  27  |     test("configuration, protocol retention, explicit tests, save and secret-safe edit", async ({
  28  |       page,
  29  |     }, info) => {
  30  |       const errors: string[] = [];
  31  |       page.on("pageerror", (e) => errors.push(e.message));
  32  |       const tests: string[] = [];
  33  |       const saves: Record<string, unknown>[] = [];
  34  |       page.on("request", (r) => {
  35  |         if (r.url().endsWith("/admin/model-connection-test"))
  36  |           tests.push(r.url());
  37  |         if (r.url().endsWith("/admin/models") && r.method() === "POST")
  38  |           saves.push(r.postDataJSON());
  39  |       });
  40  |       await page.goto("/admin/models");
  41  |       await page.waitForFunction(() => document.documentElement.dataset.appReady === "true");
  42  |       await expect(page.locator(".generic-model-row")).toHaveCount(1);
  43  |       await expect(
  44  |         page.getByRole("heading", { name: t("gm.title"), exact: true }),
  45  |       ).toBeVisible();
  46  |       await page
  47  |         .getByRole("button", { name: t("gm.add"), exact: true })
  48  |         .click();
  49  |       const dialog = page.locator("#admin-model"),
  50  |         form = page.locator("#model-form");
  51  |       await form.locator('[name="displayName"]').fill("Custom service");
  52  |       await form.locator('[name="providerModelId"]').fill("Vendor/Exact-ID");
  53  |       await form.locator('[name="connectionName"]').fill("Private provider");
  54  |       await form
  55  |         .locator('[name="baseUrl"]')
  56  |         .fill("https://provider.example/custom/v1/");
  57  |       await form.locator('[name="apiKey"]').fill("bad-key");
  58  |       for (const protocol of [
  59  |         "openai_responses",
  60  |         "anthropic_messages",
  61  |         "openai_chat",
  62  |       ]) {
  63  |         await selectValue(form.locator("select").nth(1), protocol);
  64  |         await expect(form.locator('[name="providerModelId"]')).toHaveValue(
  65  |           "Vendor/Exact-ID",
  66  |         );
  67  |         await expect(form.locator('[name="baseUrl"]')).toHaveValue(
  68  |           "https://provider.example/custom/v1/",
  69  |         );
  70  |         await expect(form.locator('[name="apiKey"]')).toHaveValue("bad-key");
  71  |       }
  72  |       await dialog
  73  |         .getByRole("button", { name: t("gm.test"), exact: true })
  74  |         .click();
  75  |       await expect(dialog.getByRole("status")).toHaveText(t("gm.testing.auth"));
  76  |       await form.locator('[name="apiKey"]').fill("synthetic-browser-key");
  77  |       await dialog
  78  |         .getByRole("button", { name: t("gm.test"), exact: true })
  79  |         .click();
  80  |       await expect(dialog.getByRole("status")).toHaveText(t("gm.test.ok"));
  81  |       expect(tests).toHaveLength(2);
  82  |       await dialog
  83  |         .getByRole("button", { name: t("gm.save"), exact: true })
  84  |         .click();
  85  |       await expect(dialog).not.toBeVisible();
  86  |       await expect(page.locator(".generic-model-row")).toHaveCount(2);
  87  |       expect(saves).toHaveLength(1);
  88  |       expect(tests).toHaveLength(2);
  89  |       expect(saves[0]).toMatchObject({
  90  |         provider_model_id: "Vendor/Exact-ID",
  91  |         enabled: false,
  92  |         connection: {
  93  |           protocol: "openai_chat",
  94  |           base_url: "https://provider.example/custom/v1/",
  95  |           api_key: "synthetic-browser-key",
  96  |         },
  97  |       });
  98  |       expect(saves[0]).not.toHaveProperty("is_default");
  99  |       const row = page
  100 |         .locator(".generic-model-row")
  101 |         .filter({ hasText: "Custom service" });
  102 |       await row.getByRole("button", { name: t("a.edit"), exact: true }).click();
  103 |       await expect(form.locator('[name="apiKey"]')).toHaveValue("");
  104 |       await expect(form.locator('[name="apiKey"]')).not.toHaveAttribute(
  105 |         "required",
  106 |         "",
  107 |       );
  108 |       const footer = await dialog.locator(".dialog-actions").boundingBox();
  109 |       expect(footer!.y + footer!.height).toBeLessThanOrEqual(
  110 |         page.viewportSize()!.height,
  111 |       );
  112 |       await page.screenshot({
  113 |         path: `../.planning/milestones/M002/implementation/evidence/generic-models29/edit-${info.project.name}-${lang}.png`,
  114 |         fullPage: true,
  115 |       });
  116 |       expect(
  117 |         await page.evaluate(
  118 |           () => document.documentElement.scrollWidth > innerWidth,
  119 |         ),
  120 |       ).toBe(false);
```