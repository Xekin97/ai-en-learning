# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: m002-generic-models.spec.ts >> UI29 en >> discard confirmation and revision recovery preserve deliberate edits
- Location: tests/e2e/m002-generic-models.spec.ts:52:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.fill: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('#admin-model').locator('[name="displayName"]')
    - locator resolved to <input value="" required="" maxlength="200" name="displayName"/>
    - fill("Edited name")
  - attempting fill action
    2 × waiting for element to be visible, enabled and editable
      - element is not visible
    - retrying fill action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and editable
      - element is not visible
    - retrying fill action
      - waiting 100ms
    58 × waiting for element to be visible, enabled and editable
       - element is not visible
     - retrying fill action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to main content" [ref=e4] [cursor=pointer]:
    - /url: "#admin-main"
  - banner [ref=e5]:
    - generic [ref=e6]:
      - link "WordWeave Admin" [ref=e7] [cursor=pointer]:
        - /url: /admin
        - text: WordWeave
        - generic [ref=e14]: Admin
      - generic [ref=e15]:
        - generic [ref=e16]:
          - generic [ref=e17]: Switch language
          - generic [ref=e18]:
            - combobox
            - combobox "Switch language" [ref=e19] [cursor=pointer]:
              - generic [ref=e20]: EN
        - generic [ref=e23]: Administrator
        - button "Log out" [ref=e24] [cursor=pointer]
  - main [ref=e25]:
    - generic [ref=e26]:
      - navigation "Admin" [ref=e27]:
        - link "Overview" [ref=e28] [cursor=pointer]:
          - /url: /admin
        - link "Analytics" [ref=e35] [cursor=pointer]:
          - /url: /admin/analytics
        - link "Models" [ref=e38] [cursor=pointer]:
          - /url: /admin/models
        - link "Plans" [ref=e44] [cursor=pointer]:
          - /url: /admin/plans
        - link "Users" [ref=e50] [cursor=pointer]:
          - /url: /admin/users
        - link "Growth operations" [ref=e55] [cursor=pointer]:
          - /url: /admin/growth
        - link "Messages" [ref=e60] [cursor=pointer]:
          - /url: /admin/notices
        - link "Featured presets" [ref=e65] [cursor=pointer]:
          - /url: /admin/presets
      - generic [ref=e71]:
        - generic [ref=e72]:
          - generic [ref=e73]:
            - heading "Model services" [level=1] [ref=e74]
            - paragraph [ref=e75]: Connect your model services to bring words to life.
          - button "Add custom model" [ref=e76] [cursor=pointer]
        - region "Model services" [ref=e77]:
          - article [ref=e78]:
            - generic [ref=e85]:
              - generic [ref=e86]:
                - heading "Admin model" [level=2] [ref=e87]
                - generic [ref=e88]: Enabled
              - code [ref=e89]: Demo service/mock/admin-model
              - paragraph [ref=e90]:
                - generic [ref=e91]: https://models.example/v1
                - generic [ref=e92]: OpenAI Chat Completions
                - generic [ref=e93]: ••••demo
              - paragraph [ref=e94]: Shared model
            - generic [ref=e95]:
              - button "Test connection" [ref=e96] [cursor=pointer]
              - button "Edit" [active] [ref=e97] [cursor=pointer]
              - button "Remove" [ref=e98] [cursor=pointer]
  - contentinfo [ref=e99]: Small moments of learning. Lasting ripples.
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import { readFileSync } from "node:fs";
  3   | import { selectValue } from "./select-control";
  4   | const source = JSON.parse(
  5   |   readFileSync(
  6   |     new URL(
  7   |       "../../../.planning/milestones/M002/design/copy.json",
  8   |       import.meta.url,
  9   |     ),
  10  |     "utf8",
  11  |   ),
  12  | );
  13  | for (const lang of ["en", "zh"]) {
  14  |   const t = (key: string) => source.static[lang + "." + key] as string;
  15  |   test.describe("UI29 " + lang, () => {
  16  |     test.beforeEach(async ({ context, request, baseURL }) => {
  17  |       await request.post("http://127.0.0.1:38084/api/v1/__test/admin-reset");
  18  |       await context.addCookies([
  19  |         { name: "wordweave_session", value: "admin", url: baseURL! },
  20  |         {
  21  |           name: "wordweave_ui_locale",
  22  |           value: lang === "en" ? "en-US" : "zh-CN",
  23  |           url: baseURL!,
  24  |         },
  25  |       ]);
  26  |     });
  27  |     test("configuration, protocol retention, explicit tests, save and secret-safe edit", async ({
  28  |       page,
  29  |     }, info) => {
  30  |       const errors: string[] = [];
  31  |       page.on("pageerror", (e) => errors.push(e.message));
  32  |       const tests: string[] = [];
  33  |       const saves: Record<string, unknown>[] = [];
  34  |       page.on("request", (r) => {
  35  |         if (r.url().endsWith("/admin/model-connection-test"))
  36  |           tests.push(r.url());
  37  |         if (r.url().endsWith("/admin/models") && r.method() === "POST")
  38  |           saves.push(r.postDataJSON());
  39  |       });
  40  |       await page.goto("/admin/models");
  41  |       await expect(page.locator(".generic-model-row")).toHaveCount(1);
  42  |       await expect(
  43  |         page.getByRole("heading", { name: t("gm.title"), exact: true }),
  44  |       ).toBeVisible();
  45  |       await page
  46  |         .getByRole("button", { name: t("gm.add"), exact: true })
  47  |         .click();
  48  |       const dialog = page.locator("#admin-model"),
  49  |         form = page.locator("#model-form");
  50  |       await form.locator('[name="displayName"]').fill("Custom service");
  51  |       await form.locator('[name="providerModelId"]').fill("Vendor/Exact-ID");
  52  |       await form.locator('[name="connectionName"]').fill("Private provider");
  53  |       await form
  54  |         .locator('[name="baseUrl"]')
  55  |         .fill("https://provider.example/custom/v1/");
> 56  |       await form.locator('[name="apiKey"]').fill("bad-key");
      |               ^ Error: locator.fill: Test timeout of 30000ms exceeded.
  57  |       for (const protocol of [
  58  |         "openai_responses",
  59  |         "anthropic_messages",
  60  |         "openai_chat",
  61  |       ]) {
  62  |         await selectValue(form.locator("select").nth(1), protocol);
  63  |         await expect(form.locator('[name="providerModelId"]')).toHaveValue(
  64  |           "Vendor/Exact-ID",
  65  |         );
  66  |         await expect(form.locator('[name="baseUrl"]')).toHaveValue(
  67  |           "https://provider.example/custom/v1/",
  68  |         );
  69  |         await expect(form.locator('[name="apiKey"]')).toHaveValue("bad-key");
  70  |       }
  71  |       await dialog
  72  |         .getByRole("button", { name: t("gm.test"), exact: true })
  73  |         .click();
  74  |       await expect(dialog.getByRole("status")).toHaveText(t("gm.testing.auth"));
  75  |       await form.locator('[name="apiKey"]').fill("synthetic-browser-key");
  76  |       await dialog
  77  |         .getByRole("button", { name: t("gm.test"), exact: true })
  78  |         .click();
  79  |       await expect(dialog.getByRole("status")).toHaveText(t("gm.test.ok"));
  80  |       expect(tests).toHaveLength(2);
  81  |       await dialog
  82  |         .getByRole("button", { name: t("gm.save"), exact: true })
  83  |         .click();
  84  |       await expect(dialog).not.toBeVisible();
  85  |       await expect(page.locator(".generic-model-row")).toHaveCount(2);
  86  |       expect(saves).toHaveLength(1);
  87  |       expect(tests).toHaveLength(2);
  88  |       expect(saves[0]).toMatchObject({
  89  |         provider_model_id: "Vendor/Exact-ID",
  90  |         enabled: false,
  91  |         connection: {
  92  |           protocol: "openai_chat",
  93  |           base_url: "https://provider.example/custom/v1/",
  94  |           api_key: "synthetic-browser-key",
  95  |         },
  96  |       });
  97  |       expect(saves[0]).not.toHaveProperty("is_default");
  98  |       const row = page
  99  |         .locator(".generic-model-row")
  100 |         .filter({ hasText: "Custom service" });
  101 |       await row.getByRole("button", { name: t("a.edit"), exact: true }).click();
  102 |       await expect(form.locator('[name="apiKey"]')).toHaveValue("");
  103 |       await expect(form.locator('[name="apiKey"]')).not.toHaveAttribute(
  104 |         "required",
  105 |         "",
  106 |       );
  107 |       const footer = await dialog.locator(".dialog-actions").boundingBox();
  108 |       expect(footer!.y + footer!.height).toBeLessThanOrEqual(
  109 |         page.viewportSize()!.height,
  110 |       );
  111 |       await page.screenshot({
  112 |         path: `../.planning/milestones/M002/implementation/evidence/generic-models29/edit-${info.project.name}-${lang}.png`,
  113 |         fullPage: true,
  114 |       });
  115 |       expect(
  116 |         await page.evaluate(
  117 |           () => document.documentElement.scrollWidth > innerWidth,
  118 |         ),
  119 |       ).toBe(false);
  120 |       expect(
  121 |         await page.evaluate(
  122 |           () => JSON.stringify(localStorage) + JSON.stringify(sessionStorage),
  123 |         ),
  124 |       ).not.toContain("synthetic-browser-key");
  125 |       expect(errors).toEqual([]);
  126 |     });
  127 |     test("discard confirmation and revision recovery preserve deliberate edits", async ({
  128 |       page,
  129 |       request,
  130 |     }) => {
  131 |       await page.goto("/admin/models");
  132 |       const row = page.locator(".generic-model-row");
  133 |       await expect(row).toHaveCount(1);
  134 |       await row.getByRole("button", { name: t("a.edit"), exact: true }).click();
  135 |       const dialog = page.locator("#admin-model"),
  136 |         name = dialog.locator('[name="displayName"]');
  137 |       await name.fill("Edited name");
  138 |       await dialog
  139 |         .getByRole("button", { name: t("cancel"), exact: true })
  140 |         .click();
  141 |       await page
  142 |         .locator("#model-discard")
  143 |         .getByRole("button", { name: t("gm.keep"), exact: true })
  144 |         .click();
  145 |       await expect(name).toHaveValue("Edited name");
  146 |       await request.post("http://127.0.0.1:38084/api/v1/__test/admin-conflict");
  147 |       await dialog
  148 |         .getByRole("button", { name: t("gm.save"), exact: true })
  149 |         .click();
  150 |       await expect(
  151 |         dialog.getByText(t("gm.conflict"), { exact: true }),
  152 |       ).toBeVisible();
  153 |       await dialog
  154 |         .getByRole("button", { name: t("gm.refresh"), exact: true })
  155 |         .click();
  156 |       await expect(name).toHaveValue("Edited name");
```