# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: m002-generic-models.spec.ts >> UI29 en >> configuration, protocol retention, explicit tests, save and secret-safe edit
- Location: tests/e2e/m002-generic-models.spec.ts:12:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.fill: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('#model-form').locator('[name="displayName"]')
    - locator resolved to <input value="" required="" maxlength="200" name="displayName"/>
    - fill("Custom service")
  - attempting fill action
    2 × waiting for element to be visible, enabled and editable
      - element is not visible
    - retrying fill action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and editable
      - element is not visible
    - retrying fill action
      - waiting 100ms
    46 × waiting for element to be visible, enabled and editable
       - element is not visible
     - retrying fill action
       - waiting 500ms
    - waiting for "http://127.0.0.1:3324/admin/models" navigation to finish...
    - navigated to "http://127.0.0.1:3324/admin/models"
    - waiting for element to be visible, enabled and editable
  - element was detached from the DOM, retrying
    - locator resolved to <input value="" required="" maxlength="200" name="displayName"/>
    - fill("Custom service")
  - attempting fill action
    2 × waiting for element to be visible, enabled and editable
      - element is not visible
    - retrying fill action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and editable
      - element is not visible
    - retrying fill action
      - waiting 100ms
    10 × waiting for element to be visible, enabled and editable
       - element is not visible
     - retrying fill action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - link "Skip to main content" [ref=f1e4] [cursor=pointer]:
    - /url: "#admin-main"
  - banner [ref=f1e5]:
    - generic [ref=f1e6]:
      - link "WordWeave Admin" [ref=f1e7] [cursor=pointer]:
        - /url: /admin
        - text: WordWeave
        - generic [ref=f1e14]: Admin
      - generic [ref=f1e15]:
        - generic [ref=f1e16]:
          - generic [ref=f1e17]: Switch language
          - generic [ref=f1e18]:
            - combobox
            - combobox "Switch language" [ref=f1e19] [cursor=pointer]:
              - generic [ref=f1e20]: EN
        - generic [ref=f1e23]: Administrator
        - button "Log out" [ref=f1e24] [cursor=pointer]
  - main [ref=f1e25]:
    - generic [ref=f1e26]:
      - navigation "Admin" [ref=f1e27]:
        - link "Overview" [ref=f1e28] [cursor=pointer]:
          - /url: /admin
        - link "Analytics" [ref=f1e35] [cursor=pointer]:
          - /url: /admin/analytics
        - link "Models" [ref=f1e38] [cursor=pointer]:
          - /url: /admin/models
        - link "Plans" [ref=f1e44] [cursor=pointer]:
          - /url: /admin/plans
        - link "Users" [ref=f1e50] [cursor=pointer]:
          - /url: /admin/users
        - link "Growth operations" [ref=f1e55] [cursor=pointer]:
          - /url: /admin/growth
        - link "Messages" [ref=f1e60] [cursor=pointer]:
          - /url: /admin/notices
        - link "Featured presets" [ref=f1e65] [cursor=pointer]:
          - /url: /admin/presets
      - generic [ref=f1e71]:
        - generic [ref=f1e72]:
          - generic [ref=f1e73]:
            - heading "Model services" [level=1] [ref=f1e74]
            - paragraph [ref=f1e75]: Connect your model services to bring words to life.
          - button "Add custom model" [ref=f1e76] [cursor=pointer]
        - region "Model services" [ref=f1e77]:
          - article [ref=f1e78]:
            - generic [ref=f1e85]:
              - generic [ref=f1e86]:
                - heading "Admin model" [level=2] [ref=f1e87]
                - generic [ref=f1e88]: Enabled
              - code [ref=f1e89]: Demo service/mock/admin-model
              - paragraph [ref=f1e90]:
                - generic [ref=f1e91]: https://models.example/v1
                - generic [ref=f1e92]: OpenAI Chat Completions
                - generic [ref=f1e93]: ••••demo
              - paragraph [ref=f1e94]: Shared model
            - generic [ref=f1e95]:
              - button "Test connection" [ref=f1e96] [cursor=pointer]
              - button "Edit" [ref=f1e97] [cursor=pointer]
              - button "Remove" [ref=f1e98] [cursor=pointer]
  - contentinfo [ref=f1e99]: Small moments of learning. Lasting ripples.
```

# Test source

```ts
  1   | import { test, expect } from "@playwright/test";
  2   | import { readFileSync } from "node:fs";
  3   | import { selectValue } from "./select-control";
  4   | const source = JSON.parse(
  5   |   readFileSync(
  6   |     new URL(
  7   |       "../../../.planning/milestones/M002/design/copy.json",
  8   |       import.meta.url,
  9   |     ),
  10  |     "utf8",
  11  |   ),
  12  | );
  13  | for (const lang of ["en", "zh"]) {
  14  |   const t = (key: string) => source.static[lang + "." + key] as string;
  15  |   test.describe("UI29 " + lang, () => {
  16  |     test.beforeEach(async ({ context, request, baseURL }) => {
  17  |       await request.post("http://127.0.0.1:38084/api/v1/__test/admin-reset");
  18  |       await context.addCookies([
  19  |         { name: "wordweave_session", value: "admin", url: baseURL! },
> 20  |         {
      |                                               ^ Error: locator.fill: Test timeout of 30000ms exceeded.
  21  |           name: "wordweave_ui_locale",
  22  |           value: lang === "en" ? "en-US" : "zh-CN",
  23  |           url: baseURL!,
  24  |         },
  25  |       ]);
  26  |     });
  27  |     test("configuration, protocol retention, explicit tests, save and secret-safe edit", async ({
  28  |       page,
  29  |     }, info) => {
  30  |       const errors: string[] = [];
  31  |       page.on("pageerror", (e) => errors.push(e.message));
  32  |       const tests: string[] = [];
  33  |       const saves: Record<string, unknown>[] = [];
  34  |       page.on("request", (r) => {
  35  |         if (r.url().endsWith("/admin/model-connection-test"))
  36  |           tests.push(r.url());
  37  |         if (r.url().endsWith("/admin/models") && r.method() === "POST")
  38  |           saves.push(r.postDataJSON());
  39  |       });
  40  |       await page.goto("/admin/models");
  41  |       await expect(page.locator(".generic-model-row")).toHaveCount(1);
  42  |       await expect(
  43  |         page.getByRole("heading", { name: t("gm.title"), exact: true }),
  44  |       ).toBeVisible();
  45  |       await page
  46  |         .getByRole("button", { name: t("gm.add"), exact: true })
  47  |         .click();
  48  |       const dialog = page.locator("#admin-model"),
  49  |         form = page.locator("#model-form");
  50  |       await form.locator('[name="displayName"]').fill("Custom service");
  51  |       await form.locator('[name="providerModelId"]').fill("Vendor/Exact-ID");
  52  |       await form.locator('[name="connectionName"]').fill("Private provider");
  53  |       await form
  54  |         .locator('[name="baseUrl"]')
  55  |         .fill("https://provider.example/custom/v1/");
  56  |       await form.locator('[name="apiKey"]').fill("bad-key");
  57  |       for (const protocol of [
  58  |         "openai_responses",
  59  |         "anthropic_messages",
  60  |         "openai_chat",
  61  |       ]) {
  62  |         await selectValue(form.locator("select").nth(1), protocol);
  63  |         await expect(form.locator('[name="providerModelId"]')).toHaveValue(
  64  |           "Vendor/Exact-ID",
  65  |         );
  66  |         await expect(form.locator('[name="baseUrl"]')).toHaveValue(
  67  |           "https://provider.example/custom/v1/",
  68  |         );
  69  |         await expect(form.locator('[name="apiKey"]')).toHaveValue("bad-key");
  70  |       }
  71  |       await dialog
  72  |         .getByRole("button", { name: t("gm.test"), exact: true })
  73  |         .click();
  74  |       await expect(dialog.getByRole("status")).toHaveText(t("gm.testing.auth"));
  75  |       await form.locator('[name="apiKey"]').fill("synthetic-browser-key");
  76  |       await dialog
  77  |         .getByRole("button", { name: t("gm.test"), exact: true })
  78  |         .click();
  79  |       await expect(dialog.getByRole("status")).toHaveText(t("gm.test.ok"));
  80  |       expect(tests).toHaveLength(2);
  81  |       await dialog
  82  |         .getByRole("button", { name: t("gm.save"), exact: true })
  83  |         .click();
  84  |       await expect(dialog).not.toBeVisible();
  85  |       await expect(page.locator(".generic-model-row")).toHaveCount(2);
  86  |       expect(saves).toHaveLength(1);
  87  |       expect(tests).toHaveLength(2);
  88  |       expect(saves[0]).toMatchObject({
  89  |         provider_model_id: "Vendor/Exact-ID",
  90  |         enabled: false,
  91  |         connection: {
  92  |           protocol: "openai_chat",
  93  |           base_url: "https://provider.example/custom/v1/",
  94  |           api_key: "synthetic-browser-key",
  95  |         },
  96  |       });
  97  |       expect(saves[0]).not.toHaveProperty("is_default");
  98  |       const row = page
  99  |         .locator(".generic-model-row")
  100 |         .filter({ hasText: "Custom service" });
  101 |       await row.getByRole("button", { name: t("a.edit"), exact: true }).click();
  102 |       await expect(form.locator('[name="apiKey"]')).toHaveValue("");
  103 |       await expect(form.locator('[name="apiKey"]')).not.toHaveAttribute(
  104 |         "required",
  105 |         "",
  106 |       );
  107 |       const footer = await dialog.locator(".dialog-actions").boundingBox();
  108 |       expect(footer!.y + footer!.height).toBeLessThanOrEqual(
  109 |         page.viewportSize()!.height,
  110 |       );
  111 |       await page.screenshot({
  112 |         path: `../.planning/milestones/M002/implementation/evidence/generic-models29/edit-${info.project.name}-${lang}.png`,
  113 |         fullPage: true,
  114 |       });
  115 |       expect(
  116 |         await page.evaluate(
  117 |           () => document.documentElement.scrollWidth > innerWidth,
  118 |         ),
  119 |       ).toBe(false);
  120 |       expect(
```