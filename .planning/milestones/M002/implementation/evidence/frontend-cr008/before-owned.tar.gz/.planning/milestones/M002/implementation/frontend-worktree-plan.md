---
milestone: M002
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: awaiting_user_review
result: cr005_implemented_pending_qa
---

# 前端实施计划

输入与授权：TRANSITION-M002-016 / 017 / 020，PRODUCT-03、UI-22/H01、FE-02、BE-03 及后端实施交接。当前正式角色 frontend-claire；没有待重选业务问题，不改批准产品、设计、API、后端或控制面。准确原件见 frontend-inputs.json 与 frontend-before.tar.gz。

## 当前返工：CR-005 / FE2-R05

TRANSITION-M002-020 已激活 frontend-claire，接收 [CR-005](../changes/CR-005.md) 与已修复待 QA 的后端 CR-006。依据 FE-02 §6.2，仅修复本机存储故障可继续作答/提交及重试时的草稿保护；不新增云端同步或改 UI 文案。使用现有 failed/retry 与恢复确认。

FE2-R05 开发自检完成、待 QA：已区分存储不可用与损坏记录；不可用时继续内存作答/概览/提交，恢复后先读取并确认旧草稿，保留 CAS/身份隔离和终态清理。新增 10 项单测；全量 299 项单测、生产构建上的 24 项定向浏览器回归、类型/代码/格式/边界/构建检查通过。详见 [当前验证](frontend-validation.md#cr005)和[源码/证据](evidence/frontend-cr005/manifest.json)，不据此关闭 QA 缺陷。

单工作区串行，责任为 review store、draft storage adapter、相关测试及本角色计划/报告/交接；原件与保护摘要见 [frontend-cr005/inputs](evidence/frontend-cr005/inputs.json)。不派生代理、不动后台、批准稿、QA 原件或控制面。风险 high，运行模型未切换。

## 原实施基线

沿用 [FE-02](../technical/frontend.md#delivery) 的 FE2-I01–06 / FE2-V01–20。I01–06 已完成本角色实施及开发自检，源码/证据已冻结，等待角色交接；逐项结果见 [frontend-validation.md](frontend-validation.md)。不将局部测试写成独立验收通过。

| ID | 当前落点 | 状态 |
| --- | --- | --- |
| FE2-I01 | UI22 copy/theme/icon、壳、对话框、10 秒欢迎与动画 | 已实施；三引擎开发检查通过 |
| FE2-I02 | 普通/预设生成、认证/承接、可编辑书架及日期复习 | 已实施；契约 mock 与真实服务链路通过 |
| FE2-I03 | 可改答案复习、本机 IDB CAS、临时对照和收据 | 已实施；本机恢复/双标签/丢响应开发回归通过 |
| FE2-I04 | 个人四视图、成长、道具/兑换和消息 | 已实施；对应开发回归通过 |
| FE2-I05 | 后台八模块、运营原子表单、预设独立预览 | 已实施；最终用户积分 hash 入口及后台 8 项回归通过 |
| FE2-I06 | 全局检查、生产构建、真服务、浏览器/可访问性、交接 | 开发检查与交接完成；首轮 QA 返工后待独立复验 |

## 工作区与所有权

单工作区串行，未创建 worktree 或委派代理。frontend-claire 负责 frontend/**、本计划、frontend-validation.md、frontend-implementation.md 和 frontend-* 证据；后端、批准产品/设计/API 和控制面保持受保护。没有自动提交、部署或真实 AI 调用。

原始失败日志永久保留，通过/失败及对应代码版本在验证报告和最终 manifest 定位。旧 M001 精确视觉与协议规格原路径保留，运行选择和继承映射见 frontend/tests/e2e/README.md，不机械运行已替代的旧判分接口。

## 接收验收边界

CR005/006 保持 OPEN，两个修复均待 qa-quinn 独立复验。CR001/002、CR039-L1、CR042-L1、AI-QUALITY-90 保持原状态。FE2-V04/09/13–17 的真机、人工读屏、生产代理、时序组合和独立 UIA 仍需质量角色按报告补验；不把它们清空或改成已通过。当前角色和正式阶段不由本计划修改。
