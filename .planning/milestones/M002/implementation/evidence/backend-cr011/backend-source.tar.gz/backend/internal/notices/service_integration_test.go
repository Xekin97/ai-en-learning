//go:build integration

package notices

import (
	"errors"
	"github.com/google/uuid"
	"testing"
	"wordweave/internal/platform/business"
	"wordweave/internal/testdb"
)

func TestNoticeVisibilityRevisionAndPagination(t *testing.T) {
	pool, ctx := testdb.Open(t)
	actor := testdb.Learner(t, ctx, pool)
	s := NewService(pool, []byte("test-notices-key"))
	input := Input{Title: business.Bilingual{EN: text("News")}, Body: business.Bilingual{EN: text("Full body")}, Visible: true, Remind: true}
	var ids []uuid.UUID
	for i := 0; i < 3; i++ {
		n, _, err := s.Save(ctx, actor, uuid.Nil, "", input)
		if err != nil {
			t.Fatal(err)
		}
		ids = append(ids, n.ID)
	}
	if _, err := pool.Exec(ctx, `UPDATE wordweave.platform_notices SET published_at='2026-01-01T00:00:00Z'`); err != nil {
		t.Fatal(err)
	}
	seen := map[uuid.UUID]bool{}
	var cursor *Cursor
	for i := 0; i < 3; i++ {
		rows, more, err := s.List(ctx, "en-US", true, cursor, 1)
		if err != nil {
			t.Fatal(err)
		}
		if len(rows) != 1 || seen[rows[0].ID] || more != (i < 2) {
			t.Fatalf("unstable page: %+v %v", rows, more)
		}
		n := rows[0]
		seen[n.ID] = true
		cursor = &Cursor{PublishedAt: n.PublishedAt, ID: n.ID, Remind: n.Remind}
	}
	before, rev, err := s.AdminGet(ctx, ids[0])
	if err != nil {
		t.Fatal(err)
	}
	input.Visible = false
	n, _, err := s.Save(ctx, actor, ids[0], rev, input)
	if err != nil {
		t.Fatal(err)
	}
	if !n.PublishedAt.Equal(before.PublishedAt) {
		t.Fatal("edit changed publication time")
	}
	if _, err = s.Get(ctx, ids[0], "en-US"); !errors.Is(err, ErrNotFound) {
		t.Fatalf("hidden notice visible: %v", err)
	}
	_, _, err = s.Save(ctx, actor, ids[0], rev, input)
	var conflict *business.RevisionConflict
	if !errors.As(err, &conflict) {
		t.Fatalf("stale write accepted: %v", err)
	}
	rows, _, err := s.List(ctx, "en-US", true, nil, 10)
	if err != nil || len(rows) != 2 {
		t.Fatalf("reminder visibility: %d %v", len(rows), err)
	}
}
