---
milestone: M002
stage: product-planning
role: product/to-c
agent_name: product-maya
status: draft_pending_scope
version: M002-PRODUCT-05
change_request: M002-CR-026
updated_on: 2026-10-01
---

# M002 产品交接：消息只提醒一次

本轮由 [063](../reviews/notice-once-reopen-063.md) 激活 product-maya，处理用户直接要求的 [CR026](../changes/CR-026.md)：后台按消息增加一次提醒配置，计数仅缓存用户浏览器。原 PRODUCT04 五项要求、UI24 列表改稿、UI22 已批准范围及其他一期/二期能力完整继承。

当前正文：[概览](../product/overview.md)、[CAP-210 / AC-210](../product/abilities.md#cap-210)、[DATA-205](../product/data-assets.md#data-205)、[PAGE-207/209](../product/pages/index.md#page-207)、[AI 契约](../product/ai-behavior.md)。仍为 49 个能力、25 个页面职责、32 个数据资产。需求来源和替代范围见 [D2-88](../decisions/product-decisions.md#d2-88)。

明确要求已落稿；仅 **D2-88-LOCAL-SCOPE OPEN**：同一浏览器切换账号时是否分别计数，问题已向用户提出，推荐按账号隔离。未确认前该草稿不作为完整可执行技术输入。默认关闭、逐条实际自动展示后记录、列表仍可手动查看、无服务端个人已读表等衔接规则见能力正文。

原件：[PRODUCT04 输入快照](../reviews/evidence/notice-once-063/product04-before.tar.gz)、[UI24 冻结清单](../design/evidence/M002-UI-24-manifest.json)。本轮不覆盖历史批准、失败或 UAT；未修改原型、生产代码、API/数据库方案或执行真实 AI。静态范围自检见 [PRODUCT05 检查](../product/evidence/M002-PRODUCT-05-check.json)，token unknown。

D2-89 为用户随后明确的独立文案修订，已记入概览及 CAP-210；由 designer-tony 先移除用户消息提醒标签并清理内部表达，不依赖 CR026 范围问题。产品草稿及 CR026 状态仍待该问题收敛。

CR026 下一具体动作：收到本地记录范围选择后，product-maya 收敛 CAP-210/AC-210 和 D2-88，再交 designer-tony 补后台开关/文案和可复现的单次提醒原型。CR025/026 保持 open；技术接收需覆盖配置存储与用户端消息响应，而计数留在浏览器。未决定视觉、API 字段、数据库结构或生产方案。
