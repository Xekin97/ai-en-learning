---
milestone: M002
stage: product-planning
role: product/to-c
agent_name: product-maya
status: ready_for_review
version: M002-PRODUCT-02
change_request: M002-CR-001
updated_on: 2026-09-18
---

# M002 产品版本与修订证据

## 原批准基线（历史）

TRANSITION-M002-002 的[产品批准记录](../reviews/product-planning.md)、[摘要证据](../reviews/evidence/product-gate-002.json)及[原件快照](../reviews/evidence/product-gate-002/approved-product-and-before-state.tar.gz)保持不变。旧稿为 19 项增量、16 项页面职责、76 项决定；未完整承接一期，不能将其批准解释为删掉旧需求。

## 正式回溯

用户确认后，TRANSITION-M002-003 正式返回 product-planning / product-maya，开放 M002-CR-001。见[回溯记录](../reviews/product-rollback.md)及[回溯证据](../reviews/evidence/product-rollback-003.json)。设计角色越界产品草稿已撤回，只保留过程档案，未作为本版内容输入。

## M002-PRODUCT-02（当前待审阅）

product-maya 从一期有效正文、原二期批准原件及用户后续明确要求独立重建五份正式产品文档，补齐 29 项原能力及其验收，保留 19 项二期能力；32 项数据索引（含 DATA-015 被替代索引）、25 项当前页面职责及 5 个旧页去向；新增 D2-77–80，保留原决定历史。

| 证据 | 用途与限制 |
|---|---|
| [输入快照](./evidence/M002-PRODUCT-02-inputs.tar.gz) | 修订前原件，包含 M001/M002 正式来源及产品交接/CR；不使用撤回草稿 |
| [输入与保护摘要](./evidence/M002-PRODUCT-02-sources.json) | 原件摘要、设计/历史批准/控制面保护摘要；不可冒充业务验收 |
| [可重复静态检查](./evidence/verify-product-02.py) | ID/相对链接/追踪/原二期详细规则保持及保护文件核对 |
| [检查报告](./evidence/M002-PRODUCT-02-check.json) | 机器可查范围及人工核对清单；独立新会话接续未执行，应用与 AI 未执行 |
| [审阅版本快照](./evidence/M002-PRODUCT-02-review.tar.gz) | 本次可审阅产品正文、决定、交接与检查证据的冻结副本 |
| [审阅快照摘要](./evidence/M002-PRODUCT-02-review.json) | 文件摘要及快照 SHA-256；不是批准记录 |

保护范围：M001、设计原件/UI 交接、两个历史关卡证据及工作流控制面均未由本次产品修订改动。原批准的摘要继续对应原快照；当前正文摘要更新只代表授权产品修订，不覆写旧批准。CR 保持 open，产品修订已 ready_for_review，待后续审阅/守门器登记接收；不自行关闭或切换阶段。
