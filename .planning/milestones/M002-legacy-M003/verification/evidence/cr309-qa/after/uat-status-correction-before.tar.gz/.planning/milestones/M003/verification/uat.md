---
milestone: M003
stage: verification
role: quality/base
agent_name: qa-quinn
status: awaiting_user_review
version: M003-UAT-READY-LOCAL-002-CR309
result: not_started
qa_result: pass
readiness_result: pass
date: 2026-10-13
---

# M003 用户功能验收

本地 UAT 环境已经准备并保持运行，用户验收尚未开始或接受。主入口是 <http://127.0.0.1:3014/create>；登录入口是 <http://127.0.0.1:3014/login>。页面不使用 `/zh` 路由前缀；如页面显示英文，请在页头的界面语言切换处选择“中文”。

账号只读私有文件是 `/tmp/wordweave-m003-uat-local-002/uat-accounts.json`（权限 `0600`）。其中只有 Basic、Pro、Admin 的本地用户名和密码，没有真实 API key、加密 key 或数据库凭据。游客无需登录。所有账号均通过页面上的普通用户名/密码表单登录，不依赖邮箱或验证码。

详细步骤和每步预期见 [`UAT-GUIDE.md`](evidence/uat-local-002/UAT-GUIDE.md)，反馈可直接填写 [`feedback-template.md`](evidence/uat-local-002/feedback-template.md)。

## CR-309 当前界面

3014 已按门禁授权刷新 CR-309 的四个前端生产文件并保持运行，用户数据、后端、数据库与模型配置未改。刷新后哈希4/4匹配，中文造文台的拦截式 Plan→final 冒烟通过且没有真实模型调用。

验收时，Plan、生成中的草稿和最终结果应使用同一阅读宽度；单词释义在桌面为两列、窄屏为一列。每项均按“单词 / 释义 / 用法”排列，Plan完成前持续可见，最终结果出现后再由最终释义替换。管理员预览新内容期间，上一份完整预览仍独立可见；当前配置改成中文释义时，旧预览仍显示其原生 `English` 标签，新预览完成后才显示“中文”。这部分只验功能与视觉一致性，不评判文章内容质量。

独立证据见 [`cr309-qa/after/summary.md`](evidence/cr309-qa/after/summary.md)；刷新后最小证明见 [`live-3014-smoke.json`](evidence/cr309-qa/after/live-3014-smoke.json)。

## 先做关键功能

1. 游客打开造文台，选择 `UAT 合成｜成功`、故事、简短、中文释义，依次加入 `machine`、`preclude`、`interim`、`juvenile`、`retroactive`。开始后应先看到 Plan，再看到连续正文，最后看到完整正文、标签和五个学习项。该模型免费且完全本地。
2. 用私有账号文件中的 Basic 登录并重复上述路径。完成后额度只减少一次；准备冒烟已经执行一次，因此当前 Basic 额度从 100 变为 99。
3. 用 Pro 登录。生成选项应显示 Pro；测试账号后台已配置内容审校开启、返修上限为 1，用户页面无需显示审稿轮次或上限。选择 `UAT 合成｜审校故障 Q02` 可验证已有有效稿被保留并显示审校未完成提示。
4. 用 Admin 登录并打开 <http://127.0.0.1:3014/admin/models>。编辑 `UAT local synthetic provider` 下的 `UAT 合成｜参数快照可编辑`，在高级选项修改 JSON、保存并重开，确认读回一致。保存配置不会测试连接或调用模型。
5. 在同一模型编辑框只用 Tab/Shift+Tab 与关闭操作，确认焦点留在最上层；继续编辑回到父弹窗中触发确认的控件，放弃或保存后回到同一服务商的编辑按钮。

## 合成模型与真实模型

- `UAT 合成｜成功`：正常完整链路，无外部调用或费用。
- `UAT 合成｜审校故障 Q02`：增强审校返回不可解析结果，用于确认保留最后有效稿。
- `UAT 合成｜两轮返修`：可控 issues；把 Pro 返修上限临时改为 2 后可观察两轮条件返修，完成后恢复为 1。管理接口接受 0～99；本轮实跑不得超过 2。
- `UAT 合成｜可取消等待`：只发送心跳，用于点击取消并确认没有假 Plan。
- `UAT 合成｜规划格式失败`：规划格式无效，用于确认 writer 不启动且任务明确失败。
- `UAT 合成｜参数快照可编辑`：只用于管理员参数保存与读回。
- `UAT 真实｜DeepSeek V4 Flash 0731`：真实 OpenRouter 模型，`json_schema` 且 `reasoning.enabled=false`。只有用户在造文台选择它并点击“开始生成”时才会产生真实外部请求和可能费用。准备过程没有探测或生成。

真实模型路径验收参数仍是上述五词、中文释义、故事、简短。该步骤验证参数、Plan/正文/学习字段、终态、配额与保存功能；文章好坏和模型审稿准确率不属于本功能 UAT 结论。

## 可选边界场景

先完成关键功能，再按需检查 Q02、最多两轮返修、取消、规划失败、错误 JSON 原文保留、冲突刷新、窄屏与键盘路径。既有自动功能 QA 已通过 21 项接口、10 项管线和 5 项 CR307 焦点复验，共 36 项，无需在本次 UAT 全量重跑。

## 环境控制

在产品仓库运行：

```bash
python3 .planning/milestones/M003/verification/evidence/uat-local-002/uat-control.py status
python3 .planning/milestones/M003/verification/evidence/uat-local-002/uat-control.py start
python3 .planning/milestones/M003/verification/evidence/uat-local-002/uat-control.py stop
```

`stop` 只停止本轮 3014/54872–54875 进程并保留数据库与运行目录；再次 `start` 会复用同一 UAT 数据。它不管理或修改旧 3013/54672–54675 服务。当前请保持运行，直到用户明确完成验收。

## 接受记录

- 用户执行日期：待定
- 逐项结果：待定
- 用户原文与授权编号：待定
- 保留限制是否接受：待定

QA 不代填用户结果，也不把 readiness PASS 写成用户已接受。
