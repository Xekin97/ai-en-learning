---
milestone: M003
stage: verification
role: quality/base
agent_name: qa-quinn
status: awaiting_user_review
version: M003-UAT-READY-LOCAL-002-CR309
qa_result: pass
uat_readiness: pass
user_uat: not_started
date: 2026-10-13
---

# M003 功能 QA 与 UAT 准备交接

## 当前结论

CR-306 功能 QA PASS，AC-317–322 均通过；CR-307 返修后独立 5/5 通过。CR-309 UI11 / FE3-15 定向独立QA 9项通过，刷新后的3014最小冒烟也通过。文章质量和模型审稿准确率按 [`qa-scope-policy.md`](../../../agt/qa-scope-policy.md) 不属于 QA 或本功能 UAT。

用户要求的本地功能 UAT 已准备完成，readiness PASS，但用户尚未执行或接受。入口为 <http://127.0.0.1:3014/create>，当前环境保持运行。

## 当前环境

- 前端：3014，Node 24，当前源码隔离副本，包含 CR307 最终文件及已授权刷新后的 CR309 四个生产文件。
- 后端：54873；PostgreSQL 18：54872；metrics：54874；本地合成 provider：54875。
- 新空数据库按当前全部 schema 初始化，没有迁移、复制或修改旧 UAT 数据。
- 旧 3013/54672–54675 经只读核查缺少当前 CR306 两列，不能复用；本轮控制脚本不管理它们。
- 用户登录文件：`/tmp/wordweave-m003-uat-local-002/uat-accounts.json`（`0600`，仅本地账号密码，无 provider/API/encryption key）。
- 统一控制：[`uat-control.py`](../verification/evidence/uat-local-002/uat-control.py)；停止保留本轮数据，当前不要自动停止或清理。

## Readiness 结果

[`readiness.json`](../verification/evidence/uat-local-002/readiness.json) 记录 5/5 PASS：

- 中文游客造文台可用，唯一真实 0731 对游客可见。
- Basic、Pro、Admin 均以真实页面用户名/密码登录成功；Basic N=0，Pro N=1。
- Admin 对专用 synthetic snapshot 模型完成 custom parameters 保存、读回和恢复，provider 调用增量 0。
- Basic 以五词、中文释义、Story/Brief 完成本地合成 Plan→正文→终态；2 次合成调用、额度 100→99。
- 无浏览器页面错误；未调用真实 provider。

后端、模型、角色与零调用准备证据见 [`backend-readiness.json`](../verification/evidence/uat-local-002/backend-readiness.json)。前端源码证据见 [`frontend-source-manifest.json`](../verification/evidence/uat-local-002/frontend-source-manifest.json)。准备后真实模型仍零调用见 [`post-smoke-zero-real-call.json`](../verification/evidence/uat-local-002/post-smoke-zero-real-call.json)。

## CR-309 定向结果

- 隔离修订源码：PAGE204在1440/390覆盖Plan、两次edit、pending与final；PAGE212覆盖旧lastPreview与新live preview并存、stale/publish gate和原生语言标签；PAGE216覆盖共享workspace代表路径。
- 计算样式：Plan/Result同一 `dt + dd + dd` 结构，桌面2列24px、移动1列；正文最大760px，行高桌面1.85/移动1.78。
- UAT刷新：只复制4个生产文件，4/4哈希匹配；live3014中文create拦截SSE smoke通过，quota不变、业务mutation 0、真实provider调用0。
- 证据：[`summary.md`](../verification/evidence/cr309-qa/after/summary.md)、[`results.json`](../verification/evidence/cr309-qa/after/results.json)、[`live-3014-smoke.json`](../verification/evidence/cr309-qa/after/live-3014-smoke.json)。用户仍未开始或接受UAT。

## 用户执行

向用户提交 [`uat.md`](../verification/uat.md) 和 [`UAT-GUIDE.md`](../verification/evidence/uat-local-002/UAT-GUIDE.md)。先跑无费用关键路径，再按需跑 Q02、N≤2、取消或规划失败。真实模型只有用户手动选择并点击生成时才调用；文章内容评价不记入功能 UAT PASS/FAIL。

## 既有 QA 证据

- 聚合：[`qa-summary.json`](../verification/evidence/cr306-qa/qa-summary.json)。
- 管理/安全：[`deterministic-api.json`](../verification/evidence/cr306-qa/deterministic-api.json)，21/21。
- 管线：[`deterministic-pipeline.json`](../verification/evidence/cr306-qa/deterministic-pipeline.json)，10/10。
- UI：首败 [`browser.json`](../verification/evidence/cr306-qa/browser.json)；修后 [`browser-focus-retest.json`](../verification/evidence/cr306-qa/browser-focus-retest.json)，5/5。
- 已有真实功能链路：[`real-r1.json`](../verification/evidence/cr306-qa/real-r1.json)、[`real-r2.json`](../verification/evidence/cr306-qa/real-r2.json)。

> 本交接不切换阶段、不自动运行真实模型、不宣称用户已经验收。
