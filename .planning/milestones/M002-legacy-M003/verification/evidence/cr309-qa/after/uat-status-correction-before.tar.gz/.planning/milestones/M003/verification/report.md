---
milestone: M003
stage: verification
role: quality/base
agent_name: qa-quinn
status: completed
version: M003-QA-04-CR309
result: pass
user_uat: not_started
date: 2026-10-13
---

# M003 独立 QA 报告

## 结论

CR-306 功能独立 QA **PASS**，AC-317–322 均有通过证据，可进入用户 UAT；用户尚未执行或接受。

CR-309 的 UI11 / FE3-15 定向独立 QA 也已 **PASS**。隔离修订源码实际覆盖 PAGE204 的 planning、两次增量编辑、pending 与 final，PAGE212 的旧预览保留/新实时预览/陈旧与发布门禁，以及 PAGE216 的共享 workspace。1440 与 390 两个视口的释义结构、字段映射、计算样式和正文排版符合 UIA-419–422；无真实模型调用。证据见 [`cr309-qa/after/results.json`](evidence/cr309-qa/after/results.json) 与 [`summary.md`](evidence/cr309-qa/after/summary.md)。

门禁授权后，UAT 3014 只刷新 CR-309 的四个生产文件。刷新后4/4文件哈希与实施manifest一致；中文 `/create` 用拦截SSE完成最小 Plan→final 冒烟，Plan/Result计算样式一致、额度不变、业务API mutation 0、页面错误0、真实provider调用0。后端、PG、模型配置与旧UAT未改，证据见 [`live-3014-smoke.json`](evidence/cr309-qa/after/live-3014-smoke.json)。

本结论执行用户确认的 [`QA 职责边界`](../../../agt/qa-scope-policy.md)：QA 验证参数、权限、结构、目标覆盖、调用编排、状态、配额、保存、UI与可访问性，不评判文章故事性、自然用词、语义逻辑或模型审稿准确率。此前因模型语义漏判给出的 QA FAIL 已撤销；CR-308 重分类为非阻塞模型能力观察，不要求 technical/backend 返工，也不声称模型漏判已修复。

## 功能通过结果

- AC-317/318：管理API与DB边界21/21通过。多模型参数隔离、`{}`、保存重读、权限、409、整单原子、严格JSON、重复键指针、保护/受控字段、NUL、depth8/9、16KiB/413和显式probe错误均符合合同；保存0 provider调用。
- AC-319/320：正式管线10/10通过。在途请求各阶段保持受理快照，后续请求采用新参数；N0、增强N2、固定编辑、审校/返修、Q02、围栏plan、heartbeat/cancel、一次扣次与DB终态成立。
- AC-322：首次发现CR-307焦点缺陷；返修后desktop/mobile各32次Tab+32次Shift+Tab、nested keep、discard父子同关、断开旧opener后的save/refetch精确恢复均通过，probe=0。CR-307 已由 REVIEW-M003-083 同步为 resolved。
- AC-321：唯一授权的 `deepseek/deepseek-v4-flash-0731` 使用 `json_schema / openrouter_require_parameters / reasoning.enabled=false` 完成两次正式完整业务请求。R1游客为planning+generation、`basic V1`；R2 Pro为planning+generation+fixed_edit+content_review、`review_passed V2`。两次均原生结构有效、五个目标及学习字段完整、DB终态有效、`can_save=true`、各消费一次额度，usage/cost可得；原180秒超时没有重现。

## 真实链路测量

| 样本 | 首scene plan | 首word / 全部word plan | 首正文 | 总时延 | usage | cost |
|---|---:|---|---:|---:|---|---:|
| R1 visitor | 7.722s | unknown / unknown | 14.159s | 21.362s | in3531 / out788 | 0.00068306 credits |
| R2 pro | 8.802s | unknown / unknown | 17.536s | 35.788s | in8135 / out1449 | 0.001070272 credits |

脚本未逐项持久化首word与全部word plan完成时间，因此如实记unknown，不补跑。真实请求共2次，第三次未运行。

## 模型能力观察边界

R2模型返回合法 `pass` 审校结果，后端也按合同正确处理。旧 [`real-evaluation.md`](evidence/cr306-qa/real-evaluation.md) 中的文章内容意见原样保留为历史模型能力观察；依据用户决定，它不属于QA评测，不否决AC-321功能验收，不触发prompt、模型或实现返工。`AI-QUALITY-90`不在本QA范围，不能从两个样本推导。

## 环境与清理

本轮使用新空PG18、全部当前migrations含0017、正式backend、隔离Nuxt与Chromium；没有历史迁移或部署结论。QA未改生产代码、产品/技术合同、控制面或提交。

54713与54772–54775均已关闭，QA源码副本、disposable backend/provider/PG及私有env/loader已删除，未归档secret。旧UAT端口在本轮起点已经关闭，不是本轮所停止；source Docker未触碰。回执见 [`backend-stack-cleanup.json`](evidence/cr306-qa/backend-stack-cleanup.json)。

## 保留限制

用户UAT、生产部署/容量、历史迁移、真机与人工读屏未验证。真实费用只代表两次请求，不是长期估计。文章质量和审稿准确率属于后续独立模型评测，不写QA PASS或FAIL。

CR-309 只做目标页面功能与视觉验证；Explore/Library 沿用既有样式，源范围核对确认其组件未改。开发方单测/lint与浏览器结果只作为输入，未代替本次独立 Vue 运行证据。
