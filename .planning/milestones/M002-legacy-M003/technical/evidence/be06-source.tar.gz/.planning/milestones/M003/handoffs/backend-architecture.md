---
milestone: M003
stage: technical-design
role: backend-architect/base
agent_name: backend-alex
status: awaiting_user_review
version: M003-BE-06
date: 2026-10-10
input_version: M003-PRODUCT-07 / CR-302 / M003-DB-03 / M003-BE-05-R1 / UI09-R2
---

# M003 初创容量与部署设计交接

backend-alex依 [TRANSITION-M003-043门检](../reviews/capacity-backend-handoff-042.md)及USER-M003-STARTUP-CAPACITY交付BE06。用户已委托低成本起步、常规容量参数与可升级策略；本版参数是待验证技术设计，不是实测容量/SLA/云商价格。建议awaiting_user_review/for-FE02，未修改控制面、未自批实施或激活后续角色。requested gpt-6-astra/high，actual serving metadata未知，Profile1.0/model-routing-v1不迁移。

## 本次取舍与当前原件

[容量部署主章](../technical/capacity-and-deployment.md)为BE6-C01–07规则唯一来源：2 vCPU/4GiB/40GiB单机、Go单副本；Go/PG/Nuxt/Nginx内存硬界1536/1024/512/128MiB，余896MiB宿主空间。构建在开发机/CI；APP/AI连接池各4不扩张，PG配置候选交DBA部署核验。

总容量2、preview子限1、每provider connection默认2、短预检guard2；global包含真实模型probe（单独最多1），active_generation另计。普通/预设/preview/probe共用一个即时Gate，全局与子限原子申请，不占一许可等待另一许可；不排队、不加MQ。受理前503 generation_busy须无run/charge/provider，后端COMMIT未知不冒充未受理。未知提交/结算先同Gate锁关闭准入，再释放该lease；保留最小pending事实，所有未知核对消除才重开。

两个槽不是两个在线用户；吞吐约为60×槽数/平均占槽秒数。在相同2核4GiB上，满足两个独立窗口（各≥30分钟且≥200受理）与内存/响应/上游目标后先测2→4，再考虑扩机或分离DB/前端。DEC-027和现启动全active扫描、进程内取消意味着不能直接replicas=2；跨实例owner/lease/fencing/恢复/取消/唯一结算需未来独立设计。

- [后端设计](../technical/backend.md)：现有内容/数据/实施边界及容量主章接点。
- [AI集成](../technical/ai-integration.md)：真实Plan→writer、固定editor、预算/用量/Q02保持；容量拒绝发生在任何模型调用之前。
- [API索引](../technical/api/index.md)、[生成/状态及新增忙碌合同](../technical/api/generation.md)、[管理](../technical/api/administration.md)、[预设/preview](../technical/api/presets.md)：七份现行原件及容量主章统一BE06；wire仍m003-stream-v5。

## 继承的内容与已确认显示

PRODUCT07/CR-302选择A不变：所有模式独立规划、完整实际Plan传writer；N0普通/后台basic不编辑不Review；增强N>0初稿无调用原生校验后固定编辑一次，再校验/同模型Review与条件整稿返修。正常普通2+t、增强4+2k+t次调用，全请求基础t≤2、内容N0–99（初始1、验证最多2轮）、同模型、每调用180s/全程600s、一请求一业务次数均不变。编辑救稿边界、业务版本与draft identity、有效lastValid/Q02、取消/断流/DB未知规则沿当前AI/API。

UI09-R2已获USER-M003-UI09-ACCEPTANCE确认，当前不要求重做原型。BE05-R1显示政策继续：初始规划标“初始构思，文章和实际用法可能调整”，与正文一起保留跨首稿/固定编辑/条件返修/retained/pending/EOF；仅权威valid完整Result（含Q02）到达时清规划、原子建立最终学习资源；失败/取消/新请求清临时内容。旧v5 expected.plan_hidden_on_first_edit只代表冻结历史断言，不能驱动UI或证明当前显示。

[原v5 fixture入口](../technical/fixtures/stream-v5/index.json)与[R1显示政策](../technical/evidence/be05-r1-display-policy.json)原样保留；BE06没有新SSE字段/事件/fixture，不重放旧checker当本次显示验证。UI09-R2基线见[设计交接](uiux.md)。

## frontend-bob / FE02接收合同

保留UI09-R2视觉、v5 reducer和规划保留，不自行编排审稿次数/假进度。三个生成POST统一消费API-302：仅明确503 generation_busy且context.accepted=false时显示忙碌，保留输入，按Retry-After提示后由用户显式再试；不自动POST、不造run/status/token/排队位置、不宣称发生扣次或退款。未知代理错误/网络EOF不是此明确拒绝，继续原终态核对边界。

busy失败不替换已有有效学习内容或preview ready结果；普通预设与后台preview同样适用。登录/读/status/cancel/save不占生成槽；取消按钮确认是CAS结果，不表示provider已免费停机。前端只统计点击到渲染并区分后端T0；不将50ms合并/180s/600s当首内容体验目标。产品文案无需新增业务步骤，实施时使用既有错误反馈区域。

## DBA / implementation / QA接收合同

| owner | 明确接点 |
|---|---|
| dba-diana | 本版进程准入无schema/迁移/新表变化；核验PG候选运行参数、8应用连接/20总连接预算、WAL/外部备份/原恢复窗口与删除补救。DB03对planning/fixed_edit枚举、两run版本CHECK、fixed_edit_native_invalid的既有实施依赖仍须落实，不重开DB设计或声称0017已实现 |
| backend-ethan / implementation | config/生产Compose资源与650s排空、660s容器grace；Service受理前共享Gate与once Lease、连接映射/冷却、真实probe纳入；三种POST Problem；未知提交/结算关栅栏先于释放、保留最小pending；main先停新准入再保留控制接口排空；Nginx三路SSE禁buffer/cache/gzip。当前代码尚无BE06实现；现BE02待审源码不能作为已交付证明 |
| frontend-bob | FE02接收本节、API-302/304、UI09-R2与BE05-R1显示政策；不把旧UI07-R1“制作原型”当当前指令 |
| QA | 后续有限provider stub验证准入原子性、上限/释放、控制响应、拒绝不建run不扣次、停机/未知栅栏；offered与admitted分别记。快503不能进入生成P95；未首内容/未完成的已受理样本计未达标；Q02交付与增强完成分别报告。真实模型速度/费用仍待授权，流程最多2轮，99仅静态 |
| product-maya / designer-tony | 本次维持PRODUCT07和已确认UI09-R2；容量/忙碌提示无需新增内容能力。保留CR-302全局依赖，不越权改产品/UI原件 |

## 检查、冻结与未验证项

本次只做文档版本、资源数字、错误封套/入口、链接、16行v5事件schema及保护hash静态核对：[输入基线](../technical/evidence/be06-before.json)、[有限checker](../technical/evidence/be06-check.py)、[结果](../technical/evidence/be06-check.json)。没有真实模型/新质量批次/Go或DB测试/浏览器/应用压测/部署；CPU/RSS、首规划/首正文/完成P95、备份恢复及云费用均未测。SLO目标和升级触发只是初值，样本不足须明示。

当前交付冻结：[BE06源包](../technical/evidence/be06-source.tar.gz)、[逐文件manifest](../technical/evidence/be06-source-manifest.json)。上一基线[control038 BE05-R1源包](../reviews/evidence/control-038/M003-BE-05-R1-source.tar.gz)及其manifest、v3/v4/v5、control042的851源保留；旧包sha256=83ae1df2b695b13eeaf5e6b0476fdac0bb235d3917dd405ec528acefc4387ddd。旧内容/显示证据只按各自范围解释。

下一步由主会话审核本设计并依法接交FE02；不是批准现在实施或自动切阶段。继续保留质量/费用/延迟、CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX等既有未验证项。
