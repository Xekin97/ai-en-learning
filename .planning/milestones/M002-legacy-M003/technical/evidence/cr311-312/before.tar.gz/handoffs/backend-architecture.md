---
milestone: M003
stage: technical-design
role: backend-architect/base
agent_name: backend-alex
status: awaiting_user_review
version: M003-BE-07
date: 2026-10-12
input_version: M003-PRODUCT-09 / TECH03 / BE06-R1 / API-AI BE06
---

# CR-306 后端交接：每模型自定义请求参数

backend-alex依[069独立门禁](../reviews/cr306-custom-product-gate-069.md)完成定向设计，可交独立接收后接续DBA。**没有当前业务阻塞；未实施、未真实复验、未批准新视觉或下游阶段。** workflow不由本交接改变。采用锁定[Profile1.0](../reviews/evidence/start/locked-profile.yaml)，requested gpt-6-astra/high、actual serving/usage unknown，未改路由锁。

## 输入与确认范围

[PRODUCT09](product.md)、[CAP-306/AC-317–322](../product/abilities.md#cap-306)、[DATA-306](../product/data-assets.md#data-306)及[USER-M003-CUSTOM-PARAMETERS](../reviews/requirements-feedback.md#cr-306-自定义请求参数简化user-m003-custom-parameters)确认每模型JSON、空{}无扩展、保护业务/凭据、保存0调用。JSON细节/持久化/合并是本角色授权内定稿，无须用户逐字段再确认。先前模式/强度/能力目录方案已撤销，未提交稿冻结于[068包](../reviews/evidence/cr306-control-068/unsubmitted-backend-typed-draft.tar.gz)，不可实施。

继承TECH03已实施的Plan→writer、增强固定编辑/审稿、基础2与内容N0–99、同模型/Q02/一次扣次/180秒每调用和600秒全请求、流式/容量及既有QA边界。[真实故障与三次诊断](../verification/model-reasoning-research.md)只证明180秒规划失败退款及off围栏等问题；不是完整成功。本次没有付费调用、改UAT配置、停止3013服务或访问/迁移数据库。

## 当前原件与技术取舍

- [后端BE7及DB接点](../technical/backend.md#be7-cr306)：复用现DTO/BindSpec/Gateway；模型一份JSONB、两run一份安全快照，不建目录/新平台。
- [API-306](../technical/api/administration.md#api-306)：custom_parameters必填对象；16KiB/深度8/重复键与数值边界；保护列表与顶层不相交合入；单项/batch/聚合原子保存、读写/测试错误。允许保护列表外平台扩展，不做仅reasoning白名单。
- [AI7](../technical/ai-integration.md#ai7-reasoning)：三协议同位置原样透传；各阶段同私有快照；OR业务json_schema用服务端require_parameters约束实际端点，其他协议不注入；不去围栏/不暗换模型/不删参数重试。空{}不追加自定义键；OR schema路由是单列业务格式修复，已在API/fixture明确。
- [生成](../technical/api/generation.md#api-306-generation)、[预设](../technical/api/presets.md#api-306-preview)、[API索引](../technical/api/index.md#api-306-index)：公开wire不变，非法保存配置受理前拒绝，真实上游拒绝/无内容沿现失败/Q02/取消/结算。
- [完整fixtures](../technical/fixtures/cr306/index.json)：服务商与模型整页GET、保存/显式probe、JSON错误/冲突、无内容等待/失败/取消/pending和预览失败；三协议透传/请求快照样例。均合成，不能宣称运行PASS。

不引入更短首内容硬超时：当前诊断不足以确定新阈值，先修参数与格式路由；180/600有限期限继续执行且不重置。真实首完整plan项/安全正文分别计时，无内容为null，推理绝不投影给用户。成本/速度改善仍待完整复验。

## 接收人与完成条件

| 下一责任人 | 精确输入与需完成事项 |
|---|---|
| dba-diana / CR306-DB | BE7-DB：ai_models.custom_parameters对象及两个run版本化安全快照；默认{}、对象/边界/不变性、原CAS/受理原子性、删除权限。明确DB CHECK与服务验证分工，修未发布schema并隔离空库验证，不升级或重置现UAT |
| designer-tony / CR306-UI | API306＋fixtures：完整PAGE208高级JSON编辑、{}说明、受保护/格式/保存冲突、短测试反馈；现PAGE204/216/212等待失败可取消。沿现design/prototype/index.html入口与M002正式视觉，新视觉须用户评审 |
| frontend-bob / CR306-FE | 待新视觉接收；新增对象schema/mapper、重复键感知编辑文本校验、服务端安全field_errors、草稿/版本合并、测试状态随配置失效；勿加能力目录或后台自动调用 |
| backend-ethan / CR306-IMPL | 获门禁后按BE7源码表/DBA真源落地；统一校验与浅合入，所有模型写入口、Probe、BindSpec覆盖；末阶段安全快照与原失败/结算回归 |
| qa-quinn / CR306-QA | BE7-V对应AC317–322：确定性边界/原子性/三协议/快照/无内容、独立页面，再按已有授权有界真实原失败样本及增强/预设链路；流程返修最多2、99静态。用户UAT另行完成 |

## 整理、自检与未验证

只定向维护本角色7份原件及CR后端处理段，已接收BE06-R1/API-AI BE06七原件与归档由[067清单](../reviews/evidence/cr306-control-067/backend-before-manifest.json)恢复；已核冻结tar及7文件hash，未覆盖。typed候选只在068历史包。稳定业务ID/wire/预算保留，当前新增字段唯一定义API306；没有新控制面真源。

静态检查原件：[check.py](../technical/evidence/cr306/check.py)、[check.json](../technical/evidence/cr306/check.json)、[source-manifest.json](../technical/evidence/cr306/source-manifest.json)。覆盖本轮字段/fixture/新链接、冻结hash、JSON形状与合成失败事件；计量分别记录产物字符数与静态输入引用范围字符数，不冒充实际累计输入；运行tokens/累计输入unknown。没有Go/API/SQL/浏览器/真实模型测试，新会话交接未测；静态通过不能代表AC317–322完成。没有提交或部署。

CR306-DB接收时补充唯一存储边界：API306对所有层级键/字符串值中的U+0000返回安全422/unsupported_character，不做有损替换，其他Unicode规则保持。仅定向静态核对见[u0000-check.json](../technical/evidence/cr306/u0000-check.json)，修订前原件与旧manifest保留于[u0000-before.tar.gz](../technical/evidence/cr306/u0000-before.tar.gz)；原131项检查仍只证明其当时版本，本次没有重跑全面检查或SQL测试。

实施接收时补充[API306统一紧凑字节算法](../technical/api/administration.md#api306-compact-bytes)：JSON.stringify同等Unicode/数字序列化，明确<>&、U+2028/U+2029及数学安全整数的`.0`/指数边界，原16KiB/范围不变。共享[向量](../technical/fixtures/cr306/compact-byte-vectors.json)与[定向证据](../technical/evidence/cr306/compact-bytes-check.json)供BE/FE交叉验证；修订前原件/旧manifest保留于[compact-bytes-before.tar.gz](../technical/evidence/cr306/compact-bytes-before.tar.gz)。未重跑全面检查，也未替应用实现验收。

CR-306仍open；DB接收、新视觉/用户评审、FE、实施、独立QA、完整真实链路与用户UAT均未完成。原CR-302、CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX保留，不因设计交付关闭。无需新增业务决定；遇到新供应商策略/费用或业务范围扩展才回产品。
