---
milestone: M003
stage: technical-design
role: frontend-architect/base
agent_name: frontend-bob
status: accepted_for_implementation
version: M003-FE-03
clarification: API306-compact-bytes owner support / 2026-10-12
current_addendum: M003-FE-CR310 / FE3-16 / 2026-10-13
current_addendum_status: awaiting_submission_review
date: 2026-10-12
input_version: M003-PRODUCT-09 / M003-BE-07 / M003-DB-04 / M003-UI-10-R1.1 (R1 visual accepted)
---

# CR-310 当前前端架构接收

frontend-bob 已依 [092](../reviews/cr310-technical-entry-gate-092.md)完成 UI12 最小接收，待独立提交检查。确认来源为 [USER-M003-REGENERATE-CONFIRM-20261013](../reviews/requirements-feedback.md#user-m003-regenerate-confirm-20261013)，没有新业务问题或上游阻塞。请求路由/已锁Profile保持，actual model/usage unknown。

- 实施唯一入口：[FE3-16 / FE3-V21](../technical/frontend.md#fe3-cr310)，对应UIA423–426及QA既有Q1–Q10。Claire获激活后改GenerationWorkspace、generation store的必要成功/归属与快照边界、同步copy和局部dialog CSS；不改AppDialog/BE/DB/API/AI。
- 核心修正：valid解锁普通输入而离页保护保留；旧标题只读result；同一Generate触发再生成确认；取消保留两份内容。discard的void/stale resolve不构成成功，必须核成功凭据、旧run/session/current state与组件动作归属后，仅一次generate冻结请求。
- save/claim、确认放弃与离页操作互斥；失败零新POST；pending从UI及store两层禁止新生成；预设只读和published snapshot保持。成功放弃后的新生成失败不可宣称旧结果仍保留。
- UI12原型/copy/实际源码已读，冻结源12/12 hash匹配；本角色无产品测试/浏览器运行。尚待Claire实现与V21、独立QA及授权内UAT刷新；本交接不自批或迁阶段。用户已授权该局部修正，不重复征询。
- 只修改两份FE文档的当前增量，旧FE03/CR309稳定ID和原文保留；CR309已通过的状态以092及现行QA入口为准。没有UAT/控制/产品代码改动，token计量未知。

## CR-309 接收原文（已完成，未改合同保留）

`frontend-bob / 2026-10-13`：已完成 UI11 的受限技术接收，待独立提交检查。入口为 [087](../reviews/cr309-technical-entry-gate-087.md)和 [CR-309](../changes/CR-309.md)，授权为 [USER-M003-GENERATION-VISUAL-CONSISTENCY-20261013](../reviews/requirements-feedback.md#user-m003-generation-visual-consistency-20261013)。不重复征询已确认的一致性方向；UI11用户接受/UAT均未被代批。Profile仍锁定1.0，requested gpt-6-astra/high、actual unknown。

## 当前交付与下一动作

- 唯一实施合同：[technical/frontend.md 的 FE3-15 / FE3-V20](../technical/frontend.md#fe3-cr309)。UIA419–422覆盖PAGE-204/216与PAGE-212预览；既有TECH04/FE03及CR306/307合同、证据保留，不需新的后端、数据库或跨层架构工作。
- `frontend-claire` 获激活后只新增 `GenerationVocabularyList.vue`，修改 `GenerationWorkspace.vue`、`pages/admin/presets.vue` 和M003局部CSS；Plan与Result分别投影entry/meaning/usage，保留独立来源与权威边界。先核代表生成区，再接后台同组件；不改Explore/Library或原PresetWordMeanings。
- 实际源发现并已在FE3-15约束：后台lastPreview词义可与新live Plan同时存在，须保持独立旧结果和原stale/ready行为；生成中article内缩与后台缺少result-body用局部容器修正，禁止全局CSS变更。
- 来源：[UI11规格](../design/design-spec.md)、[设计交接](uiux.md)、[冻结manifest](../design/evidence/cr309/M003-UI-11-source-manifest.json)。只读hash接收16项一致；第17项CR309只有087迁移owner_stage差异，已对照tar确认。未复跑设计浏览器，未新增产品测试结论；UI11原型PASS不替代Vue/QA。
- 未决关键假设/阻塞：无。待完成：Claire实现与FE3-V20结构/功能/视觉复验，qa-quinn独立复验，再按既有授权更新UAT3014；本角色不动UAT、真实模型、数据或控制状态。QA范围不含文章质量。
- 文档维护：本次仅在两份FE原件增加当前入口，FE3-01–14/V01–19和下方旧交付全文保留；旧交接的“CR306仍open/未实施”只描述当时，不覆盖现行已完成事实。无冻结证据覆盖或归档迁移。planning读取超软预算因核对既有合同与实际接点，未全读历史；token/usage未知，未执行新会话交接测试。

## 已接受 CR-306 FE03 交接原文（历史恢复与未改合同）

frontend-bob 的 [FE03原始方案](../technical/frontend.md)已由076接收，TECH04按077进入backend-ethan实施；本次仅作API306紧凑字节合同的owner接收同步。本交接不切阶段、不启动实现；CR-306仍open，真实修复未验证。采用锁定Profile1.0与model-routing-v1；requested frontier/gpt-6-astra/high，actual serving/usage unknown。

## 输入与需求确认闭环

- [PRODUCT09](product.md)、[BE07](backend-architecture.md)/[API-306](../technical/api/administration.md#api-306)/AI7、[DB04](database.md)、[UI10-R1](uiux.md)，原TECH03/FE02实施及[独立QA](../verification/report.md)作为未受影响业务基线。
- [USER-M003-CUSTOM-PARAMETERS](../reviews/requirements-feedback.md#cr-306-自定义请求参数简化user-m003-custom-parameters)确认每模型JSON、空{}、保护字段、保存0调用；[UI10-MODAL-REWORK](../reviews/requirements-feedback.md#cr-306-设计退回保留真实弹窗并对前端实现负责user-m003-ui10-modal-rework)要求现有AppDialog；[UI10R1-NEXT](../reviews/requirements-feedback.md#cr-306-接收修订设计并进入前端架构user-m003-ui10r1-next)已接受展示的R1。
- [075独立门禁](../reviews/cr306-frontend-entry-gate-075.md)已激活本角色；074仅是设计提交检查，075才是本次接收授权。R1提交时的“待评审”已由075闭环，R1.1原件继承当前接受范围；旧UI10被否定及原13项局部证据继续失效。
- 没有新增业务/供应商/成本约束或待用户决定的关键假设。代码拆分、严格解析、错误定位为已确认范围内专业细化。设计文案合同缺口已由designer-tony以R1.1补齐并接收（见下方）；FE未代写其copy。

## 本次产物与实施接点

- 唯一当前真源：[technical/frontend.md](../technical/frontend.md)。FE3-01–10/T01–06/V01–13稳定ID保留并纠正旧“delta尚未实施”事实；新增FE3-11–14和V14–19。未重开全M003，也未要求将既有内联阅读区重构成未落地的拟议组件。
- FE3-11精确接通`models/ports → admin schema → mapAdminModelDto/provider mapper → api-repository modelBody/provider/batch → model/provider draft → admin store → models.vue`。所有模型读写/probe必填custom_parameters；公共生成/选项/RunSnapshot无此字段。当前真正模型仓储为api-repository，不能误改仅负责计划/removal的admin-configuration-repository。
- 每条modelEntryDraft拥有raw；完整词法/重复键/数值/代理/NUL/深度/compactUTF8校验后才形成对象。server最终强制；客户端不造供应商支持矩阵，也不把原型JSON.parse/空值默认当实现。错误按发出请求的entry顺序及稳定ID定位，空field/413整单，server不提供的行列不虚构。
- FE3-12逐项映射AppDialog的props/slots/events、showModal/feedback stack、header/body/footer、dirty确认/精确opener；多模型增删/版本合并保留raw，远端删除不静默丢正在编辑文本。typed最大输出与output mode仍单一权威。
- probe显式、冻结目标快照、30秒/256由后端保证；编辑使旧结果stale且隔离晚回调。合法JSON无需probe即可保存，保存0模型调用。真实成功只认保存响应/读回，不认本地toast。
- FE3-13仅增加BE07确定未受理503 generation_unavailable/context.accepted=false与5条失败fixture；保留v5、Plan直到完整valid、取消/pending/Q02/一次业务扣次/预览关联、CR304/305已修行为。不加假进度或私有推理，不把配置变更追溯成在途run失效。

## UI接收与证据边界

已读R1原型源、copy/theme、交互、响应式、AppDialog/models.vue/model-provider草稿源码以及[R1 manifest](../design/evidence/cr306-r1/M003-UI-10-R1-source-manifest.json)/[真正模态证据](../design/evidence/cr306-r1/modal-rework-browser.json)。R1要求:modal、背景隔离、只body滚动、固定头尾、叠层焦点和精确返回；FE3-V18对实际Vue再验，不能仅检查[open]或复用原型PASS。

复用现sync-design/locale生成与M002 CSS、AppSelect、图标和页壳，仅加入JSON局部样式/准确文案。1440/390代表布局、手机354px观察值及稳定key label/error映射见FE3-12。原型query、fixtures、timer、直接close保存/假probe不进入生产。有限浏览器预算、针对性单测和BE/DB证据分工在V14–19；本角色没有执行产品测试或重新启动浏览器。

已接收[R1.1合同勘误manifest](../design/evidence/cr306-r1-clarification/M003-UI-10-R1.1-contract-clarification-manifest.json)与[6项有限检查](../design/evidence/cr306-r1-clarification/copy-contract-check.json)：新增`cr306.error.request_too_large`，模板`cr306.error.too_large {limit}`和`cr306.custom.size {count}/{limit}`；`count`无效时为“—”，limit分别按源展示16 KiB或含16,384字节的双语格式。修订`cr306.custom.empty/gm.test.note/cr306.probe.rejected/cr306.probe.stale`，明确空文本非法、固定256与无需先probe保存。模型配置只影响新run，现preview资格仍按API。源与增量包hash已核，R1原包保持；上述6项是owner证据，本角色只作静态接收，无新产品浏览器结论。

## 文档维护与静态自检

- 本次只接收[API306字节算法](../technical/api/administration.md#api306-compact-bytes)及[共享向量](../technical/fixtures/cr306/compact-byte-vectors.json)。frontend-claire在`application/admin/custom-parameters.ts`严格解析后调用`TextEncoder().encode(JSON.stringify(value)).byteLength`，连同admin schema/草稿提交入口执行FE3-T01/T03、V14；13个值/5个边界配方/3个数值拒绝同源消费。`.0`/指数不能绕过数学安全整数检查，非整数归一后成为整数也须安全；Unicode不额外HTML转义，不引入JCS排序。无语义冲突，不改UI/API或生产代码。
- 本次[变更前与当前源清单](../technical/evidence/cr306-fe/compact-bytes/source-manifest.json)和[定向检查](../technical/evidence/cr306-fe/compact-bytes/check.json)独立保存；下方原63项/manifest/包只代表之前交付，不被重跑或覆盖。BE已有25项为owner静态证据，本次未运行应用/DB/浏览器/真实模型验证。

- [FE02修订前恢复包](../reviews/evidence/cr306-frontend-entry-075/M003-FE-02-before-cr306.tar.gz)及[manifest](../reviews/evidence/cr306-frontend-entry-075/frontend-before-manifest.json)保持；旧FE01/设计失败/实施/QA证据不覆盖。
- FE03：[check.json](../technical/evidence/cr306-fe/check.json)、[检查脚本](../technical/evidence/cr306-fe/check.py)、[source-manifest.json](../technical/evidence/cr306-fe/source-manifest.json)、[source.tar.gz](../technical/evidence/cr306-fe/source.tar.gz)。只核版本/稳定ID/引用/源码接点、上游与冻结包hash、限定保护范围；不是产品测试或独立门检。
- 保护范围为现源码/测试、专业原件、控制及冻结设计共655个基线文件；本角色只修改两FE原件、CR306前端段与本证据目录。并行设计owner授权澄清单列归属，不归为FE写入，也不回滚他人变化。无生产代码、工作流、UAT/真实配置修改，无提交或部署。
- 同口径两FE原件字符数在check记录；静态引用字符数不冒充累计输入/tokens。planning超软预算因严格边界与现有多路径需要定向读取，未全量读历史；新会话交接测试未执行，actual serving/usage unknown。

## 未决与下一接点

当前无业务或owner合同BLOCKED，R1.1合同文字已接收；CR306新代码、V14–19、BE/DB确定性合同和AC321完整真实效果均未验证。保留CR-302 downstream pending、CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX，未替用户UAT。

当前backend-ethan依077实施BE7/DB4，主角色与流程不变；后续frontend-claire获激活后按FE3-T01→T03/T02→T04/T05→T06接配套实现和必要证据，qa-quinn独立验收。每项完成条件已在原方案，不能用设计静态PASS代替真实API/DB/模型修复。现有UAT服务/配置不动，USER-M003-NO-DATA-MIGRATION继续限制为空库初始化验证。
