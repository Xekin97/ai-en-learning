package httpapi

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"wordweave/internal/ai"
	"wordweave/internal/capacity"
	"wordweave/internal/generation"
)

func capacityServer(t *testing.T) *Server {
	t.Helper()
	gate, err := capacity.New(capacity.Config{
		Global: 5, Preview: 1, Probe: 1, Preflight: 5, Connection: 5,
		RetryAfter: 7 * time.Second, DefaultConnectionGroup: "test",
	})
	if err != nil {
		t.Fatal(err)
	}
	service := generation.NewService(nil, nil, nil, nil, time.Minute, ai.Validator{})
	service.SetCapacityGate(gate)
	return &Server{generation: service}
}

func TestGenerationBusyProblemIsExplicitlyNotAccepted(t *testing.T) {
	server := capacityServer(t)
	recorder := httptest.NewRecorder()
	request := httptest.NewRequest(http.MethodPost, "/api/v1/generations/stream", nil)
	server.writeGenerationProblem(recorder, request, capacity.ErrBusy)
	if recorder.Code != http.StatusServiceUnavailable || recorder.Header().Get("Retry-After") != "7" {
		t.Fatalf("status=%d retry-after=%q", recorder.Code, recorder.Header().Get("Retry-After"))
	}
	var problem struct {
		Code    string `json:"code"`
		Context struct {
			Accepted bool `json:"accepted"`
		} `json:"context"`
	}
	if err := json.Unmarshal(recorder.Body.Bytes(), &problem); err != nil {
		t.Fatal(err)
	}
	if problem.Code != "generation_busy" || problem.Context.Accepted {
		t.Fatalf("unexpected problem: %+v", problem)
	}
}

func TestAdminProbeBusyUsesSameCapacityProblem(t *testing.T) {
	server := capacityServer(t)
	recorder := httptest.NewRecorder()
	request := httptest.NewRequest(http.MethodPost, "/api/v1/admin/model-connections/probe", nil)
	server.writeAdminProblem(recorder, request, capacity.ErrBusy)
	if recorder.Code != http.StatusServiceUnavailable || recorder.Header().Get("Retry-After") != "7" {
		t.Fatalf("status=%d retry-after=%q body=%s", recorder.Code, recorder.Header().Get("Retry-After"), recorder.Body.String())
	}
}
