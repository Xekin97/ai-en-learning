<script setup lang="ts">
type VocabularyItem = {
  entry: string;
  meaning: string;
  usage: string;
};

const props = defineProps<{
  items: readonly VocabularyItem[];
  variant: "plan" | "result";
  heading?: string;
  languageLabel?: string;
  ariaLabel?: string;
}>();
</script>

<template>
  <section
    class="preset-meanings m003-vocabulary-panel"
    :class="
      props.variant === 'plan' ? 'm003-plan-meanings' : 'm003-result-meanings'
    "
    :aria-label="props.ariaLabel || props.heading"
  >
    <div
      v-if="props.heading || props.languageLabel"
      class="preset-meanings-head section-head"
    >
      <h3 v-if="props.heading">
        <AppIcon name="book-open-text" />{{ props.heading }}
      </h3>
      <span v-if="props.languageLabel">{{ props.languageLabel }}</span>
    </div>
    <dl class="m003-vocabulary-list">
      <div
        v-for="item in props.items"
        :key="item.entry"
        :data-plan-kind="props.variant === 'plan' ? 'word_use' : undefined"
        :data-plan-entry="props.variant === 'plan' ? item.entry : undefined"
      >
        <dt lang="en">{{ item.entry }}</dt>
        <dd>{{ item.meaning }}</dd>
        <dd class="muted" lang="en">{{ item.usage }}</dd>
      </div>
    </dl>
  </section>
</template>
