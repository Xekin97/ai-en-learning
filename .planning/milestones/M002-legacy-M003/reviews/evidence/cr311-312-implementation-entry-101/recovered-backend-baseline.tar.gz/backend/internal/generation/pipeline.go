package generation

import (
	"context"
	"errors"
	"sync"
	"time"
	"unicode"
	"unicode/utf8"

	"github.com/google/uuid"

	"wordweave/internal/ai"
	"wordweave/internal/entitlement"
)

const (
	OutcomeBasic             = "basic"
	OutcomeReviewPassed      = "review_passed"
	OutcomeRepairedPassed    = "repaired_passed"
	OutcomeLimitFinalized    = "limit_finalized"
	OutcomeServiceIncomplete = "service_incomplete"
)

type PipelineResult struct {
	Version    int
	Candidate  ai.Candidate
	Batch      ai.ValidatedBatch
	Outcome    string
	StopReason *string
}

type PipelineEdit struct {
	DraftID        string `json:"draft_id"`
	ContentVersion int    `json:"content_version"`
	BaseRev        int    `json:"base_rev"`
	Rev            int    `json:"rev"`
	At             int    `json:"at"`
	DeleteCount    int    `json:"delete_count"`
	Insert         string `json:"insert"`
	Source         string `json:"source"`
}

type pipelineExecutionError struct {
	phase string
	err   error
}

func (err *pipelineExecutionError) Error() string { return err.err.Error() }
func (err *pipelineExecutionError) Unwrap() error { return err.err }

func pipelineFailure(phase string, err error) error {
	if err == nil {
		return nil
	}
	return &pipelineExecutionError{phase: phase, err: err}
}

func PipelineFailurePhase(err error) string {
	var execution *pipelineExecutionError
	if errors.As(err, &execution) {
		return execution.phase
	}
	return "pipeline"
}

type PipelineHooks struct {
	Progress      func(phase string) error
	PlanItem      func(planID string, item ai.PlanItem) error
	Edit          func(PipelineEdit) error
	Review        func(version int, review ai.Review, repairRequested bool) error
	ReviewFailure func(version int) error
}

type validPackage struct {
	version   int
	candidate ai.Candidate
	batch     ai.ValidatedBatch
}

func ExecutePipeline(ctx context.Context, provider ai.Provider, validator ai.Validator, spec ai.GenerationSpec, policy entitlement.ContentService, hooks PipelineHooks) (PipelineResult, error) {
	execution, cancel := context.WithTimeout(ctx, 600*time.Second)
	defer cancel()
	v5, ok := provider.(ai.ContentV5Provider)
	if !ok {
		return PipelineResult{}, pipelineFailure("pipeline", errors.New("provider does not implement m003 content v5 tasks"))
	}
	contentProvider, ok := provider.(ai.ContentProvider)
	if policy.ContentReviewEnabled && !ok {
		return PipelineResult{}, pipelineFailure("pipeline", errors.New("provider does not implement content review"))
	}
	budget := ai.NewRepairBudget(entitlement.NativeCorrectionLimit)
	editor := newPublicEditor(hooks.Edit)
	planID := uuid.NewString()

	callCtx, callCancel := boundedCall(execution)
	callCtx = ai.WithInvocationObserver(callCtx, func() error {
		if hooks.Progress != nil {
			return hooks.Progress("planning")
		}
		return nil
	})
	plan, err := v5.Plan(callCtx, spec, func(item ai.PlanItem) error {
		if hooks.PlanItem == nil {
			return nil
		}
		return hooks.PlanItem(planID, item)
	})
	callCancel()
	if err != nil {
		return PipelineResult{}, pipelineFailure("planning", err)
	}

	callCtx, callCancel = boundedCall(execution)
	callCtx = ai.WithInvocationObserver(callCtx, func() error {
		if hooks.Progress != nil {
			return hooks.Progress("composing")
		}
		return nil
	})
	stream, err := v5.OpenPlanned(callCtx, spec, plan)
	if err != nil {
		callCancel()
		return PipelineResult{}, pipelineFailure("provider_open", err)
	}
	initialAttempt := editor.Begin(1, "provider", callCancel)
	var candidate1 ai.Candidate
	if policy.ContentReviewEnabled && policy.ContentRepairLimit > 0 {
		candidate1, err = stream.Receive(callCtx, initialAttempt.Add)
	} else {
		candidate1, err = receiveWithNativeProjection(callCtx, callCancel, provider, validator, spec, stream, editor, initialAttempt, budget)
	}
	_ = stream.Close()
	if policy.ContentReviewEnabled && policy.ContentRepairLimit > 0 {
		if closeErr := initialAttempt.Close(); closeErr != nil {
			err = closeErr
		}
	}
	callCancel()
	var editable *ai.EditableCandidateError
	if policy.ContentReviewEnabled && policy.ContentRepairLimit > 0 && errors.As(err, &editable) {
		err = nil
	}
	if err != nil {
		return PipelineResult{}, pipelineFailure("provider_receive", err)
	}
	if !policy.ContentReviewEnabled || policy.ContentRepairLimit == 0 {
		batch, validateErr := validator.Validate(execution, spec, candidate1)
		if validateErr != nil {
			return PipelineResult{}, pipelineFailure("validation", validateErr)
		}
		if hooks.Progress != nil {
			if err := hooks.Progress("finalizing"); err != nil {
				return PipelineResult{}, pipelineFailure("delivery", err)
			}
		}
		return pipelineFinal(validPackage{version: 1, candidate: candidate1, batch: batch}, OutcomeBasic, ""), nil
	}

	var last *validPackage
	var draft ai.EditorDraft
	if editable != nil {
		draft = editable.Draft
	} else if batch, validateErr := validator.Validate(execution, spec, candidate1); validateErr == nil {
		value := validPackage{version: 1, candidate: candidate1, batch: batch}
		last = &value
		draft, err = ai.EditorDraftFromCandidate(candidate1, nil)
	} else {
		draft, err = ai.EditorDraftFromCandidate(candidate1, validateErr)
	}
	if err != nil {
		return PipelineResult{}, pipelineFailure("validation", err)
	}

	if err := execution.Err(); err != nil {
		return finishContentFault(execution, editor, last, err, false, false, hooks)
	}
	callCtx, callCancel = boundedCall(execution)
	callCtx = ai.WithInvocationObserver(callCtx, func() error { return nil })
	fixed, err := v5.OpenFixedEdit(callCtx, spec, draft)
	if err != nil {
		callCancel()
		return finishContentFault(execution, editor, last, err, true, false, hooks)
	}
	fixedAttempt := editor.Begin(2, "provider", callCancel)
	candidate2, fixedErr := receiveWithNativeProjection(callCtx, callCancel, provider, validator, spec, fixed, editor, fixedAttempt, budget)
	_ = fixed.Close()
	callCancel()
	if fixedErr != nil {
		return finishContentFault(execution, editor, last, fixedErr, true, false, hooks)
	}
	batch2, validateErr := validator.Validate(execution, spec, candidate2)
	if validateErr != nil {
		return finishContentFault(execution, editor, last, validateErr, true, false, hooks)
	}
	value := validPackage{version: 2, candidate: candidate2, batch: batch2}
	last = &value

	repairs := 0
	for {
		if err := execution.Err(); err != nil {
			return finishContentFault(execution, editor, last, err, false, false, hooks)
		}
		callCtx, callCancel = boundedCall(execution)
		review, reviewErr := contentProvider.Review(callCtx, spec, last.batch)
		callCancel()
		if reviewErr != nil {
			if errors.Is(reviewErr, ai.ErrCriticalUsageFact) {
				return PipelineResult{}, pipelineFailure("usage_record", reviewErr)
			}
			if hooks.ReviewFailure != nil {
				if err := hooks.ReviewFailure(last.version); err != nil {
					return PipelineResult{}, pipelineFailure("review_record", err)
				}
			}
			return finishContentFault(execution, editor, last, reviewErr, false, true, hooks)
		}
		willRepair := review.Verdict == "issues" && repairs < policy.ContentRepairLimit
		if hooks.Review != nil {
			if err := hooks.Review(last.version, review, willRepair); err != nil {
				return PipelineResult{}, pipelineFailure("review_record", err)
			}
		}
		if review.Verdict == "pass" {
			if hooks.Progress != nil {
				if err := hooks.Progress("finalizing"); err != nil {
					return PipelineResult{}, pipelineFailure("delivery", err)
				}
			}
			if repairs == 0 {
				return pipelineFinal(*last, OutcomeReviewPassed, ""), nil
			}
			return pipelineFinal(*last, OutcomeRepairedPassed, ""), nil
		}
		if repairs >= policy.ContentRepairLimit {
			if hooks.Progress != nil {
				if err := hooks.Progress("finalizing"); err != nil {
					return PipelineResult{}, pipelineFailure("delivery", err)
				}
			}
			return pipelineFinal(*last, OutcomeLimitFinalized, ""), nil
		}
		repairs++
		attemptVersion := 2 + repairs
		callCtx, callCancel = boundedCall(execution)
		rewrite, rewriteErr := contentProvider.OpenRewrite(callCtx, spec, last.candidate, review.Issues)
		if rewriteErr != nil {
			callCancel()
			if errors.Is(rewriteErr, ai.ErrCriticalUsageFact) {
				return PipelineResult{}, pipelineFailure("usage_record", rewriteErr)
			}
			return finishContentFault(execution, editor, last, rewriteErr, false, false, hooks)
		}
		rewriteAttempt := editor.Begin(attemptVersion, "provider", callCancel)
		nextCandidate, rewriteErr := receiveWithNativeProjection(callCtx, callCancel, provider, validator, spec, rewrite, editor, rewriteAttempt, budget)
		_ = rewrite.Close()
		callCancel()
		if rewriteErr != nil {
			if errors.Is(rewriteErr, ai.ErrCriticalUsageFact) {
				return PipelineResult{}, pipelineFailure("usage_record", rewriteErr)
			}
			return finishContentFault(execution, editor, last, rewriteErr, false, false, hooks)
		}
		nextBatch, validateErr := validator.Validate(execution, spec, nextCandidate)
		if validateErr != nil {
			return finishContentFault(execution, editor, last, validateErr, false, false, hooks)
		}
		value = validPackage{version: attemptVersion, candidate: nextCandidate, batch: nextBatch}
		last = &value
	}
}

func receiveWithNativeProjection(ctx context.Context, cancel context.CancelFunc, provider ai.Provider, validator ai.Validator, spec ai.GenerationSpec, stream ai.Stream, editor *publicEditor, initial *publicAttempt, budget *ai.RepairBudget) (ai.Candidate, error) {
	active := initial
	ctx = ai.WithContinuationAttempt(ctx, func() (func(string) error, error) {
		if err := active.Close(); err != nil {
			return nil, err
		}
		active = editor.BeginContinuation(initial.version, cancel)
		return active.Add, nil
	})
	candidate, err := ai.ReceiveWithRepairBudget(ctx, provider, validator, spec, stream, active.Add, budget)
	if closeErr := active.Close(); closeErr != nil {
		err = closeErr
	}
	return candidate, err
}

func finishContentFault(execution context.Context, editor *publicEditor, last *validPackage, err error, fixed, review bool, hooks PipelineHooks) (PipelineResult, error) {
	if errors.Is(err, context.Canceled) && !errors.Is(execution.Err(), context.DeadlineExceeded) {
		return PipelineResult{}, pipelineFailure("cancelled", err)
	}
	if errors.Is(err, ai.ErrCriticalUsageFact) {
		return PipelineResult{}, pipelineFailure("usage_record", err)
	}
	if last == nil {
		phase := "validation"
		if !fixed {
			phase = "provider_receive"
		}
		return PipelineResult{}, pipelineFailure(phase, err)
	}
	reason := contentStopReason(err, review)
	if fixed {
		var providerErr *ai.ProviderError
		if errors.As(err, &providerErr) && (providerErr.Category == ai.FailureSchema || providerErr.Category == ai.FailureContent) {
			reason = "fixed_edit_native_invalid"
		} else if errors.Is(err, ai.ErrInvalidCandidate) {
			reason = "fixed_edit_native_invalid"
		}
	}
	if restoreErr := editor.Restore(last.version, last.batch.Passage); restoreErr != nil {
		return PipelineResult{}, pipelineFailure("delivery", restoreErr)
	}
	if hooks.Progress != nil {
		if progressErr := hooks.Progress("finalizing"); progressErr != nil {
			return PipelineResult{}, pipelineFailure("delivery", progressErr)
		}
	}
	return pipelineIncomplete(*last, reason), nil
}

func boundedCall(parent context.Context) (context.Context, context.CancelFunc) {
	return context.WithTimeout(parent, 180*time.Second)
}

func pipelineFinal(p validPackage, outcome, reason string) PipelineResult {
	var stop *string
	if reason != "" {
		stop = &reason
	}
	return PipelineResult{Version: p.version, Candidate: p.candidate, Batch: p.batch, Outcome: outcome, StopReason: stop}
}

func pipelineIncomplete(p validPackage, reason string) PipelineResult {
	return pipelineFinal(p, OutcomeServiceIncomplete, reason)
}

func contentStopReason(err error, review bool) string {
	if errors.Is(err, context.DeadlineExceeded) {
		return "content_timeout"
	}
	var providerErr *ai.ProviderError
	if errors.As(err, &providerErr) {
		switch providerErr.Category {
		case ai.FailureRateLimited:
			return "content_rate_limited"
		case ai.FailureUnavailable:
			return "content_transport_error"
		case ai.FailureProtocol, ai.FailureAuthentication, ai.FailureAuthorization:
			return "content_protocol_error"
		case ai.FailureSchema, ai.FailureContent:
			if review {
				return "content_review_invalid"
			}
			return "repair_native_invalid"
		}
	}
	if review {
		return "content_review_invalid"
	}
	if errors.Is(err, ai.ErrInvalidCandidate) {
		return "repair_native_invalid"
	}
	return "content_transport_error"
}

type publicEditor struct {
	emit    func(PipelineEdit) error
	visible []rune
	rev     int
}

type publicAttempt struct {
	mu         sync.Mutex
	editor     *publicEditor
	draftID    string
	version    int
	source     string
	pending    []rune
	started    bool
	appendMode bool
	lastEmit   time.Time
	timer      *time.Timer
	closed     bool
	err        error
	cancel     context.CancelFunc
}

func newPublicEditor(emit func(PipelineEdit) error) *publicEditor { return &publicEditor{emit: emit} }

func (e *publicEditor) Begin(version int, source string, cancel ...context.CancelFunc) *publicAttempt {
	return e.begin(version, source, false, cancel...)
}

func (e *publicEditor) BeginContinuation(version int, cancel ...context.CancelFunc) *publicAttempt {
	// A continuation has its own draft identity but inherits the current clean
	// visible prefix. Its first edit therefore appends instead of replacing.
	return e.begin(version, "provider", true, cancel...)
}

func (e *publicEditor) begin(version int, source string, appendMode bool, cancel ...context.CancelFunc) *publicAttempt {
	attempt := &publicAttempt{editor: e, draftID: uuid.NewString(), version: version, source: source, appendMode: appendMode}
	if len(cancel) > 0 {
		attempt.cancel = cancel[0]
	}
	return attempt
}

func (a *publicAttempt) Add(delta string) error {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.err != nil {
		return a.err
	}
	if a.closed {
		return errors.New("public edit attempt is closed")
	}
	if delta == "" {
		return nil
	}
	if !utf8.ValidString(delta) {
		return errors.New("public edit is not valid UTF-8")
	}
	a.pending = append(a.pending, []rune(delta)...)
	if len([]byte(string(a.pending))) > 16<<10 {
		cut := lastSafeBoundary(a.pending)
		if cut == 0 {
			return a.failLocked(&ai.ProviderError{Category: ai.FailureProtocol, Retryable: false, Err: errors.New("public edit safe buffer exceeded")})
		}
		if err := a.flushPrefixLocked(cut); err != nil {
			return err
		}
		if len([]byte(string(a.pending))) > 16<<10 {
			return a.failLocked(&ai.ProviderError{Category: ai.FailureProtocol, Retryable: false, Err: errors.New("public edit safe buffer exceeded")})
		}
	}
	safe := lastSafeBoundary(a.pending)
	if safe == 0 {
		return nil
	}
	if !a.started || safe >= 128 {
		return a.flushPrefixLocked(safe)
	}
	return a.scheduleLocked()
}

func (a *publicAttempt) Flush() error {
	a.mu.Lock()
	defer a.mu.Unlock()
	return a.flushFinalLocked(false)
}

func (a *publicAttempt) Close() error {
	a.mu.Lock()
	defer a.mu.Unlock()
	return a.flushFinalLocked(true)
}

func (a *publicAttempt) flushFinalLocked(close bool) error {
	if a.timer != nil {
		a.timer.Stop()
		a.timer = nil
	}
	if a.err == nil && len(a.pending) > 0 {
		a.err = a.flushPrefixLocked(len(a.pending))
	}
	if close {
		a.closed = true
	}
	return a.err
}

func (a *publicAttempt) scheduleLocked() error {
	if a.timer != nil || a.err != nil || a.closed {
		return a.err
	}
	delay := 50 * time.Millisecond
	if !a.lastEmit.IsZero() {
		delay -= time.Since(a.lastEmit)
	}
	if delay <= 0 {
		return a.flushPrefixLocked(lastSafeBoundary(a.pending))
	}
	a.timer = time.AfterFunc(delay, func() {
		a.mu.Lock()
		defer a.mu.Unlock()
		a.timer = nil
		if a.closed || a.err != nil {
			return
		}
		if safe := lastSafeBoundary(a.pending); safe > 0 {
			_ = a.flushPrefixLocked(safe)
		}
	})
	return nil
}

func (a *publicAttempt) flushPrefixLocked(count int) error {
	if count <= 0 || a.err != nil {
		return a.err
	}
	count = min(count, len(a.pending))
	chunk := append([]rune(nil), a.pending[:count]...)
	a.pending = a.pending[count:]
	if err := a.applyLocked(chunk); err != nil {
		return a.failLocked(err)
	}
	a.started = true
	a.lastEmit = time.Now()
	return nil
}

func (a *publicAttempt) failLocked(err error) error {
	if a.err == nil {
		a.err = err
		if a.cancel != nil {
			a.cancel()
		}
	}
	return a.err
}

func (a *publicAttempt) applyLocked(chunk []rune) error {
	e := a.editor
	if e.emit == nil {
		if !a.started && !a.appendMode {
			e.visible = append([]rune(nil), chunk...)
		} else {
			e.visible = append(e.visible, chunk...)
		}
		return nil
	}
	at, deleteCount, insert := len(e.visible), 0, string(chunk)
	if !a.started && !a.appendMode {
		p := commonPrefix(e.visible, chunk)
		at, deleteCount, insert = p, len(e.visible)-p, string(chunk[p:])
		if deleteCount == 0 && insert == "" {
			return nil
		}
		e.visible = append(append([]rune(nil), e.visible[:p]...), chunk[p:]...)
	} else {
		e.visible = append(e.visible, chunk...)
	}
	base := e.rev
	e.rev++
	return e.emit(PipelineEdit{DraftID: a.draftID, ContentVersion: a.version, BaseRev: base, Rev: e.rev, At: at, DeleteCount: deleteCount, Insert: insert, Source: a.source})
}

func (e *publicEditor) Restore(version int, text string) error {
	target := []rune(text)
	p := commonPrefix(e.visible, target)
	if p == len(e.visible) && p == len(target) {
		return nil
	}
	if e.emit == nil {
		e.visible = append([]rune(nil), target...)
		return nil
	}
	base := e.rev
	e.rev++
	err := e.emit(PipelineEdit{DraftID: uuid.NewString(), ContentVersion: version, BaseRev: base, Rev: e.rev, At: p, DeleteCount: len(e.visible) - p, Insert: string(target[p:]), Source: "retained"})
	if err == nil {
		e.visible = append([]rune(nil), target...)
	}
	return err
}

func commonPrefix(a, b []rune) int {
	n := min(len(a), len(b))
	for i := 0; i < n; i++ {
		if a[i] != b[i] {
			return i
		}
	}
	return n
}

func lastSafeBoundary(text []rune) int {
	for i := len(text); i > 0; i-- {
		if unicode.IsSpace(text[i-1]) || unicode.IsPunct(text[i-1]) {
			return i
		}
	}
	return 0
}
