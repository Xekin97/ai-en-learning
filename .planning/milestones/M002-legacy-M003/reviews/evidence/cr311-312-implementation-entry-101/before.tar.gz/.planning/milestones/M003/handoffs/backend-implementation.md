---
milestone: M003
stage: implementation
role: backend-implementer/base
agent_name: backend-ethan
status: awaiting_review
date: 2026-10-12
---

# TECH04 / CR306 后端实施交接

## CR306 后端实施提交（当前）

- 门禁：`TRANSITION-M003-077` 与 `USER-M003-CR306-IMPLEMENT-NEXT`。实施依据为已接收 TECH04 组合中的 BE07/DB04/API306/AI7；CR306 继续 open，本交接等待独立接收。
- 管理模型现在持久化并读取 `custom_parameters`；单项、batch、provider aggregate、probe 和 enable 共用严格原文校验。初始/清空必须显式 `{}`，保存保持零供应商调用；disable 不被已损坏库配置阻断。
- `BindSpec` 将规范 custom JSON 深度固定在运行连接快照中，Plan、Writer、FixedEdit、原生恢复、Review、Rewrite 继续复用该快照。三个协议均作顶层浅合并；只有规范官方 OpenRouter URL、Chat、业务 json_schema 注入 `provider.require_parameters`。
- 普通运行与 preview 在原共享配置锁/受理事务中写 exact 五键 `custom-parameters-v1` 快照。坏库配置在受理和扣费前确定失败并公开 `generation_unavailable`/`accepted:false`；既有 COMMIT unknown、pending、取消、Q02、退款和 180/600 时限未改变。
- 未发布 0017 就地新增三列、三个 CHECK、两个不可变触发器并更新 startup Verify；没有 0018、历史升级或回填。隔离 PostgreSQL 18 已验证空库初始化、合法/非法 shape、相等重赋、变更拒绝和无关状态更新。
- 验证覆盖严格边界共享 fixture、管理入口原子性、三协议、OpenRouter 路由排除矩阵、probe 400/422、普通/preview 快照、配置后改稳定性、未受理零 run/charge、既有 HTTP/结算回归。命令与原始输出见 [`backend-validation.md`](../implementation/backend-validation.md) 和 [`evidence/cr306-backend`](../implementation/evidence/cr306-backend/)。
- 未调用真实收费模型，未读取真实密钥，未部署或修改 UAT；真实参数支持和完整生成质量仍由后续独立 QA 的有界真实复验确认。

## 历史记录：CR-304 / CR-305

- 以下为先前 `TRANSITION-M003-061`、`USER-M003-QA-NEXT` 下的返修记录，不是当前 CR306 的待办或接收状态。CR-304 与 CR-305 已由独立 QA 解决，当前结论以 state 065 / QA02 为准。
- `generation_busy` 的普通生成、用户预设/后台 preview 与模型 probe 分支现在共用一个 response helper。helper 从同一整数值写入 `Retry-After` 和 `context.retry_after_seconds`，严格保持 `accepted:false`、HTTP 503、`application/problem+json`、`Cache-Control:no-store`，context 无其他字段。
- `capacity_test.go` 对普通生成、preview 和 probe 三条入口校验正文整数、响应头一致性、1..600 配置域内的测试值、严格 context 字段以及 no-store/content-type。
- 定向 HTTP API unit、定向 race、vet 与最终静态/归档核对均通过，原始命令和退出码见 [`evidence/cr304-fix`](../implementation/evidence/cr304-fix/)。本轮未运行无关全量栈、数据库、付费模型、部署或迁移。
- 历史结果：CR-304 后端返修及 CR-305 前端返修随后均已通过独立 QA；这里保留实现证据索引，不复活旧 open/待 QA 状态。

## 历史记录：TECH03 后端实施依据与边界

以下 TECH03 内容保留用于追溯既有实现与证据。当前 CR306 实施依据是上文 TECH04 的 BE07/DB04/API306/AI7，当前接收状态只看本文件首段及 CR306 独立门禁。

- 门禁：[`technical-design-054.md`](../reviews/technical-design-054.md) 与 `control-054/M003-TECH-03-source-manifest.json`。
- 技术真源：TECH03 的 BE06-R1、AI BE06、API BE06（`m003-stream-v5`）、DB03、capacity-and-deployment BE06-R1、PRODUCT07，以及 FE02/UI09-R3 的后端依赖。
- 授权：`TRANSITION-M003-055`、`USER-M003-BACKEND-IMPLEMENT-NEXT`、`USER-M003-CONTENT-20261009`、`USER-M003-NO-DATA-MIGRATION`。
- Profile 保持 `consumer-ai-web@1.0.0`。请求路由为 `strong/gpt-5.6-sol/high`；实际 serving metadata 未提供，仍为 unknown。
- 项目未上线。本轮只修订当前未发布的 0017 schema 候选并从空库初始化验证；没有新增 0018、旧库升级/回填/兼容，也没有对任何现有数据库执行迁移。
- 未提交、推送、部署、购买或调用真实收费 API；未读取或记录真实密钥。

## 实现结果

- 当时 schema 支持 v5 六阶段、七类 stop reason、Pro/Plus N0 或 N1–99、最大 V101、preview 最大 V3，并以完整 `IS TRUE` 组合谓词保护业务事实。
- 所有模式使用同一绑定目标模型完成真实独立 Plan→Writer；Writer 消费完整 Plan，局部 `plan_item` 来自安全完整条目并支持 zh/en/ja。
- 普通 N0 不执行固定编辑或 Review；增强执行初稿校验→一次 fixed_edit→原生校验→Review→条件 content_repair，共享 technical_repair 最多两次，内容预算 N 独立。
- 安全完整但 schema 不合格的初稿可以携带有界 machine errors 进入 Editor；不可解码或未封口 JSON 不标记为 valid。Q02 只适用于七类服务原因且要求 lastValid 整包，取消、断流、DB/usage 未知不走成功语义。
- `m003-content-v5` 与 `m003-stream-v5` 已落实：六阶段、严格命名事件、每事件 seq、全流 rev、每尝试 draft_id、Unicode 码点 splice、retained 回退与有界增量输出。
- 三协议解析要求明确正常终止，SSE event 总大小有界；passage 使用增量状态机，安全前缀在词边界立即或 50ms 内刷新，输出具备 128/2048 码点门槛和有界反压。
- `CompletePipeline`/`CompletePreviewPipeline` 在终态事务中核验实际 usage 事实：调用顺序、目标模型、prompt、provider 三态、technical/content 预算、末审结果和原因传递。
- CapacityGate 在 run/charge/provider 前完成零等待原子准入；覆盖 global、preview=1、probe=1、preflight、connection group、429 cooldown、draining 与 settlement health。503 带 1..600 秒 Retry-After，拒绝无 run/charge/provider。
- 取消或写失败统一执行 cancel/close/join 后再 release；超时 join 先关闭健康栅栏并保留 pending 最小事实。Release/ReleaseUnknown 采用同一锁序，健康只在全部 pending 确认后重开。
- 管理配置、impact、status、preview、publish、权限、一次扣次、终态竞态、usage 与 F/C 诊断查询已对齐；诊断输出 F、C、交/并集、去重 run、分母与 unknown 上下界。
- 最小观测包括 active global/preview/probe/preflight/connection/group、固定 busy reason、preflight 时长、首 plan、首正文和终态确认时间；没有逐 token 入库。
- Nginx 三路 SSE、固定 digest 的单副本生产 overlay、资源硬界、日志轮转和停机窗口已提供并通过静态校验，未部署。

## 验证与证据

- 第三轮完整 integration：`go test -count=1 -tags=integration ./...`，exit 0；HTTP 包 177.610s。
- 最终 unit、定向 race、vet、两个命令入口 build、`git diff --check` 均 exit 0。
- 增强真实 Gateway+DB HTTP 闭环覆盖正常四阶段、N2 两次返修至上限、第二次返修无效时回退 lastValid、增强 preview；核验阶段事实、最终 V、提示与一次扣次。
- 当时 schema 只从可丢弃空库初始化；未执行升级矩阵。三轮完整 integration 的两个失败日志与最终通过日志全部保留，断言未降低。
- 本轮自行创建的 PostgreSQL 测试容器已停止并删除；未清理其他容器、卷或用户数据。
- 完整命令、退出码、行为映射和限制见 [`backend-validation.md`](../implementation/backend-validation.md)。root 的 12 项过程反馈对应见 [`12-root-review-resolution.md`](../implementation/evidence/tech03/12-root-review-resolution.md)。
- 可恢复源码包、逐文件 SHA-256 和证据 manifest 位于 [`implementation/evidence/tech03`](../implementation/evidence/tech03/)。

## 并行所有权与整合

- backend-ethan 负责 capacity/generation/httpapi/observability/platform、0017 当前 schema、事务事实校验与总回归。
- backend-ethan/ai_tasks_v5 负责 `backend/internal/ai` 的 v5 task、增量解析和协议测试；已由主 owner 整合验证。
- backend-ethan/deploy_sse_config 负责 `nginx/**`、`compose*.yaml` 和环境变量示例；已由主 owner 静态整合验证。
- 共享 dirty 工作树中的既有修改均保留，没有创建会漏掉依赖的独立 worktree，也没有清理其他角色文件。

## 独立复核重点

- 事务中的 usage 顺序、末审结果、同模型/同连接与 N/V/outcome 组合是否覆盖全部终态路径。
- cancel/close/join/release 和 pending unknown 健康重开在普通、预设、preview 三路的一致性。
- v5 SSE 的 seq/rev/draft、50ms 安全刷新、增量解析上界与 Q02 lastValid 回退。
- production overlay 的明确容量参数、connection group 映射、SSE 代理和停机参数。

## 保留限制

- 尚未验证真实模型质量、供应商实际输出、真实费用/RPM/TPM/429、生产延迟或 2C4GiB 下的真实容量；替身和开发机结果不代表生产容量，也不宣称 20 并发可用。
- 尚未执行真实部署、备份恢复、前端浏览器联调、独立 QA 或 UAT。
- 历史 TECH03 记录当时尚未完成 CR-302 前端实施与独立 QA；当前 CR-302 的实施和独立 QA 已完成，仍等待用户 UAT。CR-303 的设计冲突解决记录不代表生产验证。
- 既有保留项 `CR039-L1`、`CR042-L1`、`AI-QUALITY-90`、`W01`、`QA26-MINIMAX` 继续保留。控制面可在独立复核接收后将实施状态切到下一门禁；本角色不自批 QA 或切换角色。
