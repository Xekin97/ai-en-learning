---
milestone: M003
stage: product-planning
role: product/to-c
agent_name: product-maya
status: awaiting_user_review
version: M003-PRODUCT-08
date: 2026-10-12
---

# CR-306 产品交接：模型推理配置与真实规划超时

product-maya 已完成本轮最小产品修订；**无当前业务阻塞，可按既有授权交独立门禁接续 backend-alex 的 CR306-BE**。CR-306仍open，真实修复/新视觉/实现尚未验证；不要求用户重新确认已要求的修复方向。建议awaiting_user_review仅是本角色交付状态，本文件不修改workflow、不自行调用守门器或切阶段。

## 输入与需求确认闭环

- [USER-M003-CR306-REPAIR](../reviews/requirements-feedback.md#cr-306-修复编排user-m003-cr306-repair)：用户已看到每模型推理研究后要求“编排一下修复吧”；[门禁066](../reviews/cr306-repair-gate-066.md)已独立检查回溯授权。CONFIRMED范围为模型推理配置与实际规划超时定向修复，含必要有界真实排障/复验；本产品角色未作真实调用。
- [D3-10](../product/overview.md#d3-10)区分已确认范围、专业建议与未决；[CAP-306](../product/abilities.md#cap-306)的模式/能力交互为待专业接收方案，不称用户逐字段批准。字段、供应商适配、未知能力、缓存/错误码/有限时限由后端在授权内收敛，无需例行逐项审批；实质新增权益、费用上限或供应商策略才回产品确认。
- 保留共同规划、增强固定编辑/审稿及两类返修预算、Q02/配额、后台basic0/enhanced1及旧保存/发布边界；[CR-302](../changes/CR-302.md)保留product_resolved_downstream_pending，不在本轮关闭。完整页面→M002正式设计→新视觉用户评审仍必需，修复委派不等于视觉已批准。
- 当前技术基线 TECH03 / BE06-R1、API-AI BE06、DB03、FE02、UI09-R3，以及既有实施/独立QA结论从[workflow](../../../workflow/state.yaml)、[后端交接](backend-architecture.md)、[验证交接](verification.md)读取。本轮不把产品旧BE04示例或原“待技术复核”字样当作撤销现有技术接收。
- 已完整读取agt-product-planning及共同/工作流/产品ToC、路由和维护契约；采用锁定[Profile1.0.0](../reviews/evidence/start/locked-profile.yaml)和v1路由，requested gpt-6-astra/high，actual_model、usage均unknown。未升级Profile或改变Codex配置。

## 原始产物

1. [overview.md / D3-10](../product/overview.md#d3-10)：本轮范围、确认分类、非目标与真实证据限制。
2. [data-assets.md / DATA-306](../product/data-assets.md#data-306)：每模型配置、能力事实与本次快照，最小诊断/隐私边界。
3. [abilities.md / CAP-306与AC-317–322](../product/abilities.md#cr306-acceptance)：保存/能力/快照/失败/完整链路/完整页面可验证结果。
4. [ai-behavior.md](../product/ai-behavior.md#cr306-reasoning)：推理与业务plan分离、结构化输出和故障结算。
5. [pages/index.md](../product/pages/index.md#cr306-pages)：现有模型管理、普通/预设生成及管理员预览的页面责任。
6. [CR-306产品处理与责任表](../changes/CR-306.md#cr306-product-repair)：CR306-BE/DB/UI/FE/IMPL/QA/UAT的输入、产物及完成条件；本交接不另抄任务表。

## 下一步与完成条件

独立门禁接交后由backend-alex先提交CR306-BE：模型配置与能力/未知状态合同、受支持适配及结构化约束、同请求快照、保存/失败/时限/结算、最小诊断及管理/流式fixture。输入是PRODUCT08、原故障/研究和现行技术/实现，不凭模型名猜能力，不把关闭推理当作关闭业务plan。输出应让DB、设计、前端和QA能直接接续AC-317–321；具体接续顺序与责任仅维护在CR-306表中。

目前无需新业务选择；有界专业建议交下一责任角色定稿。新视觉待用户评审是当前明确保留的后续门槛，并非再次请求同一修复授权。原型与正式设计未交付前不能批准尚不存在的视觉；新视觉评审与代码实现、完整真实验证分别记录。

## 维护、自检与未验证项

PRODUCT07六份原件修订前均核对[清单](../reviews/evidence/cr306-control-066/product-before-manifest.json)一致，[原件包](../reviews/evidence/cr306-control-066/product-before-cr306.tar.gz)sha256亦一致；旧审批与原故障证据未覆盖。PRODUCT08仅CR-306局部修订，版本号不将PROPOSED升级为CONFIRMED；D3-01–09、AC-301–316和原显式锚点保留。旧产品交接全文在上述原件包内恢复，不复制为第二当前入口。

有限静态检查记录在[product/evidence/cr306/check.json](../product/evidence/cr306/check.json)，含七份改动、版本/hash/引用/锚点/既有验收与冻结包核对。输入计量见[input-check.json](../product/evidence/cr306/input-check.json)及check文件；字符数为静态范围，运行token unknown。新会话交接测试未执行，静态核对不冒充独立交接通过。没有运行模型、业务、浏览器或数据库测试；未改技术/设计/业务源码、控制面，未停止UAT、重置数据、提交或部署。

未验证：AC-317–322全项；真实首规划/首正文、总时长、格式/业务质量和费用；GLM低档位完整链路；当前未捕获费用仍unknown。三次限时规划诊断不是完整成功。原件见[调研](../verification/model-reasoning-research.md)及[CR-306](../changes/CR-306.md)。CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX及用户UAT权限继续保留，不因产品交付关闭。
