---
id: API-303
version: M003-BE-07
status: awaiting_user_review
milestone: M003
---

# 管理计划内容服务

CAP-303、DATA-301、PAGE-208、AC-304/305/306/314；UIA-M003-304–306；全部admin-only，普通身份403。本文`Plan=visitor|basic|pro|plus`。路径省略 `/api/v1`；[M002 API-103](../../../M002/technical/api/administration.md) 未变字段/传输规则保留。所有配置写入与impact POST做原CSRF、严格字段预检；不调用模型、不扣额度。

## 完整读取与单计划修改

`GET /admin/groups` →200 `{items:Group[4],revision:string,native_correction_policy:NativePolicy}`，稳定顺序visitor/basic/pro/plus。Group完整字段：

```text
{code:visitor|basic|pro|plus,priority:int,rolling_24h_limit:int|null,max_entries:int,
 allowed_lengths:Length[],models:[{id:string,display_name:string,enabled:bool}],
 content_review_enabled:bool,content_repair_limit:int[0,99]}
```

基础校验恒包含；NativePolicy严格类型见API-301，由后端m003-native-policy-v1常量提供max_calls=2/scope=logical_request/ editable=false。管理页读此字段显示真实系统预算，不从fixture或计划N猜；无可写native_validation/native_correction_policy/max_calls字段，直调附加这些字段按未知字段拒绝。revision是原全局签名版本，不传内部数值。NULL quota=不限，0=禁计划次数；模型卡/extra例外沿原规则。

`POST /admin/groups/{code}/impact-preview` 与 `PUT /admin/groups/{code}` **同一完整请求类型**：

```json
{"expected_revision":"opaque-current","priority":20,"rolling_24h_limit":20,"max_entries":12,"allowed_lengths":["short","medium"],"model_ids":["model-id"],"content_review_enabled":false,"content_repair_limit":0}
```

新两字段必填且严格bool/整数非null；visitor/basic只false/0，pro/plus只false/0或true/整数1–99；Pro/Plus独立保存、初始均1；缺字段、true/0、false/非0、100、负数、小数均422 validation_failed，field_errors用JSON Pointer `/content_review_enabled`、`/content_repair_limit`。原max_entries≥1、priority≥0且全计划唯一、quota null或非负整数、有效model_ids、受支持length约束保持。未知计划404；重复priority为409 duplicate_priority。无模型/无长度/0 quota仍是警告可保存，不因服务开关改变约束。

impact 200完整data（在一个配置共享锁快照下产生）：

```text
{revision:string,base_users:int,active_trial_users:int,priority_changed:bool,
 may_change_effective_plan:bool,loses_all_models:bool,
 content_service_change:{before:{content_review_enabled:bool,content_repair_limit:int[0,99]},
 after:{content_review_enabled:bool,content_repair_limit:int[0,99]}},
 applies_to:"new_requests",in_flight_policy:"accepted_snapshot",
 usage_reset:false,trial_dates_changed:false,native_correction_policy:NativePolicy,
 warnings:("content_service_removed"|"no_models"|"no_lengths"|"zero_plan_quota"|"effective_plan_may_change")[]}
```

warnings去重，按上表枚举顺序输出。content_service_removed仅true→false；no_models按实际无启用且未移除的计划模型，no_lengths按空数组；zero_plan_quota仅limit=0；effective_plan_may_change取may_change_effective_plan。原base_users是此基础计划账号数，active_trial_users是有效目标试用人数，不承诺两者不重叠、不是精确“此次失去增强人数”；visitor人数仍按现有可统计主体口径，不编造人数。前端显示计划中文名来自code本地文案，before/after来自响应；关闭警告文案依design/copy.json，明确只影响新请求。优先级导致有效计划变更时提醒可能获得/失去增强，不用单计划开关猜每人结果。

PUT 200仍 `{group:Group,revision:string,native_correction_policy:NativePolicy}`。配置排他锁→校验expected_revision→再次完整校验→原计划/模型/长度及新字段一次事务→AdvanceConfiguration一次；成功后读新值。响应不假定客户端已经点过预览；直接API也完整校验，无新“预览凭据”存储。UI必须对当前本地草稿先impact再确认，预览后任何字段编辑即失效，发送PUT须与预览规范化body完全相同。取消修改不请求PUT。

## 冲突、异常与优先级批量

impact/PUT的409 revision_conflict沿Problem，`context={current_revision:string}`；不混合保存。前端保留本地未保存输入→GET读取服务端最新四计划→并排核对→用户保留本地修改后用最新revision重新impact→再次确认PUT。不能把current_revision自动塞进旧PUT重试。原body malformed=400、非法字段422、CSRF403、数据库暂不可用503/500；失败不抹本地输入。PUT响应丢失先GET重读；若值已匹配可以显示当前已保存配置，但不虚构原请求成功回执，不再次推进revision。

`POST /admin/groups/priority-impact`、`PUT /admin/groups/priorities`仍用 `{expected_revision:string,priorities:[{code:Plan,priority:int}]}` 恰好四行、唯一code/priority、int≥0。不得带内容字段；只改priority，不重置额度或试用时间。

priority-impact 200在原 `{affected_base_users:int,affected_trial_users:int,revision:string}` 增加：

```text
{content_service_by_plan:[{code:Plan,content_review_enabled:bool,content_repair_limit:int[0,99]}],
 may_change_content_service:bool,applies_to:"new_requests",in_flight_policy:"accepted_snapshot",
 usage_reset:false,trial_dates_changed:false,native_correction_policy:NativePolicy}
```

content_service_by_plan固定四行从同一配置快照读取；may_change_content_service用原已有基础/试用优先级前后胜出逻辑，检查是否存在赢家变化且两个计划服务配对不同的有效试用账号（EXISTS，非逐用户报表）。false不能推导“有效计划没变”；人数仍是现有受影响基础/试用计数，不是增强净增/净减。PUT成功仍 `{items:Group[4],revision,native_correction_policy:NativePolicy}`，含新字段；冲突和预览失效处理同单计划。

关闭成功后新GET generation-options及公开预设详情都从实时有效计划投影false/0，所有用户权益摘要同步显示不含增强；已有run的started快照不变。管理前端不得硬编码pro/plus永含增强。初始化只依DB3-02一次迁移，不在HTTP启动/读取中重seed。

数字0与关闭联动，1–99与开启联动；重新开启建议置1，用户可继续修改。预览before/after中的N按实际整数显示，不固定“最多1次”；基础策略总保持同一个只读NativePolicy。N=99只做配置保存/读取/边界验证，不触发99轮模拟；流程执行测试最多2轮，运行时按受理N及统一deadline控制。

BE05重发管理API，字段/校验/影响预览结构不变。增强开关的业务含义按PRODUCT07包含固定编辑/审稿/条件返修；N0关闭整个增强段，但共同规划继续。管理关闭提示不得再说“只生成一次调用”；普通正常2次、增强正常4次，业务仍一次。USER-M003-STREAM-FIRST去除用户生成页轮次呈现，不删除本页0–99配置、基础2次只读策略或后台统计。

BE05-R1仅随七份契约统一版本重发；本管理API结构、配置、预算与计费不变。规划持续显示的定向修订见API-302，后台预览同规则。

BE06容量为部署参数，不新增计划字段/管理页配置：原0–99、系统基础策略及impact保持；计划读取/保存不占生成槽。只有会调用模型的preview/探测使用容量Gate，规则见API-302/API-304与BE6-CAPACITY。

<a id="api-306"></a>
## API-306 模型推理配置、能力与保存（CR-306）

CAP-306 / DATA-306 / PAGE-208 / AC-317–319、322；继承[M002服务商聚合](../../../M002/technical/api/model-connections.md)。以下DTO是本轮唯一字段真源，其他文件引用，不复制另一个版本。所有端点admin-only；写和能力POST沿session/CSRF，401/403；JSON封套、严格字段、原2MiB/1000模型限制保持。新增字段配套前后端切换，不为旧客户端静默补模式。

### 配置和读取

```text
Effort = minimal|low|medium|high|xhigh|max
ReasoningConfig = {mode:follow|off|on, effort:Effort|null}
ReasoningCapability = {
 adapter:openrouter_chat_v1|unsupported,
 status:known|unknown, freshness:fresh|stale|unavailable,
 revision:string|null, source_url:string|null, fetched_at:Time|null,
 refresh_status:never|ok|failed, last_attempt_at:Time|null,
 unknown_reason:null|adapter_unsupported|model_missing|metadata_missing|metadata_invalid|fetch_failed,
 reasoning_supported:bool|null, mandatory:bool|null,
 supported_efforts:Effort[], effort_selection:none|listed|all_gateway,
 default_enabled:bool|null, default_effort:string|null,
 structured_outputs:bool|null
}
ReasoningValidation = {status:valid|unverified|invalid,
 code:null|capability_unknown|reasoning_unsupported|reasoning_mandatory|reasoning_effort_unsupported|structured_output_unsupported,
 can_start:bool}
```

所有模型读取（聚合GET、单项、列表、保存响应）在原AdminModelDTO增加`reasoning:ReasoningConfig, reasoning_capability:ReasoningCapability, reasoning_validation:ReasoningValidation`。`can_start`只表示本配置校验可用，不代替enabled、权益、quota、凭据、容量等原预检。follow+prompt即使能力未知也valid/can_start=true；未知不冒称已识别。不把这些管理员字段加到公开模型/RunSnapshot；配置、服务商默认和实际执行结果分开。

聚合POST/PATCH中每个`models[i]`、单模型POST/PATCH完整ModelInput及batch每项增必填`reasoning`、必填可null的`expected_capability_revision:string|null`；原字段不删。follow/off的effort必须null；on可null，非null只能属于当前能力列表，不把默认强度自动保存。漏字段/类型/null对象/未知键/组合错误422。既有无配置模型初始化为follow/null；本轮不回填现UAT。单项enable端点沿原revision body，服务端用最新已存能力验证；disable总可执行，不因能力失效阻止停用。所有写路径共用同一校验器，不能从单项/batch/enable绕过聚合约束。

新的显式off/on、改变effort/连接绑定/model ID或由停用启用显式配置，必须有fresh known能力，且`expected_capability_revision`与最新规范能力digest相同；新设置json_schema同样要求已识别OpenRouter适配的structured_outputs=true。follow+prompt可传null。现有**绑定和推理/output_mode不变**的陈旧但valid配置可保存名称等原字段；服务器不丢掉显式值。已确定invalid的启用模型必须修正或同笔停用；停用且配置未变可原样保留invalid值供管理员修复（不能新建非法覆盖）。从显式改follow允许null，无须目录；这是一笔管理员明确修改。

### 唯一能力刷新入口

`POST /admin/model-capabilities/refresh`：

```json
{"expected_revision":"cfg-current","connection_id":null,"protocol":"openai_chat","base_url":"https://openrouter.ai/api/v1","provider_model_ids":["deepseek/deepseek-v4-flash-0731"]}
```

`connection_id`必填可null；有值必须属现存服务商。协议/URL是表单候选，用于尚未保存的模型/连接；无api_key、无任意目录URL；ids数组1..1000、唯一非空原样ID，各≤500字符。调用不调用模型、不扣业务次数、不占生成槽、不保存表单。服务端仅对已识别官方适配读取固定公开目录；不向候选base_url发送网络请求。未知适配直接返回unknown，不尝试探测。GET管理读取只读已存事实；页面首次加载发现stale/unknown时可显式调用本接口一次，失败保留刷新按钮，不循环。

200 data=`{items:[{provider_model_id,capability:ReasoningCapability}],revision:string,model_calls:0}`，按请求ids顺序，目录超时/HTTP/解析失败同样200但refresh_status=failed，未曾成功则unknown/unavailable；不能用空数组伪装不支持。DB读写失败仍503，CAS冲突409。不把网络成功200等同模型可用。

实现流程：校验身份/输入/expected_revision→**无DB事务**读取固定目录（总5秒，body≤8MiB，禁重定向，原公网安全client，完整data/id唯一检查）→配置排他锁再次核对revision及connection binding→只更新匹配已保存连接/模型的能力事实；草稿结果仅留15分钟进程cache。不存在的草稿model ID不得创建模型。成功的匹配事实与配置revision一次原子提交：只有规范能力内容或known/unknown语义变化才AdvanceConfiguration一次，纯时间/失败状态更新不推进；响应返回当前revision。网络失败保留last-known-good receipt，更新最近尝试失败状态；成功目录里缺失/非法元数据是新的unknown事实，不能沿旧成功继续声称支持。并发刷新按发起序号，只发布该binding最新发起的完成结果，丢弃较早晚到结果；CAS不匹配整次拒绝，禁止覆盖新连接。

缓存key=`(adapter_version, canonical_base_url, protocol, exact_provider_model_id)`；官方URL忽略尾斜线、标准HTTPS端口，禁userinfo/query/fragment。全目录只保留规范化安全字段，不持久全目录；同一刷新批只发一次GET，同进程同目录并发合并。15分钟是**新覆盖验证新鲜度/管理缓存TTL，不是生成续租期限**。过期标stale，已保存且未被新事实否定的有效覆盖可继续按旧receipt执行；刷新失败不自动撤销它。此策略避免每次生成依赖目录及每天人工续租；代价是外部能力可能先于本地刷新改变，真实上游拒绝仍按失败/Q02处理。没有定时任务/MQ、没有自动付费probe。需要新覆盖时过期返回capability_unknown，管理员刷新后显式保存。

### 规范化、合法性和失败

只有协议openai_chat且规范URL**精确**为`https://openrouter.ai/api/v1`识别openrouter_chat_v1；名称/model前缀/子域/代理/Responses/Anthropic不能触发。新适配另走已授权流程，不自动猜。取官方目录exact id的`reasoning`与`supported_parameters`：reasoning对象合法时识别支持；mandatory缺失保持null，只在false时可off；on要求明确支持。supported_efforts数组按供应商顺序去重并与Effort相交；**null**表示全部已实现gateway档位，**字段省略**表示无档位选择，仅on/null；`none`表示关闭，不进入on列表，mandatory不能通过none绕过。未实现新枚举不发送，default_effort原样只读不得变成默认写值。默认值缺失为null。缺reasoning对象可能是非推理或动态路由，保守unknown/metadata_missing，不根据名称判断；明确supported_parameters无推理且元数据可判不支持时才reasoning_supported=false。structured_outputs仅当目录明确含`structured_outputs`与`response_format`为true，缺参数清单为null，明确不含为false；不由推理能力推导。

| code / HTTP | 条件 / field_errors与处理 |
|---|---|
| validation_failed / 422 | 类型/模式组合；`/models/0/reasoning/effort`等JSON Pointer；保留草稿 |
| reasoning_mandatory / 422 | mandatory=true却off；指mode，禁止保存/测试 |
| reasoning_effort_unsupported / 422 | 当前列表无该effort；指effort，不自动降档 |
| reasoning_unsupported / 422 | 适配不支持或明确无推理，显式off/on；指mode |
| structured_output_unsupported / 422 | OpenRouter明确不支持却新设json_schema；指output_mode |
| capability_unknown / 409 | 新覆盖/启用所需事实未知或stale；context={refresh_required:true}，不付费核验 |
| capability_conflict / 409 | expected能力digest变化；context={current_capability_revision:string|null}；重读核对后保存，不自动改参数 |
| revision_conflict / 409 | 原全局配置CAS变化；context={current_revision:string}；按原聚合重读合并流程 |

标准Problem其余字段沿API索引。语法校验先于事务，CAS先于语义校验；多个模型任一错误整笔回滚，包括连接/凭据/模型和revision；只报告确定的安全field_errors，不泄露key/上游体。保存不发目录HTTP或模型请求：读取已存receipt/管理刷新cache并在配置锁内比较digest，绑定cache不可变版本；保存期间刷新发布与配置排他锁串行。事务成功把采用的receipt随配置存下，cache丢失时可从已存receipt重建。删除/retire沿原生命周期，不留独立能力墓碑。

### 连接测试与完整预览

现有`POST /admin/model-connection-test`请求新增同样reasoning/expected_capability_revision，验证草稿绑定后冻结；返回仍{ok:true}，0保存、0业务次数，一次≤30秒短流/256token探测、共用容量Gate。显式推理同映射，但probe仍短文本、没有业务schema；页面必须说明只证连接，不能证明json_schema或完整plan/writer。跟随三协议probe请求保持原样。新参数后旧测试标“此前配置”，不能当新配置已验证。完整业务验证仅复用API-304基础/增强预览和普通生成；无需新测试页。
