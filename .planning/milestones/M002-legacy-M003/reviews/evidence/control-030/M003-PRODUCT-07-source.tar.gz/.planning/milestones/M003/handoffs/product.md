---
milestone: M003
stage: product-planning
role: product/to-c
agent_name: product-maya
status: awaiting_user_review
version: M003-PRODUCT-07
date: 2026-10-10
---

# M003 产品交接：共同规划与增强固定编辑

product-maya 已按用户选择A收敛PRODUCT07。**Q3-02 CLOSED，无新增业务待决；CR-302为product_resolved_downstream_pending，整项技术与实施尚未完成。** 可按既有后台先行顺序接交backend-alex，后端合同明确后再更新完整原型。建议awaiting_user_review，不自行切阶段、批准技术或实施。

## 输入与确认闭环

- 来源：[USER-M003-Q3-02-A](../reviews/requirements-feedback.md#q3-02共同规划与增强固定编辑confirmed--a)，2026-10-10用户对已展示问题明确回复“A”。仍在TRANSITION-M003-029的product-planning / product/to-c / product-maya范围；控制面登记由有权限角色后续同步，本角色未修改。
- 已确认：所有生成共用结构化规划，完整计划实际输入writer；普通仅首稿后原生校验/基础修正。增强N>0为规划→首稿→一次固定实际编辑→原生校验→同模型审稿/条件返修。固定编辑不占N或基础预算，正常无修正调用普通2/增强4，一请求只计一次业务次数。
- N0关闭固定编辑/审稿/内容返修但保留共同规划；后台basic0/enhanced1同理。管理0–99/初始1、流程测试最多2轮、基础全请求2次当前只读技术策略、同模型/上限定稿、Q02、保存/取消/断连/未知结算、修稿原因统计、LIVE-TEXT及成本后续观测保持。
- 技术待复核而非用户逐字段批准：初稿无调用校验及lastValid、固定编辑故障适配Q02、规划无有效稿失败、结构化接收/预览语言、稿件版本/usage与保护时限。无须重问已确认分层；由backend-alex按原业务原则定稿。
- 沿用已读agt-product-planning/产品角色契约与Profile1.0/v1锁，请求gpt-6-astra/high，actual serving model与usage unknown。

## 当前源文件（8份）

1. [product/overview.md](../product/overview.md)：D3-09与已选A范围。
2. [product/data-assets.md](../product/data-assets.md)：DATA-305真实规划输入、临时用法与最终释义分离。
3. [product/abilities.md](../product/abilities.md)：CAP-302/304/305、调用/预算示例、AC-315/316接收目标。
4. [product/pages/index.md](../product/pages/index.md)：现有完整页面与规划投影依赖，后端先行。
5. [product/ai-behavior.md](../product/ai-behavior.md)：共同规划/增强编辑、正常调用与待复核故障适配。
6. 本交接。
7. [CR-302](../changes/CR-302.md)：产品决定closed与下游pending分开，责任清单及完成条件。
8. [docs/plans/content-review-and-repair.md](../../../../docs/plans/content-review-and-repair.md)：研发输入同步A与当前入口。

## backend-alex 接收合同

1. 建立真实plan→writer数据依赖；早期场景、拟用义项/用法先服务写作，预览只是投影。共同规划覆盖普通、N0及后台basic；同请求同目标模型，writer及编辑继续完整结构化Candidate输出。
2. 增强固定实际编辑一次，与条件返修N/基础纠错分开计数；N0不执行编辑/审稿/返修。保留实际发送、用量和牵强/矛盾原因口径，规划/固定编辑不能混入条件返修分子。
3. 复核研究首稿无调用校验、编辑前不耗基础恢复及lastValid。建议保留已完整有效首稿承接编辑故障Q02；有有效稿按提示/保存/计次原则，无有效稿失败，不能从未校验草稿拼出结果。规划无有效稿故障、取消/断连/DB未知分别处理，不以A选择虚构故障细字段已批准。
4. 稿件身份/版本与内容返修次数必须分开：固定编辑也产生稿，BE04的版本=返修次数+1不能直接沿用。复核usage阶段、调用结构普通2+t/增强4+2k+t、基础2共享位置、有限循环及原有时限；不因N大而自行延长时间或声称已测高轮次。
5. 规划不是Candidate passage-first对象，需独立有界结构化接收和安全临时投影；具体schema/参数由后端设计。研究英文规划不能假称已有zh/ja，建议同次输出遵循释义语言的摘要，英语词形/短语保持英语；不额外调用翻译或词典。临时本篇义项不得替代最终原词通用释义。
6. 保留真实正文追加/删尾/替换、等待保留旧稿、lastValid恢复与DB确认整包后保存。交付对应真实fixtures及设计接收合同后再由designer-tony更新完整页面；当前stream-v4只覆盖旧正文流，不能声称已验证规划/固定编辑。

CR-302中的designer-tony/frontend-bob/dba-diana/implementer/QA依赖均保留pending。已核对 [DB02](../technical/database.md)：call_stage四类白名单与两个run表final_content_version≤N+1不能直接容纳规划/固定编辑的新阶段和稿身份；后端先定语义，再交dba-diana同步DB设计及待审迁移约束。不预设新DB表，不改现有未提交源码，不提前让UI自行猜规划事件。下一步完成条件是backend-alex对上述条目给出一致可接收设计与fixture，再按流程交UI；不是本角色宣布技术或整个CR完成。

## 维护与有限检查

修订前8/8原件已与 [PRODUCT06/control028源包](../reviews/evidence/control-028/M003-PRODUCT-06-source.tar.gz) 逐字一致；旧差异审计及A/B/C比较留在该冻结包，未覆盖。早期 [研发输入恢复快照](../product/evidence/research-alignment-06/research-handoff-before-product06.tar.gz)、PRODUCT05、BE04、UI06及研究证据保持。

本轮仅版本、链接、稳定ID、未选分支残留和保留规则核对，结果：8/8原件均标识PRODUCT07，86处本地链接/锚点无断链，六份主原件原显式稳定锚点保留；两类预算/管理配置矩阵与AC-301–307/309–311/313–314逐字未变，PRODUCT06源包hash未变。混合调用示例已加入规划/固定编辑并标技术待复核，旧选项仅保留冻结引用。未跑新模型/业务/浏览器测试，不修改状态、历史、技术/API/UI/FE/DB/源码、冻结证据，不提交或部署。

## 未验证与接续边界

无新增业务决策，Q3-02已闭环；CR-302下游尚未完成。已选A的质量、规划语言投影、固定编辑故障适配、真实首内容/正文/换稿等待、费用及CPU/RSS/GC等成本未验证。研究14/20交付中7通过、6有重要缺陷、1分歧，另6执行器中断；历史混合19/20不证明当前同模型链路达标。

保留CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX及独立UAT/发布权限。不把用户选择或文档检查当作技术、视觉或实现通过。
