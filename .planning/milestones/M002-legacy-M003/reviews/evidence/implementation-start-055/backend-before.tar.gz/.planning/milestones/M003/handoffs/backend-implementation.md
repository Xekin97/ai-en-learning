---
milestone: M003
stage: implementation
role: backend-implementer/base
agent_name: backend-ethan
status: awaiting_user_review
date: 2026-10-09
---

# 后端实施角色交接单

## 使用的输入

- 门禁：[`technical-design-012.md`](../reviews/technical-design-012.md)，`TRANSITION-M003-012`。
- 产品与行为：[`abilities.md`](../product/abilities.md)、[`ai-behavior.md`](../product/ai-behavior.md)，版本 M003-PRODUCT-03。
- 技术真源：[`database.md`](../technical/database.md) M003-DB-02、[`backend.md`](../technical/backend.md) M003-BE-02、[`ai-integration.md`](../technical/ai-integration.md) 及 [`api/index.md`](../technical/api/index.md) 的 API-301–304。
- 上游交接：[`database.md`](database.md)、[`backend-architecture.md`](backend-architecture.md)、[`frontend-architecture.md`](frontend-architecture.md)。
- 用户决定：[`requirements-feedback.md`](../reviews/requirements-feedback.md) 的 `Q01-B`、`Q02-A`、`Q03-RANGE99`。冻结配置为 `consumer-ai-web@1.0.0`，源码基线为 `45a4ab123c3308fa0a83868b6030c6b84a96f67d`。

## 需求确认闭环

- 普通/visitor 只执行首稿 prompt 与基础校验，内容服务 N0；Pro/Plus 独立 N=0–99，初值 1，基础纠错预算全请求共享 2 次。
- 同一已受理模型与连接完成初稿、review、rewrite；有具体 issues 才整稿重写，pass 早停，预算耗尽仍 issues 时定稿最后有效稿。
- 只有已有 last-valid 包时，六类内容技术故障可交付 `service_incomplete`；无有效稿、取消、断连、DB/usage 关键事实未知不使用 Q02 成功语义。
- 用户视觉评审仍未完成。它不改变本轮已确认后端契约，也不构成对 UI 的用户批准；前端未自动激活或联调。
- 尚无阻塞后端实现的产品假设；没有真实收费批次、线上配置、UAT3302 或部署授权。

## 本次产物

- 数据库迁移：[`0017_m003_content_review.sql`](../../../../backend/db/migrations/0017_m003_content_review.sql)。
- AI 与 pipeline：[`content_tasks.go`](../../../../backend/internal/ai/content_tasks.go)、[`pipeline.go`](../../../../backend/internal/generation/pipeline.go)、AI gateway/provider/usage 相关现有文件。
- 受理、终态与查询：generation service、[`status.go`](../../../../backend/internal/generation/status.go)、generation/preset HTTP handlers。
- entitlement/admin/preset/usage：`backend/internal/{entitlement,admin,generation,httpapi}` 内的 M003 差异。
- 测试入口：`content_tasks_test.go`、`pipeline_test.go`、`m003_*_integration_test.go` 及完整既有 integration suite。
- 开发验证：[`backend-validation.md`](../implementation/backend-validation.md)；原始日志在 [`implementation/evidence`](../implementation/evidence/)。
- 工作区决定：[`backend-worktree-plan.md`](../implementation/backend-worktree-plan.md)。

## 实现结果

- 0017 在真实最高版本 0016 上单向迁移。历史 run/preview/usage 不伪造新事实；新写入默认 policy v1，并由组合约束要求完整 snapshot 和合法 outcome/stop reason。
- plan group API 返回内容服务、只读 NativePolicy、impact 和 revision；0/99 可写，负数/100/小数/null/缺失/开关错配/basic 开启均拒绝。
- 三协议发送版本化初稿、strict review schema 和 rewrite 模板；provider 是否实际发送为 true/false/NULL，Reserve/MarkInvoked/RecordReview/FinishUsage 关键错误会中止而非只记录日志。
- pipeline 保存不可变 last-valid candidate+validated batch+version，支持 N0/N1/N2 实际流程、六类可恢复故障、180 秒单调用与 600 秒总执行边界。
- generation 与 preset 都在 acceptance commit 且 `started` flush 后调用 provider，使用精确 SSE seq、累计 snapshot、整包 candidate 和唯一 validated；status 使用 owner/token/TTL 和持久化结果恢复。
- preset basic/enhanced 固定 N0/N1，保存 mode 后预览；旧 mode 迟到结果不能解锁新 draft，valid incomplete 可手动发布并保留 notice。
- usage 分开文章交付、review 完成、调用事实和费用 unknown；未保存原句、私人 review 证据或新诊断平台。

## 追踪与自检

- 覆盖 API-301–304、AC-301–311、AC-313–314 的后端实现；AC-312 只完成替身与时间边界，真实内容质量仍待授权 QA。
- BE3-V01–14、DB3-V01–06 的逐项状态、命令和局限见 [`backend-validation.md`](../implementation/backend-validation.md)。
- 最终结果：unit、vet、race、build、隔离 PostgreSQL domain integration 和完整 HTTP integration 全部 exit 0；真实 0016→0017 升级保留历史 NULL 并验证 migration replay。
- `git diff --check` 通过；所有已有未提交规划/控制面/docs 修改均保留。未提交、未推送、未部署。

## 文档整理

- 当前权威入口仍是上游产品、DB02、BE02、AI 与 API 文档；本交接只描述实现状态，没有重写设计真源。
- 早期失败日志与最终通过日志都保留在 evidence 目录，便于复核修复轨迹；未归档或覆盖冻结上游证据。
- 稳定 ID 映射保持 BE3-V01–14、DB3-V01–06 和 API-301–304。

## 未决事项

- `OPEN / 已实现未由独立 QA 验证`：控制面需复核本次后端差异与 [`backend-validation.md`](../implementation/backend-validation.md) 的 PARTIAL 项。
- `OPEN / AC-312`：QA 需使用冻结输入、连接、prompt 和 pipeline 进行真实模型逐句质量、费用和时延验证；当前没有调用授权。
- `OPEN / UI`：用户视觉评审及浏览器前后端联调尚未完成，前端角色应在收到明确门禁后再接 API-301–304。
- 全局 `USER-COMPAT-001`、`USER-CLAIM-DELETE-001` 与长期未验证项继续保留。
- 开放变更请求：无。

## 已知风险

- 内容质量、provider 特有响应差异、真实费用和尾延迟只在替身环境验证；真实连接可能暴露新的兼容性问题。
- BE3-V05/V06/V10、DB3-V02/V05/V06 的开发证据为 PARTIAL，具体缺口已写入验证报告，不能被解释为 QA PASS。
- 当前是共享未提交工作区；后续角色必须保留其他角色及用户现有修改，不能整体提交或清理 `.planning`/`docs`。

## 下一步建议

- 推荐控制面/代码复核角色先检查 migration、终态事务、SSE/API 和验证缺口；完成条件是确认差异符合 `TRANSITION-M003-012` 且无新的 HIGH 契约问题。
- 用户完成视觉评审且门禁明确后，frontend 实施角色再按 API-301–304 联调；QA 使用隔离环境执行剩余真实质量与浏览器验证。
- 本交接建议状态为 `awaiting_user_review`，不宣称 QA、真实模型效果、UAT、部署或阶段迁移完成。

> 本交接单不能切换阶段。阶段迁移必须由用户显式提交给守门器。
