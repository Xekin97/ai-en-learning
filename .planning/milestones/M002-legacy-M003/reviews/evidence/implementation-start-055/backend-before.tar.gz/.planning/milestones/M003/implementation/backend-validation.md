# M003 后端开发验证

日期：2026-10-09  
角色：backend-ethan  
基线：`45a4ab123c3308fa0a83868b6030c6b84a96f67d`  
状态：实现完成，等待用户/控制面评审；本文只记录开发期验证，不代表 QA、真实模型质量或生产验收。

## 验证环境

- Go：`GOTOOLCHAIN=go1.26.7`。
- 数据库：本机 PostgreSQL 18 临时独立 cluster，随机未占用端口；所有 integration 测试显式传入 `TEST_DATABASE_URL`，未读取仓库 `.env`、未使用共享 compose 数据库、未触碰 UAT3302。
- AI：已有三协议 HTTP 替身与内存 provider；无真实凭据、真实收费或线上模型调用。
- 内容返修只执行 N=0/1/2；N=99 只检查配置边界、字段持久化和静态调用上界公式。

## 最终命令与结果

| 命令 | 结果 | 证据 |
|---|---:|---|
| `GOTOOLCHAIN=go1.26.7 go test -count=1 ./...` | PASS，exit 0 | [`backend-unit-all-final.log`](evidence/backend-unit-all-final.log) |
| `GOTOOLCHAIN=go1.26.7 go vet ./...` | PASS，exit 0 | [`backend-vet-final.log`](evidence/backend-vet-final.log) |
| `GOTOOLCHAIN=go1.26.7 go build ./...` | PASS，exit 0 | [`backend-build-final.log`](evidence/backend-build-final.log) |
| `GOTOOLCHAIN=go1.26.7 go test -race ./internal/ai ./internal/generation ./internal/admin ./internal/entitlement ./internal/httpapi` | PASS，exit 0 | [`backend-race-final.log`](evidence/backend-race-final.log) |
| `go test -count=1 -tags=integration ./internal/platform/postgres ./internal/generation ./internal/admin ./internal/entitlement ./internal/maintenance`，显式隔离 `TEST_DATABASE_URL` | PASS，5 包 exit 0 | [`backend-integration-domain-final2.log`](evidence/backend-integration-domain-final2.log) |
| `go test -count=1 -tags=integration ./internal/httpapi`，显式隔离 `TEST_DATABASE_URL` | PASS，exit 0，138.383s | [`backend-integration-httpapi-final3.log`](evidence/backend-integration-httpapi-final3.log) |
| `gofmt -l <changed-go-files>` 与 `git diff --check` | PASS，均 exit 0 且无输出 | [`backend-format-diff-final.log`](evidence/backend-format-diff-final.log) |

早期失败证据保留在同一 evidence 目录。它们记录了旧 SSE 断言、provider 阶段顺序、settlement pending 语义和 fixture 未填写新 v1 快照等问题；修复没有删除或弱化既有契约断言。最终判定以上表的 `final`/`final2`/`final3` 证据为准。

## BE3 验证映射

| ID | 开发期结果 | 实际覆盖与边界 |
|---|---|---|
| BE3-V01 | PASS | pipeline N0 不调用内容服务；N1/N2 按同一 provider/连接完成 review/rewrite；基础校验预算独立。三协议 request schema 在 `content_tasks_test.go` 验证。 |
| BE3-V02 | PASS | strict review schema、pass 早停、issues 后整稿重写、N2 上限定稿及问题证据枚举均有单元覆盖；prompt 版本常量与模板断言按 BATCH-V2 冻结文本更新。 |
| BE3-V03 | PASS | last-valid 完整 candidate/batch/version、重写版本递增、基础修正不增版本、失败尝试 3 回退有效 v2、无初稿有效包不伪装 incomplete 均有覆盖。 |
| BE3-V04 | PASS | 四计划初值、Pro/Plus 0/99、负数/100/小数/null/缺失/配对错误、basic 开启、只读 NativePolicy 与管理员权限经 unit、service integration 及完整 HTTP integration 覆盖。 |
| BE3-V05 | PARTIAL | impact before/after、accepted snapshot、关闭警告、revision 冲突已覆盖；针对 plan group PUT 的专用“数据库已提交但 HTTP ACK 丢失”注入未单独新增，现有配置 ACK 丢失和重读行为只提供同仓回归基础。 |
| BE3-V06 | PARTIAL | acceptance 持久化完整 entitlement/config/model/pipeline 快照，运行后读取冻结值；既有 trial、优先级与配额集成测试全量回归通过。未为所有“变更恰好发生在受理前/后”组合逐一新增并发测试。 |
| BE3-V07 | PASS | 受理前模型/次数校验、visitor/account 额度来源、extra 退款与运行快照由 reservation/entitlement integration 覆盖；内容权益只来自计划快照，basic/visitor 为 N0，extra 不改变 N。 |
| BE3-V08 | PASS | `started` 在 commit+flush 后，精确 seq 事件、累计 snapshot、整包 candidate、唯一 validated、Open/receive/validation/DB 失败、EOF/pending、取消和终态竞争由 HTTP matrix/race/boundary tests 覆盖。 |
| BE3-V09 | PASS | preset basic/enhanced 固定 N0/N1、先保存 mode、旧 mode 晚完成隔离、title-only 复用、valid incomplete 手动发布、管理读取 notice、公开浏览不调用均由 preset/status integration 覆盖。 |
| BE3-V10 | PARTIAL | usage true/false/NULL、unknown cost/tokens、review reason 集合和 provider call 数有 unit/integration 覆盖；未对生产规模 CAP305 报表做性能或大数据量验证。 |
| BE3-V11 | PASS | valid/incomplete/取消/断连/commit ACK/终态竞争/extra 过期退款/settlement unknown 与唯一 charge/claim 由 HTTP matrix/race 及 entitlement integration 覆盖。 |
| BE3-V12 | PARTIAL | 替身流边界、首段/慢流和总执行 deadline 有自动化覆盖；真实模型逐句自然度、因果、文体、真实费用和时延均未获授权执行。 |
| BE3-V13 | PASS | 六类内容技术 stop reason、已有 last-valid 与无有效稿分支、关键 usage/DB 错误不转 Q02、status/stream/preview notice 持久化一致均有覆盖。 |
| BE3-V14 | PASS | N0/N1/N2 实际流程与共享基础预算混合覆盖；N99 只验证配置和 `1 + 2 + (N+1) + N` 静态上界，不执行 3–99 轮。 |

## DB3 验证映射

| ID | 开发期结果 | 实际覆盖与边界 |
|---|---|---|
| DB3-V01 | PASS | 真实 0016→0017 升级、当前完整迁移、四计划初值、0/99 和非法值、`content_policy_version DEFAULT 1`、显式历史 NULL、revision 冲突及迁移幂等通过。 |
| DB3-V02 | PARTIAL | 受理写入完整 frozen snapshot，内容服务不从模型卡/extra 派生；trial/priority/quota 旧集成回归通过。未枚举所有配置变更与受理交错时序。 |
| DB3-V03 | PASS | N0/1/2、last-valid/final version、六 stop reasons、失败无有效稿、取消/DB 未知、唯一终态、commit ACK、settlement unknown、唯一扣退由 pipeline 与隔离 PG HTTP tests 覆盖。 |
| DB3-V04 | PASS | preset mode、切换、旧 run 关联保护、title-only 条件、incomplete 发布/notice、公开 pointer 保护与后台 owner 用量由隔离 PG tests 覆盖。 |
| DB3-V05 | PARTIAL | true/false/NULL 调用事实、review reason、unknown 费用、正常/预设隔离及同 run 调用事实有覆盖；大样本文章去重和生产统计查询计划未做本期性能验证。 |
| DB3-V06 | PARTIAL | 跨账号/跨管理员 status、token TTL、claim/delete/cleanup 既有 integration 回归和真实 0016 升级历史 NULL 通过；未执行人为损坏迁移后的灾难恢复演练。 |

## 关键数据库结论

- `0017_m003_content_review.sql` 先添加可空事实列，历史行保持 NULL，再为新写入设置 `content_policy_version DEFAULT 1`；新请求缺少其余 v1 snapshot 时由组合约束拒绝。
- 旧 `ai_call_usage` 行迁移为 `call_stage='legacy'`，provider/prompt/review 新事实保持 unknown/not-applicable；约束拒绝把 legacy invocation 伪造为 true。
- Pro 与 Plus 只在首次 0017 迁移得到 `enabled=true, limit=1`，启动过程不重复 seed；basic/registered 保持 0。
- outcome、final version、stop reason、failure fields、charge/refund 和最终内容在事务边界内保持一致；unknown settlement 明确返回 pending/503，不伪装已取消或已退款。

## 未验证与保留项

- 未进行真实 OpenAI/Anthropic 供应商调用、真实模型内容质量、真实收费/费用、生产延迟或 3–99 轮内容返修。
- 未进行前端浏览器联调、用户视觉评审或 QA/UAT；用户视觉评审仍未完成，前端未因本实现自动激活。
- 未连接线上数据库、生产配置、共享开发库或 UAT3302；未提交、推送或部署。
- 全局 `USER-COMPAT-001`、`USER-CLAIM-DELETE-001` 及既有长期未验证项保持原状态；本实现没有扩大范围或宣称解决。
