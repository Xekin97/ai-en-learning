# 后端实现工作区计划

## 已确认基础

- 输入为 `TRANSITION-M003-012` 通过的 M003-PRODUCT-03、M003-DB-02、M003-BE-02、API-301–304 与 AI3-01–06；用户决定沿用 `Q01-B`、`Q02-A`、`Q03-RANGE99`。
- 实现基线为 `45a4ab123c3308fa0a83868b6030c6b84a96f67d`，配置档案固定为 `consumer-ai-web@1.0.0`。
- 后端任务边界是 `backend/**`、本目录的后端验证证据和后端角色交接；不接管前端、视觉设计、QA、部署或阶段控制。
- 未出现会改变后端任务边界的未确认解释。用户视觉评审仍未完成，但不阻塞已经确认的独立后端契约。

## 当前任务与验收

任务与验收使用 [`technical/backend.md`](../technical/backend.md) 的 `BE3-01–07`、`BE3-V01–14` 和 [`technical/database.md`](../technical/database.md) 的 `DB3-01–09`、`DB3-V01–06`。执行结果见 [`backend-validation.md`](backend-validation.md)，不在本计划复制第二套任务状态。

## 是否需要并行

- pipeline、usage、generation service、HTTP handler、preset 和 migration 共享类型与终态事务，修改顺序存在直接依赖。
- 当前仓库已有用户及其他角色的未提交规划文档；另开 worktree 会要求选择性搬运大量共享文件，并增加丢失或覆盖未提交修改的风险。
- 本角色单人顺序实现即可获得可接受反馈周期，并通过隔离 PostgreSQL 和独立测试数据库保证运行隔离。
- 结论：使用现有单工作区，不创建分支或 Git worktree。

## 工作树分配

| 任务 | 分支 | worktree 路径 | 文件责任边界 | 依赖 | 负责人语义名 |
|---|---|---|---|---|---|
| M003 后端实现与开发验证 | 当前未提交工作区 | 仓库根目录 | `backend/**`、后端验证报告、后端交接与本计划 | DB02、BE02、API、AI 模板 | backend-ethan |

## 合并顺序

本角色不提交或合并。实现顺序为 migration/schema → entitlement/admin → AI/pipeline/usage → generation/status/SSE → presets → 集成验证。共享契约若需变化，停止受影响代码并交回原设计角色；本轮未发生这种情况。

## 合并检查

- 当前工作区继续保留既有 `.planning/agt/**`、workflow、M003 上游文档及 `docs/` 修改，未删除或回退。
- 后端差异通过 gofmt、`git diff --check`、unit、vet、race、build 和隔离 PostgreSQL integration。
- 未提交、未推送、未部署，也未连接真实模型或用户 UAT3302。

## 清理条件

未创建 worktree 或分支，因此没有可清理的 Git 资源。隔离 PostgreSQL 只在全部数据库验证结束后停止并删除，且不操作本机共享数据库。
