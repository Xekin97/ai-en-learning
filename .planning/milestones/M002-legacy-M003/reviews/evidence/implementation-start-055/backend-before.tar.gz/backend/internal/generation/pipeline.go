package generation

import (
	"context"
	"errors"
	"time"
	"unicode"
	"unicode/utf8"

	"wordweave/internal/ai"
	"wordweave/internal/entitlement"
)

const (
	OutcomeBasic             = "basic"
	OutcomeReviewPassed      = "review_passed"
	OutcomeRepairedPassed    = "repaired_passed"
	OutcomeLimitFinalized    = "limit_finalized"
	OutcomeServiceIncomplete = "service_incomplete"
)

type PipelineResult struct {
	Version    int
	Candidate  ai.Candidate
	Batch      ai.ValidatedBatch
	Outcome    string
	StopReason *string
}

type pipelineExecutionError struct {
	phase string
	err   error
}

func (err *pipelineExecutionError) Error() string { return err.err.Error() }
func (err *pipelineExecutionError) Unwrap() error { return err.err }

func pipelineFailure(phase string, err error) error {
	if err == nil {
		return nil
	}
	return &pipelineExecutionError{phase: phase, err: err}
}

// PipelineFailurePhase returns the stable execution boundary used for safe
// diagnostics and terminal classification. Provider/content details remain in
// the wrapped error and are never included in the public response.
func PipelineFailurePhase(err error) string {
	var execution *pipelineExecutionError
	if errors.As(err, &execution) {
		return execution.phase
	}
	return "pipeline"
}

type PipelineHooks struct {
	Stage         func(stage string, attemptVersion, repairAttempt int) error
	Snapshot      func(passage string) error
	Candidate     func(version int, batch ai.ValidatedBatch) error
	Review        func(version int, review ai.Review, repairRequested bool) error
	ReviewFailure func(version int) error
}

type validPackage struct {
	version   int
	candidate ai.Candidate
	batch     ai.ValidatedBatch
}

func ExecutePipeline(ctx context.Context, provider ai.Provider, validator ai.Validator, spec ai.GenerationSpec, policy entitlement.ContentService, hooks PipelineHooks) (PipelineResult, error) {
	execution, cancel := context.WithTimeout(ctx, 600*time.Second)
	defer cancel()
	budget := ai.NewRepairBudget(entitlement.NativeCorrectionLimit)
	callCtx, callCancel := boundedCall(execution)
	if hooks.Stage != nil {
		callCtx = ai.WithRepairObserver(callCtx, func() error { return hooks.Stage("native_repair", 1, 0) })
		callCtx = ai.WithInvocationObserver(callCtx, func() error { return hooks.Stage("generating", 1, 0) })
	}
	stream, err := provider.Open(callCtx, spec)
	if err != nil {
		callCancel()
		return PipelineResult{}, pipelineFailure("provider_open", err)
	}
	accumulator := newSnapshotAccumulator(hooks.Snapshot)
	candidate, err := ai.ReceiveWithRepairBudget(callCtx, provider, validator, spec, stream, accumulator.Add, budget)
	_ = stream.Close()
	callCancel()
	if err != nil {
		return PipelineResult{}, pipelineFailure("provider_receive", err)
	}
	if err = accumulator.Flush(); err != nil {
		return PipelineResult{}, pipelineFailure("delivery", err)
	}
	batch, err := validator.Validate(execution, spec, candidate)
	if err != nil {
		return PipelineResult{}, pipelineFailure("validation", err)
	}
	last := validPackage{version: 1, candidate: candidate, batch: batch}
	if hooks.Candidate != nil {
		if err := hooks.Candidate(1, batch); err != nil {
			return PipelineResult{}, pipelineFailure("delivery", err)
		}
	}
	if !policy.ContentReviewEnabled || policy.ContentRepairLimit == 0 {
		return pipelineFinal(last, OutcomeBasic, ""), nil
	}
	contentProvider, ok := provider.(ai.ContentProvider)
	if !ok {
		return PipelineResult{}, pipelineFailure("pipeline", errors.New("provider does not implement content review"))
	}
	repairs := 0
	for {
		if err := execution.Err(); err != nil {
			return pipelineIncomplete(last, "content_timeout"), nil
		}
		callCtx, callCancel = boundedCall(execution)
		if hooks.Stage != nil {
			version, repair := last.version, repairs
			callCtx = ai.WithInvocationObserver(callCtx, func() error { return hooks.Stage("content_review", version, repair) })
		}
		review, reviewErr := contentProvider.Review(callCtx, spec, last.batch)
		callCancel()
		if reviewErr != nil {
			if errors.Is(reviewErr, ai.ErrCriticalUsageFact) {
				return PipelineResult{}, pipelineFailure("usage_record", reviewErr)
			}
			if hooks.ReviewFailure != nil {
				if err := hooks.ReviewFailure(last.version); err != nil {
					return PipelineResult{}, pipelineFailure("review_record", err)
				}
			}
			return pipelineIncomplete(last, contentStopReason(reviewErr, true)), nil
		}
		willRepair := review.Verdict == "issues" && repairs < policy.ContentRepairLimit
		if hooks.Review != nil {
			if err := hooks.Review(last.version, review, willRepair); err != nil {
				return PipelineResult{}, pipelineFailure("review_record", err)
			}
		}
		if review.Verdict == "pass" {
			if repairs == 0 {
				return pipelineFinal(last, OutcomeReviewPassed, ""), nil
			}
			return pipelineFinal(last, OutcomeRepairedPassed, ""), nil
		}
		if repairs >= policy.ContentRepairLimit {
			return pipelineFinal(last, OutcomeLimitFinalized, ""), nil
		}
		repairs++
		attemptVersion := repairs + 1
		callCtx, callCancel = boundedCall(execution)
		if hooks.Stage != nil {
			version, repair := attemptVersion, repairs
			callCtx = ai.WithRepairObserver(callCtx, func() error { return hooks.Stage("native_repair", version, repair) })
			callCtx = ai.WithInvocationObserver(callCtx, func() error { return hooks.Stage("content_repair", version, repair) })
		}
		rewrite, rewriteErr := contentProvider.OpenRewrite(callCtx, spec, last.candidate, review.Issues)
		if rewriteErr != nil {
			callCancel()
			if errors.Is(rewriteErr, ai.ErrCriticalUsageFact) {
				return PipelineResult{}, pipelineFailure("usage_record", rewriteErr)
			}
			return pipelineIncomplete(last, contentStopReason(rewriteErr, false)), nil
		}
		nextCandidate, rewriteErr := ai.ReceiveWithRepairBudget(callCtx, provider, validator, spec, rewrite, func(string) error { return nil }, budget)
		_ = rewrite.Close()
		callCancel()
		if rewriteErr != nil {
			if errors.Is(rewriteErr, ai.ErrCriticalUsageFact) {
				return PipelineResult{}, pipelineFailure("usage_record", rewriteErr)
			}
			return pipelineIncomplete(last, contentStopReason(rewriteErr, false)), nil
		}
		nextBatch, validateErr := validator.Validate(execution, spec, nextCandidate)
		if validateErr != nil {
			return pipelineIncomplete(last, "repair_native_invalid"), nil
		}
		last = validPackage{version: attemptVersion, candidate: nextCandidate, batch: nextBatch}
		if hooks.Candidate != nil {
			if err := hooks.Candidate(last.version, last.batch); err != nil {
				return PipelineResult{}, pipelineFailure("delivery", err)
			}
		}
	}
}

func boundedCall(parent context.Context) (context.Context, context.CancelFunc) {
	return context.WithTimeout(parent, 180*time.Second)
}

func pipelineFinal(p validPackage, outcome, reason string) PipelineResult {
	var stop *string
	if reason != "" {
		stop = &reason
	}
	return PipelineResult{Version: p.version, Candidate: p.candidate, Batch: p.batch, Outcome: outcome, StopReason: stop}
}

func pipelineIncomplete(p validPackage, reason string) PipelineResult {
	return pipelineFinal(p, OutcomeServiceIncomplete, reason)
}

func contentStopReason(err error, review bool) string {
	if errors.Is(err, context.DeadlineExceeded) {
		return "content_timeout"
	}
	var providerErr *ai.ProviderError
	if errors.As(err, &providerErr) {
		switch providerErr.Category {
		case ai.FailureRateLimited:
			return "content_rate_limited"
		case ai.FailureUnavailable:
			return "content_transport_error"
		case ai.FailureProtocol, ai.FailureAuthentication, ai.FailureAuthorization:
			return "content_protocol_error"
		case ai.FailureSchema, ai.FailureContent:
			if review {
				return "content_review_invalid"
			}
			return "repair_native_invalid"
		}
	}
	if review {
		return "content_review_invalid"
	}
	return "content_transport_error"
}

type snapshotAccumulator struct {
	text     string
	emitted  bool
	emit     func(string) error
	lastSent string
	lastEmit time.Time
}

func newSnapshotAccumulator(emit func(string) error) *snapshotAccumulator {
	return &snapshotAccumulator{emit: emit}
}

func (a *snapshotAccumulator) Add(delta string) error {
	a.text += delta
	if a.emit == nil || delta == "" {
		return nil
	}
	if !a.emitted {
		runes := []rune(a.text)
		boundary := len(runes) >= 32 && (unicode.IsSpace(runes[len(runes)-1]) || unicode.IsPunct(runes[len(runes)-1]))
		sentence := len(runes) > 0 && (runes[len(runes)-1] == '.' || runes[len(runes)-1] == '!' || runes[len(runes)-1] == '?')
		if !boundary && !sentence {
			return nil
		}
		a.emitted = true
	} else if time.Since(a.lastEmit) < 250*time.Millisecond {
		return nil
	}
	if !utf8.ValidString(a.text) {
		return errors.New("snapshot is not valid UTF-8")
	}
	if err := a.emit(a.text); err != nil {
		return err
	}
	a.lastSent, a.lastEmit = a.text, time.Now()
	return nil
}

func (a *snapshotAccumulator) Flush() error {
	if a.emit == nil || !a.emitted || a.text == a.lastSent {
		return nil
	}
	if !utf8.ValidString(a.text) {
		return errors.New("snapshot is not valid UTF-8")
	}
	if err := a.emit(a.text); err != nil {
		return err
	}
	a.lastSent, a.lastEmit = a.text, time.Now()
	return nil
}
