//go:build integration

package generation

import (
	"errors"
	"strings"
	"testing"
	"time"

	"github.com/google/uuid"
	"wordweave/internal/ai"
	"wordweave/internal/identity"
	"wordweave/internal/platform/security"
	"wordweave/internal/testdb"
)

func TestM003GenerationStatusUsesPersistedOutcomeOwnerAndTTL(t *testing.T) {
	pool, ctx := testdb.Open(t)
	owner := testdb.Learner(t, ctx, pool)
	if _, err := pool.Exec(ctx, `UPDATE wordweave.accounts SET group_code='pro' WHERE id=$1`, owner); err != nil {
		t.Fatal(err)
	}
	var model uuid.UUID
	if err := pool.QueryRow(ctx, `INSERT INTO wordweave.ai_models(display_name,provider_model_id,enabled) VALUES('M003 status model','test/m003-status',true) RETURNING id`).Scan(&model); err != nil {
		t.Fatal(err)
	}
	if _, err := pool.Exec(ctx, `INSERT INTO wordweave.group_models(group_code,model_id) VALUES('pro',$1)`, model); err != nil {
		t.Fatal(err)
	}
	envelope, err := security.NewEnvelope(map[int][]byte{1: make([]byte, 32)}, 1)
	if err != nil {
		t.Fatal(err)
	}
	credentials := ai.NewCredentialStore(pool, envelope)
	if err = credentials.Put(ctx, owner, "synthetic-not-a-real-key"); err != nil {
		t.Fatal(err)
	}
	service := NewService(pool, credentials, nil, []byte(strings.Repeat("s", 32)), 30*time.Minute, ai.Validator{})
	actor := identity.Actor{ID: owner, Kind: "account", Role: "learner", GroupCode: "pro"}
	run, err := service.Start(ctx, actor, Input{ModelID: model.String(), MeaningLanguage: "en", Scenario: "story", Length: "short", Entries: []string{"learn", "weave"}})
	if err != nil {
		t.Fatal(err)
	}
	stop := "content_review_invalid"
	if err = service.CompletePipeline(ctx, run, PipelineResult{Version: 1, Batch: samplePreset(), Outcome: OutcomeServiceIncomplete, StopReason: &stop}); err != nil {
		t.Fatal(err)
	}
	view, err := service.ReadStatus(ctx, actor, run.ID, run.Token)
	if err != nil || view.Status != "valid" || view.ContentOutcome == nil || *view.ContentOutcome != OutcomeServiceIncomplete || view.FinalContentVersion == nil || *view.FinalContentVersion != 1 || view.CompletionNotice == nil || *view.CompletionNotice != "content_review_incomplete" || view.Result == nil || !view.CanSave || view.QuotaRefunded {
		t.Fatalf("view=%+v err=%v", view, err)
	}
	other := identity.Actor{ID: testdb.Learner(t, ctx, pool), Kind: "account", Role: "learner", GroupCode: "registered"}
	if _, err = service.ReadStatus(ctx, other, run.ID, run.Token); !errors.Is(err, ErrRunNotFound) {
		t.Fatalf("cross-account status error=%v", err)
	}
	if _, err = pool.Exec(ctx, `UPDATE wordweave.generation_runs SET completed_at=clock_timestamp()-$2::interval WHERE id=$1`, run.ID, intervalLiteral(TerminalTokenRetention+time.Minute)); err != nil {
		t.Fatal(err)
	}
	if _, err = service.ReadStatus(ctx, actor, run.ID, run.Token); !errors.Is(err, ErrRunExpired) {
		t.Fatalf("expired status error=%v", err)
	}
}

func TestM003PreviewStatusKeepsAcceptedModeAfterDraftModeChanges(t *testing.T) {
	service, pool, ctx, admin, input := presetFixture(t)
	input.PreviewContentMode = "enhanced"
	preset, revision, err := service.SavePreset(ctx, admin, uuid.Nil, input, "")
	if err != nil {
		t.Fatal(err)
	}
	run, err := service.StartPreviewMode(ctx, admin, preset.ID, preset.DraftVersion, "enhanced")
	if err != nil {
		t.Fatal(err)
	}
	stop := "content_rate_limited"
	if _, err = service.CompletePreviewPipeline(ctx, run, PipelineResult{Version: 1, Batch: samplePreset(), Outcome: OutcomeServiceIncomplete, StopReason: &stop}); err != nil {
		t.Fatal(err)
	}
	input.PreviewContentMode = "basic"
	if _, _, err = service.SavePreset(ctx, admin, preset.ID, input, revision); err != nil {
		t.Fatal(err)
	}
	view, err := service.ReadPreviewStatus(ctx, admin, run.ID, run.Token)
	if err != nil || view.Status != "valid" || view.PreviewContentMode != "enhanced" || view.ContentOutcome == nil || *view.ContentOutcome != OutcomeServiceIncomplete || view.CompletionNotice == nil || view.Result == nil || view.FinalContentVersion == nil || *view.FinalContentVersion != 1 {
		t.Fatalf("view=%+v err=%v", view, err)
	}
	otherAdmin := identity.Actor{ID: uuid.New(), Kind: "account", Role: "admin"}
	if _, err = service.ReadPreviewStatus(ctx, otherAdmin, run.ID, run.Token); !errors.Is(err, ErrRunNotFound) {
		t.Fatalf("cross-admin status error=%v", err)
	}
	if _, err = pool.Exec(ctx, `UPDATE wordweave.preset_preview_runs SET completed_at=clock_timestamp()-$2::interval WHERE id=$1`, run.ID, intervalLiteral(TerminalTokenRetention+time.Minute)); err != nil {
		t.Fatal(err)
	}
	if _, err = service.ReadPreviewStatus(ctx, admin, run.ID, run.Token); !errors.Is(err, ErrRunExpired) {
		t.Fatalf("expired preview status error=%v", err)
	}
}
