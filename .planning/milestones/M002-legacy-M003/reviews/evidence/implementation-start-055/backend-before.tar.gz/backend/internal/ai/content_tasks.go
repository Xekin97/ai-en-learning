package ai

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"io"
	"strings"
	"unicode/utf8"
)

const maxReviewBytes = 64 << 10

// Review uses the run's already-bound connection snapshot and target model.
// Review prose and evidence remain request-local; only the caller's compact
// review facts are eligible for persistence.
func (g *Gateway) Review(ctx context.Context, spec GenerationSpec, batch ValidatedBatch) (Review, error) {
	spec.review = &reviewTask{Passage: batch.Passage}
	spec.rewrite = nil
	spec.continuation = nil
	spec.correction = nil
	spec.PromptVersion = ReviewPromptVersion
	if err := g.credentials.BindSpec(ctx, &spec); err != nil {
		return Review{}, err
	}
	usage, err := beginUsage(ctx, spec)
	if err != nil {
		return Review{}, err
	}
	resp, decoder, err := g.request(ctx, spec, *spec.connection, false, usage)
	if err != nil {
		if finishErr := usage.done(); finishErr != nil {
			return Review{}, finishErr
		}
		return Review{}, err
	}
	stream := &openRouterStream{body: &privateProviderBody{ReadCloser: resp.Body, apiKey: spec.connection.apiKey}, usage: usage, decoder: decoder}
	defer stream.Close()
	raw, err := stream.receiveRawJSON(ctx, maxReviewBytes)
	if err != nil {
		return Review{}, err
	}
	return decodeReviewStrict(raw, batch.Passage)
}

func (g *Gateway) OpenRewrite(ctx context.Context, spec GenerationSpec, candidate Candidate, issues []ReviewIssue) (Stream, error) {
	spec.review = nil
	spec.rewrite = &rewriteTask{Candidate: candidate, Issues: append([]ReviewIssue(nil), issues...)}
	spec.continuation = nil
	spec.correction = nil
	spec.PromptVersion = RewritePromptVersion
	return g.Open(ctx, spec)
}

func (stream *openRouterStream) receiveRawJSON(ctx context.Context, limit int) (result []byte, resultErr error) {
	defer func() {
		if err := stream.usage.done(); err != nil {
			resultErr = err
		}
	}()
	stopClose := context.AfterFunc(ctx, func() { _ = stream.body.Close() })
	defer stopClose()
	scanner := bufio.NewScanner(stream.body)
	scanner.Buffer(make([]byte, 4096), limit+(1<<20))
	var eventData, content strings.Builder
	done := false
	process := func() error {
		data := strings.TrimSpace(eventData.String())
		eventData.Reset()
		if data == "" {
			return nil
		}
		if stream.decoder != nil {
			var err error
			data, err = stream.decoder.event(data)
			if err != nil {
				return err
			}
		}
		if data == "[DONE]" {
			done = true
			return nil
		}
		if !utf8.ValidString(data) {
			return protocolFailure()
		}
		stream.usage.observe(data, providerKey(stream.body))
		var envelope struct {
			Choices []struct {
				Delta struct {
					Content string `json:"content"`
				} `json:"delta"`
			} `json:"choices"`
			Error *struct {
				Code int `json:"code"`
			} `json:"error"`
		}
		if err := json.Unmarshal([]byte(data), &envelope); err != nil {
			return protocolFailure()
		}
		if envelope.Error != nil {
			return mapOpenRouterStatus(envelope.Error.Code)
		}
		for _, choice := range envelope.Choices {
			if content.Len()+len(choice.Delta.Content) > limit {
				return &ProviderError{Category: FailureProtocol, Retryable: false, Err: errors.New("task response exceeds byte limit")}
			}
			content.WriteString(choice.Delta.Content)
		}
		if stream.decoder != nil && stream.decoder.finished {
			done = true
		}
		return nil
	}
	for scanner.Scan() {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		line := scanner.Text()
		if line == "" {
			if err := process(); err != nil {
				return nil, err
			}
			if done {
				break
			}
			continue
		}
		if strings.HasPrefix(line, "data:") {
			if eventData.Len() > 0 {
				eventData.WriteByte('\n')
			}
			eventData.WriteString(strings.TrimPrefix(strings.TrimPrefix(line, "data:"), " "))
		}
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if err := scanner.Err(); err != nil {
		return nil, err
	}
	if !done && eventData.Len() > 0 {
		if err := process(); err != nil {
			return nil, err
		}
	}
	if stream.decoder != nil && !stream.decoder.finished {
		return nil, streamFailure("stream_incomplete")
	}
	if content.Len() == 0 {
		return nil, protocolFailure()
	}
	return []byte(content.String()), nil
}

func decodeReviewStrict(raw []byte, passage string) (Review, error) {
	invalid := func() (Review, error) {
		return Review{}, &ProviderError{Category: FailureSchema, Retryable: true, Err: errors.New("content review response is invalid")}
	}
	if len(raw) == 0 || len(raw) > maxReviewBytes || !utf8.Valid(raw) || rejectDuplicateJSONKeys(raw) != nil {
		return invalid()
	}
	var root map[string]json.RawMessage
	if json.Unmarshal(raw, &root) != nil || !exactObjectKeys(root, []string{"schema_version", "verdict", "issues"}) {
		return invalid()
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.DisallowUnknownFields()
	var review Review
	if decoder.Decode(&review) != nil || decoder.Decode(&struct{}{}) != io.EOF || review.SchemaVersion != 1 || (review.Verdict != "pass" && review.Verdict != "issues") || review.Issues == nil {
		return invalid()
	}
	if (review.Verdict == "pass" && len(review.Issues) != 0) || (review.Verdict == "issues" && (len(review.Issues) < 1 || len(review.Issues) > 12)) {
		return invalid()
	}
	validCode := map[ReviewCode]bool{ReviewForcedWording: true, ReviewWordSense: true, ReviewMissingPremise: true, ReviewContradiction: true, ReviewCausalLogic: true, ReviewOffTopic: true, ReviewGenreDialogue: true}
	for _, issue := range review.Issues {
		if !validCode[issue.Code] || len(issue.Evidence) < 1 || len(issue.Evidence) > 2 || strings.TrimSpace(issue.Problem) == "" || strings.TrimSpace(issue.RepairGoal) == "" || utf8.RuneCountInString(issue.Problem) > 500 || utf8.RuneCountInString(issue.RepairGoal) > 500 {
			return invalid()
		}
		for _, evidence := range issue.Evidence {
			if strings.TrimSpace(evidence) == "" || utf8.RuneCountInString(evidence) > 500 || !strings.Contains(passage, evidence) {
				return invalid()
			}
		}
	}
	return review, nil
}
