-- M003 content review and conditional rewrite facts. This migration is
-- forward-only and preserves every pre-M003 row as policy-unknown.

ALTER TABLE wordweave.entitlement_groups
  ADD COLUMN content_review_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN content_repair_limit smallint NOT NULL DEFAULT 0,
  ADD CONSTRAINT entitlement_groups_content_service_valid CHECK (
    (NOT content_review_enabled AND content_repair_limit = 0) OR
    (code IN ('pro', 'plus') AND content_review_enabled AND content_repair_limit BETWEEN 1 AND 99)
  );

UPDATE wordweave.entitlement_groups
SET content_review_enabled = true, content_repair_limit = 1
WHERE code IN ('pro', 'plus');

UPDATE wordweave.growth_settings
SET revision = revision + 1,
    recompute_target_revision = revision + 1,
    recompute_after_owner = NULL,
    updated_at = clock_timestamp()
WHERE singleton;

ALTER TABLE wordweave.generation_runs
  ADD COLUMN content_policy_version smallint,
  ADD COLUMN configuration_revision_snapshot bigint,
  ADD COLUMN content_review_enabled_snapshot boolean,
  ADD COLUMN content_repair_limit_snapshot smallint,
  ADD COLUMN pipeline_version_snapshot text,
  ADD COLUMN plan_origin_snapshot text,
  ADD COLUMN content_outcome text,
  ADD COLUMN final_content_version smallint,
  ADD COLUMN content_stop_reason text;

ALTER TABLE wordweave.generation_runs
  ADD CONSTRAINT generation_runs_m003_content_facts_valid CHECK (
    (content_policy_version IS NULL AND
      configuration_revision_snapshot IS NULL AND
      content_review_enabled_snapshot IS NULL AND
      content_repair_limit_snapshot IS NULL AND
      pipeline_version_snapshot IS NULL AND
      plan_origin_snapshot IS NULL AND
      content_outcome IS NULL AND
      final_content_version IS NULL AND
      content_stop_reason IS NULL)
    OR
    (content_policy_version = 1 AND
      configuration_revision_snapshot IS NOT NULL AND configuration_revision_snapshot > 0 AND
      content_review_enabled_snapshot IS NOT NULL AND
      content_repair_limit_snapshot IS NOT NULL AND
      pipeline_version_snapshot IS NOT NULL AND btrim(pipeline_version_snapshot) <> '' AND
      plan_origin_snapshot IS NOT NULL AND plan_origin_snapshot IN ('visitor', 'base', 'trial') AND
      ((visitor_id IS NOT NULL AND plan_origin_snapshot = 'visitor' AND
          group_code_snapshot = 'visitor' AND NOT content_review_enabled_snapshot AND content_repair_limit_snapshot = 0)
       OR
       (account_id IS NOT NULL AND plan_origin_snapshot IN ('base', 'trial') AND
          ((group_code_snapshot = 'registered' AND NOT content_review_enabled_snapshot AND content_repair_limit_snapshot = 0)
           OR
           (group_code_snapshot IN ('pro', 'plus') AND
             ((NOT content_review_enabled_snapshot AND content_repair_limit_snapshot = 0)
              OR (content_review_enabled_snapshot AND content_repair_limit_snapshot BETWEEN 1 AND 99)))))) AND
      ((call_status = 'active' AND content_outcome IS NULL AND final_content_version IS NULL AND content_stop_reason IS NULL)
       OR
       (call_status = 'valid' AND
          content_outcome IN ('basic', 'review_passed', 'repaired_passed', 'limit_finalized', 'service_incomplete') AND
          final_content_version IS NOT NULL AND final_content_version BETWEEN 1 AND content_repair_limit_snapshot + 1 AND
          ((content_outcome = 'basic' AND NOT content_review_enabled_snapshot AND final_content_version = 1)
           OR (content_outcome IN ('review_passed', 'repaired_passed', 'limit_finalized') AND content_review_enabled_snapshot)
           OR (content_outcome = 'service_incomplete' AND content_review_enabled_snapshot)) AND
          ((content_outcome = 'service_incomplete' AND content_stop_reason IN
              ('content_timeout', 'content_rate_limited', 'content_transport_error',
               'content_protocol_error', 'content_review_invalid', 'repair_native_invalid'))
           OR (content_outcome <> 'service_incomplete' AND content_stop_reason IS NULL)))
       OR
       (call_status = 'user_cancelled' AND content_outcome = 'cancelled' AND final_content_version IS NULL AND content_stop_reason IS NULL)
       OR
       (call_status IN ('provider_failed', 'server_failed', 'stream_failed', 'validation_failed') AND
          content_outcome = 'failed' AND final_content_version IS NULL AND content_stop_reason IS NULL)))
  );

ALTER TABLE wordweave.generation_runs
  ALTER COLUMN content_policy_version SET DEFAULT 1;

ALTER TABLE wordweave.preset_preview_runs
  ADD COLUMN content_policy_version smallint,
  ADD COLUMN configuration_revision_snapshot bigint,
  ADD COLUMN content_review_enabled_snapshot boolean,
  ADD COLUMN content_repair_limit_snapshot smallint,
  ADD COLUMN pipeline_version_snapshot text,
  ADD COLUMN content_outcome text,
  ADD COLUMN final_content_version smallint,
  ADD COLUMN content_stop_reason text;

ALTER TABLE wordweave.preset_preview_runs
  ADD CONSTRAINT preset_preview_runs_m003_content_facts_valid CHECK (
    (content_policy_version IS NULL AND
      configuration_revision_snapshot IS NULL AND
      content_review_enabled_snapshot IS NULL AND
      content_repair_limit_snapshot IS NULL AND
      pipeline_version_snapshot IS NULL AND
      content_outcome IS NULL AND final_content_version IS NULL AND content_stop_reason IS NULL)
    OR
    (content_policy_version = 1 AND
      configuration_revision_snapshot IS NOT NULL AND configuration_revision_snapshot > 0 AND
      content_review_enabled_snapshot IS NOT NULL AND content_repair_limit_snapshot IS NOT NULL AND
      pipeline_version_snapshot IS NOT NULL AND btrim(pipeline_version_snapshot) <> '' AND
      ((NOT content_review_enabled_snapshot AND content_repair_limit_snapshot = 0)
       OR (content_review_enabled_snapshot AND content_repair_limit_snapshot = 1)) AND
      ((status = 'active' AND content_outcome IS NULL AND final_content_version IS NULL AND content_stop_reason IS NULL)
       OR
       (status = 'valid' AND
          content_outcome IN ('basic', 'review_passed', 'repaired_passed', 'limit_finalized', 'service_incomplete') AND
          final_content_version IS NOT NULL AND final_content_version BETWEEN 1 AND content_repair_limit_snapshot + 1 AND
          ((content_outcome = 'basic' AND NOT content_review_enabled_snapshot AND final_content_version = 1)
           OR (content_outcome <> 'basic' AND content_review_enabled_snapshot)) AND
          ((content_outcome = 'service_incomplete' AND content_stop_reason IN
              ('content_timeout', 'content_rate_limited', 'content_transport_error',
               'content_protocol_error', 'content_review_invalid', 'repair_native_invalid'))
           OR (content_outcome <> 'service_incomplete' AND content_stop_reason IS NULL)))
       OR
       (status = 'cancelled' AND content_outcome = 'cancelled' AND final_content_version IS NULL AND content_stop_reason IS NULL)
       OR
       (status = 'failed' AND content_outcome = 'failed' AND final_content_version IS NULL AND content_stop_reason IS NULL)))
  );

ALTER TABLE wordweave.preset_preview_runs
  ALTER COLUMN content_policy_version SET DEFAULT 1;

ALTER TABLE wordweave.preset_versions
  ADD COLUMN preview_content_mode text NOT NULL DEFAULT 'basic',
  ADD CONSTRAINT preset_versions_preview_content_mode_valid CHECK (preview_content_mode IN ('basic', 'enhanced'));

ALTER TABLE wordweave.ai_call_usage
  ADD COLUMN call_stage text,
  ADD COLUMN prompt_version text,
  ADD COLUMN provider_invoked boolean,
  ADD COLUMN review_result text NOT NULL DEFAULT 'not_applicable',
  ADD COLUMN reason_codes text[] NOT NULL DEFAULT '{}',
  ADD COLUMN repair_requested boolean NOT NULL DEFAULT false;

UPDATE wordweave.ai_call_usage SET call_stage = 'legacy';

ALTER TABLE wordweave.ai_call_usage
  ALTER COLUMN call_stage SET NOT NULL,
  ADD CONSTRAINT ai_call_usage_m003_stage_valid CHECK (
    call_stage IN ('legacy', 'generation', 'technical_repair', 'content_review', 'content_repair')),
  ADD CONSTRAINT ai_call_usage_m003_prompt_valid CHECK (
    (call_stage = 'legacy' AND prompt_version IS NULL AND provider_invoked IS NULL) OR
    (call_stage <> 'legacy' AND prompt_version IS NOT NULL AND btrim(prompt_version) <> '')),
  ADD CONSTRAINT ai_call_usage_m003_review_valid CHECK (
    ((call_stage = 'content_review' AND review_result IN ('pending', 'pass', 'issues', 'indeterminate')) OR
     (call_stage <> 'content_review' AND review_result = 'not_applicable')) AND
    (repair_requested = (call_stage = 'content_review' AND review_result = 'issues' AND repair_requested)) AND
    ((review_result = 'issues' AND cardinality(reason_codes) BETWEEN 1 AND 3) OR
     (review_result <> 'issues' AND call_stage <> 'content_repair' AND cardinality(reason_codes) = 0) OR
     (call_stage = 'content_repair' AND cardinality(reason_codes) BETWEEN 1 AND 3)) AND
    reason_codes <@ ARRAY['forced_wording', 'contradiction', 'other_content']::text[] AND
    array_position(reason_codes, NULL) IS NULL AND
    (cardinality(reason_codes) < 2 OR reason_codes[1] <> reason_codes[2]) AND
    (cardinality(reason_codes) < 3 OR
      (reason_codes[1] <> reason_codes[3] AND reason_codes[2] <> reason_codes[3]))
  );

ALTER TABLE wordweave.ai_call_usage ALTER COLUMN call_stage DROP DEFAULT;
