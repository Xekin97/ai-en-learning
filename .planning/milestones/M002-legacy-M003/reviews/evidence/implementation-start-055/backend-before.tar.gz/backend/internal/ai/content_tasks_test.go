package ai

import (
	"encoding/json"
	"strings"
	"testing"
)

func TestReviewStrictSchemaAndEvidence(t *testing.T) {
	passage := "Mara put the only key in her bag. The key stayed on the desk."
	valid := `{"schema_version":1,"verdict":"issues","issues":[{"code":"contradiction","evidence":["Mara put the only key in her bag.","The key stayed on the desk."],"problem":"The key has incompatible locations.","repair_goal":"Keep one location."}]}`
	review, err := decodeReviewStrict([]byte(valid), passage)
	if err != nil || review.Verdict != "issues" || len(review.Issues) != 1 {
		t.Fatalf("valid review rejected: %+v %v", review, err)
	}
	for name, raw := range map[string]string{
		"duplicate":         `{"schema_version":1,"verdict":"pass","verdict":"issues","issues":[]}`,
		"pass_with_issue":   valid[:strings.Index(valid, `"verdict":"issues"`)] + `"verdict":"pass"` + valid[strings.Index(valid, `,"issues"`):],
		"invented_evidence": strings.Replace(valid, "The key stayed on the desk.", "The key vanished.", 1),
		"trailing":          valid + `{}`,
	} {
		t.Run(name, func(t *testing.T) {
			if _, err := decodeReviewStrict([]byte(raw), passage); err == nil {
				t.Fatal("invalid review accepted")
			}
		})
	}
	passReview, err := decodeReviewStrict([]byte(`{"schema_version":1,"verdict":"pass","issues":[]}`), passage)
	if err != nil || passReview.Verdict != "pass" {
		t.Fatal(err)
	}
}

func TestReviewSchemaIsSentAcrossAllProtocols(t *testing.T) {
	for _, protocol := range []string{ProtocolChat, ProtocolResponses, ProtocolAnthropic} {
		spec := GenerationSpec{ProviderModelID: "fixture/model", Entries: []string{"learn"}, review: &reviewTask{Passage: "We learn."}}
		_, body := protocolRequest(spec, connectionSnapshot{connection: Connection{Protocol: protocol}, outputMode: "json_schema"}, false)
		raw, err := json.Marshal(body)
		if err != nil {
			t.Fatal(err)
		}
		text := string(raw)
		if !strings.Contains(text, "REVIEW_SCHEMA") || !strings.Contains(text, "schema_version") || strings.Contains(text, "wordweave_learning_batch") {
			t.Fatalf("review schema missing or candidate schema leaked for %s: %s", protocol, text)
		}
		if protocol != ProtocolAnthropic && !strings.Contains(text, "wordweave_content_review") {
			t.Fatalf("structured review schema name missing for %s", protocol)
		}
	}
}
