//go:build integration

package postgres

import (
	"context"
	"testing"
	"time"

	"github.com/google/uuid"
)

func TestM003UpgradeFrom0016PreservesHistoricalNullFacts(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	databaseURL, cleanup := createMigrationTestDatabase(t, ctx, integrationDatabaseURL(t))
	defer cleanup()
	pool, err := Open(ctx, databaseURL, "m003-upgrade-test", 4)
	if err != nil {
		t.Fatal(err)
	}
	defer pool.Close()
	for _, name := range []string{
		"0001_roles_and_schema.sql", "0002_core_tables.sql", "0003_fixed_groups.sql", "0004_vocabulary_m001.sql",
		"0005_hint_occurrences_expand.sql", "0006_hint_occurrences_enforce.sql", "0007_entry_meaning.sql",
		"0008_m002_identity_vocabulary.sql", "0009_m002_review_facts.sql", "0010_m002_growth_items.sql",
		"0011_m002_presets_quota.sql", "0012_m002_notices_analytics.sql", "0013_m002_operational_privileges.sql",
		"0014_notice_remind_once.sql", "0015_generic_model_connections.sql", "0016_provider_workspace.sql",
	} {
		applyEmbeddedMigration(t, ctx, pool, name)
	}
	var owner, model, run uuid.UUID
	if err = pool.QueryRow(ctx, `INSERT INTO wordweave.accounts(username,password_hash,role,group_code) VALUES('m003_legacy','test-only','learner','registered') RETURNING id`).Scan(&owner); err != nil {
		t.Fatal(err)
	}
	if err = pool.QueryRow(ctx, `INSERT INTO wordweave.ai_models(display_name,provider_model_id,enabled) VALUES('M003 legacy model','test/m003-legacy',false) RETURNING id`).Scan(&model); err != nil {
		t.Fatal(err)
	}
	if err = pool.QueryRow(ctx, `INSERT INTO wordweave.generation_runs(account_id,credited_account_id,group_code_snapshot,model_id,model_display_name_snapshot,provider_model_id_snapshot,meaning_language,scenario,length_code,minimum_words_snapshot,max_entries_snapshot) VALUES($1,$1,'registered',$2,'M003 legacy model','test/m003-legacy','en','story','short',50,5) RETURNING id`, owner, model).Scan(&run); err != nil {
		t.Fatal(err)
	}
	if _, err = pool.Exec(ctx, `INSERT INTO wordweave.ai_call_usage(user_run_id,call_no,model_snapshot,usage_status,completed_at) VALUES($1,1,'test/m003-legacy','unknown',clock_timestamp())`, run); err != nil {
		t.Fatal(err)
	}

	applyEmbeddedMigration(t, ctx, pool, "0017_m003_content_review.sql")
	var policy, revision, repair, version *int
	var enabled *bool
	var pipeline, origin, outcome, reason *string
	if err = pool.QueryRow(ctx, `SELECT content_policy_version,configuration_revision_snapshot,content_review_enabled_snapshot,content_repair_limit_snapshot,pipeline_version_snapshot,plan_origin_snapshot,content_outcome,final_content_version,content_stop_reason FROM wordweave.generation_runs WHERE id=$1`, run).Scan(&policy, &revision, &enabled, &repair, &pipeline, &origin, &outcome, &version, &reason); err != nil {
		t.Fatal(err)
	}
	if policy != nil || revision != nil || enabled != nil || repair != nil || pipeline != nil || origin != nil || outcome != nil || version != nil || reason != nil {
		t.Fatalf("migration invented historical facts: %v %v %v %v %v %v %v %v %v", policy, revision, enabled, repair, pipeline, origin, outcome, version, reason)
	}
	var stage string
	var prompt *string
	var invoked *bool
	var reviewResult string
	var reasons []string
	if err = pool.QueryRow(ctx, `SELECT call_stage,prompt_version,provider_invoked,review_result,reason_codes FROM wordweave.ai_call_usage WHERE user_run_id=$1`, run).Scan(&stage, &prompt, &invoked, &reviewResult, &reasons); err != nil {
		t.Fatal(err)
	}
	if stage != "legacy" || prompt != nil || invoked != nil || reviewResult != "not_applicable" || len(reasons) != 0 {
		t.Fatalf("legacy usage changed: %q %v %v %q %v", stage, prompt, invoked, reviewResult, reasons)
	}
	if _, err = pool.Exec(ctx, `UPDATE wordweave.ai_call_usage SET provider_invoked=true WHERE user_run_id=$1`, run); err == nil {
		t.Fatal("legacy invocation fact was fabricated")
	}
	if err = Migrate(ctx, pool); err != nil {
		t.Fatalf("idempotent replay: %v", err)
	}
}
