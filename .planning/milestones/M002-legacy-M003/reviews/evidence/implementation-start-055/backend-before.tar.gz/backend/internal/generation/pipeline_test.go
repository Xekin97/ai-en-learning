package generation

import (
	"context"
	"errors"
	"testing"

	"wordweave/internal/ai"
	"wordweave/internal/entitlement"
)

type pipelineStream struct {
	candidate ai.Candidate
	err       error
}

func (s *pipelineStream) Receive(ctx context.Context, emit func(string) error) (ai.Candidate, error) {
	if err := ctx.Err(); err != nil {
		return ai.Candidate{}, err
	}
	if s.err != nil {
		return ai.Candidate{}, s.err
	}
	if emit != nil {
		if err := emit(s.candidate.Passage); err != nil {
			return ai.Candidate{}, err
		}
	}
	return s.candidate, nil
}
func (*pipelineStream) Close() error { return nil }

type pipelineProvider struct {
	initial    ai.Candidate
	initialErr error
	rewrites   []pipelineStream
	reviews    []ai.Review
	reviewErrs []error
	rewriteAt  int
	reviewAt   int
}

func (p *pipelineProvider) Open(context.Context, ai.GenerationSpec) (ai.Stream, error) {
	return &pipelineStream{candidate: p.initial, err: p.initialErr}, nil
}
func (*pipelineProvider) CheckCompatibility(context.Context, string) error { return nil }
func (p *pipelineProvider) Review(context.Context, ai.GenerationSpec, ai.ValidatedBatch) (ai.Review, error) {
	i := p.reviewAt
	p.reviewAt++
	if i < len(p.reviewErrs) && p.reviewErrs[i] != nil {
		return ai.Review{}, p.reviewErrs[i]
	}
	return p.reviews[i], nil
}
func (p *pipelineProvider) OpenRewrite(context.Context, ai.GenerationSpec, ai.Candidate, []ai.ReviewIssue) (ai.Stream, error) {
	i := p.rewriteAt
	p.rewriteAt++
	if i >= len(p.rewrites) {
		return nil, errors.New("unexpected rewrite")
	}
	return &p.rewrites[i], nil
}

func pipelineCandidate(extra string) ai.Candidate {
	return ai.Candidate{
		Passage: "We learn(learn) together" + extra + ".",
		Tags:    []string{"study"},
		Targets: []ai.CandidateTarget{{SourceEntry: "learn", EntryMeaning: "To gain knowledge or skill.", HintPhrase: "learn(learn) together"}},
	}
}

func pipelineReview(verdict string) ai.Review {
	result := ai.Review{SchemaVersion: 1, Verdict: verdict, Issues: []ai.ReviewIssue{}}
	if verdict == "issues" {
		result.Issues = []ai.ReviewIssue{{Code: ai.ReviewForcedWording, Evidence: []string{"We learn together."}, Problem: "The wording is forced.", RepairGoal: "Use a natural situation."}}
	}
	return result
}

func pipelineValidator(t *testing.T) ai.Validator {
	t.Helper()
	lexicon, err := ai.LoadEmbeddedLexicon()
	if err != nil {
		t.Fatal(err)
	}
	return ai.NewValidator(lexicon)
}

func TestExecutePipelineContentRepairBoundaries(t *testing.T) {
	spec := ai.GenerationSpec{Entries: []string{"learn"}, MeaningLanguage: "en", Scenario: "story", MinimumWords: 1}
	t.Run("zero_disables_content_service", func(t *testing.T) {
		provider := &pipelineProvider{initial: pipelineCandidate("")}
		result, err := ExecutePipeline(context.Background(), provider, pipelineValidator(t), spec, entitlement.ContentService{NativeValidation: true}, PipelineHooks{})
		if err != nil || result.Outcome != OutcomeBasic || result.Version != 1 || provider.reviewAt != 0 || provider.rewriteAt != 0 {
			t.Fatalf("result=%+v reviews=%d rewrites=%d err=%v", result, provider.reviewAt, provider.rewriteAt, err)
		}
	})
	t.Run("one_repair_then_pass", func(t *testing.T) {
		provider := &pipelineProvider{initial: pipelineCandidate(""), reviews: []ai.Review{pipelineReview("issues"), pipelineReview("pass")}, rewrites: []pipelineStream{{candidate: pipelineCandidate(" naturally")}}}
		result, err := ExecutePipeline(context.Background(), provider, pipelineValidator(t), spec, entitlement.ContentService{NativeValidation: true, ContentReviewEnabled: true, ContentRepairLimit: 1}, PipelineHooks{})
		if err != nil || result.Outcome != OutcomeRepairedPassed || result.Version != 2 || provider.reviewAt != 2 || provider.rewriteAt != 1 {
			t.Fatalf("result=%+v reviews=%d rewrites=%d err=%v", result, provider.reviewAt, provider.rewriteAt, err)
		}
	})
	t.Run("second_repair_failure_keeps_version_two", func(t *testing.T) {
		provider := &pipelineProvider{initial: pipelineCandidate(""), reviews: []ai.Review{pipelineReview("issues"), pipelineReview("issues")}, rewrites: []pipelineStream{{candidate: pipelineCandidate(" naturally")}, {err: &ai.ProviderError{Category: ai.FailureSchema, Retryable: true, Err: errors.New("bad candidate")}}}}
		result, err := ExecutePipeline(context.Background(), provider, pipelineValidator(t), spec, entitlement.ContentService{NativeValidation: true, ContentReviewEnabled: true, ContentRepairLimit: 2}, PipelineHooks{})
		if err != nil || result.Outcome != OutcomeServiceIncomplete || result.Version != 2 || result.StopReason == nil || *result.StopReason != "repair_native_invalid" {
			t.Fatalf("result=%+v err=%v", result, err)
		}
	})
	t.Run("two_repairs_then_limit_finalizes_version_three", func(t *testing.T) {
		provider := &pipelineProvider{
			initial:  pipelineCandidate(""),
			reviews:  []ai.Review{pipelineReview("issues"), pipelineReview("issues"), pipelineReview("issues")},
			rewrites: []pipelineStream{{candidate: pipelineCandidate(" naturally")}, {candidate: pipelineCandidate(" consistently")}},
		}
		result, err := ExecutePipeline(context.Background(), provider, pipelineValidator(t), spec, entitlement.ContentService{NativeValidation: true, ContentReviewEnabled: true, ContentRepairLimit: 2}, PipelineHooks{})
		if err != nil || result.Outcome != OutcomeLimitFinalized || result.Version != 3 || provider.reviewAt != 3 || provider.rewriteAt != 2 {
			t.Fatalf("result=%+v reviews=%d rewrites=%d err=%v", result, provider.reviewAt, provider.rewriteAt, err)
		}
	})
}

func TestExecutePipelineContentFailuresKeepLastValidPackage(t *testing.T) {
	spec := ai.GenerationSpec{Entries: []string{"learn"}, MeaningLanguage: "en", Scenario: "story", MinimumWords: 1}
	for _, tc := range []struct {
		name, stop string
		reviewErr  error
		rewriteErr error
	}{
		{"timeout", "content_timeout", context.DeadlineExceeded, nil},
		{"rate limited", "content_rate_limited", &ai.ProviderError{Category: ai.FailureRateLimited, Retryable: true}, nil},
		{"transport", "content_transport_error", &ai.ProviderError{Category: ai.FailureUnavailable, Retryable: true}, nil},
		{"protocol", "content_protocol_error", &ai.ProviderError{Category: ai.FailureProtocol, Retryable: true}, nil},
		{"review invalid", "content_review_invalid", &ai.ProviderError{Category: ai.FailureSchema, Retryable: true}, nil},
		{"repair invalid", "repair_native_invalid", nil, &ai.ProviderError{Category: ai.FailureSchema, Retryable: true}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			provider := &pipelineProvider{initial: pipelineCandidate("")}
			if tc.reviewErr != nil {
				provider.reviewErrs = []error{tc.reviewErr}
				provider.reviews = []ai.Review{{}}
			} else {
				provider.reviews = []ai.Review{pipelineReview("issues")}
				provider.rewrites = []pipelineStream{{err: tc.rewriteErr}}
			}
			result, err := ExecutePipeline(context.Background(), provider, pipelineValidator(t), spec, entitlement.ContentService{NativeValidation: true, ContentReviewEnabled: true, ContentRepairLimit: 1}, PipelineHooks{})
			if err != nil || result.Outcome != OutcomeServiceIncomplete || result.Version != 1 || result.StopReason == nil || *result.StopReason != tc.stop || result.Batch.Passage == "" {
				t.Fatalf("result=%+v err=%v", result, err)
			}
		})
	}
}

func TestExecutePipelineNeverTurnsMissingInitialPackageIntoIncompleteSuccess(t *testing.T) {
	spec := ai.GenerationSpec{Entries: []string{"learn"}, MeaningLanguage: "en", Scenario: "story", MinimumWords: 1}
	provider := &pipelineProvider{initialErr: &ai.ProviderError{Category: ai.FailureUnavailable, Retryable: true}}
	result, err := ExecutePipeline(context.Background(), provider, pipelineValidator(t), spec, entitlement.ContentService{NativeValidation: true, ContentReviewEnabled: true, ContentRepairLimit: 2}, PipelineHooks{})
	if err == nil || result.Outcome != "" || result.Version != 0 || PipelineFailurePhase(err) != "provider_receive" {
		t.Fatalf("result=%+v phase=%s err=%v", result, PipelineFailurePhase(err), err)
	}
}

func TestExecutePipelineNeverTurnsCriticalUsageFactsIntoIncompleteSuccess(t *testing.T) {
	spec := ai.GenerationSpec{Entries: []string{"learn"}, MeaningLanguage: "en", Scenario: "story", MinimumWords: 1}
	for _, provider := range []*pipelineProvider{
		{initial: pipelineCandidate(""), reviewErrs: []error{ai.ErrCriticalUsageFact}, reviews: []ai.Review{{}}},
		{initial: pipelineCandidate(""), reviews: []ai.Review{pipelineReview("issues")}, rewrites: []pipelineStream{{err: ai.ErrCriticalUsageFact}}},
	} {
		result, err := ExecutePipeline(context.Background(), provider, pipelineValidator(t), spec, entitlement.ContentService{NativeValidation: true, ContentReviewEnabled: true, ContentRepairLimit: 1}, PipelineHooks{})
		if !errors.Is(err, ai.ErrCriticalUsageFact) || PipelineFailurePhase(err) != "usage_record" || result.Outcome != "" {
			t.Fatalf("result=%+v phase=%s err=%v", result, PipelineFailurePhase(err), err)
		}
	}
}

func TestContentRepairLimitNinetyNineIsConfigurationOnly(t *testing.T) {
	policy := entitlement.ContentService{NativeValidation: true, ContentReviewEnabled: true, ContentRepairLimit: 99}
	if policy.ContentRepairLimit+1 != 100 || 1+entitlement.NativeCorrectionLimit+(policy.ContentRepairLimit+1)+policy.ContentRepairLimit != 202 {
		t.Fatalf("unexpected version/call boundaries: %+v", policy)
	}
}
