---
milestone: M003
stage: verification
role: quality/base
agent_name: qa-quinn
status: completed
version: M003-QA-06-UAT-ACCEPTED
result: pass
date: 2026-10-13
---

# M003 独立 QA 覆盖矩阵

## 当前范围与结论

依据 [`USER-QA-MODEL-QUALITY-BOUNDARY-20261012`](../../../agt/qa-scope-policy.md)，QA 验证实现与功能合同，不评判文章故事性、自然用词、语义逻辑或模型审稿准确率。此前内容评阅保留为历史模型能力观察，不参与当前 QA 结论。

当前入口由 `M003-PRODUCT-07 / TECH-03 / FE-02 / UI09-R3` 的 AC-301–316 冻结基线，以及 `M003-PRODUCT-09 / TECH-04 / BE-07 / DB-04 / FE-03 / API-306 / AI-7 / UI10-R1.1` 的 AC-317–322 增量共同组成。两组功能证据均 **PASS**；CR-307 修后通过，CR-308 已撤销为 QA 缺陷/阻塞。用户在CR-309/310修正后明确接受当前M003功能UAT。

| QA ID | 验收项 | 功能验证 | 结果 | 原件 |
|---|---|---|---|---|
| QA02-S01 | AC-301/302/303/308/311/313/315/316 | N0、N1 pass/Q02、N2两次返修；Plan→writer、fixed edit、Review/repair、保存、一次扣额与DB链 | **PASS** | [QA02冻结矩阵](../reviews/evidence/cr306-qa-entry-080/verification-before-cr306.tar.gz)；[`n2-method-retest-final.json`](evidence/qa-m003-001/n2-method-retest-final.json)、[`db-facts.json`](evidence/qa-m003-001/db-facts.json) |
| QA02-S02 | AC-308/311/313 | busy 503在受理前、Problem/header一致；前端保输入、cooldown、无自动重POST | **PASS** | [`cr304-api-results.json`](evidence/qa-m003-002/cr304-api-results.json)、[`targeted-browser-attempt3.json`](evidence/qa-m003-002/targeted-browser-attempt3.json) |
| QA02-S03 | AC-304/305/306/314 | Pro/Plus独立配置、0/99边界、native策略只读、impact/409重预览、非管理员拒绝 | **PASS** | [QA02提交回执](../reviews/evidence/qa-start-059/qa-submission-receipt.json) 与冻结矩阵 |
| QA02-S04 | AC-309/313/314 | preview Q02、Plan/草稿、Unknown≠0、确认发布、notice、键盘模式 | **PASS** | [`targeted-retest-summary.json`](evidence/qa-m003-002/targeted-retest-summary.json) 与QA02冻结矩阵 |
| QA02-S05 | AC-310/314 | N2原因持久化；按run去重的牵强/矛盾分子、交并集与repair次数 | **PASS（合成事实边界）** | [`n2-method-retest-final.json`](evidence/qa-m003-001/n2-method-retest-final.json) |
| QA02-S06 | AC-301–316对应UIA/FE3 | create/preview Plan与live draft、响应式、键盘、200%模拟、减少动效、终态清理；CR-304/305返修后26项通过 | **PASS** | [`targeted-retest-summary.json`](evidence/qa-m003-002/targeted-retest-summary.json)、[QA02提交回执](../reviews/evidence/qa-start-059/qa-submission-receipt.json) |
| CR306-D1 | AC-317 | 管理员/非管理员；多模型隔离与 `{}`；保存重读；失败/409原子；保存0调用 | **PASS** | [`deterministic-api.json`](evidence/cr306-qa/deterministic-api.json) 21/21 |
| CR306-D2 | AC-318 | 严格JSON、重复键、保护/受控字段、NUL、深度/大小、413；上游422不删参重试 | **PASS** | 同上；首次depth方法错误单独保留 |
| CR306-D3 | AC-319 | 在途旧参数/后续新参数；N0/N2；固定编辑/审校/返修编排；一次扣次与DB snapshot | **PASS** | [`deterministic-pipeline.json`](evidence/cr306-qa/deterministic-pipeline.json) 10/10；`deterministic-db-facts.json` |
| CR306-D4 | AC-320 | 围栏plan不进writer；heartbeat无假plan且可取消；Q02保留有效稿可保存 | **PASS** | 同上 |
| CR306-R1 | AC-321 | 唯一授权DeepSeek配置；游客原五词与Pro增强完整Plan→Writer→校验→DB；snapshot、配额、保存资格、usage/cost、调用阶段 | **PASS（功能）** | [`real-r1.json`](evidence/cr306-qa/real-r1.json)、[`real-r2.json`](evidence/cr306-qa/real-r2.json) |
| CR306-U1 | AC-322 | 完整AppDialog；desktop/mobile键盘、错误草稿、迟到probe、四关闭入口、保存0调用 | **PASS（CR-307返修后）** | 首败 [`browser.json`](evidence/cr306-qa/browser.json)；修后 [`browser-focus-retest.json`](evidence/cr306-qa/browser-focus-retest.json) 5/5 |
| CR309-U1 | UIA-419 / PAGE204 | 同一释义组件覆盖 Plan→两次edit→pending→final；`entry/sense/form·phrase` 与 `entry/entryMeaning/hintPhrase` 完整映射 | **PASS** | [`results.json`](evidence/cr309-qa/after/results.json)：desktop/mobile |
| CR309-U2 | UIA-420–421 / PAGE204+216 | 正文760px、18/0/14、pre-wrap/anywhere、1.85/1.78；释义桌面2列24px、移动1列且无横向溢出；trial共享组件 | **PASS** | 同上；9张隔离运行截图 |
| CR309-U3 | UIA-422 / PAGE212 | 新live Plan期间旧lastPreview独立可见，English原生标签不被当前中文配置污染；stale/publish gate保留；新preview完成后切换中文标签 | **PASS** | [`summary.md`](evidence/cr309-qa/after/summary.md)、admin during/final截图 |
| CR310-Q1–Q3 | UIA-423–424 / PAGE204 | learner/visitor完成后配置与单词可编辑；旧结果不随下一轮输入变化；桌面英文/移动中文四种关闭均零discard/零新生成并精确回焦 | **PASS** | [`results.json`](evidence/cr310-qa/after/results.json)、桌面/移动警告截图 |
| CR310-Q4–Q6 | UIA-425 | 确认后严格一次discard→一次新snapshot；重复确认不重复；discard失败保留旧结果和新输入 | **PASS** | 同上；请求顺序与完整新snapshot |
| CR310-Q7–Q9 | UIA-426 | held Save/leave discard互斥；重叠离页resolver拒绝；新一轮流可Stop/Cancel；visitor claim保持 | **PASS** | 同上；二次流2、cancel1 |
| CR310-Q10+guards | UIA-426 / PAGE216 | preset只读快照保持；pending继续锁定；3014刷新后最小中文警告取消 smoke | **PASS** | [`live-3014-smoke.json`](evidence/cr310-qa/after/live-3014-smoke.json)、[`live-source-hashes.json`](evidence/cr310-qa/after/live-source-hashes.json) 5/5 |

## AC-321 功能事实

R1 游客得到 `basic V1`，实际调用 planning1+generation1，quota 100→99，`can_save=true`。R2 Pro 得到 `review_passed V2`，实际调用 planning1+generation1+fixed_edit1+content_review1，content repair0，quota 97→96，`can_save=true`。两次 snapshot 均为 `json_schema + openrouter_require_parameters + reasoning.enabled=false`，原生结构与五个目标学习字段完整，DB终态、一次扣次、usage/cost均有证据。

模型返回的文章好坏及审稿语义准确率为 **OUT OF SCOPE**。历史 [`real-evaluation.md`](evidence/cr306-qa/real-evaluation.md) 原样保留，只作模型能力观察，不构成 QA FAIL、返工要求或成功率结论。

## 方法与环境边界

- API首次把允许depth8当非法；管线两次旧fixture未规范化语言/technical repair；焦点复验首次未真正断开旧opener。均保留为QA方法轨迹，最终定向证据通过。
- 本轮新空PG18初始化全部当前schema含0017，不是历史迁移。旧QA02及CR-304/305已解决事实继续有效。
- 真实完整请求2次，第三次未运行；不扩模型或质量批次。`AI-QUALITY-90`属于另行模型评测，不在QA范围。
- 3张新截图；未机械重跑开发全套测试。
- CR-309 新增定向隔离浏览器9项断言；实施manifest 8/8及归档哈希匹配，未重跑开发方单测/lint。随后3014按授权仅刷新4个生产文件，4/4哈希匹配，最小中文Plan→final smoke通过；额度不变、业务mutation 0、真实provider调用0。
- CR-310 新增隔离浏览器14项PASS；实施manifest 7/7及归档哈希匹配。3014仅刷新5个生产文件，5/5哈希匹配；live拦截生成/analytics，额度不变、业务mutation 0、真实provider调用0。早期失败均为QA夹具同步或held SSE请求语义不匹配，最终未发现产品缺陷。

## 当前闭环矩阵

| 闭环项 | 当前状态 | 稳定证据 |
|---|---|---|
| CR-302 downstream | **PASS / 建议resolved** | [TECH03冻结门禁](../reviews/technical-design-054.md)、[TECH03实施接收](../reviews/implementation-verification-058.md)、[QA02提交回执](../reviews/evidence/qa-start-059/qa-submission-receipt.json)、QA02-S01–S06与当前UAT接受 |
| CR-306 AC-317–322 | **PASS / 建议resolved** | API21/21、管线10/10、焦点5/5、真实R1/R2、QA汇总 |
| 当前源码与UAT | **PASS** | CR310 7/7冻结源、3014 5/5刷新源及rolling 9文件追踪一致 |
| 用户功能UAT | **ACCEPTED** | [`USER-M003-UAT-ACCEPTED-20261013`](../reviews/requirements-feedback.md#user-m003-uat-accepted-20261013)、[`user-acceptance.json`](../reviews/evidence/uat-acceptance-096/user-acceptance.json) |
| 文章质量/模型漏判 | **OUT OF QA SCOPE** | [`qa-scope-policy.md`](../../../agt/qa-scope-policy.md)；CR-308非阻塞观察 |
| 生产容量/性能、长期费用、历史迁移、真机/人工读屏 | **未验证，不阻塞本次功能UAT记录** | 报告保留限制 |
