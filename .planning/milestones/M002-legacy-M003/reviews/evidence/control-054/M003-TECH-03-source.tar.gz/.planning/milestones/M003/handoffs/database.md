---
milestone: M003
stage: technical-design
role: dba/base
agent_name: dba-diana
status: awaiting_user_review
version: M003-DB-03
date: 2026-10-10
input_version: M003-PRODUCT-07 / M003-BE-05 / CR-302
---

# M003 DBA 交接：规划与固定编辑数据契约

[数据库设计 DB03](../technical/database.md)已按BE05收敛，建议 **awaiting_user_review / for-prototype**。只交付设计及静态证据；未批准技术/实施、未切流程、未修改源码或执行迁移/seed/真实模型。DB02旧审批不覆盖DB03。

## 输入与确认闭环

- 已核实 [state](../../../workflow/state.yaml) 的TRANSITION-M003-033、technical-design / dba/base / dba-diana及同名registry；[激活检查032](../reviews/research-alignment-database-032.md)。使用agt-database-design及完整共同契约/工作流控制/DBA角色/交接模板/文档维护协议，保持consumer-ai-web@1.0.0；模型锁frontier/high、requested gpt-6-astra/high，actual serving metadata及usage unknown。
- 输入：[PRODUCT07](product.md)、[BE05](backend-architecture.md)，[BE05冻结manifest](../reviews/evidence/control-032/M003-BE-05-source-manifest.json)28项与源文件和源包hash一致；技术依据BE5-DBA、BE3-03、AI3-01/02/05；[DATA-301–305](../product/data-assets.md)/CAP-301–305/AC-301–316。
- [Q3-02-A](../reviews/requirements-feedback.md#q3-02共同规划与增强固定编辑confirmed--a)已关闭：所有模式真实Plan→Writer，增强一次固定实际编辑后Review/条件返修，固定编辑不占基础或N；N0只关闭编辑/Review/条件返修。原N0–99初始1、执行最多2轮、同请求同模型、一次业务计次、上限定稿与Q02不重问。基础2次仍为BE05技术策略，后台basic0/enhanced1沿当前设计。
- BE05具体故障/稿版本/usage是技术设计输入，非用户逐字段批准；DB03同样待评审。没有新增会改变产品结果的关键假设；目标DB应用状态未知，迁移选择前必须核实。取消/断连/DB未知不转伪成功。

## 本轮精确接收范围

| 稳定入口 | 当前契约及下游意义 |
|---|---|
| DB3-03 / BE5-DBA | 精确pipeline=m003-content-v5：N0 final1，N>0为1..N+2，用户最大101、预览增强最大3；正常review_passed为编辑V2，编辑Q02可final1。最终V取完整有效包，基础恢复同V，不能由V推算实际返修 |
| DB3-03 / AI3-02 | 七reason加fixed_edit_native_invalid；编辑网络/协议/timeout沿原技术原因；规划失败无valid不写Q02；只有incomplete带reason，notice随终态查询/保存保留 |
| DB3-04/07 / AI3-05 | 六stage增加planning/fixed_edit；两者review_result=not_applicable、repair_requested=false、reason_codes空。legacy保留，发送true/false/NULL与prompt证据不变；规划/固定编辑分列，W/F/C仅真实content_repair |
| DB3-03/08 | policy v1不变；旧pipeline保留N+1及六reason，历史NULL不造假。源码实际m003-content-v2，不能把stream-v4当pipeline。CHECK完整谓词IS TRUE与显式非空阻止UNKNOWN绕过；异常先扫描后处置 |
| DB3-08 | 当前0017确已存在但应用状态未知；确认全目标未应用才可由实施owner修候选，否则保留0017并新增空闲迁移号。已应用升级不重设管理员N/开关/revision，不seed，不改正文/学习/charge/发布事实 |

沿用现有run/usage/最终payload/claim、锁顺序/唯一结算、预览模式绑定与手动发布；不新增Plan表、永久中间稿、逐token存储或统计平台。正文是唯一数据库规则源，本交接只定位依赖。

## 文档维护与限定检查

DB3-01–09、DB3-V01–06稳定编号保留，旧验证矩阵仍为未执行计划；AC-315/316通过BE3-07/AI3-06接续。本轮已清除“最高迁移0016”“DB01未实施”“当前DB02待审”“当前上限100/预览2”等过期活动结论；它们只作为明确旧源码/旧版本事实出现。原件已与 [DB02冻结包](../reviews/evidence/database-008/artifacts.tar.gz)逐字匹配，无需另复制历史；旧研究/v3/v4/v5及其他owner原件不动。

检查入口：[db03-check.py](../technical/evidence/db03-check.py)、[db03-check.json](../technical/evidence/db03-check.json)、[修改前计量](../technical/evidence/db03-before.json)。检查两文版本/链接/稳定ID、BE05冻结一致性、0017及完成函数具体差异、有限版本/阶段/原因真值样例与SQL三值逻辑反例。真值表是静态语义模型，**未执行PostgreSQL SQL或证明数据库约束已生效**；未运行Go/API、全套测试、迁移、浏览器、真实质量/费用/时延或用户UAT。源码修改保留给实施owner。

同口径两份DB正文/交接修订前17063 Unicode字符；修订后及原件hash见check.json。增长来自可证明的v5差异、迁移分支及NULL守卫；输入按指定入口/章节定向读取，未全历史遍历。静态字符不是运行时累计输入或token，精确token/usage unknown；未执行独立新会话交接测试，静态自检不代替它。

## 未决、风险与下一步

- 新业务BLOCKED：无。CR-302仍下游pending，本角色仅提交DB03设计。未知目标库0017应用/旧pipeline分布及潜在NULL异常，不阻塞原型，阻止未核实就迁移；完成条件和扫描入口在DB3-08。
- 建议控制角色接收后交designer-tony，按BE05 v5 fixtures更新UI07完整页面：真实临时Plan→首稿→固定编辑，Q02恢复完整包及持续notice；DB确认终态才有保存/发布资格，暂定义项不能存为最终释义。视觉评审依用户原授权单独进行；本交接不激活角色。
- frontend-bob随后接收BE05/DB03/UI07再更新FE01；backend-ethan待实施授权按DB3-03/04/08修迁移/启动校验/CompletePipeline及CompletePreviewPipeline，并完成BE3-03跨调用事实校验。当前代码仅旧v2且100/2硬界，不是BE05实现；不能只放宽SQL上限。backend-alex原件/依赖版本由其owner后续接收，不由DBA代改。
- qa-quinn按DB3-V01–06/BE3-07接续针对实现验证；配置99与版本101/3独立静态/隔离校验，不实跑3–99轮。保留CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX及真实质量/费用/时延未知；任何静态PASS不关闭这些事项。
