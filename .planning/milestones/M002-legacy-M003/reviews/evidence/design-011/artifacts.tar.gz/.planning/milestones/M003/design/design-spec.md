# M003 UI/UX 增量规格

## 当前目标与有效范围

- 当前版本 `M003-UI-03`，状态 `awaiting_user_review`。输入为已接收的 `M003-PRODUCT-03`、`M003-BE-02` 与 `CR-301`；本版只补齐有限状态核对结束后的显式重新核对动作。
- 确认来源：`USER-M003-Q01-B`、`USER-M003-Q02-A`、`USER-M003-Q03-RANGE99`、`USER-M003-CONTENT-20261009`、CQ-01–14。各付费计划内容上限为整数0–99、初始1；0关闭；流程验证最多执行2轮。审校技术故障且有有效稿时可保存并持续提示，仍计一次生成。
- UI02 已冻结于 `reviews/evidence/design-007/`。UI03 未变的0–99、双预算、有效稿交付和响应式状态继续复用其已接收证据；本次浏览器证据单独写入 `design/evidence/ui03/`。
- 本轮只修订 PAGE-204/216 与 PAGE-212 的 pending 动作；不改变产品范围、计次、保存/发布资格，不新增页面、刷新恢复、token 持久化或重试平台。

## 页面—能力—数据追踪

| 页面 | 本轮设计增量 | 数据/能力 | 原型定位 |
|---|---|---|---|
| PAGE-204/216 | 原 UI02 状态；pending 在有限自动核对结束后可显式重新核对，核对中禁用重复点击 | DATA-301–303；CAP-301/302；AC-302/303/308/311/313/314；API-302 | `?page=create`；`#generation-status`、`#generation-recheck` |
| PAGE-208 | 基础纠错系统策略只读；内容整数0–99；合法/非法、影响预览、远端冲突和快照 | DATA-301/302；CAP-303；AC-304/305/306/314 | `?page=plans`；`#basic-correction-policy`、`#content-service`、`#change-preview`、`#version-conflict` |
| PAGE-212 | 原 UI02 预设规则；preview pending 提供同文案重新核对，核对中不可发布 | DATA-304；CAP-304；AC-309；API-304 | `?page=presets`；`#preview-result`、`#preset-recheck`、`#preset-publish` |
| PAGE-215/217 | 权益摘要显示实际 N；精选不承诺通过或赠送增强 | DATA-301/原 DATA-212；CAP-301/304 | `copy.json` 语义，不另建页面 |

## 设计表达

继续使用 M002 暖白阅读纸、深绿主色、造文双栏和后台侧栏；`theme.css` 只增补数字输入、系统策略、审校未完成警示及差异样式。计划页将两类预算并列：基础纠错用浅绿只读卡，内容审校用可编辑白色卡。界面直接显示“系统策略、最多2次、后台不可编辑”，不向最终用户展示产品文档里的“待技术定稿/技术建议”字样。

“内容审校未完成”使用浅杏警示，并与绿色成功提示区分；仍展示完整文章与保存按钮。正常上限定稿保持普通“生成完成”，不渲染故障警示，也不声称审稿通过。

pending 沿用既有标题和说明，在最长10秒的自动核对窗口仍未收敛后显示“重新核对”。点击只查询现有 run/preview 的 status；核对中按钮改为“核对中…”并禁用。active 或503仍回到 pending，不出现保存/发布或成功表达。

## 启动与稳定入口

在 `.planning/milestones` 运行：

```sh
python3 -m http.server 4174 --bind 127.0.0.1
```

基址：`http://127.0.0.1:4174/M003/design/prototype/`。必须经 HTTP 加载 `copy.json`、夹具和 M002 主题。

| 场景 | 查询参数 |
|---|---|
| Basic 基础只读 | `?page=plans&plan=basic&adminState=edit&lang=zh` |
| Pro 关闭/0 | `?page=plans&plan=pro&limit=0&adminState=preview&lang=zh` |
| Pro 上限99保存恢复 | `?page=plans&plan=pro&limit=99&adminState=saved&lang=zh` |
| 非法值 | `?page=plans&plan=pro&limit=-1|100|1.5|&adminState=edit&lang=zh` |
| 远端/本地冲突 | `?page=plans&plan=pro&limit=99&remote=2&adminState=conflict&lang=zh` |
| 本次 N=2 的第2次返修 | `?page=create&plan=pro&limit=2&stage=repair2&lang=zh` |
| 正常上限定稿 | `?page=create&plan=pro&limit=2&stage=complete&outcome=limit&lang=zh` |
| 审校故障有效交付 | `?page=create&plan=pro&limit=2&stage=incomplete&lang=zh` |
| 用户 pending 可重新核对/核对中 | `?page=create&plan=pro&stage=pending&recheck=available|checking&lang=zh` |
| 无有效稿/取消 | `?page=create&plan=pro&stage=failure|cancelled&lang=zh` |
| 后台固定1次、审校未完成 | `?page=presets&mode=enhanced&previewState=incomplete&lang=zh` |
| 后台 preview pending 可重新核对/核对中 | `?page=presets&mode=enhanced&previewState=pending&recheck=available|checking&lang=zh` |

入口均支持 `lang=en`。夹具只供确定构图，不代表真实用户、文章、服务、质量、费用或延迟。配置99只证明静态显示/读取，不模拟99轮。

## 页面与内容定位

| 区域 | 顺序和规则 | 文案源 |
|---|---|---|
| `#benefit-summary` | 服务名→动态 N→当前计划→受理快照；用户不可切换 | `benefit.*`、模板 `benefit.enhanced.body` |
| `#generation-status` | 原 UI02 顺序不变；pending 说明后为 `#generation-recheck`，available 可点、checking 禁用且 `aria-busy=true` | `stage.pending.*`、`action.recheck/rechecking` |
| `#basic-correction-policy` | 漏词/格式/学习字段→所有计划→最多2次系统策略→不可编辑 | `plans.base.*` |
| `#content-service` | 服务开关→内容上限输入→说明/错误；普通档禁用0；付费档整数0–99，0关、1–99开 | `plans.review.*` |
| `#change-preview` | 基础策略不变→内容旧/新 N→撤回警告→人数→新请求/在途/用量→保存 | `plans.preview/effect.*` |
| `#version-conflict` | 服务端最新值→本地未保存值→重新核对；不部分保存 | `plans.conflict/latest/local.*` |
| `#preview-result` | preview pending 复用同一说明与 `#preset-recheck`；`#preset-publish` 禁用，直至查询到允许发布的有效终态 | `stage.pending.*`、`action.recheck/rechecking` |

文案原文只在 `copy.json`；原型实际 fetch。真实 N、影响人数和用量来自应用模型。输入错误不被自动截断或静默纠正；预览/保存禁用并就地说明。协议、调用链、基础预算最终值、超时和重试由 backend-alex 定稿；界面不固定 SSE 事件或增加模型调用。

## 实现约束与验收

| 验收 ID | 定位 | 必须保持 | 充分证据 |
|---|---|---|---|
| UIA-M003-301 | `#benefit-summary` | actual plan 与动态 N；0时仅基础；在途快照不变 | Basic、N=2、N=99 文本/属性 |
| UIA-M003-302 | `#generation-status` | 第2次返修可复现；上限完成无故障/通过承诺 | repair2、limit-complete 操作与文本 |
| UIA-M003-303 | `#generation-status[data-stage=incomplete]` | 最近有效整稿、持续警示、保存可达、计一次且不称通过 | 桌面/手机操作及保存可见性 |
| UIA-M003-304 | `#basic-correction-policy/#content-service` | 两类策略区分；基础只读；普通0；付费0–99 | 四计划、控件禁用与可访问名称 |
| UIA-M003-305 | `#content-repair-limit` | 0/99合法；-1/100/1.5/空非法；非法不可预览 | 属性、错误、按钮状态；不调用模型 |
| UIA-M003-306 | `#change-preview/#version-conflict` | 旧新 N、新请求/在途；远端与本地同时保留；重新预览 | limit0、local99/remote2 |
| UIA-M003-307 | `#preview-mode/#preview-result` | 增强固定1，不读取计划 N；incomplete 有提示仍可手动发布 | enhanced/incomplete 操作与文本 |
| UIA-M003-308 | `#generation-recheck/#preset-recheck` | 自动核对最多10秒后显式可点；点击后禁用重复点击；active/503仍 pending；不保存/发布、不新生成/扣次/续传 | 中英文 available/checking 稳定入口、按钮属性与动作资格 |
| UIA-M003-309 | 全部 | ≥320px 无页面横向溢出；目标≥44px；焦点可见；状态不用颜色单独表达 | Chromium 代表视口与边界检查 |

技术可调整 DOM/组件；固定文案、顺序、保存资格、状态语义和关联上限必须保持。内容流程测试最多执行到第2轮；不得因测试深度把运行上限硬编码为2。

## 自检与未验证

UI02 已接收证据保持在 `design/evidence/ui02/` 与 design-007 冻结快照。2026-10-09 使用本地静态 HTTP、Chromium / Playwright 1.62.1 / Node v22.23.2 对 UI03 做 CR-301 定向检查：7组状态、4张新截图全部 PASS；覆盖用户与预设 pending 的 available/checking、中英文文案、点击进入 checking、禁用重复点击、保持同一 pending，以及无保存/发布。代表页无控制台错误、缺失文案或横向溢出；4张截图已人工查看，按钮、禁用态和说明关系清晰。

本轮未重跑 UI02 的其他页面、全视口或全浏览器证据；英文只做结构/文案检查，未截图。真实10秒计时、HTTP 终态、503/404/410、token 权限与正式前端焦点恢复仍由 frontend-bob/qa-quinn 按 BE02 验证。未做真实模型、UAT 3302、数据库或部署。产品工程要求的 Node 24 未用于本次静态原型检查。CR-301 已有设计解决来源，当前无新增业务选择或阻塞。
