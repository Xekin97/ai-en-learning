---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M003-UI-03
date: 2026-10-09
input_version: M003-PRODUCT-03 / M003-BE-02 / CR-301
---

# M003 UI/UX 交接

## 修订范围与来源

- UI03 仅解决 [CR-301](../changes/CR-301.md)：为 PAGE-204/216 的生成 pending 与 PAGE-212 的预览 pending 补齐显式“重新核对”动作、核对中禁用态和中英文文案。该行为来自已接收 BE02 的 API-302/API-304，不是新增业务选择或产品范围回溯。
- UI02 已接收并冻结于 `reviews/evidence/design-007/`。0–99、双预算、有效稿审校未完成、计次、预设模式及其既有证据保持有效；本轮没有重做或覆盖 UI02 证据。
- Profile 保持 `consumer-ai-web@1.0.0`。模型路由锁仍为 strong `gpt-5.6-sol/high`；宿主没有独立 serving metadata，`actual_model` 为 unknown。

## UI03 原件

- [设计规格](../design/design-spec.md)：稳定入口、定位符与更新后的 UIA-M003-308。
- [交互](../design/interactions.md)：最多10秒自动核对、手动核对、active/503保持 pending 及停止边界。
- [响应式与无障碍](../design/responsive-accessibility.md)：busy/disabled、焦点与动作资格。
- [文案源](../design/copy.json)：`action.recheck.zh/en` 为“重新核对 / Check again”，`action.rechecking.zh/en` 为“核对中… / Checking…”。
- [原型逻辑](../design/prototype/app.js) 与 [主题增量](../design/theme.css)：普通页 `#generation-recheck`，后台 `#preset-recheck`、`#preset-publish`。
- [UI03 浏览器报告](../design/evidence/ui03/M003-UI-03-browser.json)、[定向脚本](../design/evidence/ui03/browser.mjs)及同目录4张截图。

## 前端必须保持

- pending 表示有限自动核对后仍未确认。前端立即查询一次、最多每2秒且总窗口最多10秒；窗口结束才显示“重新核对”，不无限轮询。
- 点击只查询现有 run 或 preview 的 status。请求中按钮原位显示“核对中…”，设置 `disabled`、`aria-busy=true`，防止重复点击。active 或503仍回到 pending，并继续复用原 pending 标题和说明。
- 普通 pending 不显示保存；预设 pending 的 `#preset-publish` 禁用。按钮点击不代表重新生成、额度扣除、流式续传、模型调用或后台任务。
- 只使用当前 owner/token/TTL 范围。不得把 token 写入 URL、本机存储或设计新的刷新恢复平台；404/410等停止条件及权限响应以 API-302/304 为准。
- 可复现入口：
  - `?page=create&plan=pro&stage=pending&recheck=available|checking&lang=zh|en`
  - `?page=presets&mode=enhanced&previewState=pending&recheck=available|checking&lang=zh|en`

## 定向验证

2026-10-09 在本地静态 HTTP 下使用 Chromium / Playwright 1.62.1 / Node v22.23.2 检查7组状态、生成4张新截图，报告 PASS。覆盖普通与预设 available/checking、中文与英文文案、点击保持同一 pending 并进入 checking、重复点击禁用，以及 pending 时无保存/发布；代表页无控制台错误、缺失文案或横向溢出。4张截图已逐张查看，按钮、禁用态、说明与页面层级清晰。

本轮没有重跑 UI02 其他页面、全视口或全浏览器。英文只做结构与文案检查，未截图。真实10秒计时、HTTP 终态、503/404/410、token 权限、正式焦点恢复、产品代码、真实模型、UAT 3302、数据库及部署仍未验证。产品工程要求 Node 24，本次静态原型按现有 Node v22.23.2 执行。

## 接交

- CR-301 的 UI 责任已解决，M003-UI-03 建议 `awaiting_user_review`。当前无 BLOCKED、开放设计选择或新增 CR；本交接不修改 workflow、不激活前端。
- 用户/守门器接收 UI03 后，可单独恢复 frontend-bob：直接复用上述文案和定位，并依据 API-302/304 实现有限核对。DB02、BE02 及 UI02 未受影响部分不需回溯。
- 本轮只写设计、UI 交接及 CR 解决记录；未修改前端、后端、数据库、控制面或冻结证据。

> 阶段迁移由主会话和守门器控制。
