---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M003-UI-13-R4
date: 2026-10-13
input_version: M003-PRODUCT-10 / M003-BE-08 / TRANSITION-M003-099 / USER-M003-UI13-TYPING-20261013
---

# CR-311/312 UI/UX 设计交接

designer-tony 已完成 UI13-R4 首稿打字呈现修订，当前等待用户评审。CR-311/312 仍 open；本交接不批准设计、不切换阶段，不授权 frontend、实现、QA、真实模型调用或 UAT3015 刷新。

## 本轮决定

- 首稿只对合法 append 使用打字式显示。reducer 立即保存完整 received text，显示层以 Unicode grapheme 安全的前缀逐帧追随，不延迟任何权威状态或动作。
- 首个 grapheme 立即出现；基础速度 36 grapheme/s。received-display 出现积压时按剩余窗口自适应加速，使用 650ms 呈现追赶预算并允许一个浏览器渲染帧容差；新 chunk 不重置尚未完成的预算。
- 全页最多一个 `requestAnimationFrame` loop，每帧预算可以为 0 并保留非负余数，每帧最多一次 text patch。速度不随 60/120Hz 刷新率翻倍，不为每字符创建 DOM/timer。
- 使用 `Intl.Segmenter(granularity:grapheme)`；缺失时直接显示 received text。跨 chunk combining mark/ZWJ 重分段会原子更新已显示尾部，避免停留在未组合字符。
- `body_complete`、返修 begin、finalizing、validated 立即 flush；取消、失败、协议异常、新 epoch、重播/离页直接销毁循环。减少动态效果直接显示 received text。caret 只在真实 backlog 时显示，正文不设 live region。
- 返修保持 R2：完整旧稿持续可读，只有 `paragraph_complete` 才做 220ms 原位交接；Plan 240ms 收拢、稳定节点/滚动焦点、valid 动作立即可用均不变。R1 文案和 R3 六词四段书店样例/来源也不变。

## 最易评审入口

静态服务已在 `127.0.0.1:4174`：

- 中文完整流程：<http://127.0.0.1:4174/M003/design/prototype/?page=create&lang=zh&scenario=ui13-r3-bookshop&event=11&demo=open&rev=ui13-r4>。页面底部点击“播放完整过程”；状态变为“把构思写成短文”后向下滚到“短文草稿”，即可看到四个初稿块连续铺开，随后继续看返修完整段平滑更新。
- 英文窄屏 / PAGE-212：<http://127.0.0.1:4174/M003/design/prototype/?page=presets&lang=en&mode=enhanced&event=11&rev=ui13-r4>，浏览器设为 390px 后点击 Generate preview。

Harness 沿用 fixture 原有 wire 间隔，不额外停留来制造打字效果；其时间不代表线上模型耗时。

## 前端接收映射

1. `generation/reducer.ts` 继续维护 working/published 权威文本；typing presenter 另持 received/displayed，不回写 reducer。只接受 `delete_count=0 && at=旧 working/received 的 Unicode codepoint 长度` 的 initial append。
2. `GenerationWorkspace.vue` 保持 generation paper/status/paragraph key。一个可取消的 frame scheduler 计算 `rate=max(36, backlog/deadlineRemaining)`；首字符同步，其余预算不足 1 时不 patch。每个 callback 检查 epoch、host identity 和 `isConnected`。
3. 新 append 仍有 backlog 时沿用原 deadline；caught-up 后下一块才建立新的 650ms budget。页面隐藏不伪造后台 timer；恢复首帧若预算已过即追平。650ms 为呈现预算，实际 paint 允许一个浏览器帧容差。
4. Segmenter 不可用、reduced motion、非 append edit 直接同步 displayed=received。追加 combining/ZWJ 时重新 segment 全 target，并在 grapheme 数不变但 prefix 变化时原子重绘。
5. completion/revision/finalizing/valid 先同步 displayed=received 再取消 scheduler；cancel/failure/protocol error/new epoch 则丢弃未显示前缀。两条路径都不能推迟 Result、保存、配置解禁或终态。
6. `.live-draft-text` 只在 backlog 时有 `aria-busy=true` 和装饰 caret，不使用 live region；不逐字符播报、不自动滚动。PAGE-212 enhanced preview 复用相同 presenter。
7. 既有 working/published、220ms 段交接、240ms Plan 收拢、Cancel→Generate 同节点持焦、UI11/UI12、权限和保存边界继续按 UIA-M003-427–437 实现。

## 原件与证据

- [R4 设计规格](../design/design-spec.md)、[交互](../design/interactions.md)、[响应式/无障碍](../design/responsive-accessibility.md)、[theme](../design/theme.css)、[prototype](../design/prototype/index.html)。[copy](../design/copy.json) 与 [R3 rich fixture](../design/fixtures/ui13-r3-bookshop.json) 均未改变。
- [R4 lifecycle report](../design/evidence/cr312-r4/M003-UI-13-R4-typing.json) 6/6 PASS：两个时刻增长、追赶、body/valid、取消后延时无复活、重播、reduced motion、390px PAGE-212；console error 0、provider call 0。
- 调度小修后的 [targeted scheduler report](../design/evidence/cr312-r4/M003-UI-13-R4-scheduler-fix.json) 5/5 PASS：丰富块追赶、120Hz 三字符短块约 51ms、Segmenter fallback、跨 chunk combining/ZWJ 原子重组、console 0。该报告取代 lifecycle report 中旧调度实现的速度采样；其余 lifecycle 路径未受小修影响。
- 代表图：[桌面中文首稿铺开中](../design/evidence/cr312-r4/01-initial-typing-desktop-zh.png)、[390px 英文 PAGE-212](../design/evidence/cr312-r4/02-initial-typing-mobile-en-page212.png)。两图已目视；真实时间报告而非静态图证明 typing。
- [R4 source archive](../design/evidence/cr312-r4/M003-UI-13-R4-source.tar.gz)、[manifest](../design/evidence/cr312-r4/M003-UI-13-R4-source-manifest.json)、[修订前快照](../design/evidence/cr312-r4/before.tar.gz)。调度定向检查两次失败原样保留，修正后不再扩测。
- UI13/R1/R2/R3 证据冻结复用；本轮没有重跑全协议、返修 motion 或文章质量矩阵。以上只证明设计原型，不证明 Vue/API/真实模型/独立 QA/UAT。

## 未决与下一步

唯一未决是用户是否接受 R4 首稿打字呈现。接受后才由 frontend-bob 接收 [UIA-M003-427–438](../design/design-spec.md#实现验收)；CR-311/312 保持 open，应用当前仍未实现/未验证。
