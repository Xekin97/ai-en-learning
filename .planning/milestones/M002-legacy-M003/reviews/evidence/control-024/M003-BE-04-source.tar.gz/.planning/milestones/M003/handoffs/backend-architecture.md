---
milestone: M003
stage: technical-design
role: backend-architect/base
agent_name: backend-alex
status: awaiting_user_review
version: M003-BE-04
date: 2026-10-10
input_version: M003-PRODUCT-04 / M003-DB-02 / M003-BE-03 / M003-FE-01 / M003-UI-05-R1
---

# M003 连续正文与版本化编辑流交接

backend-alex 按 [TRANSITION-M003-023](../reviews/live-text-backend-022.md)完成BE04；建议awaiting_user_review/for-prototype，不改workflow或自批实施。继续使用既有v1锁frontier请求gpt-6-astra/high，实际serving metadata/usage unknown，Profile1.0不迁移。

## 确认闭环与当前选择

[USER-M003-LIVE-TEXT](../reviews/requirements-feedback.md)明确取代BE03/PRODUCT04/UI05-R1的“仅词义预览、正文最终才出现”：首稿和修订稿须消费真实正文增量，审稿无新正文时保留稿件，不突出审稿/轮次。[USER-M003-EDIT-OPS](../reviews/requirements-feedback.md)进一步询问类CRDT的前进/回退/替换与成本；用户没有要求多人协作平台。实时正文方向已CONFIRMED；本版具体splice形状/频率/实现细节为PROPOSED技术设计，待整版评审，不声称用户逐字段批准。

采用单服务器权威的版本化splice：`draft_id + content_version + base_rev/rev + seq + at/delete_count/insert + source`。append是尾插，回退是删尾，替换是区间删插；Unicode码点为位置单位。一般token只追加新片段；换稿首个安全片段到达才比较一次共同前缀并撤回旧后缀，之前不清空旧稿；Q02从lastValid一次恢复。模型继续输出原有完整Candidate/续写，位置/版本由后端代码计算，不让模型计算偏移、不每token全文diff、不加LLM调用。不采用完整CRDT、墓碑/向量时钟或每token落库；status只恢复持久终态snapshot，不新增active编辑回放服务。

基础全请求2次、内容N0–99/初始1/0全关、双预算独立、同目标模型、上限后正常定稿、内部牵强/矛盾/频率统计、一业务次数、Q02与取消/断连/DB未知规则全部保持。管理0–99及后台basic0/enhanced1不变。没有新增业务OPEN/BLOCKED；只读草稿不允许保存，最终完整Result与notice必须由DB确认。

## 当前直接原件

- [后端设计](../technical/backend.md)：BE3-01选择、BE3-08源码可复用点/缺口与改动表、BE3-09 CPU/内存/带宽/背压边界。
- [AI编排](../technical/ai-integration.md)：同模型/预算/六类内容故障不变；AI3-05连接真实首稿/重写/续写delta，Q02恢复。
- [API索引](../technical/api/index.md)、[API-301/302生成与状态](../technical/api/generation.md)、[API-303管理](../technical/api/administration.md)、[API-304预设](../technical/api/presets.md)：精确m003-stream-v4字段、splice/rev/seq与终态、预览独立身份。
- [stream-v4入口](../technical/fixtures/stream-v4/index.json)：10个场景的多帧exact wire事件（数量见检查证据）；逐帧合成节奏与有限status响应，学习字段/完整包见[packages.json](../technical/fixtures/stream-v4/packages.json)。
- [静态检查](../technical/evidence/check_stream_v4.py)、[检查证据](../technical/evidence/stream-v4-check.json)、[限定fixture生成脚本](../technical/evidence/build_stream_v4_fixtures.py)。检查只针对设计产物，不是Go/浏览器/提供方/性能验收。

## designer-tony 接收合同

1. 正常“生成”按钮自动读取index中的fixture，按wire逐条reduce，playback只调度每一帧，不能另从整包文章制作打字动画。stream-v4为唯一当前输入；v3保留可恢复但已被本次方向取代。
2. `generation.edit`与`preview.edit`共用splice语义但保持独立命名空间/token。验证seq、base_rev/rev及码点区间后应用到当前纯文本；每条先reduce、绘制可合帧。不能用JS UTF-16 `.length`冒充码点。相同紧邻帧重送无操作；缺口/错rev/旧draft不可拼接，沿status核对。
3. 直接展示真实多片首稿；内部审稿等待期间保留文章，不造审稿文字。新稿首片到达才撤回旧后缀并连续新文字，原阅读区无先清空的长白屏。草稿始终不可保存，不带旧高亮/释义/hint；终态一次建立全部Result。不能每帧强制滚到底或读屏朗读全文，换稿给克制提示即可，不显示技术ID/版本/次数。
4. 必须实际播放可观察的纯删除与替换帧：[rewrite-once](../technical/fixtures/stream-v4/rewrite-once.json)在新稿首片保留共同前缀并撤回旧尾；[rewrite-twice-recover](../technical/fixtures/stream-v4/rewrite-twice-recover.json)展示V3部分稿后retained恢复V2，再确认完整包与持续未完成notice。不能只在说明里写“支持回退”。
5. [native-continuation](../technical/fixtures/stream-v4/native-continuation.json)展示同业务V、不同draft_id的真实续写；另一次仅标注基础纠错没有新正文，不能为了动画复播拷贝。[paid-no-rewrite](../technical/fixtures/stream-v4/paid-no-rewrite.json)有审稿等待但正文不变。全部最多合成2轮，未执行模型pipeline。
6. pending/status的active→valid恢复整包；EOF未知只保留草稿与核对且禁保存；取消/无有效稿失败清草稿，分别不退/退款。preview valid后必须另核当前AdminPreset draft_version/mode/run关联，不能凭edit或valid就发布。
7. 保留用户要求的完整造文/计划/预设页面、正常按钮自动回放与取消代次隔离；中英文/移动与阅读位置由设计角色落实。playback延迟只用于合成演示，不在正式产品文案夹工程说明，不代表服务时延；精确fixture版本/资源请求证据进入UI交接。仍需用户视觉评审，不能以本轮静态PASS代替。

## 跨owner同步依赖（精确范围）

沿用原BE3-DEP01–04追踪关系，下面是本轮LIVE-TEXT撤销BE03取舍后的新动作；不越权修改owner原件。

| ID / owner | 需同步的原件与稳定ID | 完成条件 |
|---|---|---|
| BE3-DEP01 / product-maya | PRODUCT04 `overview.md` D3-04；`data-assets.md` DATA-302/303可见性；`abilities.md` CAP-302/304、AC-308/312及CAP-301受理展示；`ai-behavior.md`真实进展；PAGE-204/216及等待/词义文案；产品交接BE03依赖 | 删除仅词义/正文只出现一次/首有效包前不能显示正文等BE03约束，落实真实只读增量/切稿/退回lastValid；业务预算/配置/计次/Q02保持。首可读正文、换稿等待、总时长分别观察，不能声称已更快 |
| BE3-DEP02 / designer-tony | UI05-R1 design-spec/interactions/copy/原型app.js与UIA-M003-401–411中原BE03映射 | 按上方接收合同实际消费v4 edit；保留自动按钮/取消隔离；首稿及修订多片、真实删尾/替换、故障恢复可直接观看，完整页面交用户评审 |
| BE3-DEP03 / frontend-bob | FE01 FE3-03/04/06/07/08/09、FE3-T01/02/05、FE3-V02–06/09/11/12 | 用BE04+后续已审UI改reducer/API types/mock，移除stage/snapshot/candidate/learning-only假设；seq/rev/identity/Unicode、Q02与终态、请求epoch/取消和有界核对正确，不能先实施旧词义only |
| BE3-DEP04 / backend-ethan | 待审BE02源码与BE3-08表 | 后续获实施授权再接通rewrite delta、局部增量extractor/coalescer、edit writer/源identity、retained恢复和相应测试；按BE3-09记录实际资源。现代码不宣称符合BE04；不改DB02或上游预算 |

DB02字段足够，draft_id/stream_id/revision只是当前流内存；无DB迁移需求。若后续提出恢复活动草稿、多人编辑或模型直接生成edit计划，那是未授权扩展，不按本次自动实施。

## 验证、成本与保留

字段/顺序/身份/版本、拼接与纯删除、回退同包、重复帧无操作、缺口错rev拒绝、同V续写、Q02/取消/失败/pending及命名空间由限定checker检查；证据含具体计数、破坏变体与当前源hash。原v3 fixtures/证据和已有源码的保留hash核对在同一检查内，BE03七份与control-018冻结包修改前7/7一致。未重跑不相关全套检查。

现有安全extractor能处理跨帧JSON转义/surrogate/括号元数据，但累计字符串重解码仍有全量扫描风险；需要按BE3-09局部游标化，不能把改wire结构说成已优化整个后端。正常尾插只处理Δ，切稿少量LCP；公共队列8条/64KiB上界、50ms合并目标、2048码点provider插入界，慢客户端背压/10秒写截止、原600秒执行界不变。

100连接×10帧/秒×300B≈300KB/秒只是消息带宽假设；病理输入沿原16MiB候选/200万干净码点界，含旧有效包/新稿/解析对象，单请求可能约80–160MiB甚至更高，必须实测分配/RSS，不能凭短fixture承诺容量。后续替身测量与最小观测计划已列BE3-09，分开模型等待/LLM用量、活跃流、处理、写阻塞、事件字节和进程CPU/RSS/GC；连接秒不当CPU秒，不逐帧落库，本轮没有压测、真实模型、Go全套、迁移、浏览器、Git提交、部署或UAT3302操作。

保持CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX；质量、真实时延/费用与并发竞争未在本轮重验。定向读取当前入口/代码并停止历史扩展；运行时总输入字符/token/usage unknown，证据的静态字符计数仅用于源文件规模，不冒充运行量。

## 下一动作及边界

本角色方案已可直接驱动新原型，建议主会话按用户已授权顺序先交product-maya同步已确认条款，再交designer-tony消费v4；前端技术对齐与实施仍遵后续接交及用户视觉评审。当前建议awaiting_user_review/for-prototype；不自行激活下一角色、不把未来实施或完整CRDT列为已批准范围。
