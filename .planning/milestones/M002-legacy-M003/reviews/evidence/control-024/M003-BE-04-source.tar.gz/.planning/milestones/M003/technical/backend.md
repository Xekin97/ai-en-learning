---
milestone: M003
stage: technical-design
role: backend-architect/base
agent_name: backend-alex
version: M003-BE-04
status: awaiting_user_review
date: 2026-10-10
---

# M003 后端可实施增量

输入PRODUCT04、DB02、BE03、UI05-R1、FE01与待审BE02代码；按 [TRANSITION-M003-023](../reviews/live-text-backend-022.md)及 [USER-M003-LIVE-TEXT](../reviews/requirements-feedback.md)重开。用户明确要求首稿和修订稿真实逐部分显示，取代BE03的仅词义预览/正文最终出现取舍；不公开审稿内容/轮次、不变业务预算或终态。七份BE03已与control-018冻结包逐字核对7/7后原位更新，v3 fixtures和冻结原件不改。Profile1.0/v1路由锁不迁移。

## BE3-01 选择与范围

内部保持“组织目标词→首稿→基础校验→同目标模型审稿→条件返修/再校验→最终结算”。它本来顺序执行；**公开正文并不需要等待每个内部步骤完成**：首稿/重写/续写提供方每次收到的安全文字直接进入公开流，审稿没有正文时保持已有稿件。基础全请求2次、内容N0–99/初始1/0全关、双预算独立、最多按N返修、正常上限定稿、Q02有有效稿技术故障交付、一业务次数全部保持，无额外模型调用。

| 方式 | 收益 | 代价/风险 | 本版选择 |
|---|---|---|---|
| 每帧累计全文snapshot | 易整体覆盖，继承旧snapshot结构 | 长正文/多轮重复发送O(n²)字节，仍须稿件身份隔离，UI容易整块重绘 | 可行但不作为主路径 |
| 带身份/revision的版本化splice | 小片段直接到达；明确新稿/续写/故障恢复；复用安全delta来源 | reducer须严格校验身份、base_rev与区间 | 采用单一edit事件，不新增回放平台 |
| 等完整包再切片/前端打字 | 客户端容易演示 | 没有真实首稿/修订稿增量，仍等待整包 | 用户已明确排除 |

BE04的`generation.edit`（后台为preview.edit）用版本化splice表达追加、删尾与替换：首稿首片插入，后续尾插；重写先保留旧稿，首片到达才以splice撤回旧后缀并连续尾插；基础续写用新draft_id明确继承前缀并append真实新段落。`content_version`仍是内容返修候选版，基础恢复不加版；每次可见尝试/谱系另有draft_id，不能靠版号拼稿。半稿失败Q02用source=retained显式splice恢复lastValid正文，再由DB确认的完整终态原子建立学习资源。纯字段/标注纠错禁止改变可见正文，保持原文不播拷贝。详 [API-302](api/generation.md)。

首个安全完整词边界即可输出，不等32字符、完整段落或基础校验；后续最多50ms/128码点目标合并、单provider帧至多2048码点，仅冲刷已接收字符。可见草稿始终只读，未完成不带学习高亮/词义/hint；最终Result一并对齐。真实首字/最长无新内容/换稿空档/总时长尚未测量，50ms是flush规则不是服务时延承诺。

用户真实增量/换稿方向为CONFIRMED；事件形状与有界合并为本角色授权范围内的具体设计，整版awaiting_user_review/for-prototype，不冒充整版批准。没有新业务待决、费用、基础设施或DB字段。源码现状仅证明可复用能力和改动点，不能当成已经实现BE04。

## BE3-02 追踪与模块入口

以下相对backend/；无变化领域继承M002契约，不重写完整历史。

| CAP / DATA / API | 修改入口 | 责任 |
|---|---|---|
| CAP-301；DATA-301/302；API-301 | `internal/entitlement/service.go` Resolve/Options；`generation/service.go` start；`httpapi/catalog_handlers.go` | 唯一胜出计划读N，内容与模型卡/次数卡分离；同锁revision、origin、全请求快照；输出NativePolicy |
| CAP-302；DATA-302/303；API-302 | 新 `generation/pipeline.go`；`ai/{contract,continuation,gateway,openrouter,protocol_stream,validator}.go` | 请求级两个预算、lastValid整包/候选身份、公开投影、严格Review及六类停止原因、同连接、早停和deadline |
| CAP-303；DATA-301；API-303 | `admin/groups.go`；`httpapi/{admin_handlers,group_handlers}.go` | 0–99/开关配对严格读写、只读系统策略、impact/优先级/revision冲突；四行保留 |
| CAP-304；DATA-304；API-304 | `generation/{presets,preset_preview,preset_catalog,preset_cleanup}.go`；`httpapi/{preset_handlers,preset_preview_handlers}.go` | mode版本绑定与固定0/1；共用pipeline/Q02，preview恢复notice与手动发布 |
| CAP-305；DATA-302/304；全部 | `generation/{usage,preset_usage,settlement,charge}.go`、`ai/usage.go`、`generationtrace/*` | 每调用发送/费用事实、终态CAS、文章/调用统计，禁止审稿私有意见入库 |
| CAP-302/304；DATA-303/304；API-302/304 | `httpapi/server.go`新增两个GET路由；`generation/service.go`、`preset_preview.go` | owner/token/TTL限定状态核对，DB派生最终版本/outcome/notice，不再次调用 |

完整HTTP字段以 [API索引](api/index.md)为唯一真源。系统基础策略来自 `ai.NativeCorrectionLimit=2`/策略版本常量（拟名），读取投影和pipeline消费同源；数据库不新增可写基础预算，客户端写入字段拒绝。

## BE3-03 DB3-03–06 具体落点

| 操作 / 拟函数 | 同事务职责 |
|---|---|
| Start/StartPreset→acceptContentPolicy | 配置共享锁→主体锁→锁后Now→Resolve唯一计划→模型/词表/额度→run完整v1快照/entries/Reserve charge/开始事实。N来自计划，不从charge推断；origin=Plan.Origin；extra不改内容N；模型连接BindSpec锁内一次；commit确认后started，无事务等待模型 |
| StartPreview | 配置共享锁→管理员存在→当前draft/version/已保存mode匹配→绑定连接→完整preview快照；basic0/enhanced1，不读管理员计划，不写user charge |
| usageRecorder Reserve/MarkInvoked/RecordReview/FinishUsage | owner+call_no唯一串行；预留失败不发；审稿事实持久后才下一返修；true/false/NULL证据及错误回传详AI3-05；不允许仅log关键事实错误继续成功 |
| CompleteValid(run,PipelineResult) | 配置共享锁→主体锁→active CAS→validateContentOutcome→原charge consumed/学习成长分析→最终draft和outcome/final_content_version/content_stop_reason一次提交。`PipelineResult={Package,Outcome,StopReason}`只由服务端生成，HTTP不传它 |
| CompletePreview | 配置共享锁→preset行锁→active CAS及同一内容事实验证→完整preset_previews→仅匹配version/hash/configuration/mode且空preview_id时关联。写同一包的final_content_version/outcome/stop_reason；旧mode晚完成可独立valid但不能覆盖当前draft/公开样文 |
| SettleTerminal/ReconcileFailure/SettlePreview | 取消/真正失败写outcome及原状态/扣退次同事务，version/reason=NULL。service_incomplete直接走CompleteValid/Preview，不能先退款再转成功；pending review转indeterminate，不捏造pass/issues |
| SavePreset/PublishPreset | mode和生成条件一起版本化；仅紧邻旧草稿纯标题且mode相同继承预览及notice；发布排他配置锁+预设锁+revision/current draft，检查完整valid payload/关联/模式/终态事实，含未完成有效预览人工发布 |
| 0017候选迁移/启动 | 按DB3-02/08一次加字段、精确初始Pro/Plus1、revision一次；实施先核最大号。启动验证完整schema/配置，缺字段或非法配对失败关闭受理，不重seed、不覆盖模型/用量/期限 |

`validateContentOutcome`需核对：basic无内容调用；review_passed交付版本1审稿pass且无repair；repaired_passed交付版本已原生有效且末审pass，至少1次实际repair、不超过N；limit_finalized实际内容预算耗尽且最终有效稿末审issues；service_incomplete有本请求lastValid包及AI3-02六类原因，必要调用/审稿事实已持久化。通用规则：run snapshot=所用模型/pipeline/内容N；版本在1..N+1（preview≤2，basic=1）；最终版本来自包身份，不倒算call_no或尝试次数；只有incomplete原因非NULL，原failure_code/category保持NULL。

候选编号与审稿绑定只在请求内存编排，usage按call_no可顺序审计，不为多轮加表或持久中间稿。完成事务使用该pipeline产出的不可变完整包与事实，不能接受外部宣称“原生有效”。同稿基础纠错不增加版本。保存/claim继续一run→一batch，沿原归属/幂等/删除例外，不因内部返修新建业务run或再扣额。

## BE3-04 停止、context与唯一终态

accepted ctx关联用户连接，execution ctx在其下设整体600秒，每调用再设180秒；单次/执行deadline与显式cancel/client disconnect独立识别。内容deadline触发关闭上游并选lastValid后，使用独立有界10秒completion ctx完成Q02，不能复用已到期execution ctx让有效交付必然失败。执行截止不允许发新模型调用；DB完成/确认窗口不是模型加时。

调用预留前/发送前、接收后、validator循环、review事实提交后和成功CAS前均检查取消/终态。显式取消先确认user_cancelled提交再cancel registry；取消写/读不明不能假定已取消，返回pending核对。连接断开/write失败停止模型并按原stream_failed结算；不能将其归为content_transport_error。已进入网络发送的极短竞态可产生费用，停止后不编排下一阶段，迟到usage不复活run。

客户端断连与completion ctx独立取消保护配合：开始完成前若已断连就不尝试Q02；完成过程中监测下行ctx并争取原失败CAS。最终以数据库已提交终态为准，无法保证远端收到结果与DB提交原子一致。valid先赢（含incomplete）则取消/传输失败不退款；取消/失败先赢则不得写draft。一个请求至多一个业务终态，流丢失不改变已提交结果。

关键事实或最终提交异常，先用新鲜5秒context核对run+原charge+最终payload；valid返回库中包/版本/outcome/notice，不能用内存候选假定成功；cancelled/failed投影原值；不能确认则settlement_pending且不开保存。确认仍active才按既有server_failed退款，extra退原item且不延长期限；绝不先退款再宣service_incomplete。preview helper改明确confirmed/error，错误不伪报failed；沿现有registry/maintenance补结算，无新持久任务平台。重启读已提交终态不改写，未完成且内存包丢失沿原失败退款，不重放AI。

receiver关闭body解阻塞、context取消、事件channel可中断；单goroutine writer确保started/edit/恢复/终态顺序，seq只计公开帧；切稿前冻结旧attempt，迟到旧token不得进入新draft。status读取用VerifyRunToken+DB主体，不只依赖进程registry；待保存draft验证digest/expiry/disposition。终态能力沿1小时、草稿默认30分钟；本人已保存batch可沿原关联读取同一最终结果，不给访客token读取claim后的账号batch；删除/过期不重建。状态恢复的notice从run.outcome派生，不新增布尔列/文案副本/token持久化。

## BE3-05 调用、文章与质量统计

DB3-04/07是存储真源。provider_invoked=true才是确认调用，false明确未发，NULL未知；stage进入、repair_requested、usage行存在/收费已知都不是发送证据。`usageAggregate count(*)`不能继续冒充provider_calls，未知发送与未知费用分开展示；legacy/policy NULL单列历史未采集，不补零或basic。

按started_at半开窗口和entry_kind normal/preset、后台preview分别统计，先按run聚合再JOIN，避免多调用放大文章分母。全部受理Nall、增强E、实际审稿R、实际返修W（均按run去重）；返修率W/Nall、W/E、W/R，分母0=N/A。另报基础修正/审稿/内容返修实际调用数；两轮返修仍1篇、2个repair调用。预检拒绝不造run；取消/失败仍属受理分母。

牵强F和矛盾C按实际content_repair行的reason_codes标记文章，分别F、C、F∩C、F∪C；两轮分别触发F和C的同篇属于文章交集，调用交集只数同一调用同时有两类，二者不得混算。word_sense/缺前提/因果无据等映射other_content，基础错误不混入内容原因。Review发现、repair_requested与实际发送分别统计；末次issues未执行返修不增W。未知下界=true，上界加无true但有对应NULL的去重run；调用上界加对应NULL行，false不加，不从final版本差推算调用。

交付率=valid/全部受理用户run，包含service_incomplete；审校完成率=(review_passed+repaired_passed+limit_finalized)/增强受理，incomplete不算完成；审稿pass与上限定稿分开，incomplete按stop_reason报告，后台另列。独立质量通过必须由QA评阅，不能用valid或模型自报pass替代。费用/token保留known/partial/unknown及原精度，未报告不是0。只补现有诊断查询/测试SQL，不建统计平台或永久汇总副本。

意见/原句/推理/中间稿不入新列；review任务和包含issues的rewrite请求禁诊断正文捕获。原专用诊断授权/24小时、正文TTL、账号/批次/claim删除规则沿DB3-07/M002，不能为统计留下内容墓碑。

## BE3-06 实施与运维顺序

迁移/仓储→权益/管理→task-aware三协议Gateway与pipeline→普通及preview共用流/唯一终态→mode/状态查询→配套前端→隔离测试。新增字段必填；USER-COMPAT-001配套切换，不做旧passage.delta兼容层。已存在待审0017迁移文件，不等于已落库；实施接收后核对实际schema，不能重复初始化管理员配置。

沿原Docker/数据库部署，停写/在途结算/备份和隔离恢复依DB3-08，不新增基础设施。新事实写入后优先前滚，不能drop字段或恢复旧备份丢失数据。关闭增强仍用原计划revision，N=0仅影响新请求，不降级已受理增强。真实上线/在线配置修改需原发布授权，本轮未执行。

## BE3-07 实现与验证矩阵

以下为实施后必需验证；已有待审代码和开发证据不能替代BE04对齐验收，使用Go1.26.7、现有三协议HTTP替身及隔离PostgreSQL；不用生产/共享开发数据跑破坏用例，无真实收费调用。**CQ-14：所有流程测试实际内容返修最多2轮；0/99/100等仅配置/字段/静态循环与公式验证，不模拟3–99轮，不声称99轮已验证。** 与DB3-V01–06合并实施。

| AC / 验证ID | 修改与必要验证入口 | UI/DB追踪 |
|---|---|---|
| AC-301 / BE3-V01 | ai protocol_matrix/corrections及pipeline_test；普通无内容调用，三个协议同模型/连接；基础1/3次，增强N1≤6、N2≤8 | DB3-V02 |
| AC-302 / BE3-V02 | review/pipeline tests；首审pass早停、明确牵强/矛盾触发、两轮后pass/limit；平淡/开放结尾负例，模板组装无固定规划 | UIA-M003-302；DB3-V03 |
| AC-303 / BE3-V03 | validator/continuation/schema tests；全局基础2不重置，C1/C2/C3跨稿资源隔离；失败新稿显式撤回半稿且不影响最终包、已有v2且v3无效恢复v2 | UIA-M003-303；DB3-V03 |
| AC-304 / BE3-V04 | admin groups HTTP/DB：四计划、独立0/99往返、-1/100/小数/null/缺失/开关错配、非管理员；NativePolicy只读同源且不能写 | UIA-M003-304/305；DB3-V01 |
| AC-305 / BE3-V05 | impact完整before/after N/人数/系统策略/关闭警告，0模型调用；同revision双写仅1成功，ACK丢失重读、重新预览 | UIA-M003-306；DB3-V01 |
| AC-306 / BE3-V06 | entitlement/generation集成：trial到期、优先级/开关/N变更与受理锁两种先后，快照不混合，用量期限不重置 | UIA-M003-301；DB3-V02 |
| AC-307 / BE3-V07 | generation_reservation集成：basic+模型卡+extra仍0，pro+extra保留N，没模型/次数预检拒绝0调用 | DB3-V02 |
| AC-308 / BE3-V08 | generation_matrix/races/trace与preview集成：started写失败/Open失败、安全首词/Unicode、每稿真实增量、续写新identity、换稿及原子最终包、deadline与独立completion ctx、EOF/pending、唯一终态 | UIA-M003-301/302/308；DB3-V03 |
| AC-309 / BE3-V09 | presets集成：basic0/enhanced1独立于计划99（不执行高轮）、模式切回/标题复用/旧调用晚完、incomplete恢复提示/人工发布、浏览零调用 | UIA-M003-307；DB3-V04 |
| AC-310 / BE3-V10 | usage及SQL夹具：文章/调用不同，跨两轮F/C交并、意图未发送、true/false/NULL、0分母、legacy、incomplete交付但非完成 | DB3-V05 |
| AC-311 / BE3-V11 | charge/settlement/claim集成：valid/incomplete/取消/断连竞争、最后SQL/ACK失败、extra跨过期退款；多call仍一charge、保存claim不重扣 | DB3-V03/06 |
| AC-312 / BE3-V12 | 替身记录首可读正文/每稿首片/最长无新内容与换稿空档/总耗时；QA冻结输入/模型连接/prompt/pipeline逐句评阅自然用词/前提因果/文体，分别交付/审校完成/质量及误漏报 | UIA-M003-309相关体验；真实质量待授权 |
| AC-313 / BE3-V13 | 六类stop_reason各替身，已有包/无包/关键DB错误三分；审稿失败最终当前包、返修失败最终旧包，status/流/preview notice一致，原failure_code=NULL | UIA-M003-303/308；DB3-V03 |
| AC-314 / BE3-V14 | 混合基础/内容计数与2轮早停/上限；静态确认循环读取N不是2，配置99/版本100仅存取边界；不执行3–99轮；系统基础预算独立不可写 | UIA-M003-304/305；DB3-V01/03/05 |

权限/隐私/TTL定向覆盖status跨账号/跨管理员/visitor claim后归属、expired/discarded/deleted、notice不抹掉；DB3-V06核对旧完整数据/删除/迁移恢复。前端fixture覆盖N0/1/2内部流程的增量/切稿与管理N99配置；final3及无效v3最终v2、pending、incomplete、模式冲突；用户页面显示只读草稿但不显示N或尝试次数。实现后按仓库现有隔离测试约定运行相关go test，不把本表写成PASS。

保留CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX及真实质量/费用/流式延迟未验证状态。本轮无新业务待决/DB字段变更；后端接收不等于技术总门禁完成，仍需前端架构交接。

## BE3-08 精确源码可行性与待审实现对齐

以下基于当前工作树只读检查，未执行或改动业务Go代码。现有约50个未提交后端修改保持。

| 代码/已存在测试入口（相对backend） | 已证实能力/限制 | BE04必要改动与验证 |
|---|---|---|
| `ai/protocol_stream.go` protocolDecoder.event；`ai/openrouter.go` Stream.Receive/Extract | 三协议归一化正文text，非文本通道不进Candidate；每次上游帧调用passageExtractor后立即onPassageDelta | 全生成/重写/续写均接入同一公共投影；Review接收器继续不接正文callback，不接私有推理通道 |
| `ai/openrouter.go` passageStringStart/findJSONStringEnd/trailingHighSurrogate | 仅识别对象首键passage；转义/UTF-16尾部最多12字节回退、前缀单调检查；最终严格decode及clean一致性 | 保留有界解析，新增有限XML样标签前缀门，不能先把标签/内部包裹发出去。相关`annotations_test.go`/`transport_boundaries_test.go`已有跨字节样例，应定向回归而非声称本轮已跑 |
| `ai/annotations.go` annotationParser.Push | 元数据标注不进text，普通括号组平衡后释放，原Unicode rune位置计数 | 与最终parse共用，首字合并器不得越过parser安全边界；自然括号/emoji/引号/换行继续按码点 |
| `generation/pipeline.go` PipelineHooks/SnapshotAccumulator | 首稿才用snapshot累计32字符/250ms；OpenRewrite Receive回调被置空；内部lastValid/candidate正确领域入口已存在 | 改为带attempt identity的text hook/coalescer，首词即发/50ms有界flush。rewrite回调接入真实delta；保留内部Review/预算，不按公开帧统计调用 |
| `ai/continuation.go` receiveCorrection/appendContinuation/applyContentCorrection | 续写真实delta会加双换行；字段修正回调静默，必须clean前后完全相等；不合法拷贝只在剩余基础预算内重试 | 增加本地attempt开始/模式回调或等价轻量hook，让续写首片新draft继承原前缀；字段修正保持静默，不复播全文、不放宽字段白名单；每次任务结束先flush旧缓冲 |
| `httpapi/generation_handlers.go`、`preset_preview_handlers.go` | 已有单writer、同步ack、事件channel与取消 | 改为v4 started含stream_id、edit联合；严格seq/revision/区间与cancel感知写入；过滤内部阶段，终态前恢复lastValid半稿；HTTP两个namespace同规则独立token |
| `generation/status.go`与DTO/charge/usage | 持久终态/完整payload/notice无需逐token记录 | status只换contract_version；不加stream_id/draft/token表，未确认DB仍pending；迟到usage不能复活run |
| `pipeline_test.go`、`generation_matrix_integration_test.go`、`stream_boundaries_integration_test.go`、`m002_presets_integration_test.go`、原races/trace | 当前断言基于BE02首稿snapshot/candidate/stage | 后续接收BE04后改为真实首词、多片重写、同V续写新ID、Q02恢复旧有效版、无有效稿/取消清稿、EOF/pending保留禁保存；内部最多2轮及全局基础2独立验证 |

公开投影仅保存当前可见text/identity、待flush片段和已有lastValid包，不保留逐token历史或中间稿库。source=retained来自已有lastValid，属于真实恢复事件而非伪造模型新token。每次尝试注册时封闭旧emitter epoch，旧回调不得给当前ID打标签；所有已排队公开edit由同一writer有序处理，再发切换/终态；取消或stream_failed则丢弃待flush并走原结算。

本轮限定检查为 [stream-v4 fixtures](fixtures/stream-v4/index.json) 与 [check_stream_v4.py](evidence/check_stream_v4.py)，证据 [stream-v4-check.json](evidence/stream-v4-check.json)。检查拼接/身份/业务版本/整包/异常、几种破坏变体及相关原件；不是Go实现、浏览器、真实提供方、质量或延迟PASS。旧v3 fixture及证据原样保留。

## BE3-09 编辑流的服务器成本与边界（PROPOSED）

USER-M003-EDIT-OPS询问的是前进/回退/替换与服务器负担，没有多人并发写同稿需求。完整CRDT要解决多副本并发合并、乱序传播；本服务只有一个权威作者和一条有序SSE，选base_rev/rev校验的splice即可，既不需要墓碑/向量时钟，也不写每token数据库。终态status提供完整结果snapshot；不提供active稿件恢复/编辑日志/重放。本自定义字符串操作不是RFC6902实现。接交时用户可评审操作结构与预算，当前不是已批准或已压测容量。

### 复杂度与当前源码的实际缺口

正常append只处理新片段O(Δ)，增量维护code point计数和revision；**不得每帧`[]rune(fullText)`/重算全文码点或`string += delta`**。投影可用有界`[]rune`增量append（只转换Δ，cap不超过200万）或分段buffer；writer只序列化edit.insert，不重序列化累计全文。首片换稿/retained恢复最多各做一次O(当前稿+目标前缀)的LCP，不逐token做diff，也不保留历轮稿副本。客户端同理，正常尾插只处理片段；DOM绘制可合帧，但每条edit先按序reduce且不跳rev。

当前`openrouter.go`的Extract每次传入累计document、重新寻找passage并json.Unmarshal累计字符串，仍有O(n²)扫描/分配风险；`pipeline.go`的accumulator也有累计string追加/快照。这是代码事实，不能只把wire改delta就宣称服务器已线性化。BE04实施应在原passageExtractor内增加已消费游标/字符串状态/至多12字节未完成escape-tail，仅解码新输入，把每个安全增量交给既有annotationParser；原完整raw builder保留到结束做一次strict decode/clean一致性校验。只做本文件局部增量解析与既有跨边界测试，不建设另一套协议平台；未完成前不得宣称大正文吞吐达标。

### 有界队列、频率与取消

- 单连接仅1个串行writer；正常coalescer最多50ms、128码点目标批量，单provider edit.insert最多2048码点，待flush缓冲≤16KiB。结束/切换前可即时排出有限尾部帧，不用播放定时器拉长已经完整到达的数据。
- 发送队列同时受8条事件/64KiB普通增量上界约束；达到任一上界暂停provider接收hook形成背压，不丢edit、不跳seq/rev。合并只在分配seq/rev之前进行，不能丢已编号操作。现有同步ack实现相当于队列0/1，继续使用也满足此上界，无需为此增加8格队列。
- retained恢复和最终Result沿现有候选16MiB/干净正文200万码点界，最多各一个在途不可变大对象引用，不能塞入多个全文拷贝绕开普通队列界；先排空增量再写大包。json序列化额外缓冲算入内存观测。
- write/flush 10秒deadline、每调用180秒/整体执行600秒保护保持。慢客户端阻塞包含在原时间保护内；超时写失败/断连立即cancel上游、释放待发缓冲并按原stream_failed结算；不是Q02内容故障。不能为流畅而另起无限发送goroutine或后台继续生成。

### 量级示例与单请求内存

100并发×10帧/秒×300字节/帧≈300KB/秒；若正常20帧/秒约600KB/秒。这里只是**假设平均序列化帧大小**的消息带宽，未含HTTP/TLS、提供方入站和终态整包，不是已测容量。最大2048码点可达8192 UTF-8字节，再加协议字段；100连接×20此类满帧约16.4MB/秒＋封套，不能用300B均值当最坏上界。结束尾部/恢复/最终包的突发另算，限流/背压以实际字节度量。

不能只按短fixture估算内存。现有raw Candidate上限16MiB、annotationParser干净文本上限200万rune（底层rune数组约8MB、UTF-8正文最多约8MB），再有lastValid原始candidate/validated包、正在形成的新candidate、JSON解码和validator索引。新增公共投影最多一个当前稿约8MB＋16KiB coalescer＋64KiB普通队列；避免把lastValid/当前稿/发送快照多份复制。包含原pipeline对象与短时JSON/校验分配的**病理上限输入量级可能达每请求约80–160MiB甚至更高（依实现分配峰值）**，此为工程估算而非硬RSS上限；100个同时顶上限请求不能承诺只耗几百MB。普通几百字请求通常远低于此，但必须测真实分配后给容量结论。不改变产品最大长度或并发权益，本轮不擅自新增全局请求拒绝策略。

### 后续限定性能验证

获实施授权后以提供方替身（零真实模型费）对短/长及接近现有安全界输入、1/10/100并发做单流/总量测量：首个safe片段→公开edit的p50/p95、每稿首片等待、正常flush间隔、帧数/字节、CPU/allocs与峰值RSS、背压队列高水位、慢客户端取消后goroutine/缓冲回收、terminal整包延迟。比较输入长度翻倍的解析CPU/分配增长，专查累计解析残留；不把合成播放器时钟当线上延迟。验收先验证上界/无无界增长、edit一致性和取消及时，再由实测决定是否需额外优化；本轮未执行这些压测，也未承诺100并发容量。

### 最小后续观测（用户成本关注，不阻塞本轮原型）

用户提出尽量减少服务长期占用并希望后续能统计。复用既有run时间、ai_call_usage、generationtrace及进程metrics，不新增表/成本平台，不逐帧落DB、不记录正文；在请求结束聚合一次无正文数值即可。普通splice应用、视觉平滑/滚动留前端，后端仍承担鉴权、同模型编排、安全清洗、取消与结算；等I/O时阻塞等待，不忙轮询。

| 需要区分的量 | 最小来源/口径 | 不能据此声称 |
|---|---|---|
| 模型等待、调用次数/token/提供方费用 | 既有usage与各调用开始/结束；可得时记录首上游text时间，未知费用保持unknown | 调用wall time不等于模型CPU，也不等于自有服务器CPU |
| 后端实际处理与活跃流时长 | 既有trace区间增加safe-decode/edit-encode累计wall time；请求受理到流关闭单独记 | 连接秒不是CPU秒，处理区间wall time也不是逐请求CPU账单 |
| 排队/写阻塞 | hook等待writer的累计/最长等待、writer耗时、队列字节高水位、写超时/取消原因 | 慢浏览器阻塞不应混成模型慢或Q02内容故障 |
| 下行消息/网络 | 内存累加事件数、序列化JSON字节、最终包字节、替换/恢复数；请求结束汇总 | 应用字节不含所有TLS/TCP开销，也不直接等于部署账单 |
| 并发与进程资源 | 活跃SSE gauge、进程CPU/RSS/heap/GC指标，沿现有采集入口 | Go共享runtime/GC让单请求CPU/内存精确归因困难，不能按连接秒平均成真实成本 |

若尚无对应metrics项，在后续实施计划中补有限计数/直方图，不在本轮实现。固定并发替身压测比较空闲基线与1/10/100并发时的进程CPU、峰值RSS/heap、GC与吞吐，报告基线差异/每完成请求均值及样本窗口；它们是负载下的均值估算，不是逐请求精确账单。实际人民币/美元费用依部署的CPU/内存/时长/带宽计费规则与实测量后算，现不承诺“很轻”。
