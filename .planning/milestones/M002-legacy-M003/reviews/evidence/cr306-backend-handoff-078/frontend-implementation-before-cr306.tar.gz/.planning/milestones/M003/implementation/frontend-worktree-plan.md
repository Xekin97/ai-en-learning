---
milestone: M003
stage: implementation
role: frontend-implementer/base
agent_name: frontend-claire
status: implemented_developer_verified
date: 2026-10-10
source_version: M003-TECH-03 / M003-FE-02 / M003-UI-09-R3 / M003-BACKEND-TECH03-IMPL
---

# M003 前端实施工作区计划

## 已确认基础

- 实施范围来自 `TRANSITION-M003-057` 与 `USER-M003-FRONTEND-IMPLEMENT-NEXT`；业务语义采用 PRODUCT07、API-301–304、FE02、UI09-R3，视觉以用户确认的 UI09-R2/M002 为基线。
- 普通权益只执行共同规划、writer 与最多 2 次原生恢复；增强执行固定编辑、审稿和独立 N=0–99 内容返修；流程仅执行到 N2，N99 只做配置/静态边界。
- v5 SSE 使用严格 seq/rev/Unicode 码点 splice、能力 token 仅内存、有限 status 核对；明确 busy 只认 503 `generation_busy` + `accepted:false`，Retry-After 只解禁，不自动 POST。
- 当前无会改变任务边界的未确认解释。真实模型质量、生产容量、部署和用户 UAT 不在本轮。

## 当前任务与验收

| 任务               | 依赖                      | 完成条件                                                                | 状态                   |
| ------------------ | ------------------------- | ----------------------------------------------------------------------- | ---------------------- |
| FE3-T01 契约与传输 | API-301–304 / 后端 TECH03 | 严格 DTO、mapper、v5 用户/preview/status、busy/token 边界，页面不接 DTO | 已验证                 |
| FE3-T02 流与终态   | T01                       | seq/rev/splice/Plan/终态/pending/cancel/request epoch 有单测            | 已验证                 |
| FE3-T03 计划管理   | T01                       | M002 全字段 + native2 只读 + 独立 N0–99 + impact/冲突失效               | 已验证                 |
| FE3-T04 预设闭环   | T01/T02                   | mode 保存、preview 绑定、Q02 确认、精确 publish body                    | 已验证                 |
| FE3-T05 页面与资源 | T02–T04 / UI09-R3         | 三页准确 copy/布局/状态；760px 居中、窄屏铺满                           | 已验证（限定开发范围） |
| FE3-T06 联调与交接 | T01–T05                   | 质量命令、定向浏览器、实际后端替身联调、恢复包与交接                    | 已验证                 |

## 是否需要并行

- T01–T05 共享 generation/admin schemas、ports、stores、copy 和三个页面，依赖方向连续；并行会造成相同文件和契约归约冲突。
- 结论：单工作区串行实施；不创建 worktree 或子任务。先核对代表生成区，再扩展计划与预设。

## 合并顺序与检查

1. generation DTO/schema/mapper/repository → reducer/store → GenerationWorkspace 与单测。
2. admin groups DTO/mapper/repository/store/page → presets DTO/repository/store/page。
3. 设计 copy/theme 转换、页面整合、定向浏览器和后端替身联调。
4. 每个边界先跑相关 Vitest/typecheck；收敛时跑 lint、lint:boundaries、format:check、build 和定向 Playwright。

所有修改限 `frontend/**` 与本角色三份实施文档、`implementation/evidence/frontend-tech03/**`。共享 dirty 工作树中的后端与控制面修改不触碰、不回滚。本轮无分支合并或 worktree 清理。

## 实际收敛

- 采用单工作区串行实现，未创建分支、worktree、子任务或提交；共享后端修改与控制面保持原样。
- 代表生成区先完成 schema/mapper/repository/reducer/store，再接 plans、presets、公开 preset detail 与 UI09-R3 样式。真实 Go/隔离空库/本地 provider 暴露出的 UsageSummary、公开 preset detail 与全局 plan revision 三处集成缺口均在前端责任内闭合。
- 当前源码和验证入口见 [frontend-validation.md](frontend-validation.md)、[frontend-implementation.md](../handoffs/frontend-implementation.md) 和 [evidence/frontend-tech03](evidence/frontend-tech03)。本状态只表示开发期范围完成；不切换阶段、不替代独立 QA 或用户 UAT。
