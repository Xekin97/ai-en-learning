---
milestone: M003
stage: product-planning
role: product/to-c
agent_name: product-maya
status: awaiting_user_review
version: M003-PRODUCT-11
current_scope: pronunciation
date: 2026-10-15
---

# M003 单词发音当前产品交接

根据 [TRANSITION-M003-106](../reviews/milestone-scope-correction-106.md)，单词发音归入仍进行中的 M003，整体里程碑尚未批准收尾。此前 CR311/312 的功能 QA 与用户 UAT 接受保持，不重做已接受功能；M004 是误建登记，仅保留历史原件。

## 输入与确认闭环

当前 [state](../../../workflow/state.yaml) 为 M003 / product-planning / product-maya；workstream context 为 single。继续使用锁定 [consumer-ai-web@1.0.0](../reviews/evidence/start/locked-profile.yaml) 与 [model-routing-v1](../../../agt/model-routing-v1.lock.json)，requested gpt-6-astra/high，actual_model/usage unknown。

[原发音授权](../../M004/reviews/evidence/start/authorization.json)与[范围/权益答复](../../M004/reviews/evidence/start/scope-confirmations.json)继续有效，其 M004 ID 仅为历史标记。用户已确认词典音频优先、浏览器兜底，工具台选词/词义卡及已保存文章词详情，所有用户免费且不扣造文额度；不重复询问。本轮只有归属纠正，无新业务、交互或验收语义决定。此前“下一步”保持原意记录，批准及阶段切换由 root/gatekeeper 处理，本交接不自批。

## 当前主入口与增量原件

| Profile 主入口 | PRODUCT11 增量原件 |
| --- | --- |
| [overview.md](../product/overview.md) | [目标、范围与技术待办](../product/pronunciation/overview.md) |
| [data-assets.md](../product/data-assets.md) | [DATA-401～404](../product/pronunciation/data-assets.md) |
| [abilities.md](../product/abilities.md) | [CAP-401～404、AC-401～410](../product/pronunciation/abilities.md#acceptance) |
| [pages/index.md](../product/pages/index.md) | [PAGE-401～403](../product/pronunciation/pages/index.md) |
| [ai-behavior.md](../product/ai-behavior.md) | [AI、额度与发音边界](../product/pronunciation/ai-behavior.md) |

五份主入口仅更新 frontmatter 并前置当前指针，PRODUCT10 正文与稳定 ID 原样保留；旧阶段措辞由入口说明限定为历史提交状态，不视为当前未完成任务。原产品交接及纠正前原件可由[完整快照](../reviews/evidence/milestone-correction-106/before-correction.tar.gz)恢复。M004 全部原件不修改、不删除。

## 验收、未决项与接续

沿用 10 项 AC，当前发音实现仍未验收；无关键产品范围问题待重问。三个技术 OPEN 的唯一任务定义在[增量总览](../product/pronunciation/overview.md)：OPEN-401 资源使用条件、OPEN-402 目标网络与真实音频、OPEN-403 浏览器声音/手势/有限等待。没有因归位新建问题，也没有以静态检查宣称可播放。

后续专业角色建议 designer-tony，接收三处入口及现有 CAP/AC，分别完成交互原型与沿用 M002/M003 基准的正式设计；具体激活及批准由控制面处理。原发音设计尚未开始，本轮不新增设计、技术调研、源码或运行验证。沿用 [QA 范围政策](../../../agt/qa-scope-policy.md)，不做文章质量评分；真实 UAT3015、数据和模型配置保持，历史 retained_open_items 不因本整理关闭。

## 归位与自检

仅写五份 PRODUCT11 增量、五份主入口与本交接；未修改控制面、历史来源、源码或运行时。静态检查核对新增/修订链接、M003 归属、PRODUCT10 正文逐字保留及 M004 原件哈希不变；这不是浏览器或音频验收，也不是用户批准。

```json
{
  "status": "PASS",
  "version": "M003-PRODUCT-11",
  "files_written": 11,
  "new_or_revised_local_links_checked": 72,
  "broken_links": 0,
  "product10_bodies_preserved": 5,
  "m004_files_unchanged": true,
  "data_ids": 4,
  "capability_ids": 4,
  "page_ids": 3,
  "acceptance_ids": 10,
  "technical_open_items": 3,
  "semantic_changes": false,
  "milestone_closeout_approved": false,
  "runtime_verification": false
}
```
