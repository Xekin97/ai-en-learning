---
milestone: M003
stage: technical-design
role: frontend-architect/base
agent_name: frontend-bob
version: M003-FE-01
status: awaiting_user_review
date: 2026-10-09
input_version: M003-PRODUCT-03 / M003-UI-03 / M003-DB-02 / M003-BE-02
---

# M003 前端可实施架构

## FE3-01 输入、决定与技术边界

本稿供 frontend-claire 接续实施；只有技术方案，未改业务代码或运行产品验收。活动身份已按 TRANSITION-M003-011 恢复为 technical-design / frontend-bob。Profile 采用 [consumer-ai-web@1.0.0 冻结原文](../reviews/evidence/start/locked-profile.yaml)，不采用框架工作树2.0。按项目路由锁请求 frontier / gpt-6-astra / high；actual_model、token/usage 无独立运行证据，记 unknown。

权威输入：[产品03](../product/overview.md)、[CAP-301–305 / AC-301–314](../product/abilities.md)、[页面](../product/pages/index.md)、[数据](../product/data-assets.md)、[AI行为](../product/ai-behavior.md)、[UI03设计规格](../design/design-spec.md)、[DB02](database.md)、[BE02](backend.md)、[API-301–304](api/index.md)、[AI3](ai-integration.md)。UI03 只补 pending 动作；UI02 未变的配置、草稿替换和故障交付继续有效。[CR-301](../changes/CR-301.md) 已由设计责任角色解决并正式接回，不是仍开放阻塞。

- **CONFIRMED**：[Q01-B / Q02-A / Q03-RANGE99](../reviews/requirements-feedback.md)；各付费计划独立整数0–99、初始1；0关闭内容服务；已有完整基础有效稿的内容技术故障保留最近有效整稿、持续提示、可保存、仍计一次。流程执行测试最多2次内容返修；99仅配置/字段边界。
- **已接收专业方案**：BE02 的全请求基础纠错2次、180秒单次/600秒执行保护、后台 basic0/enhanced1、流与status精确字段。它们是研发委派内的技术定稿，不冒称用户逐字段选定。前端不设计模型调用或自行延长超时。
- **本角色技术选择**：保留现有 Nuxt 4 / Vue 3 / TypeScript、Zod、eventsource-parser、Nuxt useState 与现有 i18n、Vitest/Playwright 工具链；具体依赖沿 `frontend/package.json` 和锁文件。Node 24 / pnpm10.33.0 是现有工程约束，不升级依赖。继续请求级 SSR 读取加客户端交互/流：SSR提供初始选项和列表，POST流仅由用户操作启动。纯CSR会改变现有首屏/身份装配；SSG不适合私有状态，均无本期收益。不新增状态库、服务端渲染框架或后台任务平台。
- **全局有效约束**：[USER-COMPAT-001](../../M001/reviews/first-release-compatibility-policy.md) 要求配套前后端切换，不加旧 passage.delta 兼容层；[USER-CLAIM-DELETE-001](../../M001/reviews/claimed-batch-delete-retention-exception.md) 保持删除后404，不尝试恢复已删除批次。当前应用基础 commit `45a4ab123c3308fa0a83868b6030c6b84a96f67d`；上游 M003 未提交修改以控制角色冻结快照为恢复来源，不能只靠 commit 声称含本期设计。

没有新业务选择；本次不创建支付、审稿模型选择、历史重写、质量报表、全页刷新续流或 token 本地持久化。真实收费批次、UAT3302、线上配置、部署及代用户UAT均不在授权内。

## FE3-02 数据层、类型与状态归属

保持依赖方向：`HTTP/SSE DTO → Zod完整校验 → mapper → application model/event → runtime store/reducer → presenter/component`。SSR也走同一仓储/mapper，注入的 Nuxt 状态只有可序列化应用模型；不是原响应透传。页面、展示组件不得导入schema/DTO、直接fetch或读取snake_case传输字段。

下表均相对 `frontend/`；“新增”是实施拟文件，本轮不创建代码。

| 层/入口 | 本期职责 |
|---|---|
| `app/infrastructure/http/schemas/generation.ts`、`admin.ts`、`presets.ts`、`admin-presets.ts` | 按API真源扩展严格DTO；共用ContentService、NativePolicy、完整Result与终态关联校验；新增status封套和命名事件schema；移除delta消费类型 |
| `app/infrastructure/http/repositories/api-repository.ts`、`presets-repository.ts`、`admin-configuration-repository.ts`、`admin-presets-repository.ts` | 生成/取消/status/计划impact与保存/预览请求编码；token仅进vault与header；解析后才向应用发事件；不自动重放副作用POST/PUT |
| `app/infrastructure/http/mappers/index.ts`、`span-mapper.ts`、`presets-mapper.ts`、`admin-presets-mapper.ts` | camelCase转换，完整稿一次生成segments/targets/tags；保留outcome、notice、版本、canSave及unknown用量；按Unicode code point解释半开offset，不用JS UTF-16下标截错emoji |
| `app/application/shared/models.ts`、`ports.ts`；新增 `app/application/generation/content-service.ts` | 定义应用权益/快照/有效包/终态联合；port新增状态查询；只有应用模型进store，无Vue/Zod依赖 |
| `app/application/generation/reducer.ts` | 纯函数校验运行内顺序、尝试/接受/最终版本和业务终态；用户生成与预览共用规则函数，但两者事件/能力凭证/额度结果分别建模 |
| `app/application/admin/configuration.ts`、`plan-policy.ts`、`presets.ts` | 完整计划draft/impact、表单合法性、模式与版本关联、publishReady选择条件；不把NativePolicy写进可编辑draft |
| `app/runtime/stores/generation.ts`、`presets.ts`、`admin.ts`、`admin-presets.ts` | 应用动作、SSR加载、session epoch、请求归属、有限核对与竞争处理；调用仓储port，不能直接消费DTO/传输parser |
| `app/presentation/admin/admin-plan-presenter.ts`；新增 `app/presentation/generation/content-service-presenter.ts` | 仅应用模型→准确文案key/变量/动作资格/区域状态，不按计划名猜增强、不把review_passed直接渲染为质量通过 |

保留 `plugins/application-ports.server.ts` 的每SSR请求独立transport/vault，以及客户端Nuxt app实例隔离；`runtime/stores/generation.ts` 当前WeakMap控制器和session epoch机制继续使用。`runtime/session/token-vault.ts` 保存短期generation/preview能力，不进入useState、SSR payload、local/sessionStorage、URL、日志或analytics。注销/换主体清空私有状态与能力，取消计时器及旧请求回调；不可跨账号展示旧正文。新请求用本地request identity/epoch隔离，同一run内seq单独计数。

状态分工：服务端事实为options、accepted snapshot、完整最终资源/版本/notice、计划revision及preview关联；客户端为当前stage、lastSeq、正在尝试的版本、待显示snapshot、取消/核对busy；表单为原始数字输入/本地草稿/远端基线/已预览输入；URL仅原有页面和资源ID，不加入token、候选正文、原型stage或模拟plan参数。

### 严格schema与映射要求

以 [API-301/302](api/generation.md)、[API-303](api/administration.md)、[API-304](api/presets.md) 为字段唯一真源，不在本稿重复维护第二份wire schema：

1. `ContentService`只接受false/0或true/整数1–99且native_validation=true；visitor/basic只能false/0。NativePolicy是后端实际读取的只读常量对象 `m003-native-policy-v1 / logical_request / 2 / false`。所有未标nullable字段必填；数组不接收null；严格未知字段/类型/枚举校验。请求序列化从明确字段白名单构造，不展开整份UI状态。
2. 普通与用户预设的options包含有效计划、来源、配置revision、内容服务；started以受理snapshot覆盖页面预估。后台started只有preview的mode/服务/基础策略/版本，不虚构用户plan或charge。后台线协议只用 `basic|enhanced`；原型 `mode=base`、文案键 `preset.mode.base` 仅展示命名，明确映射到 `basic`，不能把base发API。
3. Result整包复用现有目标/标签/释义/位置约束，验证每个目标及位置后一次map；不从上一版補默认targets或兼容null。status允许有效终态result=null且can_save=false，不能强制所有valid都有可用payload，也不能从valid反推可保存。
4. 有效outcome严格为basic/review_passed/repaired_passed/limit_finalized/service_incomplete；只在service_incomplete时notice=`content_review_incomplete`，其他notice=null。failed/cancelled/active也按API关联null值、refund和can_save。历史管理预览明确允许version/outcome=null，不将其补成审稿通过。
5. UsageSummary保持providerCalls、unknownCalls、invocationUnknownCalls、notInvokedCalls及nullable token/cost分别映射；未知不写0、不把几种unknown相加成调用总数。无需新增本期统计页面。

## FE3-03 流读取、版本与reducer

POST fetch + eventsource-parser沿现有传输读取，UTF-8增量解码，支持一个chunk多帧/一帧跨chunk；heartbeat仅保活，不更新正文或阶段。token在完整started校验成功后留vault；其余应用事件无token。parser的终止、flush、abort有明确清理，不能在finally无条件把流故障写为业务failed。

建议应用状态保留独立成员 `acceptedSnapshot / lastSeq / stage / attemptContentVersion / repairAttempt / acceptedCandidate{contentVersion,result} / final{contentVersion,result?,outcome,notice,canSave} / reconciliation`；生命周期区分 `idle / starting / streaming / pending / valid / failed / cancelled / saved`。UI的generating/draft/review/repair/complete/incomplete是上述事实的投影，不作为另一套可自行成功的状态机。可读首稿text与完整candidate不同，前者没有学习资源或保存资格。

| 输入 | reducer约束与应用结果 |
|---|---|
| started | 仅一次、seq=1、run身份/快照固定；可取消。旧options与受理revision不同时刷新options供下次使用，但不覆盖本次snapshot |
| stage | seq严格+1；generating为attempt1/k0；native_repair/content_review用当前尝试版本、k=version−1；content_repair第k次为attempt=k+1。只推进尝试字段，不推进acceptedCandidate。N=0禁止内容阶段；k≤N、version≤N+1 |
| passage.snapshot | seq严格+1，仅version1，替换累计首稿正文而非append；后端已去标注并安全提取。不得解析JSON片段或在前端猜缺词；候选整包已显示后不能用迟来snapshot覆盖它 |
| candidate | seq严格+1、完整校验、版本递增且≤N+1；一次替换正文/tags/targets/segments及acceptedVersion，保留草稿标签，不可保存。基础纠错不新增版本；内容重写token从不直显 |
| validated | seq严格+1；run匹配、final版本/整包等于最近candidate；只有DB确认的有效终态才进入valid；completionNotice进入持久状态而非toast。取消按钮关闭，保存可达；正常limit_finalized与审校故障incomplete分开 |
| failed/cancelled | 只接受一种业务终态；清正文/candidate并禁保存；failed退款true，cancelled退款false。不能因为曾有candidate擅自改成valid |
| settlement_pending / 无终态EOF / 传输或协议异常 | pending，停止不可信流消费，保留安全内存但不授予保存；界面按UI03 pending区域显示；若仍持有效run能力立即有限status核对 |

所有命名业务事件顺序连续；倒退/重复/跳号、无started后续事件、越界版本、普通档内容stage、outcome/notice不符触发停止消费及核对，不能静默忽略后继续拼稿。不要让UI帧合并跳过seq检查：每个事件先校验/reduce，再在animation frame只绘制最新累计正文；candidate/终态到达先清待绘制snapshot。

**必须通过的合法版本例**：N=2，candidate1→review1→content_repair(attempt2,k1)→candidate2→review2→content_repair(attempt3,k2)→validated(final2,service_incomplete)。第三稿未完整有效，无candidate3，交付第二稿不是倒退。另一例candidate3已接受、其审稿失败则final3；禁止退回2。实际fixture补足全部seq与完整Result，不能将API文档省略seq2–7的说明例直接当流。

首稿展示依真实累计安全snapshot；后端32个Unicode字符/完整句边界及250ms合并是生产者规则，前端不额外等段落、不凭时钟显示虚假阶段。增强仅保留固定语义阶段槽位，当前返修模板使用动态k/N；不预建99步骤，也不硬编码2为运行上限。native_repair不冒称内容返修，沿正在生成/当前草稿显示，只有实际content_repair显示第k次内容返修。

## FE3-04 终态核对、取消、保存与信任

有限核对以API明确status为权威读取：用户 `GET /generations/{run_id}/status` + X-Generation-Token；后台 `GET /admin/preset-previews/{preview_id}/status` + X-Preview-Token。仅使用当前owner和内存能力，不重开SSE、不调用模型，不发送Last-Event-ID。

- 自动核对立即一次；串行请求、间隔不小于2秒，总窗口最多10秒，到期中止未完成查询并显示UI03动作。手动“重新核对”执行一次现有status读取，忙碌禁用；active/503继续pending，不自动开启无限轮询。取消/离开/换主体使该窗口作废。
- 使用 `request identity + session epoch + run ID + reconciliation generation` 接收回调。status不是SSE事件，不要求它有seq或前端见过candidate：断流漏candidate时，经过严格校验的DB完整终态可直接建立final。旧active/503不能覆盖已确认终态；终态后关闭旧流与核对计时器，迟到snapshot/stage/错误不改变结果。
- 相同run的DB有效最终内容不随HTTP先后切换。取消返回valid只是终态种类确认，继续status读最终包/notice，不能拿本地candidate当final；取消返回failed/cancelled沿DB结果。若两个已确认结果实质矛盾，禁止开放新的保存动作并核对权威status/报告契约错误，不能“后到获胜”。已完成保存/claim的本地动作资格也不能被较早status响应重开。
- `valid + result + can_save=true`才能保存/访客claim；valid但result=null或can_save=false可保留outcome/notice，关闭收录。已保存本人的batch、丢弃/TTL失效、访客claim归属变化均服从API，不重建结果。有效草稿默认30分钟、终态能力1小时；404/410停止核对并关保存，按现有安全错误反馈处理，重新生成必须是新的用户意图。
- 取消受理前记录意图，started拿到能力后发cancel；不把直接abort当作取消成功。取消中禁重复操作；503/未知结算继续pending。完成先赢则展示其真实最终包和notice，取消先赢则清稿且仍计一次。用户离开沿现有未完成/未收录确认与被动abort；abort、刷新、断连不触发前端Q02成功。
- POST受理响应未知且没有started/token时，不自动重POST、不推定未扣次；无法调用有token要求的status，保留安全未知说明，重读options获取可用性但它不是终态证明。下一次显式意图仍受服务端active槽位/配额约束。
- 前端不从局部超时、429、EOF、无效重写推导service_incomplete；只有DB已提交的validated/status有该结论。六类内容故障与下行断连/取消/DB未知的分类归BE02。技术失败可能仍有提供方费用，不将quota_refunded当作退模型账单。

incomplete使用 `stage.incomplete.title/body`，完整文章和动作前持续可见。它通过SSE→status恢复、保存动作后的当前结果状态保持；管理员preview GET、published管理读取、发布确认/成功返回也保持。已有合法读取路径刷新时不丢notice；这不新增用户书架wire字段或token恢复平台。公开预设不泄露后台mode/审稿私有信息。完成文案前四类统一“生成完成”，limit可用 `stage.limit.body` 说明，绝不称独立评测通过。

保存/放弃/访客认证承接沿原API-006能力、归属、幂等与TTL，不新造一个run、不重算模型、不再次扣额度；无片段保存。请求中重复提交/保存/核对均由busy与服务端唯一性共同约束，客户端按钮不是权限或结算真源。

## FE3-05 PAGE-208 配置表单与冲突

`pages/admin/plans.vue`保留原四计划、模型/长度/词数/额度/优先级。两个并列区域忠实映射设计：基础系统策略只读卡与内容配置卡，不把内容N塞进原基础恢复参数。

| 配置 | 界面来源与合法状态 | 写入 |
|---|---|---|
| 基础纠错 | groups/impact返回NativePolicy；显示全部计划、全请求最多2次、系统策略不可编辑；校验策略对象后使用批准 `plans.base.fixed`，不从fixture或N猜值 | 不提供开关/数字输入；不发送native_policy/max_calls/native_validation等额外字段 |
| visitor/basic内容 | GET真实false/0；禁用开关/输入但保留标签与解释 | 完整请求仍明确false/0，不能根据优先级解锁 |
| pro/plus内容 | 各自raw string输入；整数0–99；0关、1–99开；重新打开当前0/非法值时置1；关闭置0 | 一次完整body包含开关及整数N；不串改另一个付费计划 |

原始输入与合法数字分开，空值、负数、小数、100、非整数文本均保留输入、aria-invalid和错误说明，禁预览/确认；不要Number('')→0、parseInt截断、小数取整或max属性静默修正。`type=number,min=0,max=99,step=1`只是控件提示，应用校验和服务端校验仍独立执行。非管理员路由/按钮与服务端403双层控制。

表单本地维护 `baseline / local / remote / editRevision / preview{normalizedInput, revision, impact}`。现有页面pending input快照不足以防止之后编辑，须在**任意字段**改变时清预览，包括原模型/长度/额度/词数/优先级及内容两字段；异步impact返回也检查editRevision和selected plan，不让旧请求重新解锁确认。确认发送的完整规范化body必须等于被预览body，expected_revision也相同；不引入服务端预览凭据。

impact严格按响应展示：真实before/after开关与N、NativePolicy不变、baseUsers/activeTrialUsers、priorityChanged/mayChangeEffectivePlan、去重有序warnings、仅新请求生效/在途快照、usage_reset=false/trial_dates_changed=false。人数不是此次失去增强的人数、不相加冒称去重人数。关闭警告仅对应真实true→false；无模型/长度/零quota仍沿原可警告保存规则，不因开内容服务忽略预检。

409 revision_conflict：保留整份local→GET四计划最新值→remote/local并排→用户保留本地修改再核对，按现有按字段mergeEdited约定仅合并明确本地编辑，校验全部字段→使用最新revision重新impact→重新确认。不能自动塞新revision重发旧PUT；duplicate_priority使用原专用错误，不混为revision冲突。取消恢复当前基线，不发PUT；失败保留本地输入。PUT200后重读并显示新配置；响应丢失先GET，值相同只说明当前配置已保存，不捏造原请求成功回执，不盲写第二次。

优先级批量沿四行code/priority原body，不携带内容字段；preview投影增加contentServiceByPlan、mayChangeContentService、NativePolicy及生效边界。false不推导有效计划没变；任何批量字段编辑也清确认。更新后刷新后续options/公开预设详情与当前有效权益摘要；当前进行中的run快照不可改。

## FE3-06 PAGE-212 预设模式、预览与发布

`pages/admin/presets.vue`、`application/admin/presets.ts`、`runtime/stores/admin-presets.ts`及仓储/mapper沿现有版本模型增量。用户 `trial/[presetId].vue`仍使用GenerationWorkspace和本人options/started；公开预设只提供固定生成配置例外，不授予内容服务，浏览目录/详情不启动模型。

1. 后台options读取previewContentModes/defaultPreviewContentMode/previewContentRepairLimit/NativePolicy；只有basic/enhanced，增强独立固定1，即使付费计划99也不变，无计划模拟器或次数选择器。
2. 本地mode或生成参数变动立即stale、取消publishReady；先保存包含mode的完整draft，拿新的draftVersion/revision，之后显式预览发送 `{draft_version,preview_content_mode}`。切回旧mode也需新预览；只有紧邻草稿纯标题修改的预览继承由服务器确认，前端不自己复用旧关联。
3. 独立preview事件使用专用schema/port、token与UI状态；不混用generation_token/quota_refunded。规则与FE3-03共用，但N只0/1、版本只1/2、k只0/1。用量显示从UsageSummary，不按stage次数累计。
4. preview.validated/status valid仅证明run有效；立即GET当前AdminPreset。当前draftVersion、mode、关联previewRunId及完整payload匹配，且无未保存mode/配置变化，才ready。旧mode迟到成功、并发另一个run获关联、已切换选择的旧GET都不得解锁当前draft。所有回调带session epoch、preset ID及编辑版本。
5. ready中的service_incomplete仍持续 `preset.incomplete`，可在人工发布确认中原样再次展示；limit_finalized正常可发布，不以审稿pass作为门槛。取消/failed/pending/无payload/stale一律不能发布。管理GET的published结果有notice则重新打开仍显示；纯标题继承也保留notice。
6. publish精确body只有 `{expected_revision,draft_version}`，移除当前仓储多带的 `confirmed:true`，不新增“审稿通过”或mode/次数字段。人工确认是UI行为，服务端仍独立校验。成功用返回对象再读确认；响应丢失先GET，冲突保留本地并重新核对，不能换revision盲重试。旧公开版本保持至发布真正成功。
7. preview pending遵FE3-04/UI03，`#preset-recheck`只读该preview状态；`#preset-publish`禁用。status恢复结果不存在时不能重新造预览或发布。失败/取消也可能有真实用量，与用户额度分离。

## FE3-07 设计转译、组件与页面定位

设计真源为 [UI03原型HTML](../design/prototype/index.html)、[app.js实际结构](../design/prototype/app.js)、[copy.json](../design/copy.json)、[theme.css](../design/theme.css)、[interactions](../design/interactions.md)、[responsive-accessibility](../design/responsive-accessibility.md)。只沿本轮区域改现有Vue，不复写整站，不把原型示例当业务种子。原型评审链接、fixture账户、演示下一阶段和query模拟参数不进生产。

| PAGE / CAP / DATA | 路由与现有入口（相对frontend/app） | 组件/呈现边界与原型定位 | API / UIA |
|---|---|---|---|
| PAGE-204/216；CAP-301/302/304；DATA-301–303 | `/create`、`/trial/:presetId`；`pages/create.vue`、`pages/trial/[presetId].vue`、`presentation/components/GenerationWorkspace.vue` | 新增ContentServiceSummary、GenerationProgress、GenerationResultNotice三个小展示组件；复用正文/学习资源。`#benefit-summary`→权益；`#generation-status`→完整稿、状态/警示、动作；`#generation-recheck`→有限核对 | API-301/302/304；UIA-M003-301/302/303/308 |
| PAGE-208；CAP-303；DATA-301 | `/admin/plans`、`pages/admin/plans.vue` | 原表单内增加 `#basic-correction-policy`、`#content-service`、`#content-repair-limit`；`#change-preview/#version-conflict`复用原确认/冲突布局并补齐双预算内容；业务校验移到应用模型/动作 | API-303；UIA-M003-304/305/306 |
| PAGE-212；CAP-304/305；DATA-304 | `/admin/presets`、`pages/admin/presets.vue` | 模式fieldset `#preview-mode`、`#preview-result`、`#preset-recheck/#preset-publish`；共用进度/notice展示，数据来自独立preview模型 | API-304；UIA-M003-307/308 |
| PAGE-215；CAP-301；DATA-301及既有道具 | `/account/items`等既有ItemsWorkspace/ItemEffect使用处 | 保留计划卡目标计划/时长与原说明，不根据Pro/Plus名字承诺增强；当前本人服务摘要有展示时取API-301实时结果，不能拿它冒充未激活卡的目标计划权益。现有ItemEffect仅目标计划/时长，不新增API未提供的目标计划N摘要 | API-301及原道具契约；UIA-M003-301语义、AC-306/307 |
| PAGE-217；CAP-304；原DATA-212 | `/explore`、预设详情/跳转入口 | 保留已发布样文/词义/配置，复用准确提示，不新增审稿徽章或后台notice公开投影；“我也试试”只是跳转 | API-304；AC-309 |

组件只接应用render model和emit意图；父workspace调用store，无DTO泄入props。固定阶段轨道不用通用流程引擎，重复使用仅限普通/预设共同生成区域。正文候选整包替换之后清空旧高亮/tooltip引用，避免旧offset套到新正文。

### 文案、样式和资源接入

- 扩展 `frontend/scripts/sync-design.mjs`：保留现有M002生成流程，在已有locale JSON增加独立 `m003`命名空间；M003键为语言**后缀** `.zh/.en`，不同于M002语言前缀。去后缀后按现有 `.`→`__`映射及i18n必要转义，保留原标点/省略号/换行。提供 `useDesignCopy`的显式M003入口/同等小函数，旧M002调用不变。
- 动态模板只注入应用模型变量：`limit`取当前options或已受理snapshot；`count`取repairAttempt；`plan`取计划code对应现有中文/英文标签；`basic/trial`取impact人数；后台`preset.usage.count`取logicalRuns。缺必要值即加载/契约错误，不显示默认1或原型样例。变量按文本插值，不拼HTML，不将用户/AI结果v-html。
- NativePolicy严格确认maxCalls=2后使用批准 `plans.base.fixed`，其只读常量值必须来自后端并被schema核对；若策略版本变化则交责任角色同步文案，不能绕开schema继续显示写死2。内容N绝不使用该固定文案。
- `frontend/design/source-manifest.json`记录M003-UI-03 copy/theme/prototype来源及SHA256，同时保留M002基线来源。生成资源运行时位于frontend内，不fetch `.planning/`。主题增量去掉源文件的相对M002 @import，按已有M002→M003→application顺序本地引入或等价合并；复用色值/间距/字体/动效，不把整个原型class重新套到所有页面。
- 展示组件采用暖白纸张、深绿、浅绿系统策略、浅杏incomplete/冲突；notice放在正文动作之前。原型 `--fast/--motion` 转换为现有主题token的轻淡入；中断/卸载终止动画，减少动效即时切换。原型无新增图片资产，沿用现有本地字体、图标及许可证，不引入CDN/新图像生成。

### 响应式、性能与无障碍

按UI03：≥1101px造文310px配置+正文，后台180px导航；761–1100px造文单列、后台150px且计划单列；≤760px全部单列，导航/标签/阶段轨道局部横滚，页面本身不横溢。内容输入手机至少92px；按钮≥44×44px、间距≥8px；系统策略/错误/冲突双方/notice不可隐藏。768×1024与320×700必须补正式实现覆盖，不能把390截图外推。

真实checkbox/radio/number/button，label及aria-describedby关联；无百分比不用progressbar。阶段polite只朗读状态，不逐snapshot读全文；正文lang=en，界面zh/en切换不改生成正文/释义。差异/冲突出现聚焦标题、成功status不抢焦点；核对按钮原位busy/disabled，终态转到新状态标题。现有离开/发布确认对话框维持focus trap和关闭后返回触发点。测试键盘、200%缩放和reduced-motion，不只跑axe。

性能只做相关约束：逐事件轻量校验，帧内合并累计首稿绘制；仅完整candidate构建segments，一次替换避免重算旧稿；内存只保留当前首稿/最近有效包，不建立历轮稿库；阶段DOM为常数规模、不随N增至99。SSR响应private/no-store，现有哈希静态资源immutable；不缓存跨身份权益/草稿。继承现有Nitro/Go代理与SSE流转发，客户端不设短于后端600秒的业务失败计时，不用心跳伪装有用内容延迟。

## FE3-08 Mock、开发验证与验收追踪

复用现有 `tests/fixtures/m002.ts`、`tests/unit/generation-stream.test.ts`、`tests/e2e/generation-stream-backend.mjs`、`m002-admin-presets-fixture.mjs`、`mock-backend.mjs`；M003新增局部fixture模块和定向spec，不再造一套Mock平台。fixture先通过API schema、完整顺序与Result校验；后端说明例/原型简短故事不能直接充作符合生产长度的完整结果。正反例期望来自API和UI原件，不能由当前实现反向生成。

| FE验证ID | 具体fixture/动作与期望 | 追踪 |
|---|---|---|
| FE3-V01 | visitor/basic N0、有模型卡+extra仍0；Pro额外次数仍本人N；在途试用到期/计划关闭，started保持原快照、下一options变更；前端不出现内容stage，非法事件拒绝 | API-301/302；UIA-M003-301；AC-301/306/307；BE3-V01/06/07 |
| FE3-V02 | N1首审pass；N1修一次后pass或issues上限；N2两次后pass/limit；固定阶段槽位和第2次/N模板，最后有效完整稿可保存，无“审稿通过”承诺 | API-302；UIA-M003-302；AC-302/314；BE3-V02/14 |
| FE3-V03 | 首稿native1→candidate1→review→repair2→native2→candidate2→review issues→limit；同一完整包/6调用事实由后端替身核验，UI仅1次生成。第二次基础仍无效则final1 incomplete；N2尝试3失败final2，candidate3后review失败final3 | API-302；UIA-M003-303；AC-303/311/313/314；DB3-V03 |
| FE3-V04 | SSE跨UTF-8/chunk、多帧、heartbeat、累计snapshot不重复append、candidate清旧buffer/offset；重复/跳seq、basic内容stage、版本/notice不合法→停止消费并核对；EOF不成功 | API-302；UIA-M003-302/308；AC-308；BE3-V08 |
| FE3-V05 | pending→GET valid恢复缺失candidate；晚active/503/取消响应不覆盖valid；立即+2秒节奏、10秒停止，手动一次active/503仍pending；404/410停止；无token不重POST；切主体/离开旧回调无效 | API-302/304；UIA-M003-308；AC-308/311/313；BE3-V08/11/13 |
| FE3-V06 | 六类内容故障后DB valid/incomplete同一包+notice；SSE/status/保存后的当前结果保持；无有效稿failed退款、主动取消不退款、DB提交未知pending三分；result=null或canSave=false不开放保存 | API-302；UIA-M003-303/308；AC-303/308/311/313 |
| FE3-V07 | 四计划初值；Pro0与Plus99独立存取、再读取；-1/100/1.5/空/null/缺字段/配对错拒绝；NativePolicy只读无写字段；普通不能开启，非管理员403 | API-301/303；UIA-M003-304/305；AC-304/314；DB3-V01 |
| FE3-V08 | impact真实旧新N/人数/生效边界；任何原字段及N编辑使旧预览/迟到impact失效；local99/remote2冲突保留两份、重读重预览；PUT丢响应先读不盲重试；优先级变更展示可能改变内容服务 | API-303；UIA-M003-306；AC-305/306；BE3-V05/06 |
| FE3-V09 | 预设basic0/enhanced1不随计划99；先保存mode后预览；basic→enhanced→basic、旧mode晚完/并发关联失败不ready；incomplete完整稿GET/管理published/确认保持notice且可手动发布；pending/失效payload不得发布 | API-304；UIA-M003-307/308；AC-309/313/314；DB3-V04 |
| FE3-V10 | UsageSummary真实调用/未知发送/未知费用分别显示，null费用不为0；后台不扣用户额度、浏览不调用；不从版本或stage次数推导统计 | API-304；UIA-M003-307；AC-310/314；BE3-V10 |
| FE3-V11 | 运行页面对copy源查文本/顺序/名称/禁用/notice；代表四视口、zh/en、长状态/长正文、Tab/焦点、200%、reduced-motion及真实替换序列；保存后重读/预设发布重读 | API-301–304；UIA-M003-301–309；AC-304/305/308/309/313 |
| FE3-V12 | 记录合成流首可读内容、最长无新内容间隔、总时长及换稿，不当作线上时延；QA独立逐句评阅自然用词/逻辑/文体及误漏报，冻结模型/配置/样本 | API-302/304；UIA-M003-309；AC-312；BE3-V12 |

**边界99只做静态/存取**：N99的ContentService、权益显示、管理PUT/GET、version100字段正例及101反例、动态reducer上界函数；不制造99次stage序列，不执行3–99轮模型或替身pipeline。N2流程仍必须真正走两次内容返修，基础2次与内容2次不同。混合例中检查不算模型恢复调用；前端不新增wire计数，实际调用/一次charge由BE/DB隔离集成证据证明。

开发自检采用需求验收模式：Vitest验证schema/mapper/reducer和表单失效、status竞争；仓储contract测试严格请求body/字段/未知费用；dependency-cruiser验证页面无DTO/状态无传输依赖；Playwright验证真实点击/网络/焦点与准确还原。现有测试受共同schema变化影响的生成/options/预设/管理fixture同步，不改无关期待来凑通过。执行Node24环境中的 `pnpm typecheck`、`pnpm lint`、`pnpm lint:boundaries`、相关 `pnpm test -- <files>`、定向Playwright、`pnpm build`；在实施报告记录实际命令与结果，本架构不声称已执行。

前端验证写入规定的 `implementation/frontend-validation.md`，QA继续规定的coverage-matrix/report/ai-evaluation，不新建测试管理体系。前端负责接口到运行DOM、候选/终态资格、设计转译与必要失败路径；QA负责跨后端/DB的权限/结算/持久化、独立用户流程和AC-312质量边界。可以复用开发充分证据，但Mock成功不等于真实模型质量或服务商费用结论。

### 有限浏览器证据计划

已接收设计证据：[UI02 10组/8截图](../design/evidence/ui02/M003-UI-02-browser.json)证明未变设计区域；[UI03 7组/4截图](../design/evidence/ui03/M003-UI-03-browser.json)证明pending动作设计。两者均为静态原型，不证明实现、真实10秒核对、HTTP权限、发布持久化或流式动效。UI03未变区域可复用UI02作为还原基线，不重做设计。

正式实施优先合并约12组行为场景覆盖FE3-V01–11：生成基础/两轮/上限/incomplete/核对竞争、四计划边界/预览冲突、预设切模式/发布，再补未验证视口语言/键盘缩放。截图软上限8张、模型查看软上限4张，先选造文/配置/预设桌面和手机代表区域；其余用文本/属性/边界断言。UI03 pending动作同时检查普通/预设的available/checking，真实计时用可控时钟。超过预算仅因仍缺验收、失败或条件不同追加，写清ID与原因，不因预算省略必要覆盖，也不为每个组合再截图。

比较固定浏览器、视口/DPR、字体/主题、语言、数据、状态；正文视觉用有效固定fixture，不能遮掉notice/数值/冲突。结构化成功不代替必要视觉判断；动效用真实操作和状态采样，不能只静态截图声称通过。未有真实读屏/设备/线上代理证据时明确未执行。达到当前范围所需证据即停止，不扩大旧遗留项修复。

## FE3-09 实施任务、顺序与交接条件

| 任务 | 修改入口与完成条件 | 依赖 |
|---|---|---|
| FE3-T01 契约基础 | FE3-02所列schemas/models/ports/mappers/repositories及fixtures；API-301–304完整字段、请求白名单、outcome关联、mode basic/enhanced、status和NativePolicy通过定向测试 | 技术总门禁；配套BE02可对接或契约Mock |
| FE3-T02 流/核对 | reducer、generation/admin-presets stores及token-vault能力接口；seq/三个版本/累计snapshot/原子候选/终态竞争/10秒核对/取消正确；移除旧delta和EOF即failed | T01；FE3-V01–06 |
| FE3-T03 计划配置 | admin schemas/configuration/plan-policy/store/plans.vue/presenter；两类矩阵、raw数字、预览失效、冲突重读、priority摘要及独立N往返 | T01；FE3-V07/08 |
| FE3-T04 预设闭环 | presets model/store/repository/page；mode先保存、关联验证、晚响应隔离、incomplete发布notice、精确publish body；用户预设共用生成体验 | T01/T02；FE3-V09/10 |
| FE3-T05 UI转译 | sync-design/locales/manifest、主题增量、GenerationWorkspace/三展示组件、计划/预设区域；先核代表生成与计划区域再复用；PAGE215/217不凭名称宣传增强 | T02–04；UI03/FE3-V11 |
| FE3-T06 联调交付 | 适用旧fixture同步、边界lint/构建、隔离后端联调、有限运行浏览器证据；填前端验证与实施交接，明确失败/未验证，提交QA | T01–05；FE3-V01–12 |

最小源码风险已识别：当前generation reducer只支持delta；store将EOF/传输错误归failed；preview store catch可覆盖validated；plans pending可能继续使用旧输入；publish多带confirmed。实施只在上述责任入口修正本期必要语义，不全站重构。预设/普通复用校验规则而保留不同权限边界，不为复用混合token或结算。

部署架构沿现有Nuxt node-server与Go `/api/v1`代理、配置与数据保护；配套升级不兼容旧流。设计阶段不构建/部署候选、不触碰在线库；实际上线与SSE生产代理验证保持后续权限。验收不要求真实收费调用。后端已完成实现且配套契约可用后再做隔离联调，不用UAT3302承接开发测试。

## FE3-10 当前静态自检与保留事项

本轮只交付本文与 [前端架构交接](../handoffs/frontend-architecture.md)。读取基座agt-frontend-design、共同契约/工作流/角色、设计交付协议、模型路由及实际使用模板；锁定Profile未迁移。定向接收上游与源代码，无业务实现、模型请求、迁移、提交或部署。

静态检查记录在交接：版本/本地路径锚点/稳定ID/文案键/围栏、API到UIA/AC追踪及源码入口核对；只证明方案一致性，不是运行PASS。CR-301已解除，当前无新增业务未决或阻塞。实施完成条件见FE3-T01–06；不能把本稿交付当作技术阶段已迁移。

保留 [M002报告原入口](../../M002/verification/report.md#保留事项)：CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX不因本期方案关闭、不顺手扩修。真实内容质量、误漏报、成功率≥90%、费用、实际首可读/无新内容/总延迟、99轮链路均未验证。新会话交接测试未执行，静态自检不等于独立恢复成功。建议 awaiting_user_review，由控制角色审阅原件并处理技术总门禁，本角色不改state或启动实现。
