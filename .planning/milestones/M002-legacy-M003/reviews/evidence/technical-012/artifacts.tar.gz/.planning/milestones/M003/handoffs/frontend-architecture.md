---
milestone: M003
stage: technical-design
role: frontend-architect/base
agent_name: frontend-bob
status: awaiting_user_review
version: M003-FE-01
date: 2026-10-09
input_version: M003-PRODUCT-03 / M003-UI-03 / M003-DB-02 / M003-BE-02
---

# M003 前端架构交接

frontend-bob 已完成可实施的 [M003-FE-01 原件](../technical/frontend.md)。建议 awaiting_user_review；本交接不修改workflow、不切实现或代用户UAT。按 TRANSITION-M003-011 恢复后完成，Profile仍为consumer-ai-web@1.0.0；路由锁请求frontier/gpt-6-astra/high，actual_model与运行usage均unknown。

## 使用的输入与需求确认

- [产品03](product.md)、[UI03](uiux.md)、[DB02](database.md)、[BE02](backend-architecture.md)，及各自链接的当前原件。准确HTTP/SSE字段仅以 [API-301–304](../technical/api/index.md) 为真源；原型不决定API。
- [Q01-B/Q02-A/Q03-RANGE99](../reviews/requirements-feedback.md) 已确认：各付费计划独立N初始1、整数0–99/0关闭、内容技术故障有有效稿则提示后保留并计一次；内容流程测试最多2次。全请求基础2次和后台basic0/enhanced1沿已接收BE02专业方案，不冒称用户逐字段决定，不重复询问。
- [UI03接收/恢复](../reviews/ui-recheck-011.md) 与 [design-011冻结包](../reviews/evidence/design-011/artifacts.tar.gz)；[CR-301](../changes/CR-301.md) 已解决pending显式核对动作，无剩余关键假设或新增业务选择。
- 全局约束：[首版兼容政策](../../M001/reviews/first-release-compatibility-policy.md)、[主动删除claim例外](../../M001/reviews/claimed-batch-delete-retention-exception.md)、[长期保留事项](../../M002/verification/report.md#保留事项)。不增旧流兼容、不恢复已删除内容、不扩修旧问题，不授权真实收费批次、线上配置/数据、UAT3302或部署。

## 本次产物与关键实现约束

唯一当前前端方案为 [frontend.md](../technical/frontend.md)：FE3-01–10；修改入口与依赖为FE3-T01–06，验证计划FE3-V01–12。沿原Nuxt/Vue、请求级SSR加客户端流、schema→mapper→应用状态→展示，不迁移技术栈或另建平台。

- 三个版本独立：stage的尝试版本、candidate的完整有效版本、DB最终选中版本。尝试v3失败交付v2合法；candidate整包替换但不可保存；status可以恢复未在本机收到的DB完整终态，不能要求它重放所有candidate。
- 首稿为累计安全snapshot，重写token不直显；seq连续、N/k动态，普通档不能出现内容stage。唯一终态不按网络到达先后覆盖；EOF/取消未知/DB未知进入有限核对，不能伪报退款或完成。
- status自动窗口最多10秒，之后UI03显式核对；owner/token/TTL不变，内存token不持久化，刷新不是续传。service_incomplete通过流/status/当前结果和管理preview/发布读取持续保留notice，保存/发布资格另由完整有效资源决定。
- PAGE-208真正区分只读NativePolicy与付费N；raw输入0–99、联动、任何字段编辑使预览失效。冲突同时保留local/remote，重读重新预览，不换revision盲重试。
- 预设mode先保存再预览；后台增强独立固定1；valid之后重读当前draft/mode/run匹配才ready；旧mode晚完不解锁新版本。完整有效incomplete可人工发布，确认与发布后不抹notice。publish请求按BE02移除旧代码额外confirmed字段。

## UI接收与转换入口

已经读取 [design-spec](../design/design-spec.md)、[copy](../design/copy.json)、[theme](../design/theme.css)、[原型实际结构](../design/prototype/app.js)、[交互](../design/interactions.md)、[响应式/无障碍](../design/responsive-accessibility.md)。FE3-07映射PAGE-204/216、208、212及215/217到已有路由、组件、应用模型和API；保留原型顺序/文案/样式并将评审query与示例数据排除出生产。

- 文案转换扩展现有 `frontend/scripts/sync-design.mjs`，M003语言后缀键编译到独立m003命名空间，不能误套M002语言前缀算法；manifest记录来源，运行产品不依赖planning目录。
- UI03新增文案 `action.recheck/rechecking.zh/en` 已确认存在；普通 `#generation-recheck`、后台 `#preset-recheck/#preset-publish` 已映射。原型 `base` 映射API `basic`，不造第三种模式。
- 样式继承现有M002主题与M003增量，去除构建产物对planning的相对@import；准确notice、NativePolicy和N不能被fixture值替代。无新图片资源要求。
- 设计证据复用：[UI02](../design/evidence/ui02/M003-UI-02-browser.json) 10组/8截图证明未变区域；[UI03](../design/evidence/ui03/M003-UI-03-browser.json) 7组/4截图证明pending补齐。它们是原型证据，不是产品前端通过。
- 实施采用需求验收模式，计划约12组合并行为场景、截图8/模型查看4的软上限，必要失败/缺证据按ID追加；详FE3-08。补768/320、英文、200%、键盘焦点/reduced-motion及真实HTTP/计时/持久化，无需重做整套设计。

## 追踪与静态自检

本轮源码基础commit：`45a4ab123c3308fa0a83868b6030c6b84a96f67d`。未提交的产品/设计/技术原件通过控制角色冻结包定位；未改变他人工作区修改。前端代码定向读取包括generation schema/reducer/store/仓储、plans表单、admin preview/store、token-vault、SSR装配、设计同步脚本和依赖边界规则。

静态检查（2026-10-09）：

| 检查 | 结果与证据边界 |
|---|---|
| 激活、输入与版本 | state为technical-design/frontend-bob；两份FE01同一输入版本；UI03已接收，CR301已resolved；Profile1.0锁未修改 |
| 本地引用/稳定ID | 两份文档Markdown本地路径与显式/标题锚点检查0断链；FE3-01–10、T01–06、V01–12齐全；围栏成对 |
| API→UIA→AC | FE3-07/08逐项对应API-301–304、UIA-M003-301–309与AC-301–314；统计/真实质量列明后端/QA边界，不用UI测试代替 |
| 文案与语义 | 检查recheck/rechecking、incomplete、limit、固定基础策略和动态权益/返修模板双语键全部存在；尝试3/最终2、双预算、N99仅字段、后台固定1与发布notice人工交叉核对 |
| 实现/运行 | 未执行产品构建、Vitest/Playwright、真实模型、数据库迁移或UAT；本文的PASS仅指上述文档静态条件，不表示前端已实现或AC已通过 |

可复核设计输入SHA256：`copy.json=fde7c533fb45dc98213798e1eeee62cd427e9466f1b1e1e754d280dbde63208a`；`theme.css=748c589f2d46fd337510506346ea28e2ede2017196facef928b8f773ba8d4921`；`prototype/app.js=2ff786d035914129f993c02be172b43683eb60368016f5654d84af162adbf990`。冻结包为恢复原件，摘要用于检查是否发生后续变化。

## 文档维护、未决与风险

- 本轮首次创建frontend.md和本交接，按稳定编号单处维护正文，没有追加历史流水或覆盖旧批准。责任回溯只创建过CR-301，后由设计角色解决；未改上游原件、源码或控制面。
- planning读取超过8k软目标，原因是核对BE02精确事件/终态/配置与UI03局部回溯、关联全局权限/保留边界；输入按定向文件/章节读取，未全载历史。运行token/usage unknown；无可可靠重建的完整已读字符计量，不将文件总大小冒充实际输入。
- 新会话交接测试未执行；静态自检不能证明独立接续成功。应用最终运行与还原仍未验证，落实位置为FE3-T01–06及实施前端验证报告。
- **BLOCKED：无。开放CR：无。** 重要未知仍是精简链路真实质量/误漏报/费用/实际延迟；99轮流程未执行且不在本期流程测试要求。保留CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX原状态，不纳入顺手修复。

## 下一步

由控制角色审阅FE01原件与技术总门禁；若按授权进入实现，backend-ethan先交付BE02/DB02配套接口，frontend-claire按FE3-T01–06实施并补前端验证，qa-quinn按AC-301–314独立核验。前端可先用契约Mock完成可逆实现，但不能用Mock声称数据库结算、质量或上线通过。阶段状态和实现启动由控制角色按原权限处理。
