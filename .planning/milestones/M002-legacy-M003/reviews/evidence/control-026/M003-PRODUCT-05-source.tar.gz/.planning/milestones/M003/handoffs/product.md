---
milestone: M003
stage: product-planning
role: product/to-c
agent_name: product-maya
status: awaiting_user_review
version: M003-PRODUCT-05
date: 2026-10-10
---

# M003 产品交接

product-maya 已完成 **BE3-DEP01 / LIVE-TEXT 产品同步**，六份原件统一PRODUCT05，建议awaiting_user_review/供UI06原型。无新增业务待决，不自批BE04技术或未来实现，不修改状态或激活下游。

## 输入与确认闭环

- 正式入口：[TRANSITION-M003-025](../reviews/live-text-product-024.md)，状态为product-planning / product/to-c / product-maya；沿用已读agt-product-planning及产品角色契约。
- **CONFIRMED**：[USER-M003-LIVE-TEXT](../reviews/requirements-feedback.md#m003-live-text-连续正文与修订稿流式展示)要求首稿与修订稿像聊天AI一样按真实片段显示。撤销PRODUCT04“仅词义预览、正文最终一次出现、第一有效包前不得显示正文”；审稿无新文时保留已收到内容，仍不突出审稿/返修或次数。完整导航、选词、配置、计划/预设及学习交互保持。
- **PROPOSED技术方案**：[BE04交接](backend-architecture.md)提供单服务端版本化splice支持追加、删尾/替换与lastValid恢复；具体字段、位置/版本和性能参数以 [API-302](../technical/api/generation.md) / [BE3-09](../technical/backend.md#be3-09-编辑流的服务器成本与边界proposed) 为真源，不是用户逐字段批准。模型输出格式、同目标模型和调用预算不变，不要求完整CRDT、模型编辑指令或多人协作。
- **后续计划**：[USER-M003-STREAM-COST](../reviews/requirements-feedback.md#m003-stream-cost-服务占用的后续统计)记录模型等待/用量、连接秒、事件/字节、写阻塞及进程CPU/RSS/GC的分开观测；连接秒不当CPU秒，不伪称逐请求精确成本。复用run/usage/metrics内存累计后汇总，不逐token落DB、不新增正文日志/仪表盘/数据库或成本试验。性能与金额未验证，不阻塞本轮原型。
- **不变规则**：普通仅基础纠错；基础全请求2次只读技术策略、双预算独立；付费各计划N整数0–99/初始1、0关闭、按N运行/流程测试最多2次；同模型、上限定稿、一请求一次计次、牵强/矛盾统计。管理两类预算和0–99、后台preset基础0/增强1保留。Q02最近有效整包故障交付须持续提示“内容审校未完成”、可保存并计一次，取消/断连/结算未知规则不变。
- 沿用 [锁定Profile1.0](../reviews/evidence/start/locked-profile.yaml)、[v1模型锁](../../../agt/model-routing-v1.lock.json)：frontier请求gpt-6-astra/high，实际serving model与usage unknown。[M002已验收交接](../../M002/handoffs/verification.md)、[兼容政策](../../M001/reviews/first-release-compatibility-policy.md)、[删除政策](../../M001/reviews/claimed-batch-delete-retention-exception.md)保持。

## 本次六份原件

1. [overview.md](../product/overview.md)：D3-04、最新确认、撤销旧方案和后续成本边界。
2. [data-assets.md](../product/data-assets.md)：DATA-302/303草稿与最终资源可见性、后续统计口径。
3. [abilities.md](../product/abilities.md)：CAP-301/302/304、AC-308/312；其余业务验收保持。
4. [pages/index.md](../product/pages/index.md)：PAGE-204/216真实正文、换稿、等待与保存文案。
5. [ai-behavior.md](../product/ai-behavior.md)：真实增量、失败恢复、完整性、Q02及观测边界。
6. 本交接单。

## 责任接收与下一动作

| ID / owner | 当前结果与完成条件 |
|---|---|
| BE3-DEP01 / product-maya | **已同步PRODUCT05**：旧BE03词义only取舍撤销，真实增量/删尾/替换/lastValid、DB确认保存资格与成本计划已进入当前正文；不越权改backend原件依赖状态 |
| BE3-DEP02 / designer-tony，UI06 | 接收 [BE04设计合同](backend-architecture.md#designer-tony-接收合同) 与 [stream-v4/index.json](../technical/fixtures/stream-v4/index.json)。正常生成按钮自动消费wire多帧，不能从最终全文造打字动画。实际演示首稿多片、审稿无新文保留、修订首片前保留旧稿及到达后的纯删除/替换、失败后lastValid恢复；草稿不带旧学习资源且不可保存，DB确认终态后建立全部资源。pending/EOF只读保留并核对；取消/无有效稿失败清稿；Q02持续提示、保存和计次一致。管理员预览保持独立模式/用量与发布关联检查。完整造文/计划/预设页面、自动回放和取消隔离保留；记录fixture版本/场景及消费证据，交用户查看原型，合成间隔不作性能证据 |
| BE3-DEP03 / frontend-bob | 后续按BE04及审阅后的UI更新FE01 reducer/types/mock，移除learning-only旧假设；具体身份/顺序/码点/有界核对沿后端交接。尚未接收为完成 |
| BE3-DEP04 / backend-ethan | 待审源码保护与实施对齐、后续资源观测按BE3-08/09及原owner授权边界继续；本轮不改代码/DB02，不宣布实现符合BE04 |

本步产品同步完成条件：已确认方向及撤销项在六份一致，技术建议与未验证效果分开，其他业务规则及owner去向保留。下一步由主会话按现有授权接交UI06，不重复询问N、Q02或LIVE-TEXT方向；原型仍需用户视觉评审，未来实施另行接收。

## 维护、检查与保留

- 修改前六份PRODUCT04与 [control020冻结包](../reviews/evidence/control-020/M003-PRODUCT-04-source.tar.gz) 逐字6/6一致；旧审批、BE03/BE04及UI05-R1冻结证据保持。六份当前原件原位维护，无新竞争真源。
- 定向检查方法：Python核对版本/本地链接/锚点及冻结04业务章节，rg检查旧显示约束。结果：6/6版本一致，原有显式锚点全部保留，68处链接/锚点无断链；CAP-303/305与其余12条AC业务行逐字未变；不运行代码、浏览器、模型、fixture checker或新质量测试，后端既有静态检查不代替UI验收。
- **无新增业务OPEN/BLOCKED**。具体BE04编辑技术、UI06效果、真实质量/时延/费用/服务器资源与并发竞争未验证。CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX沿 [workflow](../../../workflow/state.yaml) 保留。首可读正文、每稿换稿等待、最长无新正文间隔及总时长后续单独记录，不声称已更快/更省。
- 定向读取当前原件、三条最新用户来源及BE04相关章节，未递归历史；运行时输入字符/token/usage unknown。未做新会话接续测试，实际wire消费由designer-tony验证。
- 本轮仅改六份产品原件，未改UI/API/BE/FE/DB/源码/控制面/历史或冻结证据，未提交、部署、调用真实模型或触碰UAT3302。
