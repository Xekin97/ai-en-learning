---
id: API-M003
version: M003-BE-05
status: awaiting_user_review
milestone: M003
agent_name: backend-alex
---

# M003 Markdown API 增量

继承 [M002 公共传输/鉴权/错误](../../../M002/technical/api/index.md) 与 [多提供方契约](../../../M002/technical/api/model-connections.md)。统一前缀 `/api/v1`；JSON严格字段、重复键/未知键/类型/null/尾随校验；成功JSON仍 `{data,meta:{request_id}}`，SSE data没有封套。本文类型中未标nullable的字段均必填非null；所有数组即使为空也不可null。所有副作用和只读POST需要原CSRF，cookie身份不变。USER-COMPAT-001：前后端配套切换，移除旧passage.delta以及BE02 stage/snapshot/candidate公开消费分支，不做旧客户端兼容层，不建OpenAPI。

| 契约 | 能力/数据/页面 | 对原API的增量 |
|---|---|---|
| [API-301/302](generation.md) | CAP-301/302/305；DATA-301–303；PAGE-204/215/216 | API-004选项、API-005生成/终态、API-006保存资格 |
| [API-303](administration.md) | CAP-303；DATA-301；PAGE-208 | API-103计划完整字段、impact/revision/优先级 |
| [API-304](presets.md) | CAP-304/305；DATA-302–304；PAGE-212/216/217 | API-202公开预设和管理员mode/预览/发布 |

接口只暴露调用方所需权益和安全状态；不公开私有review、prompt、provider ID、connection或内部审稿意见。公开终态枚举与completion_notice只说明交付/审校过程，不是独立质量评测。后台usage继承获授权的数值投影。数据库现 [DB02](../database.md) 尚待DBA按BE3-03修订六stage/七stop reasons/版本约束，不声称兼容；pipeline与review以 [AI3](../ai-integration.md) 为真源。示例仅展示schema，不是达标文章、产品种子或真实使用数据。

BE05流版本为`m003-stream-v5`：共同实际规划的完整场景/用词条目投影plan_item，完整Plan输入writer；增强新增必经固定编辑。保留v4的真实版本化edit splice/Q02 retained与全部结算规则，业务V独立于N。完整样例：[stream-v5/index.json](../fixtures/stream-v5/index.json)，限定检查：[check_stream_v5.py](../evidence/check_stream_v5.py)。普通/后台basic也有规划，后台enhanced固定编辑后最多1条件返修；无旧协议兼容/恢复平台。v3/v4原件留存。
