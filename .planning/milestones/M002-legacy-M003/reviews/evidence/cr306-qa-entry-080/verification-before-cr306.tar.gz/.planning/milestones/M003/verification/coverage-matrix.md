---
milestone: M003
stage: verification
role: quality/base
agent_name: qa-quinn
status: completed
version: M003-QA-02
result: pass
date: 2026-10-12
---

# M003 独立 QA 覆盖矩阵

## 范围、方法与证据预算

本轮验收 `M003-PRODUCT-07 / M003-TECH-03 / M003-FE-02 / M003-UI-09-R3`，视觉基准为已批准 `M003-UI-09-R2 / M002`。首轮接收复用 [`implementation-receipt.json`](../reviews/evidence/qa-start-059/implementation-receipt.json) 的 100 个后端、45 个前端文件 hash；定向返修接收由 [`qa-fix-gate-064.md`](../reviews/qa-fix-gate-064.md) 与 `post-fix-integrity.json` 限定为 CR-304/305 授权变化。未机械复跑开发单测、lint、typecheck 或 build。

首轮使用 `qa-m003-001`，返修复验使用全新 `qa-m003-002`：随机独占端口、一次性空 PostgreSQL、真实 Go/Nuxt/Chromium 与合成 provider。首轮截图 7 张，定向复验新增 0，仍低于软上限 8；送模图片 2 张，低于软上限 4。合成 provider 只证明协议、状态、持久化与界面行为，不证明自然语言质量、真实费用、真实供应商表现或生产容量。

| QA ID | 批准验收 / 覆盖 | 实际场景与判定方法 | 结果 | 原件 |
|---|---|---|---|---|
| M003-QA-S01 | AC-301/302/303/308/311/313/315/316；FE3-V01–06 | 普通 N0、增强 N1 pass、N1 Q02、N2 两次返修；真实 HTTP/SSE、v5、Plan→writer、固定编辑/Review/repair、Result、notice、保存、一次扣额与 DB 链 | **PASS** | [`api-results.json`](evidence/qa-m003-001/api-results.json)、[`n2-method-retest-final.json`](evidence/qa-m003-001/n2-method-retest-final.json)、[`db-facts.json`](evidence/qa-m003-001/db-facts.json) |
| M003-QA-S02 | AC-308/311/313；API-302；FE3-V05/06/13 | status、错误 token；测试栈配置 1 槽并保持一个请求已受理，使第二请求命中真实 busy；核对 503 Problem/header 与严格前端保输入、cooldown 解禁、无自动 POST | **PASS** | [`cr304-api-results.json`](evidence/qa-m003-002/cr304-api-results.json)、[`targeted-browser-attempt3.json`](evidence/qa-m003-002/targeted-browser-attempt3.json) |
| M003-QA-S03 | AC-304/305/306/314；API-303；FE3-V07/08/11 | Pro/Plus 独立 2/99、native2 只读、非法边界、双人数不求和、impact 失效、409 后重预览、非管理员拒绝 | **PASS** | 首轮 API/DB 与 [`browser-results-final.json`](evidence/qa-m003-001/browser-results-final.json) |
| M003-QA-S04 | AC-309/313/314；API-304；FE3-V09/10/11 | enhanced Q02 preview；Plan/草稿；Unknown≠0；明确确认发布；notice 保留；键盘 mode | **PASS** | [`browser-results-final.json`](evidence/qa-m003-001/browser-results-final.json) |
| M003-QA-S05 | AC-310/314；CAP-305；BE3-V10 | N2 持久化 reason；按运行去重核对牵强/矛盾分子、交并集与 repair 次数 | **PASS（合成事实边界）** | 分母 1，forced 1，contradiction 1，交/并集 1，repair calls 2；[`n2-method-retest-final.json`](evidence/qa-m003-001/n2-method-retest-final.json) |
| M003-QA-S06 | UIA-M003-401.a–411.a；FE3-V11 | 两页 Plan/live draft 各 3 点、aria-hidden；正常动画与 reduced-motion；焦点、终态清理；首轮键盘、200%、320/390/768/1440、≥44px | **PASS** | [`targeted-browser-attempt3.json`](evidence/qa-m003-002/targeted-browser-attempt3.json)、[`preview-reduced-results.json`](evidence/qa-m003-002/preview-reduced-results.json)，其余复用首轮浏览器证据 |

## CR-304 / CR-305 定向复验

- **CR-304 PASS**：真实 HTTP 503 `generation_busy`，`accepted:false`、无 SSE、`retry_after_seconds=5`，与 `Retry-After: 5` 一致且 `no-store`。严格前端保留模型和两个词，cooldown 内禁用、到期解禁；请求计数从 busy 后到解禁仍为 1，没有自动重 POST。1 槽仅为确定性测试配置，不代表生产并发上限。
- **CR-305 PASS**：普通 create 与后台 preview 的 Plan、live draft 各 3 点且 `aria-hidden=true`。正常模式为 `m003-writing / 1.2s / running`；减少动效为 `none / 0s`。两页焦点稳定，完整终态清除 Plan/draft/writing，未见 page error。

聚合原件为 [`targeted-retest-summary.json`](evidence/qa-m003-002/targeted-retest-summary.json)：API 5、主浏览器 16、后台 reduced-motion 续测 5，共 26 个已记录检查通过。未受影响范围复用 `qa-m003-001`，没有全量重跑。

## 方法更正与原件保留

首轮所有失败保留于 `qa-m003-001`，判定链见 [`method-corrections.json`](evidence/qa-m003-001/method-corrections.json)。定向复验也保留方法过程：首次浏览器批次错过已退出 holder 的事件；下一次使用错误选词类名与普通布局链接；第三次 16 项已经通过后，剩余后台 reduced-motion 因文本同时命中 button/heading 停止；续测首次又使用了不完整按钮 accessible name。最终使用立即绑定的有界退出 Promise、真实 `.word-token`、后台 `/admin` 链接和 `.admin-record` 标题过滤完成。上述均为 QA 方法问题，没有新增产品失败。

## 未验证与保留

- `AI-QUALITY-90`、`CR039-L1`、`CR042-L1`、`W01`、`QA26-MINIMAX` 状态不变。
- 未调用真实付费模型，未验证自然语言质量、真实费用、供应商波动、生产 SSE 代理、生产迁移或 10/20/50/100 容量。
- N 实际执行到 2；99 只验证配置存取和影响失效，不执行 99 轮。
- 200% 是 Chromium emulation；没有真机、人工读屏或人工缩放专项。
