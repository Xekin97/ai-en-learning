---
milestone: M003
stage: verification
role: quality/base
agent_name: qa-quinn
status: completed
version: M003-QA-02
result: pass
user_uat: not_started
date: 2026-10-12
---

# M003 独立 QA 报告

## 结论

本轮独立 QA **PASS**。CR-304 与 CR-305 的约定定向复验全部通过；QA 已在两份 CR 写入独立复验记录，最终关闭状态由根代理同步。其他首轮通过证据按版本与依赖关系复用，没有全量重跑。当前可进入用户 UAT；用户尚未执行或接受。

## 接收版本与运行方法

首轮输入为 M003-PRODUCT-07、TECH-03、FE-02、UI09-R3，视觉继承 UI09-R2/M002。返修由 [`qa-fix-gate-064.md`](../reviews/qa-fix-gate-064.md) 接回 verification；`post-fix-integrity.json` 证明 15,717 个旧保护文件仅有已授权的 3 Go、2 Vue 与 4 份交付文档变化。QA 未修改生产源码。

首轮 API 54 项经方法判定后只有 CR-304 产品缺陷，浏览器 31 项只有 CR-305；N2 方法修正后通过。返修复验在新的 1 槽 disposable 栈完成 26 个结构化检查：CR-304 API 5 项、主浏览器 16 项、后台 reduced-motion 续测 5 项，全部通过。聚合见 [`targeted-retest-summary.json`](evidence/qa-m003-002/targeted-retest-summary.json)。

## 核心通过结果

- 普通 N0 与增强 N1/N2 有真实 Plan→writer；SSE seq、v5 snapshot/splice/replace、完整 Result、Q02 notice/status/save、一次扣额与错误 token 隐藏符合合同。
- N2 到两次 repair，终态 V4；`forced_wording` 与 `contradiction` 按运行去重事实均为 1。该合成单样本只证明统计输入与持久化口径。
- native correction 固定 2 且只读；Pro 2、Plus 99 独立；非法边界、权限、impact、冲突重预览通过。
- 后台 enhanced Q02 键盘选择、Plan/草稿、Unknown≠0、确认后发布与 notice 保留通过。
- 受影响页的键盘、稳定焦点、终态清理、760px 对称阅读列、320/390/768/1440、200% emulation、≥44px 均通过。

## CR-304 定向复验

在**测试环境配置容量为 1**且该槽已被一个受理请求占用时，第二请求得到 503 `generation_busy`；body 为 `accepted:false, retry_after_seconds:5`，header 为 `Retry-After: 5`，无 SSE 且 `no-store`。严格前端显示可恢复服务不可用状态，模型和 `grape/young` 保留；cooldown 内按钮禁用，到期解禁，POST 计数仍为 1，没有自动重试。该方法只验证饱和合同，不描述生产并发上限。

## CR-305 定向复验

普通 create 与后台 preview 的 Plan、live draft 都渲染 3 个 `aria-hidden=true` 书写点。正常模式 computed animation 为 `m003-writing / 1.2s / running`；`prefers-reduced-motion: reduce` 为 `none / 0s`。两页 Plan→draft 更新不抢已聚焦的稳定链接；完整终态移除临时 Plan、draft 和 writing 节点。无 page error，未增加截图。

## 方法历史

定向浏览器第一次因 holder 退出监听绑定过晚而挂起；后续依次纠正选词节点、后台稳定焦点和预设记录 locator。每次首次输出均保留，最终以聚合原件为准。方法错误没有被计为产品缺陷，也没有扩大矩阵。

## 未验证与范围边界

真实付费模型、自然语言质量与 `AI-QUALITY-90`、真实费用/账单、生产容量/部署/迁移、真实供应商、生产 SSE 代理、真机输入法、人工读屏和人工 200% 专项均未验证。99 只验证配置，不执行 99 次返修。

## 资源清理

`qa-m003-001` 与 `qa-m003-002` 的 provider、backend、frontend 均已停止，PostgreSQL 正常退出；各自独占端口关闭，临时目录删除。第二轮原件为 [`local-stack-cleanup.json`](evidence/qa-m003-002/local-stack-cleanup.json)。当前没有 QA 进程、端口或临时数据库留待接管。
