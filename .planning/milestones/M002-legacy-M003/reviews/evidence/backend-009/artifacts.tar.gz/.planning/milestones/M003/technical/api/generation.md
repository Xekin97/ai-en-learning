---
id: API-301-302
version: M003-BE-02
status: awaiting_user_review
milestone: M003
---

# 权益、动态生成流与唯一终态

CAP-301/302/305，DATA-301–303，PAGE-204/215/216，AC-301–303/306–308/310–314及UIA-M003-301–303/308。V=访客、L=本人学习者；管理员走独立预览。以下路径省略 `/api/v1`；公共封套/错误继承[index](index.md)。新增字段均必填；只有显式null可空，整数必须JSON整数，拒绝未知/重复字段及尾随JSON。

## API-301 选项和系统基础策略

```text
ContentService = {native_validation:true,content_review_enabled:false,content_repair_limit:0}
               | {native_validation:true,content_review_enabled:true,content_repair_limit:int[1,99]}
NativePolicy = {version:"m003-native-policy-v1",scope:"logical_request",max_calls:2,editable:false}
Plan = visitor|basic|pro|plus
ValidContentOutcome = basic|review_passed|repaired_passed|limit_finalized|service_incomplete
CompletionNotice = "content_review_incomplete"|null
```

ContentService严格关联配对；visitor/basic固定关闭0。NativePolicy由后端系统常量映射，pipeline版本定位，不来自计划表可编辑值；基础预算覆盖首稿与所有后续稿，不能重置。用户/管理写接口不得接受native_policy/max_calls等系统字段。

`GET /generation-options` V/L：保留M002完整data，新增 `configuration_revision:string,content_service:ContentService,native_correction_policy:NativePolicy`。原effective_plan仍 `{code:Plan,origin:visitor|base|trial,trial_ends_at:Time|null}`。revision及内容权益同配置共享锁读取；可用性仍检查模型/长度/次数，增强不免预检。页面依实际开关/N，不凭计划名、模型/次数卡推断；试用只取唯一胜出计划。

`POST /generations/stream` 请求仍严格 `{model_id:string,meaning_language:zh|en|ja,scenario:story|discussion|business|news,length:short|medium|long|xlong,entries:string[]}`，64KiB及原词表/配置授权限制不变；不接受content_service/mode/prompt/provider/技术预算。受理事务重新解析当前权益：旧options下输入仍合法则接受，以started覆盖预估并刷新options供下次使用；本次快照之后不变。输入失效422，权限403，active冲突409 generation_in_progress，次数不足429 quota_exhausted，配置/凭据不可用503 generation_unavailable；预检拒绝不调用。

受理事务配置共享锁→主体锁→锁后业务时间→完整快照/模型连接/run/entries/原charge/开始事实同事务。COMMIT确定未成功返回Problem；ACK不明用已分配run ID限时读回，完整run/charge确认才继续，否则503 temporarily_unavailable并交原恢复，不宣称未扣次。POST不自动幂等重放；新生成必须用户新意图，普通/用户预设共享每主体一个active槽。

## API-302 SSE 精确字段

受理COMMIT确认后发送200 SSE并flush started成功才Open；started写失败无上游调用，按stream_failed结算。随后Open失败在本SSE处理，不改JSON响应。原headers/no-store/15秒heartbeat保持；每次write/flush设置10秒截止并续设。POST fetch读取，无Last-Event-ID/流重连；heartbeat不算正文/业务事件。

所有命名事件seq从1逐一递增，单writer按发生顺序发；无封套。下表为完整data类型，`V`是稿件版本整数1至N+1（最多100），`K`是本次实际已确认发送的内容返修尝试序号0至N。attempt_content_version代表正在处理的候选；content_version代表已经接受的完整候选；final_content_version只代表最终选中包。

| event | 完整data |
|---|---|
| generation.started | `{seq:int,run_id:string,generation_token:string,snapshot:RunSnapshot}` |
| generation.stage | `{seq:int,stage:generating|native_repair|content_review|content_repair,attempt_content_version:V,repair_attempt:K}` |
| passage.snapshot | `{seq:int,content_version:1,passage:string}` |
| generation.candidate | `{seq:int,content_version:V,result:Result}` |
| generation.validated | `{seq:int,run_id:string,final_content_version:V,result:Result,content_outcome:ValidContentOutcome,completion_notice:CompletionNotice}` |
| generation.failed | `{seq:int,code:FailureCode,quota_refunded:true,retryable:bool,request_id:string}` |
| generation.cancelled | `{seq:int,quota_refunded:false}` |
| generation.settlement_pending | `{seq:int,code:"settlement_unconfirmed",request_id:string}` |

`RunSnapshot={configuration_revision:string,effective_plan:{code:Plan,origin:visitor|base|trial},content_service:ContentService,native_correction_policy:NativePolicy}`。计划来源/内容N来自受理事实；不返回凭据/provider/prompt/私有Review。系统策略由该run.pipeline版本映射，不在状态查询用新部署的当前常量覆盖旧快照。

`Result={passage:string,tags:string[],targets:Target[]}`；`Target={entry:string,entry_meaning:string,hint_phrase:string,hint_blanks:[{start:int,end:int}],occurrences:[{surface:string,start:int,end:int}]}`。原词每项一个、输入顺序、非null数组；offset为Unicode code point半开区间；完整规则继承 [M002书架](../../../M002/technical/api/identity-library.md)。candidate和validated都严格完整校验，不从上一个版本补字段。

### 事件语义和reducer

1. started只一次，固定N并开放取消；stage只在相应调用provider_invoked=true事实确认落库后发，不能用计划/计时器制造阶段。generating用version1/K0；native_repair和content_review使用其当前候选version、K=version−1；content_repair第k次用attempt_version=k+1/repair_attempt=k。基础修正不改变版本或K。
2. passage.snapshot仅首稿版本1。安全extractor解析转义/标注后，在完整词边界达到32个Unicode字符或完整句边界即首显（先到者），以后仅有真实新文本才最多每250ms合并累计正文，字符串闭合刷新尾部。完整词边界是已确认空白/标点分隔；未闭合JSON转义/标注/末词缓冲，不泄露原JSON或猜测正文。不要求完整段落/人为分段。
3. 首稿基础续写同版本累计快照，字段纠错静默；C1整包原生有效才candidate1。普通随即定稿；增强审稿时保留C1草稿。所有内容重写token缓冲；新版本整体原生有效才candidate原子替换正文/tags/targets，再审查该稿。失败新稿永不作为candidate出现。
4. stage更新“尝试版本/第k次”，不推进“已接受版本”。candidate只能增加已接受版本且不得超N+1；validated的final_content_version必须等于最近candidate版本/Result。例如已有candidate2，stage(content_repair,attempt3,k2)后稿3无效，validated(final2,service_incomplete)合法；不是正文版本倒退。若稿3有效已candidate3、其审稿故障，则final3。不会从candidate3回退到2。
5. outcome/notice严格关联：basic仅关闭；review_passed增强且未内容返修；repaired_passed增强且交付稿末审pass；limit_finalized增强且N用尽、末审可判定issues；service_incomplete增强且内容技术故障。只有service_incomplete notice非null并固定为content_review_incomplete，其余必须null。用户文案依copy.json：前四种统一“生成完成”，不声称独立质量通过；第五种持续提示“内容审校未完成”及仍计一次，可保存。
6. 只有数据库确认valid后发validated；candidate始终不可保存。failed/cancelled清草稿并禁保存；pending是传输结束说明，**不是业务终态**，可保留草稿但禁保存并核对。EOF无终态不成功。无started后续事件、seq倒退/重复/跳号、版本越界、candidate倒退、basic出现内容阶段、outcome/notice不匹配均停止消费并查询status，不能容错拼稿。
7. validated/failed/cancelled只一种业务终态。HTTP取消/查询与SSE收敛同run数据库结果，不用网络到达顺序覆盖。新一轮review无需预建N个UI步骤。

```text
event: generation.started
data: {"seq":1,"run_id":"run-example","generation_token":"opaque","snapshot":{"configuration_revision":"opaque-revision","effective_plan":{"code":"pro","origin":"trial"},"content_service":{"native_validation":true,"content_review_enabled":true,"content_repair_limit":2},"native_correction_policy":{"version":"m003-native-policy-v1","scope":"logical_request","max_calls":2,"editable":false}}}

event: generation.stage
data: {"seq":8,"stage":"content_repair","attempt_content_version":3,"repair_attempt":2}

event: generation.validated
data: {"seq":9,"run_id":"run-example","final_content_version":2,"result":{"passage":"They learned together.","tags":["学习"],"targets":[{"entry":"learn","entry_meaning":"学习","hint_phrase":"learn through practice","hint_blanks":[{"start":0,"end":5}],"occurrences":[{"surface":"learned","start":5,"end":12}]}]},"content_outcome":"service_incomplete","completion_notice":"content_review_incomplete"}
```

示例省略seq2–7（含完整candidate2），只说明字段和第三稿尝试失败后的最终版本；短正文不是满足线上长度的模型fixture。真正流不允许跳号。通常N=2路径：started→generating→snapshot*→candidate1→review1→repair2→candidate2→review2→repair3→candidate3→review3→validated3，可在任一审稿pass早停。

### 故障、核对与权限

FailureCode仍 `authentication|authorization|rate_limited|provider_unavailable|protocol_error|schema_error|content_validation_failed|generation_timeout|generation_failed`。仅真正失败终态使用generation.failed；六类内容故障且有完整有效包按 [AI3-02](../ai-integration.md#ai3-02-六类内容故障与保留稿) 发validated/service_incomplete，不先failed再成功。retryable仅表示用户可新意图重试，不自动重发本请求。认证/授权错误false，其他尊重真实ProviderError；不泄露上游正文。DB关键事实失败先核对，不能套内容故障成功。

`GET /generations/{run_id}/status` V/L，X-Generation-Token，无query/body，200：

```text
{run_id:string,status:active|valid|failed|cancelled,snapshot:RunSnapshot,
 final_content_version:V|null,result:Result|null,can_save:bool,quota_refunded:bool,
 content_outcome:ValidContentOutcome|failed|cancelled|null,completion_notice:CompletionNotice}
```

同一一致读取run、charge和结果。active的outcome/version/result为null，can_save=false，refund=false；failed/cancelled的outcome同status、version/result=null、can_save=false，只有failed refund=true。valid读取run.final_content_version/outcome并导出notice，不按调用次数猜；有效draft仍可用时result完整/can_save=true（V表示可claim）。已保存的本人学习者可沿既有generation_run_id读取其本人batch组装同一结果，can_save=false；已丢弃/过TTL无结果、已删除batch或visitor已经claim给账号时result=null/can_save=false，仍在允许状态窗口内返回outcome/notice；不可用访客token读归属他人账号的batch。result不可用不抹掉故障提示、不重新生成。

使用VerifyRunToken+DB主体/owner检查，待保存draft还需token digest及原expiry/disposition；终态沿1小时能力窗口，草稿默认30分钟。404不匹配/资源已删除，410能力过期，503 DB暂不能确认；前端404/410停止核对并关闭保存，保留安全说明、重新生成是新意图；503/active短核对后仍未知保持pending。立即查一次，最多每2秒、总10秒，未收敛提供显式“重新核对”，不无限轮询。此GET不调模型、不续流，不把token写本机/URL；刷新丢token不新增恢复能力。已有合法恢复途径重读结果时notice必须稳定，不能把UI“刷新仍有提示”解释为新续传平台。

`POST /generations/{run_id}/cancel` 原权限/header/{}→200 `{status:cancelled|valid|failed,quota_refunded:bool}`，仅确认DB终态才200；未知503 settlement_unconfirmed。先CAS确认取消，再cancel context；完成先赢则valid（可能service_incomplete），用status读取最终包/notice；失败先赢failed/true。重复cancel不二次结算，不把有候选稿当拒绝取消理由。取消本身不触发内容故障交付。

客户端断连/write失败沿原技术失败退款；valid先提交后断连仍valid不退款。execution deadline在有lastValid的内容阶段可带提示完成，其独立完成/核对ctx不继承到期；客户端取消/断连另行检测并参与CAS。保存/放弃/claim沿M002 API-006与原TTL/幂等；服务器要求valid+完整最终资源，无论内部几次调用始终一run一charge，service_incomplete不额外扣次或退款。
