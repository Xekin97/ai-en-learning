---
milestone: M003
stage: technical-design
role: backend-architect/base
agent_name: backend-alex
status: awaiting_user_review
version: M003-BE-02
date: 2026-10-09
input_version: M003-PRODUCT-03 / M003-UI-02 / M003-DB-02
---

# M003 后端架构修订交接

backend-alex 已按TRANSITION-M003-008活动职责修订七份后端原件；建议awaiting_user_review，不改workflow、不切前端/实现或代用户UAT。项目路由锁frontier/high保持requested gpt-6-astra/high；actual_model/usage无独立证据，仍unknown。

## 输入与确认闭环

- [用户原始选择](../reviews/requirements-feedback.md)：Q01-B各付费档独立N、初始1；Q03-RANGE99确认整数0–99、0关闭、流程测试到2次；Q02-A有最近有效稿时内容故障交付、持续提示、计一次。没有剩余数值选择，不重复询问。
- [产品03](product.md)、[UI02](uiux.md)、[DB02](database.md)及[当前接交008](../reviews/database-revision-008.md)已接收；恢复核对state/agents为technical-design/backend-alex；Profile仅consumer-ai-web@1.0.0，沿此前完整读取的agt-backend-design技能/共同契约/角色/模板和模型路由恢复，未迁移Profile。
- 基础全请求2次正式作为本版后端系统策略、后台只读；单次180秒/执行600秒不随N增加；后台basic0/enhanced1。普通可逆技术细节在既有委派内定稿，不解释为用户逐字段原话或线上费用授权。
- BE01已在 [feedback-005](../reviews/evidence/feedback-005/artifacts.tar.gz)冻结。撤销它的用户固定1次、仅1/2版本、审校技术故障一律退款和不得保留旧有效稿规则；不撤销普通原生有效性、同目标模型、唯一结算及原删除政策。

## 本次权威产物

- [backend.md](../technical/backend.md)：BE3-01–07、代码入口/事务与六类结算边界、统计及AC-301–314/DB3/UIA追踪。
- [ai-integration.md](../technical/ai-integration.md)：按N循环/lastValid整包、独立两个预算与context、六类stop_reason映射、三协议快照、版本化首稿/审稿/重写system与user模板。
- [API索引](../technical/api/index.md)、[生成/状态](../technical/api/generation.md)、[管理计划](../technical/api/administration.md)、[后台预览](../technical/api/presets.md)：严格字段与结果联合、readonly NativePolicy、动态N、attempt/accepted/final版本、outcome/notice、impact/revision、preview/发布闭环。

## 相对BE01的主要变化与接续条件

1. 运行按受理N（0–99），基础共享2次独立；通常无基础纠错为2k+2次调用，数学界2N+4。N1最多6/N2最多8；N99计数界202不代表会用满，600秒先到可结束。**流程执行测试最多2轮，配置99/版本100/公式只静态或字段校验，不运行3–99轮。**
2. 有效包故障交付为valid/service_incomplete，同事务最终包+version/stop_reason+原charge consumed；原failure_code/category为NULL。取消/下行断连/DB未知/崩溃各守原规则，不借Q02伪装成功。
3. SSE stage的attempt_content_version/repair_attempt与candidate.content_version、最终final_content_version分开。尝试v3失败、最后有效v2可合法最终交付v2；新稿有效才整包替换，无跨稿拼字段。
4. validated和status、后台preview/管理读取/发布确认保留content_outcome及completion_notice。五类有效结论可区分，UI不把审稿通过当独立质量通过；已有恢复途径重读时保留提示，不增加刷新续传/中间稿库。
5. 管理groups/impact返回真实NativePolicy供只读展示；付费N独立0–99；后台增强预览固定1、不读计划N。DB02现有字段足够，无变更请求，无竞争真源。

frontend-bob可在控制角色接收后用API-301–304建立严格schemas/fixtures/reducer：覆盖N0/1/2流程及N99静态权益显示、尝试3最终2、incomplete可保存、pending禁保存/有限核对、revision冲突重新预览、mode先保存/后预览/手动发布。不能从原型猜字段或继续消费旧passage.delta。status沿owner/token/1小时终态及draft TTL，仅核对已存在终态。

后端实施按BE3-07与DB3-V01–06：先schema/快照/仓储，然后共用pipeline/三协议/事实回调，接终态与流、计划/预览闭环。候选0017实施先核最高号；迁移与源码尚未执行。技术总门禁仍需前端架构及交接，不以本稿推进实现。

## 文档维护、验证与未决

- 唯一当前后端入口为上述七份M003-BE-02；稳定API-301–304、BE3-01–07、AI3-01–06保留，新增BE3-V13/14跟踪AC-313/314。旧研究、审批、冻结证据、DB/UI/产品原件和控制面未修改。
- 静态检查方法：七份版本/Markdown路径与锚点/代码围栏/AC-301–314与BE3-V01–14/六类stop_reason/旧规则定向搜索；检查结果PASS：7/7版本一致，本地路径与锚点0断链，围栏闭合，AC-301–314/BE3-V01–14及六类原因齐全；定向搜索未发现活动正文继续固定用户一次或内容故障一律退款。本轮未执行Go测试、DB约束/迁移、真实模型或UAT，不能把文档检查写成运行PASS。
- BLOCKED：无真实业务/DB设计阻塞；开放CR：无。后续前端接收有不可实现字段时回原角色就地修订，不改其他责任原件绕过。
- 未验证：实际多轮效果、误漏报、调用频率/成本、首可读内容/最大无新内容/总时长；CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX保持workflow原入口状态，不扩张为本期全量修复。
- 本轮产品planning读取超过8k软目标，原因是三角色修订/用户确认与DB新增终态完整核对；代码和基座另计，运行token/usage unknown。正文就地收敛增量，没有另建历史流水报告；未执行新会话交接测试，不把静态自检等同接收成功。

下一步由控制角色审阅原件并按权限接交；本角色不修改状态。授权仍不包含真实收费批次、生产部署或替用户验收。
