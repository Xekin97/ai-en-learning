---
id: API-303
version: M003-BE-03
status: awaiting_user_review
milestone: M003
---

# 管理计划内容服务

CAP-303、DATA-301、PAGE-208、AC-304/305/306/314；UIA-M003-304–306；全部admin-only，普通身份403。本文`Plan=visitor|basic|pro|plus`。路径省略 `/api/v1`；[M002 API-103](../../../M002/technical/api/administration.md) 未变字段/传输规则保留。所有配置写入与impact POST做原CSRF、严格字段预检；不调用模型、不扣额度。

## 完整读取与单计划修改

`GET /admin/groups` →200 `{items:Group[4],revision:string,native_correction_policy:NativePolicy}`，稳定顺序visitor/basic/pro/plus。Group完整字段：

```text
{code:visitor|basic|pro|plus,priority:int,rolling_24h_limit:int|null,max_entries:int,
 allowed_lengths:Length[],models:[{id:string,display_name:string,enabled:bool}],
 content_review_enabled:bool,content_repair_limit:int[0,99]}
```

基础校验恒包含；NativePolicy严格类型见API-301，由后端m003-native-policy-v1常量提供max_calls=2/scope=logical_request/ editable=false。管理页读此字段显示真实系统预算，不从fixture或计划N猜；无可写native_validation/native_correction_policy/max_calls字段，直调附加这些字段按未知字段拒绝。revision是原全局签名版本，不传内部数值。NULL quota=不限，0=禁计划次数；模型卡/extra例外沿原规则。

`POST /admin/groups/{code}/impact-preview` 与 `PUT /admin/groups/{code}` **同一完整请求类型**：

```json
{"expected_revision":"opaque-current","priority":20,"rolling_24h_limit":20,"max_entries":12,"allowed_lengths":["short","medium"],"model_ids":["model-id"],"content_review_enabled":false,"content_repair_limit":0}
```

新两字段必填且严格bool/整数非null；visitor/basic只false/0，pro/plus只false/0或true/整数1–99；Pro/Plus独立保存、初始均1；缺字段、true/0、false/非0、100、负数、小数均422 validation_failed，field_errors用JSON Pointer `/content_review_enabled`、`/content_repair_limit`。原max_entries≥1、priority≥0且全计划唯一、quota null或非负整数、有效model_ids、受支持length约束保持。未知计划404；重复priority为409 duplicate_priority。无模型/无长度/0 quota仍是警告可保存，不因服务开关改变约束。

impact 200完整data（在一个配置共享锁快照下产生）：

```text
{revision:string,base_users:int,active_trial_users:int,priority_changed:bool,
 may_change_effective_plan:bool,loses_all_models:bool,
 content_service_change:{before:{content_review_enabled:bool,content_repair_limit:int[0,99]},
 after:{content_review_enabled:bool,content_repair_limit:int[0,99]}},
 applies_to:"new_requests",in_flight_policy:"accepted_snapshot",
 usage_reset:false,trial_dates_changed:false,native_correction_policy:NativePolicy,
 warnings:("content_service_removed"|"no_models"|"no_lengths"|"zero_plan_quota"|"effective_plan_may_change")[]}
```

warnings去重，按上表枚举顺序输出。content_service_removed仅true→false；no_models按实际无启用且未移除的计划模型，no_lengths按空数组；zero_plan_quota仅limit=0；effective_plan_may_change取may_change_effective_plan。原base_users是此基础计划账号数，active_trial_users是有效目标试用人数，不承诺两者不重叠、不是精确“此次失去增强人数”；visitor人数仍按现有可统计主体口径，不编造人数。前端显示计划中文名来自code本地文案，before/after来自响应；关闭警告文案依design/copy.json，明确只影响新请求。优先级导致有效计划变更时提醒可能获得/失去增强，不用单计划开关猜每人结果。

PUT 200仍 `{group:Group,revision:string,native_correction_policy:NativePolicy}`。配置排他锁→校验expected_revision→再次完整校验→原计划/模型/长度及新字段一次事务→AdvanceConfiguration一次；成功后读新值。响应不假定客户端已经点过预览；直接API也完整校验，无新“预览凭据”存储。UI必须对当前本地草稿先impact再确认，预览后任何字段编辑即失效，发送PUT须与预览规范化body完全相同。取消修改不请求PUT。

## 冲突、异常与优先级批量

impact/PUT的409 revision_conflict沿Problem，`context={current_revision:string}`；不混合保存。前端保留本地未保存输入→GET读取服务端最新四计划→并排核对→用户保留本地修改后用最新revision重新impact→再次确认PUT。不能把current_revision自动塞进旧PUT重试。原body malformed=400、非法字段422、CSRF403、数据库暂不可用503/500；失败不抹本地输入。PUT响应丢失先GET重读；若值已匹配可以显示当前已保存配置，但不虚构原请求成功回执，不再次推进revision。

`POST /admin/groups/priority-impact`、`PUT /admin/groups/priorities`仍用 `{expected_revision:string,priorities:[{code:Plan,priority:int}]}` 恰好四行、唯一code/priority、int≥0。不得带内容字段；只改priority，不重置额度或试用时间。

priority-impact 200在原 `{affected_base_users:int,affected_trial_users:int,revision:string}` 增加：

```text
{content_service_by_plan:[{code:Plan,content_review_enabled:bool,content_repair_limit:int[0,99]}],
 may_change_content_service:bool,applies_to:"new_requests",in_flight_policy:"accepted_snapshot",
 usage_reset:false,trial_dates_changed:false,native_correction_policy:NativePolicy}
```

content_service_by_plan固定四行从同一配置快照读取；may_change_content_service用原已有基础/试用优先级前后胜出逻辑，检查是否存在赢家变化且两个计划服务配对不同的有效试用账号（EXISTS，非逐用户报表）。false不能推导“有效计划没变”；人数仍是现有受影响基础/试用计数，不是增强净增/净减。PUT成功仍 `{items:Group[4],revision,native_correction_policy:NativePolicy}`，含新字段；冲突和预览失效处理同单计划。

关闭成功后新GET generation-options及公开预设详情都从实时有效计划投影false/0，所有用户权益摘要同步显示不含增强；已有run的started快照不变。管理前端不得硬编码pro/plus永含增强。初始化只依DB3-02一次迁移，不在HTTP启动/读取中重seed。

数字0与关闭联动，1–99与开启联动；重新开启建议置1，用户可继续修改。预览before/after中的N按实际整数显示，不固定“最多1次”；基础策略总保持同一个只读NativePolicy。N=99只做配置保存/读取/边界验证，不触发99轮模拟；流程执行测试最多2轮，运行时按受理N及统一deadline控制。

BE03仅因统一契约版本重发本管理API，字段/校验/影响预览语义不变。USER-M003-STREAM-FIRST去除用户生成页轮次呈现，不删除本页0–99配置、基础2次只读策略或后台统计。
