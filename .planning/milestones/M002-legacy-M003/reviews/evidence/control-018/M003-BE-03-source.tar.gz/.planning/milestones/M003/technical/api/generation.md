---
id: API-301-302
version: M003-BE-03
status: awaiting_user_review
milestone: M003
---

# 权益、动态生成流与唯一终态

CAP-301/302/305，DATA-301–303，PAGE-204/215/216，AC-301–303/306–308/310–314及UIA-M003-301–303/308。V=访客、L=本人学习者；管理员走独立预览。以下路径省略 `/api/v1`；公共封套/错误继承[index](index.md)。新增字段均必填；只有显式null可空，整数必须JSON整数，拒绝未知/重复字段及尾随JSON。

## API-301 选项和系统基础策略

```text
ContentService = {native_validation:true,content_review_enabled:false,content_repair_limit:0}
               | {native_validation:true,content_review_enabled:true,content_repair_limit:int[1,99]}
NativePolicy = {version:"m003-native-policy-v1",scope:"logical_request",max_calls:2,editable:false}
Plan = visitor|basic|pro|plus
ValidContentOutcome = basic|review_passed|repaired_passed|limit_finalized|service_incomplete
CompletionNotice = "content_review_incomplete"|null
```

ContentService严格关联配对；visitor/basic固定关闭0。NativePolicy由后端系统常量映射，pipeline版本定位，不来自计划表可编辑值；基础预算覆盖首稿与所有后续稿，不能重置。用户/管理写接口不得接受native_policy/max_calls等系统字段。

`GET /generation-options` V/L：保留M002完整data，新增 `configuration_revision:string,content_service:ContentService,native_correction_policy:NativePolicy`。原effective_plan仍 `{code:Plan,origin:visitor|base|trial,trial_ends_at:Time|null}`。revision及内容权益同配置共享锁读取；可用性仍检查模型/长度/次数，增强不免预检。页面依实际开关/N，不凭计划名、模型/次数卡推断；试用只取唯一胜出计划。

`POST /generations/stream` 请求仍严格 `{model_id:string,meaning_language:zh|en|ja,scenario:story|discussion|business|news,length:short|medium|long|xlong,entries:string[]}`，64KiB及原词表/配置授权限制不变；不接受content_service/mode/prompt/provider/技术预算。受理事务重新解析当前权益：旧options下输入仍合法则接受，以started覆盖预估并刷新options供下次使用；本次快照之后不变。输入失效422，权限403，active冲突409 generation_in_progress，次数不足429 quota_exhausted，配置/凭据不可用503 generation_unavailable；预检拒绝不调用。

受理事务配置共享锁→主体锁→锁后业务时间→完整快照/模型连接/run/entries/原charge/开始事实同事务。COMMIT确定未成功返回Problem；ACK不明用已分配run ID限时读回，完整run/charge确认才继续，否则503 temporarily_unavailable并交原恢复，不宣称未扣次。POST不自动幂等重放；新生成必须用户新意图，普通/用户预设共享每主体一个active槽。

## API-302 SSE 精确字段（m003-stream-v3）

授权为 [USER-M003-STREAM-FIRST](../../reviews/requirements-feedback.md)。BE03改变公开投影：**首个基础有效稿只提供原词释义预览；正文、标签、提示与位置仅在最终有效结算后整包交付**。不公开中间正文、审稿/返修阶段、意见或轮次；管理配置和内部调用事实保持。BE02 的 generation.stage / passage.snapshot / generation.candidate 被移除，无兼容分支。

受理COMMIT确认后发送200 SSE并flush started成功才Open；started写失败无上游调用，按stream_failed结算。随后Open失败在本SSE处理，不改JSON响应。原headers/no-store/15秒注释heartbeat保持，每次write/flush设置10秒截止并续设。POST fetch读取，无Last-Event-ID、流重连或事件回放。注释heartbeat不占seq、不改变页面进展。

所有命名事件seq从1严格连续递增；单writer序列化，内部阶段不占公开seq。下表是完整data；所有字段必填，只有显式null可空。`V`为内部有效稿身份整数1..N+1（最多100），仅供一致性验证，不是百分比或用户步骤。

| event | 完整data |
|---|---|
| generation.started | `{seq:int,contract_version:"m003-stream-v3",run_id:string,generation_token:string,snapshot:RunSnapshot}` |
| generation.progress | `{seq:int,phase:composing|finalizing}` |
| generation.learning_ready | `{seq:int,content_version:1,entries:LearningEntry[]}` |
| generation.validated | `{seq:int,run_id:string,final_content_version:V,result:Result,content_outcome:ValidContentOutcome,completion_notice:CompletionNotice}` |
| generation.failed | `{seq:int,code:FailureCode,quota_refunded:true,retryable:bool,request_id:string}` |
| generation.cancelled | `{seq:int,quota_refunded:false}` |
| generation.settlement_pending | `{seq:int,code:"settlement_unconfirmed",request_id:string}` |

`RunSnapshot={configuration_revision:string,effective_plan:{code:Plan,origin:visitor|base|trial},content_service:ContentService,native_correction_policy:NativePolicy}`。受理N用于服务与协议一致性，保留为技术元数据；不是用户进度或摘要文案输入。生成页不显示系统预算、返修上限/次数，也不从计划名推断进度。版本定位系统策略，status不以新部署常量覆盖旧快照。

`LearningEntry={entry:string,entry_meaning:string}`；恰含本次全部原词各一次、输入顺序，非空字符串、无额外字段。它是首个基础有效包中 `targets[].{entry,entry_meaning}` 的只读投影；不是新模型产物、最终资源或跨稿缓存。模型原输出仍passage在前，不改成词义优先的生成任务。不依赖词典服务、数据库新列或额外调用。

`Result={passage:string,tags:string[],targets:Target[]}`；`Target={entry:string,entry_meaning:string,hint_phrase:string,hint_blanks:[{start:int,end:int}],occurrences:[{surface:string,start:int,end:int}]}`。原词每项一个、输入顺序、非null数组；offset为Unicode code point半开区间。完整规则继承 [M002书架](../../../M002/technical/api/identity-library.md)。终态必须带完整校验后的全部字段，不从词义预览补字段。

### 真实事件与页面时间线

| 时点 / 后端事实 | 公开事件 / 安全展示 | 尚不能宣称 |
|---|---|---|
| T0：受理事务已提交，未等提供方Open | started：已受理，等待生成；可取消 | 尚无词义/正文，不能说模型已开始写作 |
| T1：首稿调用provider_invoked=true事实已确认落库 | progress(composing)：正在生成 | 无百分比、剩余时间或完成承诺 |
| T2：首稿连同学习字段通过全部基础校验 | learning_ready：可先查看这些原词的词义；短文仍在生成 | 不展示内部正文/标签/提示；释义预览不可保存 |
| T2至T3：内部审稿/条件重写/基础恢复继续 | 不发内部阶段事件；保留原词预览和正在生成状态 | 心跳不是新进度，不能编造第k次或新词义 |
| T3：pipeline已选出唯一最终有效包，开始完成事务 | progress(finalizing)：正在完成，尚未开放保存 | 不是已成功；数据库仍可能待核对 |
| T4：valid及charge/最终payload同事务确认 | validated：原子显示全文、标签、全部词义/提示/位置；可保存/承接 | outcome不代表独立质量保证 |

T0是后端最早可感知点，不等待模型首字；提交前客户端只显示“正在提交”。T1/T2没有固定毫秒保证；无数据时诚实等待。N=0时T2到T4可能极短，前端允许同一绘制帧直达完成，不能人为留住词义预览制造动画。N>0时词义预览提供真实可读内容；其通用释义仍可能在最终包改善措辞，最终整包替换且不得保留旧词义/hint/offset。不得为保持预览而限制内部整稿返修。

### 事件状态机、身份与幂等

- started严格一次且seq=1；composing最多一次，只来自首稿真实调用发送证据，后续基础纠错/审稿/返修不重发。learning_ready严格最多一次，必须在composing之后，来自版本1首个整包有效稿。它不要求增加模型调用或提前解析未校验JSON。
- finalizing最多一次，正常有效交付前发生且在learning_ready之后；选包后不再发模型调用/词义事件。可能随后validated，也可能failed/cancelled/pending；未提交的内存有效包不算成功。
- 正常流有效序列：started→composing→learning_ready→finalizing→validated。首稿失败可从started/composing直接failed；主动取消可在任意非终态位置；pending后服务端关闭流并进行状态核对。EOF无终态也进入待核对，绝不自动保存/退款/重新POST。
- 两轮内部返修仍只有上述五个公开事件，final_content_version可为3；学习预览version1与final version3不是漏事件。返修v3无效而lastValid=v2时最终为2；没有公开candidate或attempt约束。状态查询可在缺失任何流事件时直接恢复DB完整终态。
- outcome关联不变：basic仅N0；review_passed增强且无返修；repaired_passed增强且末审pass；limit_finalized预算用尽且末审issues；service_incomplete是内容技术故障有有效稿。前四类notice=null且用户统一“生成完成”；只有第五类必须notice=content_review_incomplete，持久提示“内容审校未完成”，可保存且仍计一次。不得展示上限用尽或审稿通过徽章。
- seq重复/倒退/跳号、未知事件/phase、版本越界、漏必填/多余字段、重复learning、在finalizing后收到非终态进度、错误outcome/notice均停止消费并查询status，不能忽略后拼包。各事件先校验再reducer，绘制可以合帧。
- validated/failed/cancelled只有一种DB业务终态。重复同一DB终态的status/取消确认不重复渲染结算、不重复保存或扣退额；迟到active/503/旧流不覆盖已确认终态。同run两个已确认终态实质冲突则锁住新保存并核对/报告契约错误，不能后到获胜。重复SSE帧仍属于传输协议错误；“幂等终态”不是放宽连续seq。
- failed/cancelled清除词义预览且禁保存；pending可保留标为预览的词义，但正文不存在、保存禁用。完成后只用最终Result，保存后的当前结果继续保留notice。状态result不可用不以词义预览重建。
- `contract_version`标识当前响应协议，不是持久业务版本；status按本契约投影既有DB事实，pipeline_version_snapshot仍用于查找该run的技术策略。配套切换不新增旧协议兼容。

### 原型接收与完整fixture

[stream-v3/index.json](../fixtures/stream-v3/index.json) 是版本化fixture入口；其中的文件每条 `wire[]` 都是 `{event,data}`，无省略字段、连续seq；可直接序列化为 `event: <event>\ndata: <JSON(data)>\n\n`。`status_responses`为真实JSON封套，`expected`是测试断言，`internal_evidence`只解释合成路径、禁止接入页面状态或模拟计数。

允许展示字段：phase→本地高层文案，learning_ready.entries→原词词义预览，validated.result→最终文章与资源，completion_notice→持续异常提示，失败code/退款事实→既有错误文案。run/token/seq/contract_version/content_version/final_content_version/N/native policy/outcome内部分类只供协议、权限与一致性处理；token不得呈现在URL/DOM/localStorage。原型不得自行编造stage或靠setTimeout推进“后台阶段”；演示“下一事件/播放fixture”可以调度已有wire帧，但时长必须标合成，不能声称实际服务时延。

### 故障、核对与权限

FailureCode仍 `authentication|authorization|rate_limited|provider_unavailable|protocol_error|schema_error|content_validation_failed|generation_timeout|generation_failed`。仅真正失败终态使用generation.failed；六类内容故障且有完整有效包按 [AI3-02](../ai-integration.md#ai3-02-六类内容故障与保留稿) 发validated/service_incomplete，不先failed再成功。retryable仅表示用户可新意图重试，不自动重发本请求。认证/授权错误false，其他尊重真实ProviderError；不泄露上游正文。DB关键事实失败先核对，不能套内容故障成功。

`GET /generations/{run_id}/status` V/L，X-Generation-Token，无query/body，200：

```text
{contract_version:"m003-stream-v3",run_id:string,status:active|valid|failed|cancelled,snapshot:RunSnapshot,
 final_content_version:V|null,result:Result|null,can_save:bool,quota_refunded:bool,
 content_outcome:ValidContentOutcome|failed|cancelled|null,completion_notice:CompletionNotice}
```

同一一致读取run、charge和结果。status只返回持久终态事实，不新增临时phase或重放词义预览；active的outcome/version/result为null，can_save=false，refund=false；failed/cancelled的outcome同status、version/result=null、can_save=false，只有failed refund=true。valid读取run.final_content_version/outcome并导出notice，不按调用次数猜；有效draft仍可用时result完整/can_save=true（V表示可claim）。已保存的本人学习者可沿既有generation_run_id读取其本人batch组装同一结果，can_save=false；已丢弃/过TTL无结果、已删除batch或visitor已经claim给账号时result=null/can_save=false，仍在允许状态窗口内返回outcome/notice；不可用访客token读归属他人账号的batch。result不可用不抹掉故障提示、不重新生成。

使用VerifyRunToken+DB主体/owner检查，待保存draft还需token digest及原expiry/disposition；终态沿1小时能力窗口，草稿默认30分钟。404不匹配/资源已删除，410能力过期，503 DB暂不能确认；前端404/410停止核对并关闭保存，保留安全说明、重新生成是新意图；503/active短核对后仍未知保持pending。立即查一次，最多每2秒、总10秒，未收敛提供显式“重新核对”，不无限轮询。此GET不调模型、不续流，不把token写本机/URL；刷新丢token不新增恢复能力。已有合法恢复途径重读结果时notice必须稳定，不能把UI“刷新仍有提示”解释为新续传平台。

`POST /generations/{run_id}/cancel` 原权限/header/{}→200 `{status:cancelled|valid|failed,quota_refunded:bool}`，仅确认DB终态才200；未知503 settlement_unconfirmed。先CAS确认取消，再cancel context；完成先赢则valid（可能service_incomplete），用status读取最终包/notice；失败先赢failed/true。重复cancel不二次结算，不把已有内部有效稿或词义预览当拒绝取消理由。取消本身不触发内容故障交付。

客户端断连/write失败沿原技术失败退款；valid先提交后断连仍valid不退款。execution deadline在有lastValid的内容阶段可带提示完成，其独立完成/核对ctx不继承到期；客户端取消/断连另行检测并参与CAS。保存/放弃/claim沿M002 API-006与原TTL/幂等；服务器要求valid+完整最终资源，无论内部几次调用始终一run一charge，service_incomplete不额外扣次或退款。
