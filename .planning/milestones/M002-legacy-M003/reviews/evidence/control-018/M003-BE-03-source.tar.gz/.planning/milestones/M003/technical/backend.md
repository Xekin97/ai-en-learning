---
milestone: M003
stage: technical-design
role: backend-architect/base
agent_name: backend-alex
version: M003-BE-03
status: awaiting_user_review
date: 2026-10-10
---

# M003 后端可实施增量

输入 [M003-PRODUCT-03](../handoffs/product.md)、[M003-DB-02](database.md)、BE02/FE01与UI04及待审实现；本轮按 [TRANSITION-M003-017](../reviews/backend-stream-first-016.md) 和 [USER-M003-STREAM-FIRST](../reviews/requirements-feedback.md)重开。用户明确取消生成页突出内部审稿/返修与次数的展示要求，优先于旧PAGE-204等对应条款；其他产品规则继续有效。原七份BE02已与technical-012冻结快照逐字核对一致后修订，冻结原件未覆盖。Profile1.0与model-routing-v1不迁移。

## BE3-01 选择与范围

保留Go模块化单体/PostgreSQL、三协议 `ai.Gateway`、run/charge/draft/usage/preset版本。真正变化是 **公开流由中间正文+内部阶段改为词义预览+最终整包**，不是将旧页面第k次文字隐藏。内部仍按“受理与组织目标词→生成→基础校验→同目标模型审稿/条件返修→最终结算”；组织词条是现有输入校验/快照/提示组装，不新增模型规划调用。基础全请求2次只读、内容N整数0–99初始1/0全关、两预算独立、上限后有效定稿、一run一业务次数、Q02有效稿故障交付全部保持。

| 可行公开方式 | 收益 | 成本/风险 | 本版取舍 |
|---|---|---|---|
| 首稿正文逐字显示、内部稿整包替换 | 首个正文可能更早可读 | 用户读中的情节会改写，部分正文无保存资格，需增量安全解析/版本UI | 不采用；BE02输入并非约束 |
| 首个完整基础有效包仅提取原词词义，正文最终交付 | 已有数据与调用；等待中有可读材料；正文一次稳定呈现 | 第一有效包之前没有新内容，不能声称比正文流更快；最终释义可能调整 | 本版技术选择，交原型具体审阅 |
| 全程仅高层状态直到最终结果 | 最少临时状态 | 丢掉增强处理期间已经可用的词义，长等待更空白 | 可行但不选 |
| 额外词典/词义LLM或重排prompt先产词义 | 潜在更早的词义 | 新成本/依赖或改变生成提示效果，需独立确认与验证 | 不引入，不作为实施项 |

源码证据：`generation/service.go`受理保存原词；`ai/contract.go`中entry_meaning属于模型Candidate/ValidatedBatch；当前生成prompt先passage再targets；`pipeline.go`首次validator.Validate成功才有完整可靠词义。故无需改算法/提示顺序或加调用；公开adapter把首次有效Candidate投影为learning_ready，后续Candidate只更新内部lastValid。词义是输入原词的通用字典释义，不应随剧情改义；模型仍可能改措辞/纠正表达，终态必须用最终完整包替换全部预览，不把预览当最终学习资源。

T0提交成功即started可感知，T1首稿发送事实持久后composing，T2首次整包基础有效后词义预览，T3选出最终包准备DB事务后finalizing，T4确认valid后完整正文/学习资源与保存资格到达。T0前仅客户端提交状态；T1/T2之间只有真实等待，没有释义/正文占位内容、百分比或计时假阶段。15秒注释心跳只保活。首有用内容改为词义，可能晚于BE02首正文；各时点与无新内容间隔均未实测，不承诺“更快”。普通流程可能同帧完成，不为动画延迟终态。精确字段、状态机和展示白名单在 [API-302](api/generation.md)。

选择与既有规则的状态：用户展示方向及后台先行顺序为CONFIRMED；本版公开投影为授权范围内的具体技术设计、整版awaiting_user_review，不冒充用户已逐字段批准。没有新增费用、权益、存储或业务计次选择，无业务BLOCKED项。180/600秒保护、同模型、内部统计及Q02语义继承BE02，不人工增加生成链路。

## BE3-02 追踪与模块入口

以下相对backend/；无变化领域继承M002契约，不重写完整历史。

| CAP / DATA / API | 修改入口 | 责任 |
|---|---|---|
| CAP-301；DATA-301/302；API-301 | `internal/entitlement/service.go` Resolve/Options；`generation/service.go` start；`httpapi/catalog_handlers.go` | 唯一胜出计划读N，内容与模型卡/次数卡分离；同锁revision、origin、全请求快照；输出NativePolicy |
| CAP-302；DATA-302/303；API-302 | 新 `generation/pipeline.go`；`ai/{contract,continuation,gateway,openrouter,protocol_stream,validator}.go` | 请求级两个预算、lastValid整包/候选身份、公开投影、严格Review及六类停止原因、同连接、早停和deadline |
| CAP-303；DATA-301；API-303 | `admin/groups.go`；`httpapi/{admin_handlers,group_handlers}.go` | 0–99/开关配对严格读写、只读系统策略、impact/优先级/revision冲突；四行保留 |
| CAP-304；DATA-304；API-304 | `generation/{presets,preset_preview,preset_catalog,preset_cleanup}.go`；`httpapi/{preset_handlers,preset_preview_handlers}.go` | mode版本绑定与固定0/1；共用pipeline/Q02，preview恢复notice与手动发布 |
| CAP-305；DATA-302/304；全部 | `generation/{usage,preset_usage,settlement,charge}.go`、`ai/usage.go`、`generationtrace/*` | 每调用发送/费用事实、终态CAS、文章/调用统计，禁止审稿私有意见入库 |
| CAP-302/304；DATA-303/304；API-302/304 | `httpapi/server.go`新增两个GET路由；`generation/service.go`、`preset_preview.go` | owner/token/TTL限定状态核对，DB派生最终版本/outcome/notice，不再次调用 |

完整HTTP字段以 [API索引](api/index.md)为唯一真源。系统基础策略来自 `ai.NativeCorrectionLimit=2`/策略版本常量（拟名），读取投影和pipeline消费同源；数据库不新增可写基础预算，客户端写入字段拒绝。

## BE3-03 DB3-03–06 具体落点

| 操作 / 拟函数 | 同事务职责 |
|---|---|
| Start/StartPreset→acceptContentPolicy | 配置共享锁→主体锁→锁后Now→Resolve唯一计划→模型/词表/额度→run完整v1快照/entries/Reserve charge/开始事实。N来自计划，不从charge推断；origin=Plan.Origin；extra不改内容N；模型连接BindSpec锁内一次；commit确认后started，无事务等待模型 |
| StartPreview | 配置共享锁→管理员存在→当前draft/version/已保存mode匹配→绑定连接→完整preview快照；basic0/enhanced1，不读管理员计划，不写user charge |
| usageRecorder Reserve/MarkInvoked/RecordReview/FinishUsage | owner+call_no唯一串行；预留失败不发；审稿事实持久后才下一返修；true/false/NULL证据及错误回传详AI3-05；不允许仅log关键事实错误继续成功 |
| CompleteValid(run,PipelineResult) | 配置共享锁→主体锁→active CAS→validateContentOutcome→原charge consumed/学习成长分析→最终draft和outcome/final_content_version/content_stop_reason一次提交。`PipelineResult={Package,Outcome,StopReason}`只由服务端生成，HTTP不传它 |
| CompletePreview | 配置共享锁→preset行锁→active CAS及同一内容事实验证→完整preset_previews→仅匹配version/hash/configuration/mode且空preview_id时关联。写同一包的final_content_version/outcome/stop_reason；旧mode晚完成可独立valid但不能覆盖当前draft/公开样文 |
| SettleTerminal/ReconcileFailure/SettlePreview | 取消/真正失败写outcome及原状态/扣退次同事务，version/reason=NULL。service_incomplete直接走CompleteValid/Preview，不能先退款再转成功；pending review转indeterminate，不捏造pass/issues |
| SavePreset/PublishPreset | mode和生成条件一起版本化；仅紧邻旧草稿纯标题且mode相同继承预览及notice；发布排他配置锁+预设锁+revision/current draft，检查完整valid payload/关联/模式/终态事实，含未完成有效预览人工发布 |
| 0017候选迁移/启动 | 按DB3-02/08一次加字段、精确初始Pro/Plus1、revision一次；实施先核最大号。启动验证完整schema/配置，缺字段或非法配对失败关闭受理，不重seed、不覆盖模型/用量/期限 |

`validateContentOutcome`需核对：basic无内容调用；review_passed交付版本1审稿pass且无repair；repaired_passed交付版本已原生有效且末审pass，至少1次实际repair、不超过N；limit_finalized实际内容预算耗尽且最终有效稿末审issues；service_incomplete有本请求lastValid包及AI3-02六类原因，必要调用/审稿事实已持久化。通用规则：run snapshot=所用模型/pipeline/内容N；版本在1..N+1（preview≤2，basic=1）；最终版本来自包身份，不倒算call_no或尝试次数；只有incomplete原因非NULL，原failure_code/category保持NULL。

候选编号与审稿绑定只在请求内存编排，usage按call_no可顺序审计，不为多轮加表或持久中间稿。完成事务使用该pipeline产出的不可变完整包与事实，不能接受外部宣称“原生有效”。同稿基础纠错不增加版本。保存/claim继续一run→一batch，沿原归属/幂等/删除例外，不因内部返修新建业务run或再扣额。

## BE3-04 停止、context与唯一终态

accepted ctx关联用户连接，execution ctx在其下设整体600秒，每调用再设180秒；单次/执行deadline与显式cancel/client disconnect独立识别。内容deadline触发关闭上游并选lastValid后，使用独立有界10秒completion ctx完成Q02，不能复用已到期execution ctx让有效交付必然失败。执行截止不允许发新模型调用；DB完成/确认窗口不是模型加时。

调用预留前/发送前、接收后、validator循环、review事实提交后和成功CAS前均检查取消/终态。显式取消先确认user_cancelled提交再cancel registry；取消写/读不明不能假定已取消，返回pending核对。连接断开/write失败停止模型并按原stream_failed结算；不能将其归为content_transport_error。已进入网络发送的极短竞态可产生费用，停止后不编排下一阶段，迟到usage不复活run。

客户端断连与completion ctx独立取消保护配合：开始完成前若已断连就不尝试Q02；完成过程中监测下行ctx并争取原失败CAS。最终以数据库已提交终态为准，无法保证远端收到结果与DB提交原子一致。valid先赢（含incomplete）则取消/传输失败不退款；取消/失败先赢则不得写draft。一个请求至多一个业务终态，流丢失不改变已提交结果。

关键事实或最终提交异常，先用新鲜5秒context核对run+原charge+最终payload；valid返回库中包/版本/outcome/notice，不能用内存候选假定成功；cancelled/failed投影原值；不能确认则settlement_pending且不开保存。确认仍active才按既有server_failed退款，extra退原item且不延长期限；绝不先退款再宣service_incomplete。preview helper改明确confirmed/error，错误不伪报failed；沿现有registry/maintenance补结算，无新持久任务平台。重启读已提交终态不改写，未完成且内存包丢失沿原失败退款，不重放AI。

receiver关闭body解阻塞、context取消、事件channel可中断；单goroutine writer确保started/高层进展/词义预览/终态顺序；内部候选不直接发往客户端。status读取用VerifyRunToken+DB主体，不只依赖进程registry；待保存draft验证digest/expiry/disposition。终态能力沿1小时、草稿默认30分钟；本人已保存batch可沿原关联读取同一最终结果，不给访客token读取claim后的账号batch；删除/过期不重建。状态恢复的notice从run.outcome派生，不新增布尔列/文案副本/token持久化。

## BE3-05 调用、文章与质量统计

DB3-04/07是存储真源。provider_invoked=true才是确认调用，false明确未发，NULL未知；stage进入、repair_requested、usage行存在/收费已知都不是发送证据。`usageAggregate count(*)`不能继续冒充provider_calls，未知发送与未知费用分开展示；legacy/policy NULL单列历史未采集，不补零或basic。

按started_at半开窗口和entry_kind normal/preset、后台preview分别统计，先按run聚合再JOIN，避免多调用放大文章分母。全部受理Nall、增强E、实际审稿R、实际返修W（均按run去重）；返修率W/Nall、W/E、W/R，分母0=N/A。另报基础修正/审稿/内容返修实际调用数；两轮返修仍1篇、2个repair调用。预检拒绝不造run；取消/失败仍属受理分母。

牵强F和矛盾C按实际content_repair行的reason_codes标记文章，分别F、C、F∩C、F∪C；两轮分别触发F和C的同篇属于文章交集，调用交集只数同一调用同时有两类，二者不得混算。word_sense/缺前提/因果无据等映射other_content，基础错误不混入内容原因。Review发现、repair_requested与实际发送分别统计；末次issues未执行返修不增W。未知下界=true，上界加无true但有对应NULL的去重run；调用上界加对应NULL行，false不加，不从final版本差推算调用。

交付率=valid/全部受理用户run，包含service_incomplete；审校完成率=(review_passed+repaired_passed+limit_finalized)/增强受理，incomplete不算完成；审稿pass与上限定稿分开，incomplete按stop_reason报告，后台另列。独立质量通过必须由QA评阅，不能用valid或模型自报pass替代。费用/token保留known/partial/unknown及原精度，未报告不是0。只补现有诊断查询/测试SQL，不建统计平台或永久汇总副本。

意见/原句/推理/中间稿不入新列；review任务和包含issues的rewrite请求禁诊断正文捕获。原专用诊断授权/24小时、正文TTL、账号/批次/claim删除规则沿DB3-07/M002，不能为统计留下内容墓碑。

## BE3-06 实施与运维顺序

迁移/仓储→权益/管理→task-aware三协议Gateway与pipeline→普通及preview共用流/唯一终态→mode/状态查询→配套前端→隔离测试。新增字段必填；USER-COMPAT-001配套切换，不做旧passage.delta兼容层。已存在待审0017迁移文件，不等于已落库；实施接收后核对实际schema，不能重复初始化管理员配置。

沿原Docker/数据库部署，停写/在途结算/备份和隔离恢复依DB3-08，不新增基础设施。新事实写入后优先前滚，不能drop字段或恢复旧备份丢失数据。关闭增强仍用原计划revision，N=0仅影响新请求，不降级已受理增强。真实上线/在线配置修改需原发布授权，本轮未执行。

## BE3-07 实现与验证矩阵

以下为实施后必需验证；已有待审代码和开发证据不能替代BE03对齐验收，使用Go1.26.7、现有三协议HTTP替身及隔离PostgreSQL；不用生产/共享开发数据跑破坏用例，无真实收费调用。**CQ-14：所有流程测试实际内容返修最多2轮；0/99/100等仅配置/字段/静态循环与公式验证，不模拟3–99轮，不声称99轮已验证。** 与DB3-V01–06合并实施。

| AC / 验证ID | 修改与必要验证入口 | UI/DB追踪 |
|---|---|---|
| AC-301 / BE3-V01 | ai protocol_matrix/corrections及pipeline_test；普通无内容调用，三个协议同模型/连接；基础1/3次，增强N1≤6、N2≤8 | DB3-V02 |
| AC-302 / BE3-V02 | review/pipeline tests；首审pass早停、明确牵强/矛盾触发、两轮后pass/limit；平淡/开放结尾负例，模板组装无固定规划 | UIA-M003-302；DB3-V03 |
| AC-303 / BE3-V03 | validator/continuation/schema tests；全局基础2不重置，C1/C2/C3跨稿资源隔离；失败新稿不影响学习预览或最终包、已有v2且v3无效最终v2 | UIA-M003-303；DB3-V03 |
| AC-304 / BE3-V04 | admin groups HTTP/DB：四计划、独立0/99往返、-1/100/小数/null/缺失/开关错配、非管理员；NativePolicy只读同源且不能写 | UIA-M003-304/305；DB3-V01 |
| AC-305 / BE3-V05 | impact完整before/after N/人数/系统策略/关闭警告，0模型调用；同revision双写仅1成功，ACK丢失重读、重新预览 | UIA-M003-306；DB3-V01 |
| AC-306 / BE3-V06 | entitlement/generation集成：trial到期、优先级/开关/N变更与受理锁两种先后，快照不混合，用量期限不重置 | UIA-M003-301；DB3-V02 |
| AC-307 / BE3-V07 | generation_reservation集成：basic+模型卡+extra仍0，pro+extra保留N，没模型/次数预检拒绝0调用 | DB3-V02 |
| AC-308 / BE3-V08 | generation_matrix/races/trace与preview集成：started写失败/Open失败、首次完整词义/Unicode、无中间正文、原子最终包、deadline与独立completion ctx、EOF/pending、唯一终态 | UIA-M003-301/302/308；DB3-V03 |
| AC-309 / BE3-V09 | presets集成：basic0/enhanced1独立于计划99（不执行高轮）、模式切回/标题复用/旧调用晚完、incomplete恢复提示/人工发布、浏览零调用 | UIA-M003-307；DB3-V04 |
| AC-310 / BE3-V10 | usage及SQL夹具：文章/调用不同，跨两轮F/C交并、意图未发送、true/false/NULL、0分母、legacy、incomplete交付但非完成 | DB3-V05 |
| AC-311 / BE3-V11 | charge/settlement/claim集成：valid/incomplete/取消/断连竞争、最后SQL/ACK失败、extra跨过期退款；多call仍一charge、保存claim不重扣 | DB3-V03/06 |
| AC-312 / BE3-V12 | 替身记录首可读词义/首正文/最长无新内容/总耗时；QA冻结输入/模型连接/prompt/pipeline逐句评阅自然用词/前提因果/文体，分别交付/审校完成/质量及误漏报 | UIA-M003-309相关体验；真实质量待授权 |
| AC-313 / BE3-V13 | 六类stop_reason各替身，已有包/无包/关键DB错误三分；审稿失败最终当前包、返修失败最终旧包，status/流/preview notice一致，原failure_code=NULL | UIA-M003-303/308；DB3-V03 |
| AC-314 / BE3-V14 | 混合基础/内容计数与2轮早停/上限；静态确认循环读取N不是2，配置99/版本100仅存取边界；不执行3–99轮；系统基础预算独立不可写 | UIA-M003-304/305；DB3-V01/03/05 |

权限/隐私/TTL定向覆盖status跨账号/跨管理员/visitor claim后归属、expired/discarded/deleted、notice不抹掉；DB3-V06核对旧完整数据/删除/迁移恢复。前端fixture覆盖N0/1/2内部流程的同一公开序列和管理N99配置；final3及无效v3最终v2、pending、incomplete、模式冲突；用户页面不显示N或尝试稿。实现后按仓库现有隔离测试约定运行相关go test，不把本表写成PASS。

保留CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX及真实质量/费用/流式延迟未验证状态。本轮无新业务待决/DB字段变更；后端接收不等于技术总门禁完成，仍需前端架构交接。

## BE3-08 待审源码对齐与限定检查

当前工作树约50个后端改动是待审BE02实现，不修改/回退它们。本版尚未实现。后续实施owner需精确修订：

| 当前源码/测试 | BE03必要变化 |
|---|---|
| `generation/pipeline.go` PipelineHooks及HTTP两个流handler | 内部Stage/Review/lastValid仍可保留，HTTP不直通stage/snapshot/candidate；首发送事实只投影一次composing，首有效batch投影一次learning_ready，pipeline最终选包后发finalizing。无新LLM轮次 |
| `httpapi/generation_handlers.go`、`preset_preview_handlers.go` | 两入口共用轻量公开投影规则、连续seq；不为被过滤内部事件分配seq；started/status加contract_version；移除旧SSE名；取消/写失败仍及时打断模型 |
| `generation/status.go` / status DTO | 保留DB终态/同稿/notice/TTL与can_save；加协议版本，不读内存预览作为结果；不用新表保存公开phase |
| `pipeline_test.go`、`generation_matrix_integration_test.go`、`stream_boundaries_integration_test.go`、`m002_presets_integration_test.go`及既有races/trace | 区分内部调用/预算断言与公网事件断言；公开5事件在内部0/1/2轮都成立；最终包可与词义预览版本不同；Q02/断连/取消/提交未知仍分支；迁移旧passage.snapshot/candidate断言 |
| `ai/contract.go`、`content_tasks.go`、`continuation.go`、validator/usage/charge | 生成schema、prompt与内部版本/预算/调用事实不因展示而变；只取消对用户首稿增量输出依赖，不移除提供方解码/有限恢复和真实费用事实 |

本轮仅 `technical/fixtures/stream-v3` 和 `technical/evidence/check_stream_v3.py` 的确定性静态检查，不运行Go业务全套、数据库迁移、真实模型或UAT3302。检查证据见 [stream-v3-check.json](evidence/stream-v3-check.json)。其PASS只证明设计fixture/文档一致，不能证明实现或实际AI质量/延迟。
