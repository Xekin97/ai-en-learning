---
milestone: M003
stage: technical-design
role: backend-architect/base
agent_name: backend-alex
status: awaiting_user_review
version: M003-BE-03
date: 2026-10-10
input_version: M003-PRODUCT-03 / M003-DB-02 / M003-BE-02 / M003-FE-01 / M003-UI-04
---

# M003 生成流先行设计交接

backend-alex 按 TRANSITION-M003-017 与 [USER-M003-STREAM-FIRST](../reviews/requirements-feedback.md)交付七份BE03契约及直接供原型消费的事件fixture，建议awaiting_user_review。未改workflow、自批或激活下一角色；本交接不是实施、上线或UAT授权。运行请求为既有v1锁frontier `gpt-6-astra/high`，actual serving metadata/usage unknown，Profile1.0不迁移。

## 确认闭环与关键取舍

用户确认的方向：后台先设计、再由原型承接；生成页不突出审稿返修、不展示上限/轮次。Q01-B、Q03-RANGE99、Q02-A和两类预算/同模型/计次继续有效，用户没有授权隐瞒技术失败。旧PRODUCT03/PAGE-204和UI04对应展示条款已被最新明确指示取代，责任owner仍须同步原件。

本版技术选择：**受理即时可感知→真实调用开始→首个基础有效包的原词释义预览→最终整包文章**。内部算法仍按配置N运行，不新建规划或展示调用、不改变passage优先的模型输出顺序；只改变公开投影与交互消费契约。词义预览来自版本1完整ValidatedBatch，最终可能为v2/v3；最终全文、标签、词义、提示及位置原子替换，不保留预览字段混拼。普通请求可能直接同帧到完成，无人为延迟。第一有效包之前没有可读的新词义/正文，只显示受理或正在生成；首次有用内容时间未实测，不能称比原正文流更快。

可行方式及取舍在 [BE3-01](../technical/backend.md#be3-01-选择与范围)。没有新增费用、权益、持久字段或重大业务变化待决；本版具体技术设计待评审，不伪称用户已批准每个字段。若下游要新增词典/LLM释义调用、改业务终态或费用，须先提出新业务确认，不能据本交接直接实施。

## 当前原件

- [backend.md](../technical/backend.md)：内部/公开分层、四方案比较、真实时间线、模块/事务/统计、BE3-V01–14及待审源码精确影响。
- [ai-integration.md](../technical/ai-integration.md)：按N循环、两个独立预算、同目标模型、六类内容故障与Q02、提示模板和调用事实。
- [API索引](../technical/api/index.md)、[生成与状态API](../technical/api/generation.md)、[计划管理API](../technical/api/administration.md)、[预设API](../technical/api/presets.md)：m003-stream-v3事件/字段/状态机、status/取消/TTL/保存、管理0–99与后台basic0/enhanced1。
- [fixture索引](../technical/fixtures/stream-v3/index.json)：8条完整合成路径，普通、内部两轮、最近有效v2故障交付、pending后status交付、EOF未知、无有效稿失败、取消、后台增强故障交付；共享完整包在[packages.json](../technical/fixtures/stream-v3/packages.json)。内部只合成最多两轮，没有实际模型或业务pipeline执行。
- [轻量检查脚本](../technical/evidence/check_stream_v3.py) 与 [检查证据](../technical/evidence/stream-v3-check.json)：字段与文档表一致、连续seq、原词完整/offset、词义v1来源、最终整包、终态/保存/notice/退款以及版本/本地链接核对。PASS范围仅文档与fixture。

## designer-tony 接收合同

1. 读取API-302时间线、事件状态机及fixture索引；原型应实际加载JSON的 `wire[]`，按 `{event,data}` reduce展示。不能再以 `stage=repair2`、自编第k次或计时假后台阶段驱动生成页面。演示播放器可逐帧/合成间隔播放现有事件，标明是合成场景。
2. 初始状态与受理响应前区分；started后才能说已受理，composing后才能说正在生成；learning_ready前不得预填词义。词义只为预览，不能保存，最终Result出现后一次替换全部资源。使用字段白名单，不读取internal_evidence/expected给用户展示。
3. 同一条公开5事件序列适用于basic和内部两轮；两轮场景的final v3含不同释义措辞，用于证明最终资源确实替换而非补旧词义。Q02场景final v2而内部v3失败，必须完整文章+持续“内容审校未完成”+可保存，不能当作普通无异常完成。
4. pending/意外EOF不能开保存，按status_responses核对；状态valid无须此前收到candidate或最后词义，直接建立最终整包。failed/cancelled清预览，退款事实分别true/false。后台preview不混用户token或扣次，valid后另核当前draft关联才能发布。
5. 在用户要求的现有完整造文、计划管理、预设管理页面内做原型；计划管理0–99与基础2次只读保持，后台mode/真实用量保留。用户生成页无审稿轨道、N、k或通过徽章；故障事实持续准确可见。可访问性文案与布局由designer-tony负责，不由后端越权定义最终视觉。
6. 原型交付需要记录消费的fixture版本/路径和对应可操作场景，证明相同输入事件决定相同保存/警示结果；仍须用户完整页面视觉评审，不能把本次后端静态PASS当作UI批准。

## 跨owner同步依赖（精确范围）

这些是最新已确认展示方向的落实依赖，不是重新向用户询问N、Q02或流程顺序，也不由backend-alex修改其他owner原件。

| ID / owner | 受影响原件/稳定ID | 必须同步 / 完成条件 |
|---|---|---|
| BE3-DEP01 / product-maya | PRODUCT03 `product/pages/index.md` PAGE-204、PAGE-216及文案建议；`overview.md` D3-04；`abilities.md` CAP-301/302/304、AC-308/312；`ai-behavior.md`真实进展段 | 撤销用户侧“含审稿与最多N次”和“等待/草稿/审稿/返修可区分”的强制展示；明确首有用内容可为词义预览、最终正文一次出现。AC-308的“可先呈现”落实到真实词义，不要求旧正文流；AC-312分别记录首词义/首正文/最大无内容间隔。CAP-303/305及AC-301–307/309–311/313–314的业务预算/管理/统计/Q02保持；不将原型方向改成隐藏故障 |
| BE3-DEP02 / designer-tony | UI04 `design/prototype`、`interactions.md`、`copy.json`、响应式/无障碍及UIA-M003-301/302/303/307/308/309 | 生成页面不再突出权益大提示、内部步骤/第k/N次；以BE03 fixtures实际驱动首词义、最终整包、Q02、pending/取消，完整页面先给用户评审。UIA304–306管理配置继续有效 |
| BE3-DEP03 / frontend-bob | FE01 `technical/frontend.md` FE3-03/04/06/07/08/09、FE3-V02–06/09/12及FE3-T01/02 | 替换stage/snapshot/candidate reducer及动态k/N模板；加入learning_ready与只在终态建正文/资源；终态版本无需等于预览v1；保留身份epoch、token/seq、有限核对、取消及保存竞争。更新mock与BE03一致，再形成正式前端接收 |
| BE3-DEP04 / backend-ethan | 现有待审backend实现；[BE3-08](../technical/backend.md#be3-08-待审源码对齐与限定检查) | 先保护约50个未提交文件，后续获实施授权才按表对齐两个HTTP流、pipeline公开adapter、status DTO和旧流断言；内部算法/DB事实继续保留。当前代码仍是输入，未声称符合BE03 |

DB02无需新增列或迁移：公开词义为内存投影，最终仍既有payload和final_content_version/outcome/stop_reason。数据库文档若提中间稿仍可作为内部包解释；若owner认为需改存储，先列精确差异，不新建恢复/协议兼容平台。

## 整理、验证与保留项

七份原BE02均与 [technical-012冻结包](../reviews/evidence/technical-012/artifacts.tar.gz)逐字一致后才修订；旧BE02/FE01/TECH-02及UI04冻结证据未改。当前七份版本统一M003-BE-03；稳定BE3/AI3/API编号沿用，新增BE3-08与本交接依赖ID。没有新建控制面真源，所有他人源码/产品/UI/DB/FE保持。

本次planning读取超过8k软目标，因必须对齐产品、DB02、FE01、BE02及确认例外；已在安全检查点停止历史扩展，仅维护当前原件。检查证据记录七份当前文档字符数及文件hash；runtime token/usage unknown，不拿静态字符冒充实际token。没有运行新会话交接测试；实际原型消费检查待designer-tony。

保留CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX。实际三协议、取消/断连/DB竞争、真实质量/费用/时延均未在本轮重验；本轮未跑Go全套、迁移、服务商测试、提交Git、部署或触碰UAT3302。fixture检查不代表这些条目通过。

## 下一动作及边界

后台方案已形成可审阅原件，建议由主会话按现有明确授权办理限定接交给designer-tony，依据BE03做完整页面原型；同步BE3-DEP01/03，前端实施仍等待用户视觉评审及相应阶段接收。接交完成条件是消费确切事件、完整终态/异常语义不丢、用户能实际查看原型。没有权限由本角色自行切阶段或把未来实施一起批准。
