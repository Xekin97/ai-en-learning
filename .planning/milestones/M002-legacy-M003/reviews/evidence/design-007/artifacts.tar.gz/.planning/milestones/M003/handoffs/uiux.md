---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M003-UI-02
date: 2026-10-09
input_version: M003-PRODUCT-03
---

# M003 UI/UX 交接

## 输入与确认来源

- 采用已接收 `M003-PRODUCT-03`：`reviews/requirements-feedback.md`、`reviews/product-revision-006.md`、`handoffs/product.md`，以及 `product/overview.md`、`data-assets.md`、`abilities.md`、`pages/index.md`、`ai-behavior.md`、`reviews/product-planning.md`。
- 用户确认 `USER-M003-Q01-B`、`USER-M003-Q02-A`、`USER-M003-Q03-RANGE99` 与既有 `USER-M003-CONTENT-20261009`、CQ-01–14：Pro/Plus 分别配置整数0–99且初始1；0关闭整个内容审校；技术故障已有完整有效稿时允许保存并持续提示，仍计一次生成；配置99只验静态边界，流程测试最多执行2轮。
- Profile 只采用 `reviews/evidence/start/locked-profile.yaml` 的 `consumer-ai-web@1.0.0`，未采用2.0。模型路由锁要求 strong `gpt-5.6-sol/high`；宿主没有独立 serving metadata，`actual_model` 为 unknown。
- UI01 为历史快照，保存在 `reviews/evidence/feedback-005/`；原浏览器文件未覆盖。本次新增证据只写入 `design/evidence/ui02/`。

## 交付原件

- [设计规格](../design/design-spec.md)：PAGE/CAP/DATA 追踪、稳定入口、定位符与 UIA-M003-301–309。
- [主题增量](../design/theme.css)：继承 M002/UI01，仅增加数字上限、只读系统策略、审校未完成与冲突样式。
- [可运行原型](../design/prototype/index.html) 与 [交互模块](../design/prototype/app.js)：PAGE-204/216、PAGE-208、PAGE-212 的评审状态。
- [中英文文案源](../design/copy.json) 与 [确定性夹具](../design/prototype/fixtures.json)：原型实际 fetch；动态 N 通过模板注入。
- [交互约束](../design/interactions.md) 与 [响应式/无障碍约束](../design/responsive-accessibility.md)。
- [UI02 浏览器报告](../design/evidence/ui02/M003-UI-02-browser.json)、[可重跑脚本](../design/evidence/ui02/browser.mjs)及同目录8张截图。

## 必须保持的界面契约

- 基础纠错与内容审校分开表达。基础纠错适用于所有计划，显示系统策略“每次生成全程最多2次”，后台只读且不可关闭；该数值仍由后端最终定稿。visitor/basic 的内容审校固定0且只读。
- Pro/Plus 内容返修上限分别配置整数0–99。0与关闭联动，1–99与开启联动；空、负数、小数、100以上保留原输入、显示错误并禁用预览/保存。保存原子地包含开关和 N。
- 用户权益摘要读取本次受理快照的实际 N。第 k 次返修显示 `k/N`；不为高 N 预建步骤。正常达到内容上限时按普通完成交付，不显示故障，也不声称审稿通过。
- 内容服务技术故障且已有最近完整有效稿时，允许收录/放弃，持续显示“内容审校未完成”，并说明仍计一次生成。无有效稿失败、结算未知 pending、主动取消均不可保存。
- 配置预览保留基础策略不变、内容旧/新 N、权益撤回影响、新请求生效、在途快照及用量说明。远端冲突同时展示远端最新值与本地未保存值，须重新预览后确认。
- 后台预设只有基础/增强两模式；增强固定最多1次，并明确不读取或模拟 Pro/Plus 计划上限。完整有效预览即使审校未完成仍可由管理员确认后手动发布，不能标作审稿通过。
- 原型阶段是应用状态。设计不固定 SSE 事件、调用链、复审/重试预算，也不要求新增模型调用；由 backend-alex 定稿协议，再由 frontend-bob 映射状态。

## 启动与验证

在 `.planning/milestones` 运行 `python3 -m http.server 4174 --bind 127.0.0.1`，访问 `http://127.0.0.1:4174/M003/design/prototype/`。全部稳定查询参数见 `design-spec.md#启动与稳定入口`。

2026-10-09 使用 Chromium / Playwright 1.62.1 / Node v22.23.2 检查本地静态原型。报告为 PASS：10组状态、8张新截图；覆盖基础只读、0差异、99保存恢复、100手机错误、第2轮返修、故障有效稿交付、remote2/local99冲突、后台固定1次审校未完成、正常上限定稿，以及 -1/1.5/空值、0→开回1、failure/pending 保存资格。代表页无控制台错误、文案缺键或页面横向溢出。8张截图已逐张人工查看，桌面/手机层级、折行、警示和动作资格清晰。

未验证 768×1024、320×700、英文视觉、真实读屏、200% 缩放、正式前端还原、真实模型、UAT 3302、数据库、服务端持久化、部署或99轮流程。产品工程要求 Node 24，本次仅按现有 Node v22.23.2 运行静态原型检查。证据不证明真实内容质量、费用或流式时延。

## 接交条件与剩余责任

- 当前无 BLOCKED、开放 CR 或新增业务选择；`M003-UI-02` 可供用户/守门器审阅，本交接不切阶段。
- 用户/守门器接受 UI02 并进入 technical-design 后可交 DBA：从 DATA-301/302/304 与 UIA-M003-304–307 定义四计划安全初值、0–99校验、配置版本/并发冲突、请求权益快照及必要事实落点。未知或不完整配置不得授予内容审校权益。
- backend-alex 需接收：基础纠错预算最终值、内容0–99运行语义、故障有效稿交付与“仍计一次”、无有效稿/pending/取消唯一终态、流式与调用链；不得从 UI 原型倒推协议或额外调用。
- frontend-bob/qa-quinn 后续覆盖未验证视口、中英文、读屏、缩放、应用持久化及正式实现。若新增普通档内容审校、独立只审不修、第三种预设模式或改变故障计费，应回产品处理，不能由实现自行扩展。

> 本交接不修改 workflow；阶段迁移由主会话和守门器控制。
