# M003 UI/UX 增量规格

## 当前目标与有效范围

- 当前版本 `M003-UI-02`，状态 `awaiting_user_review`。输入为已接收的 `M003-PRODUCT-03`，来源 `reviews/requirements-feedback.md`、`reviews/product-revision-006.md`、`handoffs/product.md` 及六份产品原件。
- 确认来源：`USER-M003-Q01-B`、`USER-M003-Q02-A`、`USER-M003-Q03-RANGE99`、`USER-M003-CONTENT-20261009`、CQ-01–14。各付费计划内容上限为整数0–99、初始1；0关闭；流程验证最多执行2轮。审校技术故障且有有效稿时可保存并持续提示，仍计一次生成。
- UI01 只作为历史，冻结快照位于 `reviews/evidence/feedback-005/` 与已接收设计快照；旧浏览器证据不覆盖、不作为 UI02 通过依据。
- 本轮只修订 PAGE-204/216、PAGE-208、PAGE-212 及 PAGE-215/217 文案语义；沿用 M002/UI01 风格，不新增页面、支付、独立审稿或配置平台。

## 页面—能力—数据追踪

| 页面 | 本轮设计增量 | 数据/能力 | 原型定位 |
|---|---|---|---|
| PAGE-204/216 | 本次动态 N；第2次返修；正常上限定稿；可保存但审校未完成；失败/pending/取消 | DATA-301–303；CAP-301/302；AC-302/303/308/311/313/314 | `?page=create`；`#benefit-summary`、`#generation-status` |
| PAGE-208 | 基础纠错系统策略只读；内容整数0–99；合法/非法、影响预览、远端冲突和快照 | DATA-301/302；CAP-303；AC-304/305/306/314 | `?page=plans`；`#basic-correction-policy`、`#content-service`、`#change-preview`、`#version-conflict` |
| PAGE-212 | 基础/增强两模式；增强固定1次，不模拟计划 N；审校未完成有效预览可手动发布 | DATA-304；CAP-304；AC-309 | `?page=presets`；`#preview-mode`、`#preview-result` |
| PAGE-215/217 | 权益摘要显示实际 N；精选不承诺通过或赠送增强 | DATA-301/原 DATA-212；CAP-301/304 | `copy.json` 语义，不另建页面 |

## 设计表达

继续使用 M002 暖白阅读纸、深绿主色、造文双栏和后台侧栏；`theme.css` 只增补数字输入、系统策略、审校未完成警示及差异样式。计划页将两类预算并列：基础纠错用浅绿只读卡，内容审校用可编辑白色卡。界面直接显示“系统策略、最多2次、后台不可编辑”，不向最终用户展示产品文档里的“待技术定稿/技术建议”字样。

“内容审校未完成”使用浅杏警示，并与绿色成功提示区分；仍展示完整文章与保存按钮。正常上限定稿保持普通“生成完成”，不渲染故障警示，也不声称审稿通过。

## 启动与稳定入口

在 `.planning/milestones` 运行：

```sh
python3 -m http.server 4174 --bind 127.0.0.1
```

基址：`http://127.0.0.1:4174/M003/design/prototype/`。必须经 HTTP 加载 `copy.json`、夹具和 M002 主题。

| 场景 | 查询参数 |
|---|---|
| Basic 基础只读 | `?page=plans&plan=basic&adminState=edit&lang=zh` |
| Pro 关闭/0 | `?page=plans&plan=pro&limit=0&adminState=preview&lang=zh` |
| Pro 上限99保存恢复 | `?page=plans&plan=pro&limit=99&adminState=saved&lang=zh` |
| 非法值 | `?page=plans&plan=pro&limit=-1|100|1.5|&adminState=edit&lang=zh` |
| 远端/本地冲突 | `?page=plans&plan=pro&limit=99&remote=2&adminState=conflict&lang=zh` |
| 本次 N=2 的第2次返修 | `?page=create&plan=pro&limit=2&stage=repair2&lang=zh` |
| 正常上限定稿 | `?page=create&plan=pro&limit=2&stage=complete&outcome=limit&lang=zh` |
| 审校故障有效交付 | `?page=create&plan=pro&limit=2&stage=incomplete&lang=zh` |
| 无有效稿/结算待核对/取消 | `?page=create&plan=pro&stage=failure|pending|cancelled&lang=zh` |
| 后台固定1次、审校未完成 | `?page=presets&mode=enhanced&previewState=incomplete&lang=zh` |

入口均支持 `lang=en`。夹具只供确定构图，不代表真实用户、文章、服务、质量、费用或延迟。配置99只证明静态显示/读取，不模拟99轮。

## 页面与内容定位

| 区域 | 顺序和规则 | 文案源 |
|---|---|---|
| `#benefit-summary` | 服务名→动态 N→当前计划→受理快照；用户不可切换 | `benefit.*`、模板 `benefit.enhanced.body` |
| `#generation-status` | 完整稿→阶段/警示→动作；草稿不可保存；`repair2` 明示第2次和本次 N；`incomplete` 可保存且提示持续 | `stage.*`、模板 `stage.repair.*` |
| `#basic-correction-policy` | 漏词/格式/学习字段→所有计划→最多2次系统策略→不可编辑 | `plans.base.*` |
| `#content-service` | 服务开关→内容上限输入→说明/错误；普通档禁用0；付费档整数0–99，0关、1–99开 | `plans.review.*` |
| `#change-preview` | 基础策略不变→内容旧/新 N→撤回警告→人数→新请求/在途/用量→保存 | `plans.preview/effect.*` |
| `#version-conflict` | 服务端最新值→本地未保存值→重新核对；不部分保存 | `plans.conflict/latest/local.*` |
| `#preview-mode` | 基础默认→增强固定1次→不赠予读者/不模拟计划 N→生成/发布 | `preset.mode.*` |

文案原文只在 `copy.json`；原型实际 fetch。真实 N、影响人数和用量来自应用模型。输入错误不被自动截断或静默纠正；预览/保存禁用并就地说明。协议、调用链、基础预算最终值、超时和重试由 backend-alex 定稿；界面不固定 SSE 事件或增加模型调用。

## 实现约束与验收

| 验收 ID | 定位 | 必须保持 | 充分证据 |
|---|---|---|---|
| UIA-M003-301 | `#benefit-summary` | actual plan 与动态 N；0时仅基础；在途快照不变 | Basic、N=2、N=99 文本/属性 |
| UIA-M003-302 | `#generation-status` | 第2次返修可复现；上限完成无故障/通过承诺 | repair2、limit-complete 操作与文本 |
| UIA-M003-303 | `#generation-status[data-stage=incomplete]` | 最近有效整稿、持续警示、保存可达、计一次且不称通过 | 桌面/手机操作及保存可见性 |
| UIA-M003-304 | `#basic-correction-policy/#content-service` | 两类策略区分；基础只读；普通0；付费0–99 | 四计划、控件禁用与可访问名称 |
| UIA-M003-305 | `#content-repair-limit` | 0/99合法；-1/100/1.5/空非法；非法不可预览 | 属性、错误、按钮状态；不调用模型 |
| UIA-M003-306 | `#change-preview/#version-conflict` | 旧新 N、新请求/在途；远端与本地同时保留；重新预览 | limit0、local99/remote2 |
| UIA-M003-307 | `#preview-mode/#preview-result` | 增强固定1，不读取计划 N；incomplete 有提示仍可手动发布 | enhanced/incomplete 操作与文本 |
| UIA-M003-308 | failure/pending/cancelled | 无有效稿不可保存；pending 不宣成功；取消沿原结算 | 稳定入口的动作可见性 |
| UIA-M003-309 | 全部 | ≥320px 无页面横向溢出；目标≥44px；焦点可见；状态不用颜色单独表达 | Chromium 代表视口与边界检查 |

技术可调整 DOM/组件；固定文案、顺序、保存资格、状态语义和关联上限必须保持。内容流程测试最多执行到第2轮；不得因测试深度把运行上限硬编码为2。

## 自检与未验证

UI02 使用独立 `design/evidence/ui02/` 保存脚本、JSON 和截图，未改 UI01 证据。2026-10-09 在本地静态 HTTP 下以 Chromium / Playwright 1.62.1 / Node v22.23.2 检查 10 组状态：8 个截图场景、正常上限定稿结构、边界交互。报告 `M003-UI-02-browser.json` 为 PASS；0、99、-1、100、1.5、空值、0→开启回1、基础只读、第2轮返修、故障有效交付、无有效稿、pending、冲突及后台固定1次均通过；代表页无控制台错误、缺失文案或页面横向溢出。人工查看全部 8 张新截图，桌面与手机的层级、折行、警示、保存资格及冲突对照清晰，无需再调整。

未验证 768×1024、320×700、英文视觉、真实读屏、200% 缩放、产品代码还原、真实模型、UAT 3302、数据库、部署和99轮流程。产品工程要求的 Node 24 未用于本次静态原型检查。真实质量、费用及流式时延仍由后续技术与验证原件覆盖。当前无新增业务选择、CR 或阻塞。
