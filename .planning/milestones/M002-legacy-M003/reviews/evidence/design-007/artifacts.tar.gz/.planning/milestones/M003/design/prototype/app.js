const [copy, fixtures] = await Promise.all([
  fetch("../copy.json").then((response) => {
    if (!response.ok) throw new Error("copy.json");
    return response.json();
  }),
  fetch("./fixtures.json").then((response) => {
    if (!response.ok) throw new Error("fixtures.json");
    return response.json();
  }),
]);

const params = new URLSearchParams(location.search);
const lang = params.get("lang") === "en" ? "en" : "zh";
document.documentElement.lang = lang === "zh" ? "zh-CN" : "en";
const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[char]);
const t = (key) => copy.static[`${key}.${lang}`] ?? `⟦${key}⟧`;
const tt = (key, values) => Object.entries(values).reduce((text, [name, value]) => text.replaceAll(`{${name}}`, value), copy.templates[`${key}.${lang}`] ?? `⟦${key}⟧`);
const href = (changes) => {
  const next = new URLSearchParams(params);
  Object.entries(changes).forEach(([key, value]) => value == null ? next.delete(key) : next.set(key, value));
  return `?${next.toString()}`;
};
const button = (label, changes, className = "btn") => `<a class="${className}" href="${href(changes)}">${esc(label)}</a>`;
const planCodes = ["visitor", "basic", "pro", "plus"];

function header(admin = false) {
  const language = lang === "zh" ? "EN" : "中文";
  const languageHref = href({lang: lang === "zh" ? "en" : "zh"});
  if (admin) return `<header class="topbar admin-topbar"><div class="container header-inner"><a class="brand" href="${href({page:"plans"})}"><span class="brand-mark" aria-hidden="true">≈</span>${esc(t("brand"))}<small>${esc(t("admin.label"))}</small></a><span class="prototype-mark">${esc(t("prototype.scope"))}</span><div class="header-actions"><a class="btn quiet lang-link" href="${languageHref}">${language}</a><span class="pill">${esc(t("admin.label"))}</span></div></div></header>`;
  return `<header class="topbar"><div class="container header-inner"><a class="brand" href="${href({page:"create"})}"><span class="brand-mark" aria-hidden="true">≈</span>${esc(t("brand"))}</a><nav class="nav" aria-label="Primary"><a href="#">${esc(t("nav.home"))}</a><a href="#">${esc(t("nav.picks"))}</a><a aria-current="page" href="${href({page:"create"})}">${esc(t("nav.learn"))}</a><a href="#">${esc(t("nav.review"))}</a><a href="#">${esc(t("nav.library"))}</a></nav><div class="header-actions"><a class="btn quiet lang-link" href="${languageHref}">${language}</a><span class="avatar" aria-label="Xiao">小</span></div></div></header>`;
}

function adminNav(current) {
  return `<nav class="admin-nav-m003" aria-label="Admin"><a href="#">${esc(t("admin.overview"))}</a><a href="#">${esc(t("admin.models"))}</a><a ${current === "plans" ? 'aria-current="page"' : ""} href="${href({page:"plans"})}">${esc(t("admin.plans"))}</a><a ${current === "presets" ? 'aria-current="page"' : ""} href="${href({page:"presets"})}">${esc(t("admin.presets"))}</a></nav>`;
}

function readLimit(plan, raw = params.get("limit")) {
  const text = plan.editable ? String(raw ?? plan.limit) : "0";
  const integer = /^\d+$/.test(text);
  const value = integer ? Number(text) : Number.NaN;
  return {raw:text, value, valid:integer && value >= 0 && value <= 99};
}

function entitlement(planCode) {
  const plan = fixtures.plans[planCode] ?? fixtures.plans.basic;
  const parsed = readLimit(plan);
  const limit = parsed.valid ? parsed.value : plan.limit;
  return {plan, limit, enhanced:plan.editable && limit > 0, planName:lang === "zh" ? plan.nameZh : plan.nameEn};
}

function stageRail(stage, enhanced) {
  const steps = enhanced ? ["generating", "draft", "review", "repair", "complete"] : ["generating", "draft", "complete"];
  const normalized = stage.startsWith("review") ? "review" : stage.startsWith("repair") ? "repair" : stage === "incomplete" ? "complete" : ["idle", "cancelled", "failure", "pending"].includes(stage) ? "generating" : stage;
  const current = Math.max(0, steps.indexOf(normalized));
  return `<ol class="stage-rail" aria-label="Generation stages">${steps.map((key, index) => `<li class="${index < current ? "done" : index === current ? "current" : ""}" ${index === current ? 'aria-current="step"' : ""}>${esc(t(`stage.${key}`))}</li>`).join("")}</ol>`;
}

function storyBody(stage, repairCount) {
  const repaired = repairCount > 0 || ["complete", "incomplete"].includes(stage);
  const text = repaired ? fixtures.draft.repairedText : fixtures.draft.text;
  const label = stage.startsWith("repair") ? tt("stage.repair.label", {count:repairCount}) : stage === "incomplete" ? t("stage.incomplete.title") : t(`stage.${stage.startsWith("review") ? "review" : stage}`);
  return `<span class="draft-label">${esc(label)}</span><h2 class="result-title">${esc(fixtures.draft.title)}</h2><p class="story-text" lang="en">${esc(text)}</p><div class="learning-facts">${fixtures.draft.meanings.map((item) => `<p>${esc(item)}</p>`).join("")}</div>`;
}

function createPage() {
  const planCode = planCodes.includes(params.get("plan")) ? params.get("plan") : "pro";
  const {enhanced, limit, planName} = entitlement(planCode);
  let stage = params.get("stage") || "idle";
  if (stage === "repair") stage = "repair1";
  if (!enhanced && (stage.startsWith("review") || stage.startsWith("repair") || stage === "incomplete")) stage = "draft";
  const repairCount = stage === "repair2" || stage === "review2" ? 2 : stage === "repair1" ? 1 : 0;
  const source = params.get("source") === "preset" ? "preset" : "normal";
  const benefitName = enhanced ? t("benefit.enhanced.name") : t("benefit.base.name");
  const benefitBody = enhanced ? tt("benefit.enhanced.body", {limit}) : t("benefit.base.body");
  const config = source === "preset" ? `<div class="setting-row"><span>${esc(t("source.preset"))}</span><strong>${esc(fixtures.preset.title)}</strong></div>` : "";
  const settings = `<aside class="panel m003-settings" aria-labelledby="settings-title"><h2 id="settings-title">${esc(t("create.settings"))}</h2>${config}<div class="setting-row"><span>AI ${lang === "zh" ? "模型" : "model"}</span><strong>Model A</strong></div><div class="setting-row"><span>${lang === "zh" ? "场景 · 长度" : "Genre · length"}</span><strong>${lang === "zh" ? "故事 · 简短" : "Story · Brief"}</strong></div><div class="setting-row"><span>${esc(t("create.words"))}</span><div class="word-list">${fixtures.draft.words.map((word) => `<span class="chip" lang="en">${esc(word)}</span>`).join("")}</div></div>${stage === "idle" ? button(t("create.generate"), {stage:"draft"}, "btn primary") : ""}</aside>`;
  let content;
  if (stage === "idle") {
    content = `<div class="empty-service"><div><span class="empty-icon" aria-hidden="true">✎</span><h2>${esc(t("create.empty.title"))}</h2><p>${esc(t("create.empty.body"))}</p></div></div>`;
  } else if (["cancelled", "failure", "pending"].includes(stage)) {
    const titleKey = stage === "cancelled" ? "stage.cancelled" : `stage.${stage}.title`;
    const bodyKey = stage === "cancelled" ? "stage.cancelled.body" : `stage.${stage}.body`;
    content = `<div class="empty-service" role="${stage === "failure" ? "alert" : "status"}"><div><span class="empty-icon" aria-hidden="true">${stage === "pending" ? "…" : "×"}</span><h2>${esc(t(titleKey))}</h2><p>${esc(t(bodyKey))}</p>${stage === "pending" ? "" : button(t("action.retry"), {stage:"draft"}, "btn primary")}</div></div>`;
  } else {
    const completed = ["complete", "incomplete"].includes(stage);
    const review = stage.startsWith("review");
    const repair = stage.startsWith("repair");
    const body = stage === "incomplete" ? t("stage.incomplete.body") : repair ? tt("stage.repair.body", {count:repairCount, limit}) : review ? t("stage.review.body") : stage === "draft" ? t("stage.draft.body") : params.get("outcome") === "limit" ? t("stage.limit.body") : t("stage.complete.body");
    const next = stage === "draft" ? (enhanced ? "review1" : "complete") : stage === "review1" ? "repair1" : stage === "repair1" ? (limit >= 2 ? "review2" : "complete") : stage === "review2" ? "repair2" : "complete";
    content = `<div class="generation-stage"><article data-region="generation-result">${storyBody(stage, repairCount)}<p class="stage-note ${stage === "incomplete" ? "incomplete-note" : ""}" role="status" aria-live="polite">${esc(body)}</p><div class="generation-actions">${completed ? `${button(t("action.save"), {saved:"1"}, "btn primary")}${button(t("action.discard"), {stage:"idle"}, "btn quiet")}` : `${button(t("action.cancel"), {stage:"cancelled"}, "btn")}${button(lang === "zh" ? "演示下一阶段" : "Show next stage", {stage:next}, "btn quiet")}`}</div></article><aside>${stageRail(stage, enhanced)}</aside></div>`;
  }
  const scenarios = `<div class="scenario-links" aria-label="Prototype states"><a href="${href({plan:"basic",limit:null,stage:"idle"})}">Basic</a><a href="${href({plan:"pro",limit:"2",stage:"repair2"})}">Repair 2 / 2</a><a href="${href({plan:"pro",limit:"2",stage:"complete",outcome:"limit"})}">Limit complete</a><a href="${href({plan:"pro",limit:"2",stage:"incomplete"})}">Review incomplete</a><a href="${href({plan:"pro",stage:"failure"})}">No valid draft</a><a href="${href({plan:"pro",stage:"pending"})}">Pending</a><a href="${href({plan:"pro",stage:"cancelled"})}">Cancelled</a></div>`;
  return `${header()}<main class="container page" id="main"><header class="page-head"><div><h1>${esc(t("create.title"))}</h1><p>${esc(t("create.intro"))}</p></div></header><section id="benefit-summary" class="entitlement-strip" data-enhanced="${enhanced}" data-limit="${limit}"><div><strong>${esc(benefitName)}</strong><p>${esc(benefitBody)}</p></div><div class="entitlement-meta">${esc(tt("benefit.plan", {plan:planName}))}<br>${esc(t("benefit.snapshot"))}</div></section><div class="m003-workspace">${settings}<section id="generation-status" class="panel generation-panel" data-stage="${esc(stage)}" data-repair-count="${repairCount}">${content}</section></div>${scenarios}</main>`;
}

function planTabs(planCode) {
  return `<nav class="plan-tabs" aria-label="Plans">${Object.entries(fixtures.plans).map(([code, plan]) => `<a aria-current="${code === planCode}" href="${href({plan:code,limit:null,remote:null,adminState:"edit"})}">${esc(lang === "zh" ? plan.nameZh : plan.nameEn)}</a>`).join("")}</nav>`;
}

function plansPage() {
  const planCode = fixtures.plans[params.get("plan")] ? params.get("plan") : "pro";
  const plan = fixtures.plans[planCode];
  const planName = lang === "zh" ? plan.nameZh : plan.nameEn;
  const adminState = params.get("adminState") || "edit";
  const parsed = readLimit(plan);
  const currentLimit = plan.limit;
  const proposedLimit = parsed.valid ? parsed.value : null;
  const currentLabel = currentLimit === 0 ? t("plans.review.off") : tt("plans.review.on", {limit:currentLimit});
  const proposedLabel = parsed.valid ? (proposedLimit === 0 ? t("plans.review.off") : tt("plans.review.on", {limit:proposedLimit})) : t("plans.review.invalid");
  let lower = "";
  if (adminState === "preview" && parsed.valid) {
    lower = `<section id="change-preview" class="change-preview" data-state="preview"><header><h2>${esc(t("plans.preview.title"))}</h2><p>${esc(planName)}</p></header><div class="change-body"><div class="policy-unchanged"><strong>${esc(t("plans.base.title"))}</strong><span>${esc(t("plans.base.fixed"))}</span></div><div class="diff-row"><div class="diff-value"><small>${lang === "zh" ? "当前内容上限" : "Current content limit"}</small><br><strong>${esc(currentLabel)}</strong></div><span aria-hidden="true">→</span><div class="diff-value"><small>${lang === "zh" ? "保存后内容上限" : "Content limit after save"}</small><br><strong>${esc(proposedLabel)}</strong></div></div>${proposedLimit === 0 && currentLimit > 0 ? `<div class="warning-box">${esc(t("plans.disable.warning"))}</div>` : ""}<p><strong>${esc(tt("plans.impact", {basic:plan.basicUsers, trial:plan.trialUsers}))}</strong></p><ul class="impact-list"><li>${esc(t("plans.effect.new"))}</li><li>${esc(t("plans.effect.inflight"))}</li><li>${esc(t("plans.effect.usage"))}</li></ul><div class="actions">${button(t("plans.cancel"), {adminState:"edit",limit:null})}${button(t("plans.save"), {adminState:"saved"}, "btn primary")}${button(lang === "zh" ? "演示远端冲突" : "Show remote conflict", {adminState:"conflict",remote:"2"}, "btn quiet")}</div></div></section>`;
  } else if (adminState === "conflict" && parsed.valid) {
    const remoteRaw = params.get("remote") ?? String(currentLimit);
    const remoteNumber = /^\d+$/.test(remoteRaw) ? Math.min(99, Number(remoteRaw)) : currentLimit;
    const remoteLabel = remoteNumber === 0 ? t("plans.review.off") : tt("plans.review.on", {limit:remoteNumber});
    lower = `<section id="version-conflict" class="conflict-box" role="alert"><h2>${esc(t("plans.conflict.title"))}</h2><p>${esc(t("plans.conflict.body"))}</p><div class="conflict-compare"><div><small>${esc(t("plans.latest"))}</small><br><strong>${esc(remoteLabel)}</strong></div><div><small>${esc(t("plans.local"))}</small><br><strong>${esc(proposedLabel)}</strong></div></div>${button(t("plans.recheck"), {adminState:"preview",remote:null}, "btn primary")}</section>`;
  } else if (adminState === "saved" && parsed.valid) {
    lower = `<div id="save-result" class="success-box" role="status" data-saved-limit="${proposedLimit}">${esc(t("plans.saved"))} <strong>${esc(proposedLabel)}</strong></div>`;
  }
  const enabled = parsed.valid && proposedLimit > 0;
  const controls = `<div class="plan-grid"><section class="service-card system-policy" id="basic-correction-policy"><h2>${esc(t("plans.base.title"))}</h2><p>${esc(t("plans.base.body"))}</p><div class="service-state"><strong>${esc(t("plans.base.fixed"))}</strong><span class="fixed-badge">✓</span></div></section><section class="service-card" id="content-service"><h2>${esc(t("plans.review.title"))}</h2><p>${esc(t("plans.review.rule"))}</p><div class="service-state"><div><strong id="review-state-label">${esc(parsed.valid ? proposedLabel : t("plans.review.invalid"))}</strong><small>${esc(plan.editable ? t("plans.sameModel") : t("plans.review.locked"))}</small></div><label class="switch"><span class="sr-only">${esc(t("plans.review.title"))}</span><input id="content-review-switch" type="checkbox" ${enabled ? "checked" : ""} ${plan.editable ? "" : "disabled"}><span aria-hidden="true"></span></label></div><label class="limit-field" for="content-repair-limit"><span>${esc(t("plans.review.limit"))}</span><input id="content-repair-limit" type="number" inputmode="numeric" min="0" max="99" step="1" value="${esc(parsed.raw)}" ${plan.editable ? "" : "disabled"} aria-invalid="${!parsed.valid}" aria-describedby="limit-help${parsed.valid ? "" : " limit-error"}"></label><p id="limit-help" class="field-help">${esc(plan.editable ? t("plans.review.limit.help") : t("plans.review.locked"))}</p>${parsed.valid ? "" : `<p id="limit-error" class="field-error" role="alert">${esc(t("plans.review.invalid"))}</p>`}</section></div><div class="form-footer">${parsed.valid ? button(t("plans.preview"), {adminState:"preview"}, "btn primary") : `<button class="btn primary" disabled>${esc(t("plans.preview"))}</button>`}</div>`;
  const scenarios = `<div class="scenario-links"><a href="${href({plan:"basic",limit:null,adminState:"edit"})}">Basic read-only</a><a href="${href({plan:"pro",limit:"0",adminState:"preview"})}">Limit 0</a><a href="${href({plan:"pro",limit:"99",adminState:"saved"})}">Limit 99</a><a href="${href({plan:"pro",limit:"-1",adminState:"edit"})}">Invalid −1</a><a href="${href({plan:"pro",limit:"100",adminState:"edit"})}">Invalid 100</a><a href="${href({plan:"pro",limit:"1.5",adminState:"edit"})}">Invalid 1.5</a><a href="${href({plan:"pro",limit:"99",remote:"2",adminState:"conflict"})}">Remote 2 / local 99</a></div>`;
  return `${header(true)}<main class="container page admin-shell-m003" id="main">${adminNav("plans")}<div><header class="page-head"><div><p class="eyebrow">WORDWEAVE / ${esc(t("admin.label"))}</p><h1>${esc(t("plans.title"))}</h1><p>${esc(t("plans.intro"))}</p></div></header>${planTabs(planCode)}<section class="panel" data-plan="${esc(planCode)}" data-limit-valid="${parsed.valid}">${controls}${lower}</section>${scenarios}</div></main>`;
}

function presetsPage() {
  const mode = params.get("mode") === "enhanced" ? "enhanced" : "base";
  const state = params.get("previewState") || "ready";
  const enhanced = mode === "enhanced";
  const modeLabel = t(`preset.mode.${mode}`);
  let result = "";
  if (state === "stale") result = `<div id="preview-result" class="warning-box" role="status" data-state="stale">${esc(t("preset.stale"))}</div>`;
  else if (state === "running") result = `<div id="preview-result" data-state="running"><p class="stage-note" role="status">${esc(t(enhanced ? "stage.review.body" : "stage.wait.body"))}</p>${button(t("action.cancel"), {previewState:"cancelled"})}</div>`;
  else if (state === "cancelled") result = `<div id="preview-result" class="warning-box" role="status" data-state="cancelled">${esc(t("stage.cancelled.body"))}</div>`;
  else result = `<section id="preview-result" class="preview-paper" data-state="${state === "incomplete" ? "incomplete" : "ready"}"><div class="section-head"><h2>${esc(lang === "zh" ? "预览" : "Preview")}</h2><span class="pill">${esc(modeLabel)}</span></div><h3>${esc(fixtures.draft.title)}</h3><p class="story-text" lang="en">${esc(enhanced ? fixtures.draft.repairedText : fixtures.draft.text)}</p><div class="${state === "incomplete" ? "warning-box incomplete-note" : "success-box"}">${esc(t(state === "incomplete" ? "preset.incomplete" : "preset.ready"))}</div></section>`;
  const modeControl = `<fieldset id="preview-mode" class="mode-group"><legend>${esc(t("preset.mode"))}</legend><div class="mode-options"><label class="mode-option"><input type="radio" name="mode" value="base" ${!enhanced ? "checked" : ""}><span><strong>${esc(t("preset.mode.base"))}</strong><br><small>${esc(t("benefit.base.body"))}</small></span></label><label class="mode-option"><input type="radio" name="mode" value="enhanced" ${enhanced ? "checked" : ""}><span><strong>${esc(t("preset.mode.enhanced"))}</strong><br><small>${esc(tt("benefit.enhanced.body", {limit:1}))}</small></span></label></div><p class="field-help">${esc(t("preset.mode.note"))}<br>${esc(t("preset.mode.limit"))}</p></fieldset>`;
  const scenarios = `<div class="scenario-links"><a href="${href({mode:"base",previewState:"ready"})}">Base ready</a><a href="${href({mode:"enhanced",previewState:"running"})}">Enhanced running</a><a href="${href({mode:"enhanced",previewState:"ready"})}">Enhanced ready</a><a href="${href({mode:"enhanced",previewState:"incomplete"})}">Review incomplete</a><a href="${href({mode:"enhanced",previewState:"stale"})}">Mode changed</a></div>`;
  return `${header(true)}<main class="container page admin-shell-m003" id="main">${adminNav("presets")}<div><header class="page-head"><div><p class="eyebrow">WORDWEAVE / ${esc(t("admin.label"))}</p><h1>${esc(t("preset.title"))}</h1><p>${esc(t("preset.intro"))}</p></div></header><div class="preset-layout"><aside class="panel preset-list"><h2>${lang === "zh" ? "预设列表" : "Presets"}</h2><button><strong>${esc(fixtures.preset.title)}</strong><br><small>${lang === "zh" ? "有修改草稿" : "Edited draft"}</small></button></aside><section class="panel">${modeControl}<div class="form-footer">${button(t("preset.generate"), {previewState:"running"})}${button(t("preset.publish"), {}, "btn primary")}</div>${result}<p class="usage-note">${esc(tt("preset.usage", {count:fixtures.preset.usage}))}</p></section></div>${scenarios}</div></main>`;
}

const page = params.get("page") || "create";
const app = document.querySelector("#app");
app.innerHTML = page === "plans" ? plansPage() : page === "presets" ? presetsPage() : createPage();
app.setAttribute("aria-busy", "false");

document.querySelector("#content-review-switch")?.addEventListener("change", (event) => {
  const current = document.querySelector("#content-repair-limit")?.value;
  location.href = href({limit:event.currentTarget.checked ? (/^[1-9]\d?$/.test(current) ? current : "1") : "0", adminState:"edit"});
});
document.querySelector("#content-repair-limit")?.addEventListener("change", (event) => {
  location.href = href({limit:event.currentTarget.value, adminState:"edit"});
});
document.querySelectorAll('input[name="mode"]').forEach((input) => input.addEventListener("change", (event) => {
  location.href = href({mode:event.currentTarget.value, previewState:"stale"});
}));
