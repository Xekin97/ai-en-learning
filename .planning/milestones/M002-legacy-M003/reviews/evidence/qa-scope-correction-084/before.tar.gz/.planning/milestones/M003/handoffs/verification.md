---
milestone: M003
stage: verification
role: quality/base
agent_name: qa-quinn
status: blocked
version: M003-QA-03-CR306
qa_result: fail
user_uat: not_started
date: 2026-10-12
---

# M003 独立 QA 技术诊断交接

## 当前结论

CR-306 独立 QA **FAIL**，不得进入用户 UAT。AC-317–320 通过；AC-322 的 CR-307 修后独立5/5通过，建议根代理同步 resolved。AC-321 的 R1/R2 正式完整链路技术上均成功，但 R2 内容审校漏判明显牵强用词，已建立 [`CR-308`](../changes/CR-308.md)。CR-306/308 保持 open。

原故障的参数与链路目标已证明：唯一模型 `deepseek/deepseek-v4-flash-0731` 在 `json_schema + openrouter_require_parameters + reasoning.enabled=false` 下完成共同Plan→Writer→原生校验→DB终态，未重现原180秒超时；增强实际执行固定编辑与审校。该事实不覆盖内容质量FAIL。

## 建议接收角色

`technical / backend-alex` 仅接 CR-308 AI contract 诊断/修订：指定模型一次真实语义漏判，非当前 backend 实现偏差。已有只读诊断确认 content review 收到完整 fixed-edit V2 clean passage、五个 entries 与 scenario，无截断/解析偏差；`m003-review-v2` 已要求检查牵强整合，模型仍返回 strict `pass`。

下一角色应决定是否以及如何调整 prompt/payload/模型质量合同。不得直接改实现、盲发第三次、扩模型或宣称总体漏判率。若建议更换收费模型、扩大真实样本或改变费用/质量边界，需回用户。

## 核心证据

- 管理/安全边界：[`deterministic-api.json`](../verification/evidence/cr306-qa/deterministic-api.json)，21/21。
- 管线/失败语义：[`deterministic-pipeline.json`](../verification/evidence/cr306-qa/deterministic-pipeline.json)，10/10；DB为 `deterministic-db-facts.json`。
- CR-307首败与复验：[`browser.json`](../verification/evidence/cr306-qa/browser.json)、[`browser-focus-retest.json`](../verification/evidence/cr306-qa/browser-focus-retest.json)。
- R1/R2完整真实原件：[`real-r1.json`](../verification/evidence/cr306-qa/real-r1.json)、[`real-r2.json`](../verification/evidence/cr306-qa/real-r2.json)、[`real-evaluation.md`](../verification/evidence/cr306-qa/real-evaluation.md)。
- 安全导入/零调用证明：`real-model-import-public.json`、`real-model-import-zero-call-proof-public.json`。
- 当前专业结论：[`report.md`](../verification/report.md)、[`coverage-matrix.md`](../verification/coverage-matrix.md)、[`ai-evaluation.md`](../verification/ai-evaluation.md)。
- 机器可读聚合：[`qa-summary.json`](../verification/evidence/cr306-qa/qa-summary.json)。

## R1 / R2 事实

- R1 visitor：scene plan 7.722s，首正文14.159s，总21.362s；planning1+generation1，basic V1，quota100→99，can_save=true；in/out 3531/788，0.00068306 credits。
- R2 pro：scene plan8.802s，首正文17.536s，总35.788s；planning1+generation1+fixed_edit1+review1，content repair0，review_passed V2，quota97→96，can_save=true；in/out8135/1449，0.001070272 credits。
- 两次脚本未逐项持久化首word plan与全部word plan完成时间，均记unknown，不补跑。
- 增强审校分母1，实际返修触发0/1，独立明显漏判1/1；只描述该样本。第三次未运行。

## 文档和状态边界

旧 QA02、CR-304/305 已解决事实继续有效，不复活。CR-307 由QA建议resolved但不自行关闭。CR-306/308保持open，用户UAT未开始。`AI-QUALITY-90`仍UNVERIFIED。QA未修改生产代码、技术/产品合同、控制面或提交。

安全临时env和隔离栈已清理：QA停止并删除54713源码副本；backend-ethan正常停止PG18/backend/provider，删除私有env/loader/PG data，54772–54775均关闭。公开回执为 `backend-stack-cleanup.json`；凭据从未写入公开证据。原UAT端口在本轮起点已关闭，本轮未停止/重启/修改旧UAT或source Docker。

> 本交接不切换阶段、不关闭 CR 或里程碑。
