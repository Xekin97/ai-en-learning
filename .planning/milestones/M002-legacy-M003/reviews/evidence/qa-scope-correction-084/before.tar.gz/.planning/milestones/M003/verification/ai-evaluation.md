---
milestone: M003
stage: verification
role: quality/base
agent_name: qa-quinn
status: blocked
version: M003-QA-03-CR306
result: real_pipeline_pass_quality_fail
quality_result: fail_bounded_sample
date: 2026-10-12
---

# M003 AI 验证范围

## 当前结论

CR-306 已在唯一授权的 `deepseek/deepseek-v4-flash-0731` 上完成两个真实完整业务请求。两者均经正式 Plan→Writer→原生校验→DB 终态，snapshot 为 `json_schema / openrouter_require_parameters / {"reasoning":{"enabled":false}}`，并取得真实 usage/cost。R2 还实际经过固定编辑与内容审校。

技术链成功不等于独立内容质量通过。R2 的明显牵强用词被审校判为 `pass`，故 AC-321 内容质量当前 FAIL，见 [`CR-308`](../changes/CR-308.md)。两个有界样本不构成 `AI-QUALITY-90`，该指标继续 **UNVERIFIED**。

## 真实样本

| 样本 | 终态 / 调用 | 时延 | usage / cost | 独立内容判定 |
|---|---|---|---|---|
| R1 visitor basic | `basic V1`；planning1、generation1；repair0 | scene plan 7.722s；首word plan unknown；全部word plan unknown；首正文14.159s；总21.362s | in3531 / out788；0.00068306 credits | Story/Brief成立；主线词自然，preclude略机械，juvenile插曲关联偏弱；技术PASS、轻微牵强观察 |
| R2 pro enhanced | `review_passed V2`；planning1、generation1、fixed_edit1、review1、content repair0 | scene plan 8.802s；首word plan unknown；全部word plan unknown；首正文17.536s；总35.788s | in8135 / out1449；0.001070272 credits | `juvenile birds`机械类比明显牵强，`starting retroactively`不自然；审校漏判，质量FAIL |

两次均 `can_save=true`、quota consumed；R1游客100→99，R2 Pro 97→96。完整公开正文、五个中文释义/提示、DB调用、prompt versions 与费用见 [`real-r1.json`](evidence/cr306-qa/real-r1.json)、[`real-r2.json`](evidence/cr306-qa/real-r2.json) 和 [`real-evaluation.md`](evidence/cr306-qa/real-evaluation.md)。证据没有凭据、generation token、私有推理或完整私有请求体。

## 修稿与漏判观察

- 完整真实请求分母2，原生有效2；仅表示这两次技术链。
- 增强审校分母1：原生 `pass` 1、content repair触发0、独立明显漏判1。
- 固定编辑1；基础 technical repair0；内容 repair0。数据库持久化 forced/contradiction reason均为0，因为审校未报问题；不能把独立漏判伪写成已触发reason。
- 第三次未运行，不用重采样稀释或覆盖失败，不扩模型或质量批次。

## 确定性流程证据

本轮合成正式栈仍证明参数快照、Plan/writer、N0/N2、Q02、围栏与heartbeat/cancel合同：[`deterministic-pipeline.json`](evidence/cr306-qa/deterministic-pipeline.json) 10/10；管理与安全边界 [`deterministic-api.json`](evidence/cr306-qa/deterministic-api.json) 21/21。旧 QA02 的 N2 reason 持久化、busy 和书写点证据继续有效，不被真实样本覆盖。

## 未验证

- `AI-QUALITY-90`、总体自然度/逻辑成功率、长期误漏报率与跨模型表现；
- 生产容量、延迟分位数、长期成本或账单一致性；
- 99轮返修；本轮真实增强内容返修为0，确定性替身最多执行2轮；
- CR-308 究竟是一次模型随机漏判，还是 prompt/全文传递/路由的实现偏差，待 technical 诊断。
