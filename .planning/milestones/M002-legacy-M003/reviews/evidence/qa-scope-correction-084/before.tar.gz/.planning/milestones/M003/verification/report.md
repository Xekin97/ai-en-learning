---
milestone: M003
stage: verification
role: quality/base
agent_name: qa-quinn
status: blocked
version: M003-QA-03-CR306
result: fail
user_uat: not_started
date: 2026-10-12
---

# M003 独立 QA 报告

## 当前结论

CR-306 当前独立 QA **FAIL**，不能进入用户 UAT。AC-317–320 通过，AC-322 的 [`CR-307`](../changes/CR-307.md) 已完成独立返修复验并建议 resolved。AC-321 的两个真实完整请求技术链均原生有效，但增强内容审校把明显牵强正文判为 `pass`，已登记 [`CR-308`](../changes/CR-308.md)；不能把技术成功等同内容质量通过。

确定性管线首两轮另有 QA fixture 方法失败，已与产品缺陷分开保存；修正临时替身后 AC-319/320 的 10 项整链检查全部通过。真实模型按授权只运行 R1/R2 两次完整业务请求，没有 probe、其他模型或第三次盲重跑。

## 已验证事实

- 正式管理 API 在两模型间隔离自定义参数，`{}` 语义、保存重读、权限、409 与整单原子成立；保存不触发 provider。
- 严格 JSON 与后端边界涵盖重复键指针、对象类型、保护/受控字段、NUL、允许 depth 8/拒绝 depth 9、规范化 16,384 字节与表单级 413；显式 synthetic probe 的 422 有明确响应，没有自动重试或清空参数。
- 围栏 planning 只调用 planning，未进入 writer、不可保存并退款；纯 heartbeat 未发布假 plan 且主动取消可达。
- 在途请求各阶段与 DB snapshot 均保持旧自定义参数，后续请求采用新参数；N0 保留共同 Plan→writer，增强 N2 实际走固定编辑、三次审校与两次内容返修，参数在各阶段一致，一次扣次成立。Q02 在审校协议失败时保留最后有效稿并可保存；围栏 plan 不进 writer，heartbeat 可取消。
- AppDialog 首轮除焦点外均通过；返修后 desktop/mobile 各 32 次 Tab+32 次 Shift+Tab、nested keep、discard 父子同关与旧 opener 断开后的 save/refetch 精确恢复为 5/5 PASS，probe=0。
- R1 游客在 21.362s 得到 `basic V1`：planning+generation，额度100→99，can_save=true；input/output为3,531/788，总成本0.00068306 OpenRouter credits。
- R2 Pro在35.788s得到`review_passed V2`：planning+generation+fixed_edit+content_review，额度97→96，can_save=true；input/output为8,135/1,449，总成本0.001070272 OpenRouter credits。技术/固定编辑/审校真实执行，但内容返修0。
- R2 末句把新零件磨合期类比为 `juvenile birds`，`starting retroactively` 也不自然；审校仍记录 `pass`、空原因。增强审校分母1、返修触发0、独立明显漏判1；只描述本样本。

## 缺陷与门禁

CR-307 首次 [`browser.json`](evidence/cr306-qa/browser.json) 保持不可覆盖，修后 [`browser-focus-retest.json`](evidence/cr306-qa/browser-focus-retest.json) 独立通过，建议根代理同步 resolved。当前阻塞为 CR-308：需由 technical / AI backend owner 区分指定模型的一次概率性漏判与 prompt、稿件传递或审校路由偏差；第三次调用已停止。

## 证据与环境边界

本轮使用新空 PG18、全部当前 migrations（含 0017）、正式 backend、隔离 Nuxt 与 Chromium；没有历史迁移结论。生产源码清单匹配提交交接，只有 CR-306 文档因后续处理段追加而与早期 backend manifest 不同。共享工作树保持 dirty，QA 未改生产源码、控制面或提交。

原 QA02 的 CR-304/305 解决事实仍有效，见 [`qa-m003-001`](evidence/qa-m003-001/) 与 [`qa-m003-002`](evidence/qa-m003-002/)。本轮确定性 API 为 21/21、管线为 10/10；聚合为 [`qa-summary.json`](evidence/cr306-qa/qa-summary.json)，完整证据入口为 [`cr306-qa`](evidence/cr306-qa/)。

## 未验证

`AI-QUALITY-90`、长期质量成功率、供应商波动、生产迁移/容量、真机与人工读屏保持未验证。R1/R2 的真实 usage/cost 是两次请求的实际值，不是长期费用估计。首个 scene plan 与首正文时间已记录；首个词义/用法 plan item及全部五词 plan完成时间因脚本未逐项持久化而为 unknown，不补跑。

## 资源清理

QA 自有 54713 Nuxt 与源码副本已停止/删除；backend-ethan 已停止 disposable backend/provider/PG18，54772–54775 均关闭，并删除含 env、loader、PG data 的私有临时目录，未归档 secret。独立复核 54713/54772–54775 全部 CLOSED，见 [`backend-stack-cleanup.json`](evidence/cr306-qa/backend-stack-cleanup.json)。旧 UAT 端口在本轮起点已经关闭，不是本轮清理所停止；source Docker 未触碰。
