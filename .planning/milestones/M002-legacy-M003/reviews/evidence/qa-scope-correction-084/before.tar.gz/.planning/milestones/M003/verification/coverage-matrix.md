---
milestone: M003
stage: verification
role: quality/base
agent_name: qa-quinn
status: blocked
version: M003-QA-03-CR306
result: fail
date: 2026-10-12
---

# M003 独立 QA 覆盖矩阵

## 当前范围与方法

当前验收输入为 `M003-PRODUCT-09 / TECH-04 / BE-07 / DB-04 / FE-03 / API-306 / AI-7 / UI10-R1.1`，范围为 AC-317–322。QA 在本轮新建空 PostgreSQL 18 数据库上加载全部当前 schema（含 0017），使用正式 Go binary、隔离 Nuxt 页面、Chromium 与确定性 provider；没有复制业务库或把旧库升级当作本轮证据。原 UAT 3013/54672–54675 在本轮起点已关闭，本轮没有停止、重启或修改它们。

开发已有 Go/FE 测试不机械重跑。当前证据预算为 3 张新截图（上限 4）、真实完整调用 2（上限 3）；第三次因已有明确质量漏判而停止，不以盲重跑覆盖失败。旧 `M003-QA-02`、CR-304/305 已解决事实由 [`qa-m003-001`](evidence/qa-m003-001/) 和 [`qa-m003-002`](evidence/qa-m003-002/) 保留，本轮不复活。

| QA ID | 验收项 | 独立场景 | 当前结果 | 原件 |
|---|---|---|---|---|
| CR306-D1 | AC-317 | 管理员/非管理员；多模型参数隔离与 `{}`；保存重读；缺项/非法整单原子；409；保存 provider calls=0 | **PASS** | [`deterministic-api.json`](evidence/cr306-qa/deterministic-api.json) 21/21 |
| CR306-D2 | AC-318 | array/null/保护键/受控冲突/嵌套 headers/NUL/depth 9/规范化超限/重复 JSON pointer/整单 413；显式 probe 422 不重试并保留参数 | **PASS** | 同上；depth 8 被 QA 误当非法的首次方法失败原样保留于 `deterministic-api-initial-method-failure.json` |
| CR306-D3 | AC-319 | 在途 run 旧参数与新 run 新参数；N0/增强、固定编辑/审校/最多 N2、一次扣次、DB snapshot | **PASS** | [`deterministic-pipeline.json`](evidence/cr306-qa/deterministic-pipeline.json) 10/10；[`deterministic-db-facts.json`](evidence/cr306-qa/deterministic-db-facts.json) |
| CR306-D4 | AC-320 | 围栏 plan 不进 writer/不可保存/退款；纯心跳不造 plan 且可取消；上游拒绝；Q02 last-valid | **PASS** | 同上；围栏仅 planning，heartbeat/cancel 无假 plan，Q02 保留有效稿并可保存 |
| CR306-R1 | AC-321 | 指定 DeepSeek、游客 5 词中文 Story/Brief 完整真实链路；增强完整链路；质量/时延/usage/cost/配额/DB | **FAIL（技术链完成，质量漏判）** | [`real-r1.json`](evidence/cr306-qa/real-r1.json)、[`real-r2.json`](evidence/cr306-qa/real-r2.json)、[`real-evaluation.md`](evidence/cr306-qa/real-evaluation.md)；CR-308 |
| CR306-U1 | AC-322 | desktop/mobile 真 AppDialog、DOM/几何/键盘、错误草稿、晚 probe、四关闭入口、保存零调用 | **PASS（返修复验）** | 首败 [`browser.json`](evidence/cr306-qa/browser.json) 保留；修后 [`browser-focus-retest.json`](evidence/cr306-qa/browser-focus-retest.json) 5/5；CR-307 建议 resolved |

## AC-322 已通过与失败边界

两视口均通过 top-layer `:modal`、遮罩背景隔离、固定 header/footer、滚动无横溢、移动端 44px、重复键错误保留原文并聚焦、无 PATCH、显式 probe 参数与迟到结果 stale、四关闭入口统一脏确认、保存后重读和保存零 provider 调用。

首次焦点生命周期失败为从 textarea 键盘遍历第 14 次后落到 `BODY`，保存关闭后不回精确 opener。CR-307 返修后，两视口各 32 次 Tab + 32 次 Shift+Tab、nested keep、discard 父子同关、旧 opener 断开后的 save/refetch 精确返回均通过，probe=0。原失败保持，修后可建议 CR-307 resolved。

## AC-321 真实内容结论

R1 游客基础链在 21.362s 得到 `basic V1`，R2 Pro 增强链在 35.788s 得到 `review_passed V2`；两者 snapshot 均为 `json_schema + openrouter_require_parameters + reasoning.enabled=false`，配额各消费1，保存资格均为 true，usage/cost 已由供应商元数据记录。R2 实际调用 fixed edit 与 content review，但没有 content repair。

R2 的 `juvenile birds` 机械类比与 `starting retroactively` 明显牵强，审校却返回 `pass`。该单样本漏判已登记 [`CR-308`](../changes/CR-308.md)，阻塞 AC-321 内容质量 PASS；不能用 2/2 原生有效或模型自报 `pass` 替代独立质量结论。

## 方法原件与限制

- `deterministic-api-initial-method-failure.json` 保留 QA 将允许的 depth 8 用作非法样本所致首败；改为 depth 9 后相同产品检查 21/21 通过。
- 管线两次方法失败均未判为产品缺陷：替身没有规范化 `Chinese` 并误分类 technical repair。参数快照本身已有直接观察和 DB 一致证据，但整条增强/Q02 仍需最终替身重跑。
- `AI-QUALITY-90` 继续 **UNVERIFIED**。两个真实请求仅是有界故障复验，不形成总体成功率；N=2 是每 run 的内容返修上限，本次增强实际返修 0。
