---
milestone: M003
stage: technical-design
role: dba/base
agent_name: dba-diana
status: awaiting_user_review
version: M003-DB-02
date: 2026-10-09
---

# M003 数据库最小增量

本稿是可交后端落实的数据库设计建议，不代表已迁移或上线。依据 [M003-PRODUCT-03](../handoffs/product.md)、[M003-UI-02 接收](../reviews/ui-revision-007.md)、[DATA-301–304](../product/data-assets.md)、[CAP-301–305 / AC-301–314](../product/abilities.md)；确认范围见 [D3-01–08](../product/overview.md)、[Q01-B / Q02-A / Q03-RANGE99](../reviews/requirements-feedback.md) 与 [研发授权](../reviews/start.md)。付费档独立整数0–99、初始1及有效稿故障交付已 CONFIRMED；基础全请求2次与后台增强固定1次仍是当前技术/产品方案，不冒充用户逐字段确认。Profile 保持 consumer-ai-web@1.0.0。

本版取代DB01的固定开/1、禁止恢复最近有效稿、内容服务故障一律退款规则；[DB01冻结快照](../reviews/evidence/feedback-005/artifacts.tar.gz)及旧审批保持。DB3稳定编号不变，后端旧BE01/API依赖须同步，不能沿旧批准进入实现。
## DB3-01 现状、选项与范围

已只读核实：迁移最高为 `backend/db/migrations/0016_provider_workspace.sql`；单 PostgreSQL，四计划库内代码为 `visitor/registered/pro/plus`，API 的 `basic` 映射 `registered`，不能新增第五行。`growth_settings.revision` 是现有全局配置版本；`business.LockConfiguration` 先拿配置共享/排他锁，之后读取业务时间。`entitlement.Resolve` 只选基础/试用中优先级胜出的一份计划；模型卡、额外次数另行合并。

`generation_runs` 已承载逻辑请求、模型快照和终态，`generation_charges` 一请求一扣额来源；`ai_call_usage` 一提供方尝试一行（现实现先写 unknown 再调用）。预设已有不可变版本、预览 run、有效 payload 及手动发布指针。依据：`internal/admin/groups.go`、`internal/entitlement/service.go`、`internal/generation/{service,charge,usage,presets,preset_preview,preset_cleanup}.go`（均相对 `backend/`）。

选择直接扩展上述表，保留现有主键/FK/隔离/结算，不建独立权益、审稿任务、正文副本或统计平台。单列比 JSON 权益 blob 更易约束四行合法组合；调用事实放在既有 usage 行，比新增计数表更少双写。没有真实容量/慢查询证据，不新增索引、队列、分区、物化报表或通用审计表。

## DB3-02 计划配置（DATA-301；CAP-303）

`wordweave.entitlement_groups` 增加：

| 字段 | 类型 / 可空 / 默认 | 约束与用途 |
|---|---|---|
| `content_review_enabled` | boolean NOT NULL DEFAULT false | 一个审稿＋条件返修服务开关 |
| `content_repair_limit` | smallint NOT NULL DEFAULT 0 | 整数0–99；不是技术恢复预算 |

命名 CHECK `entitlement_groups_content_service_valid`：`(NOT content_review_enabled AND content_repair_limit=0) OR (code IN ('pro','plus') AND content_review_enabled AND content_repair_limit BETWEEN 1 AND 99)`。基础原生校验恒有，不设可关闭字段；基础全请求2次为后端系统策略、全部计划只读，不新增可编辑列，正式数值由pipeline版本定位。无只审不修、普通增强或独立审稿模型配置。API须先验证输入为整数再绑定smallint，不截断/四舍五入小数；DB约束兜底存储值范围。

初始化分两步但同一受控迁移事务完成：加列默认关/0；仅现有 pro/plus 行设开/1，visitor/registered 保持关/0，核验恰有四行；沿既有 `AdvanceConfiguration` 语义使全局 revision 仅前进一次（含现有重算标记），原配置时间戳仅按现有更新触发器推进。不得重跑旧 seed、不覆盖模型/长度/额度/优先级/期限/用量/activated_at。迁移账本保证只执行一次；应用每次启动不得重置管理员后来设置的开关或N。空库依顺序迁移也得到同一结果。此初始化只描述目标版本，本轮不执行，生产启用仍需发布授权。

管理读取、差异预览与保存复用全局 revision：预览持配置共享锁读完整旧配置和基础/有效体验人数，不写库、不调模型；保存配置排他锁→校验 expected revision→校验全字段→同事务更新计划/模型/长度及开关配对→revision 一次前进。非法/缺失新字段拒绝；不能把请求缺字段默认为增强。冲突整笔回滚，返回最新 revision 供前端重新预览；响应丢失先重读，不以旧预览盲重试。优先级批量保存原规则保留，无新逐用户模拟。

## DB3-03 受理快照和终态（DATA-302/304；CAP-301/302）

在 `generation_runs` 与 `preset_preview_runs` 同名增加以下列；保留原 `call_status/status` 作为唯一运行终态，不引入第二状态机：

| 字段 | 类型 / 初值 | 精确规则 |
|---|---|---|
| `content_policy_version` | smallint NULL；迁移前行 NULL，之后 DEFAULT 1 | NULL 仅表示历史未采集；非空仅允许 1 |
| `configuration_revision_snapshot` | bigint NULL，无默认 | v1 必填且 >0，存受理配置数字 revision，不存外部签名 token |
| `content_review_enabled_snapshot` | boolean NULL，无默认 | v1 必填，受理后不可随计划变更 |
| `content_repair_limit_snapshot` | smallint NULL，无默认 | v1 必填；用户关/0或开/1–99；后台预览单独限制关/0或开/1 |
| `pipeline_version_snapshot` | text NULL，无默认 | v1 必填且 btrim 非空；定位本次编排/提示集合与技术预算版本，具体版本字符串归后端 |
| `content_outcome` | text NULL，无默认 | active 时 NULL；v1 终态必填，枚举见下 |
| `final_content_version` | smallint NULL，无默认 | v1 valid 必填，用户1至N+1（最多100）、预览1至2；基础均为1；非valid与历史行NULL |
| `content_stop_reason` | text NULL，无默认 | 仅service_incomplete必填，其余包括active/历史为NULL；枚举见下，不存原始错误正文 |

仅 `generation_runs` 增 `plan_origin_snapshot text NULL`，v1 必填，允许 `visitor/base/trial`；visitor 行只能 visitor，账号行只能 base/trial。有效计划复用 `group_code_snapshot`，不可从 `generation_charges.plan_code` 推断（额外次数没有该列）；trial 不新增一套权益表或到期任务。v1 账号增强只允许 group snapshot 为 pro/plus；visitor/registered 固定关/0。配置 revision 是事实，不 FK 到持续变化的配置行。分别命名两表快照CHECK：用户关闭/0或付费开启/1–99；预览关闭/0或开启/1，不读取Pro/Plus的N。`final_content_version`不参与受理必填，只有最终valid提交时才赋值。

所有新 CHECK 用命名约束并显式判断 `IS NOT NULL`，避免 SQL NULL 穿透：旧行 policy=NULL 时全部上述新事实和 origin/outcome 维持 NULL；policy=1 时完整快照、合法配对、来源及下表终态必须同时满足。先加无默认可空列保留旧行，再给 policy 设置 DEFAULT 1；新应用所有 INSERT 必须显式提供 v1 全字段，不允许借 NULL 绕过受理。库检查与仓储测试共同落实，不为兼容旧调用方填造假历史值。

| `content_outcome` | 与原终态/权益一致性 |
|---|---|
| `basic` | valid 且关闭服务 |
| `review_passed` | valid 且增强，末次已判定通过、未执行内容返修 |
| `repaired_passed` | valid 且增强，已执行至少一次且不超过N的内容返修、最终交付版本已判定通过 |
| `limit_finalized` | valid 且增强，已用尽内容返修预算且最后稿原生有效；最终内容结论仍有问题，不冒充通过 |
| `service_incomplete` | valid 且增强；内容审校技术故障或返修新稿基础恢复失败，交付最近基础有效整稿；仍消耗一次业务额度 |
| `cancelled` | generation 的 user_cancelled / preview 的 cancelled；即使曾有有效稿也不转故障交付 |
| `failed` | generation 的既有四类失败 / preview 的 failed；详细原因沿 failure_code/failure_category |

行级 CHECK 兜底终态/权益组合；跨调用的“已返修/最终版本实际通过/次数上限”在终态仓储事务核验。达到内容上限不能写 validation_failed；无效新稿不能写limit_finalized，有最近有效稿时按service_incomplete交付，否则失败。service_incomplete的原failure_code/failure_category仍为NULL（run已valid），不改变原扣次/累计约束。历史结果保持原值，NULL不是“曾审稿通过”。

`content_stop_reason`白名单为 `content_timeout/content_rate_limited/content_transport_error/content_protocol_error/content_review_invalid/repair_native_invalid`：依次表示内容阶段单次/总时限、限流、连接/上游断流、协议错误、审稿不能判定、返修稿基础校验恢复耗尽；恢复调用本身发生技术错误使用对应前五类。CHECK显式要求 `content_outcome='service_incomplete'` 时原因非NULL且在白名单，其他状态原因NULL。具体错误到这六类的映射由backend-alex定稿；不含主动取消、客户端写流/断连、DB不确定或进程崩溃。API completion notice由service_incomplete稳定映射“内容审校未完成”，无需重复存文案或布尔标志。

首稿内容版本为1，每次内容返修候选分配下一版本；同候选的基础纠错沿用版本、不新增版本。只有全套原生校验成功才用该版本及正文/标签/释义/全部位置**整包**替换内存中的最近有效稿；旧有效包保持到替换成功。最终只将选中包写入既有generation_drafts/preset_previews，并在同事务写final_content_version；它来自该包的身份，不从实际返修次数、call_no或最后一次尝试倒算。例：首稿v1有效，返修v2无效且恢复耗尽，最终仍v1、service_incomplete；正常两轮后可为v3。运行校验最终版本≤快照N+1且来自本请求有效包，最高100不代表需实跑99轮。

候选稿和意见只在请求内存，不为多轮建立持久中间稿库。已提交终态的状态查询/最终响应从run读取outcome、version并导出notice，再读取同一最终draft或已保存批次；后台从preview run/validated_payload读取。不得刷新后丢提示、重新造文或把较新无效片段当最终稿；原token、主体隔离、状态窗口/draft TTL保持，不新增无限恢复承诺。单次进程崩溃不承诺找回尚未提交的内存稿。

## DB3-04 最小逐调用事实（DATA-302/304；CAP-305）

扩展 `ai_call_usage`；保留现有 owner XOR、`UNIQUE(user_run_id,call_no)` / `UNIQUE(preview_run_id,call_no)`、模型/费用/token 和级联：

| 字段 | 类型 / 默认 | 规则 |
|---|---|---|
| `call_stage` | text NOT NULL；旧行填 `legacy`，随后移除默认 | 新值仅 `generation/technical_repair/content_review/content_repair`；新写必须传入，不猜旧行阶段 |
| `prompt_version` | text NULL，无默认 | 非 legacy 必填且非空，实际该次 prompt 版本；不保存 prompt 正文 |
| `provider_invoked` | boolean NULL，无默认 | NULL 未确认、false 明确未发出、true 已调用提供方适配器发送边界；不是费用已知标志 |
| `review_result` | text NOT NULL DEFAULT 'not_applicable' | 枚举 `not_applicable/pending/pass/issues/indeterminate`；仅 content_review 可用后三种及 pending |
| `reason_codes` | text[] NOT NULL DEFAULT '{}' | 去重、无 NULL；只含 `forced_wording/contradiction/other_content`；具体自然用词、逻辑、主题/文体细类由后端映射，不含句子 |
| `repair_requested` | boolean NOT NULL DEFAULT false | 仅 review_result=issues 可为 true；表示决定返修，不表示执行 |

CHECK：content_review 的 review_result 只能为 pending/pass/issues/indeterminate；非 content_review 的 review_result 必为 not_applicable 且 repair_requested=false；review_result=issues 必有非空 reason_codes，pass/pending/indeterminate 原因数组为空；除 content_review/content_repair 外数组为空；content_repair 必有非空原因（从触发审稿复制，保留同篇双类），legacy 新字段为 NULL/空/不适用。判定去重可由 `reason_codes` 限定为三元素白名单并在仓储规范排序去重；数组数量≤3、无NULL与白名单包含关系由 CHECK 执行，重复值由仓储拒绝。无需新自引用 FK 或审稿意见表。

每次提供方尝试在调用前短事务预留唯一 call_no、阶段/提示/原因，usage 仍 unknown；若预留失败不发送。审稿响应解析后，在一个短事务写 review_result/原因/返修意图，再允许后续返修。实际调用确认和用量由 adapter 回调同一行更新；发出后限流/超时仍可为 provider_invoked=true，发送前拒绝为 false。不能用存在 usage 行、阶段进入、repair_requested、收到费用与否替代实际调用。

DB 与远端发送无法原子提交：进程在发送边界崩溃或回调写入失败时保留 NULL（未知），不猜 true/false、不自动重发；重启既有失败结算路径可把 pending 审稿标 indeterminate，不能伪造“未发生”。统计单列未知调用/请求数；已确认频率与未知上下界并列，不能宣称崩溃窗口精确计数。backend-alex 负责为各 adapter 明确“已调用”证据和回调时机，测试必须覆盖这一窗口。`completed_at` 现有预留占位语义不作为真实调用完成证据。

普通请求不得预留 content_review/content_repair。增强按受理快照N（用户1–99、后台1）分配内容返修位置，最多N个；未确认尝试暂占位置，不在不确定后自动重发突破预算。实际次数只数provider_invoked=true，false和NULL不伪装实际调用；发送前已失败、未知发送或时限保护若终止内容服务，按DB3-03/05选择有有效稿交付或失败，不保证用满N。

一个逻辑请求内串行分配call_no。基础纠错按整个请求共享当前后端建议2次；内容返修另计N，审稿/复审及本地校验不扣两类修复预算，换稿不重置。technical_repair行保持reason_codes为空，不能混入内容缺陷原因计数；具体基础错误沿原诊断分类，无需新统计列。pipeline版本定位技术预算/复审与保护时限，后端须定稿。实现按N控制循环，流程测试到2不是运行上限；无新增高轮次队列/后台续跑。`model_snapshot` 必须等于该 run 的目标模型快照，连接绑定沿原受理 spec；后续调用不重读可能已修改的模型连接。

## DB3-05 事务与竞态

| 边界 | 增量与原子性 |
|---|---|
| 受理普通/用户预设 | 配置共享锁→账号/访客锁→锁后业务时间解析唯一有效计划和模型→检查额度→一次 INSERT run（含完整内容快照）、entries、原来源 charge 与既有开始事实→COMMIT；全部成功才调模型；预设配置例外不复制后台模式 |
| 受理后台预览 | 配置共享锁→管理员存在校验/预设版本匹配→插入 preview run 快照；明确模式生成关/0或开/1，不解析管理员计划、不写用户 charge |
| 每次调用/审稿事实 | 短事务、幂等按 owner+call_no；不得持配置锁、账号锁或 DB 事务等待网络/流；后续阶段发起前检查取消/终态，已在途调用可稍后补记真实用量但不能恢复 run 状态 |
| 有效完成 | 沿 `CompleteValid`：配置共享锁→主体锁→active CAS→质量终态/跨调用事实校验→原 charge consumed/原成长与分析→选中最终有效整包的draft INSERT及outcome/version/stop_reason，单次提交；service_incomplete走同一有效完成事务，不先失败退款再转成功；预览对应active CAS+三项终态事实+完整preset_preview+匹配关联同事务 |
| 取消/失败/恢复 | 沿 `SettleTerminal/ReconcileFailure`：CAS、outcome、原来源 charge/refund、分析同事务；取消消耗一次；内容服务故障且有最近有效包优先走上行valid，只有无有效稿或不适用Q02的既有失败退原来源；额外次数返还原 item 即使已过期也不延长 expires_at、不新造永久额度；重启核对已提交终态不改写；仅未完成且无法恢复内存稿的run按原恢复路径写outcome=failed |
| 保存/承接/放弃 | 原唯一 run→batch / claim 事务不变，不因返修建第二个业务 run、不再次扣额；完成 ACK 不明读库终态+原 charge+最终 draft，禁止再调模型“重建成功” |

用量更新不与用户扣次绑定：失败/取消后真实提供方用量仍可能非零；未知用量保持 NULL，不补零。若关键审稿/返修事实无法持久化，或最终提交/结算不确定，不发送后续调用、不开保存、不伪装service_incomplete；先保持pending核对已提交终态，确认仍active后才能按既有server_failed原子退款，无法确认继续待核对。费用回调晚到可更新原 usage，不能改权益或终态。账号已删除时 FK/影响行数阻止重新创建事实。完成、取消、断连、账号删除、维护退款竞争只允许一个已提交终态；前端片段与内存状态不授予保存资格。

## DB3-06 预览模式与发布关联（DATA-304；CAP-304；UIA-M003-306/307）

`preset_versions` 增 `preview_content_mode text NOT NULL DEFAULT 'basic' CHECK (... IN ('basic','enhanced'))`。旧版本、已有成功预览按原行为归 basic；preview run 的两列权益快照表示其模式，不再重复加模式列。旧 run 的 policy NULL 可用于证明旧 basic 预览，绝不视为增强。

选中模式保存为草稿版本的后台元数据；不加入公开 `configuration`，不修改原 config_hash 算法或用户输入参数。版本“生成条件”是 `(config_hash, preview_content_mode)`，所有读取/复用/发布校验同时比较两项及原 configuration 等值条件。UI 本地模式变化立即使 ready 失效；服务端在启动预览/发布前必须已保存对应模式版本，如何承载该更新由后端 API 决定。

修改模式创建新版本、清空 preview_id 并推进既有配置/preset revision；只有与**紧邻旧草稿**生成参数和模式均相同的纯标题变化可以继承旧 preview_id。basic→enhanced→basic 不能自动恢复先前预览；当前新模式须有新的成功预览。新预览完成仅可填入其匹配版本的空 preview_id；不得回写新草稿模式，不覆盖公开版本或已有公开样文。并发旧模式晚完成可记录成功事实和独立用量，但不能解锁当前新模式的发布。

发布事务沿现有配置排他锁+预设锁+expected revision+当前 draft version，增加 mode 匹配与完整 payload/valid/outcome 检查。上限定稿及service_incomplete的有效增强预览均可手动发布；后者的预览/状态/发布确认必须保留“内容审校未完成”，不得标通过；片段/失败/取消/结算未知不可。增强始终固定N=1，不模拟付费计划N。发布只更新 published_version_id/listed 等原字段；旧线上版本保持到人工发布成功。用户点击已发布预设时只读公开生成参数，再按本人计划受理；后台 enhanced 不能赠送读者权益。

## DB3-07 统计、保留与权限

以 run 为分母，usage 为调用事实；按受理 started_at 时间窗、entry_kind 和后台预览分组，先逐 run 聚合再计数，避免多调用 JOIN 放大分母。M003 正式统计限定 policy_version=1；历史 policy NULL 单列覆盖量，不伪装基础新请求。全部受理=run 数，增强=快照 true，实际审稿=存在 content_review 且 provider_invoked=true；失败/取消仍属于已受理，不因退款从分母消失。预检拒绝沿现有 `generation_precheck_rejected` 事实单列，不造 run。

实际返修请求=存在 content_repair 且 provider_invoked=true 的去重 run；实际返修调用=对应行数；同run执行多轮仍只算一篇，基础纠错调用单列不混计。牵强/矛盾分别按**实际返修行** reason_codes 计请求/调用，交集与并集用 run 去重；审稿发现原因及 repair_requested 另计，复审拒绝但没再调用不增返修。分母为0给 N/A；未知调用单列，NULL 不当 false。费用/token 沿既有 known/partial/unknown 汇总，不能凭审稿通过宣称独立质量通过。查询/诊断输出即可，不新增 UI 报表或永久计数副本。

交付率=valid用户run/全部受理用户run（包含service_incomplete）；审校完成率=(review_passed+repaired_passed+limit_finalized)/增强受理用户run，普通basic不进入该分母。审稿通过与上限定稿分开，service_incomplete计入交付但不计审校完成/通过，按stop_reason单列；取消、pending及后台预览单列。独立质量仍来自QA评阅，不能用交付或自报pass替代。未确认发送采用原未知区间，不以最终稿版本差推算实际调用；不新建报表或永久汇总副本。

新事实与父记录同寿命、同 owner 删除：账号删除级联 run→usage，沿既有 credited visitor/claim 显式删除规则；本人主动删批次同事务删除 consumed claim（USER-CLAIM-DELETE-001），不为统计留正文墓碑，原无正文计量事实按既有规则保留。draft 沿配置 TTL，consumed claim 其余情况24小时，闲置访客30天且无阻塞资源时清理；不把 analytics 明细90天误套成所有 run 的 TTL。后台预览清理沿 `CleanupPresets`：当前草稿/发布/在途引用保留，非引用内容经过原1小时窗口清理，preview run/usage事实保留，不因模式切换提前删公开内容。

不在新列写原句、审稿正文、候选稿、内部推理、秘密或学习资源副本；处理期候选/意见仅请求内使用，最终正文/标签/释义/全部 occurrence 通过现有有效 payload 原子保存。既有专用账号诊断24小时及其授权范围保持，不顺势扩为普通账号正文留存。新增列沿原表权限，不新增跨用户可读入口；后台模式/配置仍由服务层管理员鉴权，数据库连接身份不能代替登录者权限。

## DB3-08 保留数据的迁移、恢复与验证

新增递增迁移（当前候选0017，实施先核对实际最大号），原0001–0016不改。只做列/约束/精确初始化，不 DROP/TRUNCATE、重建用户/词表/学习库/密钥/模型。切换沿 [M002 数据库 §12](../../M002/technical/database.md)：配套版本停写窗口、等候或按原失败路径结算在途、关闭旧进程写入后迁移；不承担旧协议、双写或混跑，USER-COMPAT-001 不等于可删旧完整业务数据。

迁移前记录schema版本、各表行数/主键集合及不含凭据原文的摘要；可恢复备份需在隔离库演练。新增历史事实保持未知，已有正文/学习字段/已发布预览/pointer/hash/charge/库存/有效期限完整保留；四计划仅允许新列及其更新时间变化，growth_settings仅预期revision/重算字段变化。验证约束后才切新配套服务；未完成配置/缺列/非法组合须失败关闭服务受理，不能兜底赠予增强。本期DB01尚未实施，直接在首个新迁移落实DB02，不虚构线上DB01→DB02迁移。若实施发现目标库已有新增列，先核实实际迁移版本并另行前滚放宽约束/补列，保留管理员原N/开关，不重跑初始1、不伪造历史终态。结构新增与初始化失败整笔回滚并保持停写，已经有新版业务写入后优先前滚，不直接 drop 新列或恢复旧备份丢失新事实。

备份权限、加密、删除补救沿 M002，不另许诺生产PITR/RPO/RTO或新增期限。恢复先核对恢复点之后已确认删除与charge状态，避免恢复已删内容/重复扣退次；无法证明则不开写。未知发送只标未知/结算失败，不在恢复中重放模型调用。

| 验证 ID | 对照验收 / 必须给出的隔离证据 |
|---|---|
| DB3-V01 | AC-304 / AC-305 / AC-314；空库完整迁移、含旧完整数据库升级；付费独立0/1/2/99存取、负数/100/小数/空值及开关联动非法输入拒绝（小数在API类型层，DB检查整数域），普通增强拒绝；只改允许字段，不重seed；二管理员同revision至多一笔成功，失败/响应丢失无半配置 |
| DB3-V02 | AC-301 / AC-306 / AC-307；配置更改/试用到期/优先级变更与受理的两种先后，快照一致；basic+模型/次数卡不赠服务；增强用extra仍增强；在途不受新配置影响 |
| DB3-V03 | AC-302 / AC-303 / AC-308 / AC-311 / AC-313 / AC-314；仅执行最多2轮内容返修与共享基础纠错混合示例；有效包及final_content_version对齐，修前/修后校验；通过/上限定稿/service_incomplete/无有效稿失败/取消唯一终态；有效稿+审稿超时/限流/协议/解析/返修无效恢复耗尽、无有效稿和DB未知各自分支，最终响应与查询均保留提示；事务末步失败全回滚；CAS竞争、COMMIT不明、重启、extra过期退款、保存和claim不重扣 |
| DB3-V04 | AC-309；默认basic、enhanced固定1、service_incomplete有效预览提示与手动发布、双向切模式与切回、纯标题复用、旧调用晚完成、并发发布；失败不改公开pointer，用户权益不取后台模式；旧完整样文和学习资源保留 |
| DB3-V05 | AC-310 / AC-314；交付/审校完成/独立质量分离、两轮内容与基础调用分开、同run去重、0分母、正常/预设/后台分离、牵强与矛盾交集/并集、意图后未调用、调用失败/未知、复审拒绝、多usage行无分母放大、未知费用不为0 |
| DB3-V06 | 隐私/运维；跨账号读写拒绝；批次/claim、账号/credited visitor删除清理新事实；预览清理不删公开内容；迁移失败回滚及隔离恢复核验新旧完整数据，旧运行行不伪造审稿事实 |

CQ-14验证边界：配置0/99及非法值不调用模型；内容返修流程仅测至2轮，实施静态检查循环消费N，不硬编码2；final_content_version边界100只做字段/约束样例，不执行3–99轮链路、不声称高轮次通过。AC-312仍归独立质量验证。

以上为待实现计划，未执行真实数据库迁移或运行测试。本轮静态检查：两份文档本地Markdown目标0断链，DB3-01–09与DB3-V01–06定义齐全；字段空值/默认/约束人工交叉核对完成。只读源码核对和文档静态核对不能证明上述PASS。既有 CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX 保持原状态；AC-312 精简链路真实质量、时延/费用未验证，须由后续QA按授权评价，不能从存储设计推出质量达标。

## DB3-09 下游责任与接续条件

无阻塞产品决定、无新增CR。backend-alex 可基于本设计继续：按PRODUCT03/UI02和本DB02同步BE01/API：按N循环、基础全请求2次正式定稿及保护时限、最终有效包版本/6类stop reason映射、可恢复notice、adapter实际调用证据、有效故障交付与取消/DB未知的唯一终态；旧禁止回退与一律退款失效。这些影响调用事实与终态写入，不重复审批已确认数值/计次。若需调整本文列或分类，先在技术交接指出差异交DBA收敛，不能另建竞争真源。frontend-bob落实 revision冲突、模式先保存再预览、草稿替换/终态才可保存；qa-quinn负责DB3-V01–06（AC-301–311/313/314）与独立AC-312证据，遵守流程仅执行到2轮、配置边界独立核对。实施前后端必须给出明确上述边界，不能把“由后端决定”当作不实现。

本稿完成条件是上述数据增量、迁移和接续责任可审阅；建议 awaiting_user_review，由控制角色按既有委派流程接收，不自行改 workflow 或宣布通过技术总门禁。
