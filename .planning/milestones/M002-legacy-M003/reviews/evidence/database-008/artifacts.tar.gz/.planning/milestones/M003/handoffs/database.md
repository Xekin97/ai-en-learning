---
milestone: M003
stage: technical-design
role: dba/base
agent_name: dba-diana
status: awaiting_user_review
version: M003-DB-02
date: 2026-10-09
input_version: M003-PRODUCT-03 / M003-UI-02
---

# M003 DBA 交接

已修订 [数据库增量 M003-DB-02](../technical/database.md)，建议 awaiting_user_review；本角色没有切换流程、修改源码、执行迁移/种子/真实调用。本版待接收，旧DB01批准不覆盖本版；[feedback-005冻结原件](../reviews/evidence/feedback-005/artifacts.tar.gz)保持。

## 输入与确认闭环

- 已核实 [workflow](../../../workflow/state.yaml) 的 TRANSITION-M003-007 / technical-design / dba/base / dba-diana，以及agents同名激活；[锁定Profile](../reviews/evidence/start/locked-profile.yaml)仍consumer-ai-web@1.0.0。沿已读取agt-database-design技能、共同契约、DBA角色及交接模板恢复，不迁移Profile。
- [产品03](product.md)、[产品接收006](../reviews/product-revision-006.md)、[UI02](uiux.md)、[UI接收007](../reviews/ui-revision-007.md)、[用户反馈确认](../reviews/requirements-feedback.md)；追踪DATA-301–304、CAP-301–305、AC-301–314及UIA-M003-301–309相关状态。
- Q01-B/Q03-RANGE99已确认：Pro/Plus独立整数0–99，初始1，0关闭整个审校；配置0/99另验，流程执行仅到2轮。Q02-A已确认：内容服务故障且有最近基础有效整稿则可保存、提示未完成、仍计一次。基础共享2次为后端系统策略建议、只读；预览基础0/增强固定1沿产品03方案。
- 撤销DB01固定开/1、禁止恢复有效稿和内容故障一律退款。取消/客户端断连、DB不确定及崩溃恢复仍各守原边界，不以Q02掩盖不确定终态。USER-COMPAT-001与USER-CLAIM-DELETE-001保持；无新增业务分歧、无需重复用户选择。
- 模型锁继续frontier/high，requested gpt-6-astra/high；actual_model/usage未知，不声称独立核验运行服务模型。

## 最小增量与下游差异

- DB3-02/03：计划及用户快照约束改0–99/开关配对、普通固定0；预览独立0/1。初值只在首次迁移写1，不覆盖管理员配置；现有revision、试用唯一计划、在途快照与历史NULL规则不变。
- DB3-03：新增valid下的service_incomplete结论；两张run表各增final_content_version和content_stop_reason。版本取最终有效整包身份，基础纠错不另增版本，最大100；六类精简中止原因。notice从结论映射，无独立通知表、无中间稿副本库。
- DB3-04/05：内容按快照N独立计次、基础全请求预算不重置；实际发送true/false/unknown事实保持。有效故障交付与最终整包、版本/原因、charge consumed同事务；无有效稿按失败退款，DB未知先pending核对，不先退款再转成功。
- DB3-06/07：后台增强始终1次；有效未完成预览带提示后可人工发布。多轮文章按run去重、实际调用单列；交付/审校完成/审稿通过/独立质量分开，基础与内容原因不混计；原删除、保留及隐私规则保持。
- DB3-08：候选0017仍待实施核对；迁移源实际最高0016，DB01未落库，不虚构已部署版本。AC-301–314通过DB3-V01–06及独立质量检查追踪；只到2轮流程测试，不把99配置验证说成99轮链路通过。

## 文档维护与设计验证

只维护本数据库正文及交接，保留DB3-01–09/DB3-V01–06稳定ID；未修改源码、控制面、其他专业原件、冻结研究或旧证据。沿已读现有表/事务证据，定向重新核对迁移最高0016；无需全量重读历史。正文提供历史NULL、复用表和不新增平台的理由。

静态检查已完成：Python检查两份版本均DB02、本地Markdown目标0断链、DB3-01–09/DB3-V01–06及AC-301–314逐项存在；旧固定一次/一律退款活动规则定向复查无残留。首次检查因AC简写无法匹配失败，已展开稳定编号并重跑PASS，未涉及运行代码。迁移、DB约束/事务、API/流式、模型质量及用户UAT均未执行。本轮输入token/usage未知，文档字符数不等同token；未执行新会话恢复测试。

## 未决、风险与下一步

- BLOCKED：无；开放CR：无。可按当前授权接交backend-alex，本角色不激活下游、不改state。
- backend-alex须同步BE01/API/AI原件的旧固定一次、禁止回退、一律失败退款规则；定稿按N循环、基础2次及保护时限、6类中止原因映射、最终有效包版本、notice查询恢复、取消/断连/DB未知与退款边界。字段和事实真源仍在DB3-03–05；需要调整则定向交DBA收敛。完成条件为这些契约一致且没有继续依赖旧结算规则。
- frontend-bob待正式后端契约：动态N/预算分离、整体替换、service_incomplete提示与保存、pending不可保存、预览固定1及手动发布；不得从原型猜协议。
- qa-quinn在实现后验证DB3-V01–06与AC-312；当前AC-301–314均未获实现PASS。保留CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX及真实质量/费用/时延未知，不扩大本期修复范围。
