---
milestone: M003
stage: technical-design
role: dba/base
agent_name: dba-diana
status: awaiting_user_review
version: M003-DB-01
date: 2026-10-09
---

# M003 DBA 交接

已交付 [数据库增量 M003-DB-01](../technical/database.md)，建议 awaiting_user_review；本角色没有切换流程、修改源码、执行迁移/种子/真实调用。当前版本是工作树文档，待控制角色接收并冻结，不冒充已批准版本。

## 输入与确认闭环

- [锁定Profile](../reviews/evidence/start/locked-profile.yaml) consumer-ai-web@1.0.0、`.planning/agt/project.yaml` / `agents.yaml` / `workflow/state.yaml`：已核实 M003 / technical-design / dba/base / dba-diana 激活。
- [产品交接](product.md)、[UI交接](uiux.md)、[设计接收](../reviews/uiux-design.md)；DATA-301–304、CAP-301–305、AC-301–312、UIA-M003-303–306；[USER-M003-CONTENT-20261009](../reviews/start.md)、D3-01–06。
- 已确认分层、同目标模型、上限定稿仍原生有效、真实返修频率；D3-05/06 的Pro/Plus初始化开/1和后台模式保持委派建议，不当作新增线上启用授权。未知配置不赠增强，模型/次数卡不赠内容服务，试用取唯一有效计划。
- USER-COMPAT-001 不承担旧版本兼容，仍须保留完整现有数据；USER-CLAIM-DELETE-001 的删批次同时删claim例外继承。冻结研究、M002审批和旧质量未验证项未改。
- 采用模型锁 frontier/high（requested gpt-6-astra/high）；没有独立 actual_model/usage 元数据，不声称已核验服务模型或精确token。

## 接续入口与自检

- DB3-02：四计划新增配对列、一次初始化、现有全局revision；DB3-03：请求受理快照与质量终态；DB3-04：既有usage逐调用事实及未知发送窗口；DB3-05：一次结算、事务与竞态；DB3-06：预设版本模式和发布关联；DB3-07–08：最小统计、原保留删除、迁移恢复及DB3-V01–06。
- 已只读核实实际迁移0001–0016以及 `backend/internal/admin/groups.go`、`entitlement/service.go`、`platform/business/state.go`、`generation/{service,charge,usage,presets,preset_preview,preset_cleanup}.go`、maintenance/learning删除路径。无新增表/索引/队列；不持DB事务等待模型。
- 关键现状差异：数据库basic叫registered；额外次数的charge不保存计划，需run独立origin快照；现有usage预留行不证明实际调用；预览只比较config_hash不足以保护新增模式，须同时核对mode和当前版本。
- 静态验证：本轮新建两份Markdown；Python静态检查退出0，Markdown本地目标0断链，DB3-01–09及DB3-V01–06齐全；字段空值/默认/约束人工交叉核对完成。未执行迁移、PostgreSQL约束/事务测试、模型调用、UAT或上线。

## 文档维护

当前真源仅 `technical/database.md` 与本交接，DB规则按DB3稳定ID集中维护；无附加附录/CR、无历史搬移或覆盖。引用M002未改保留/恢复规则，新增规则不复制旧库全量设计。产品planning读取超过8k软目标，原因是实际权益/扣额/预览和删除依赖核对；代码/基座单独计量，运行时input token unknown；交付正文及交接合计约13.6k字符、186行，字符数不等同token。交接前执行静态检查，未执行新会话恢复测试，不将静态检查等同接收成功。

## 未决与风险

- BLOCKED：无关键业务阻塞。开放CR：无。普通可逆细节不重复申请用户批准。
- 后端必须收敛：pipeline/提示集合和整个逻辑请求的技术预算；复审方案对应的content_outcome；各adapter确认实际发送的时机及未知窗口；SSE/取消/退款竞态和关键事实写入失败策略。责任backend-alex，影响DB3-03–05的实施；可以现在继续架构设计，实施前需明确，不能留模糊实现空洞。
- 未验证：DB3-V01–06 / AC-301–312均是计划，真实数据保留迁移、并发、隔离/删除、实际服务商频率/时延/成本没有通过声明。未知调用不能当作未发生返修；旧记录未知事实不能编造。
- 既有 CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX 沿 [workflow保留项](../../../workflow/state.yaml) 和原验证入口保持，不扩大为本期额外全量修复。

## 下一步

控制角色可在既有委派范围接收本稿并接交backend-alex，当前角色不改state。后端以DB3-09责任落实API/编排/流式和上述边界，若字段需变由DBA就地收敛；frontend-bob接收模式/revision/最终批次规则；qa-quinn在实现后提供DB3-V01–06与独立质量证据。完成技术总门禁仍需其余Profile产物和对应交接，不以本DBA交付替代。
