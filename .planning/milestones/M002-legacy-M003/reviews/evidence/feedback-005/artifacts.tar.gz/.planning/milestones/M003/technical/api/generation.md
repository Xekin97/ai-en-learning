---
id: API-301-302
version: M003-BE-01
status: awaiting_user_review
milestone: M003
---

# 权益、生成流与唯一终态

关联CAP-301/302/305、DATA-301–303、PAGE-204/215/216、AC-301–303/306–308/310–312。V=访客，L=本人学习者；管理员仍用独立预览。下文路径均省略 `/api/v1`，公共封套/错误继承[index](index.md)。

## API-301 选项与受理

`GET /generation-options` V/L：保留M002完整字段，增加必填 `configuration_revision:string`（不透明签名配置版本）、`content_service:ContentService`。原 `effective_plan={code:visitor|basic|pro|plus,origin:visitor|base|trial,trial_ends_at:Time|null}`不变。返回版本与权益从同一配置共享锁内读；availability仍由模型/长度/额度等预检决定，增强不授予额外生成资格。

```text
ContentService = {native_validation:true,content_review_enabled:false,content_repair_limit:0}
               | {native_validation:true,content_review_enabled:true,content_repair_limit:1}
```

这是严格判别联合；visitor/basic固定第一种，Pro/Plus可第一或第二种。页面只依返回布尔显示包含/未包含，不凭计划名、模型卡、次数卡或公开预设样文推断。试用只取唯一胜出的有效计划；`configuration_revision`不是客户端缓存权限凭证。

`POST /generations/stream` V/L：请求仍严格为 `{model_id:string,meaning_language:zh|en|ja,scenario:story|discussion|business|news,length:short|medium|long|xlong,entries:string[]}`，64KiB限制及原词表/权限/长度校验不变。不得传content_service/mode/review/prompt/provider字段。事务再次解析当前权益，不要求请求携旧options版本；若选项已过期但当前仍可生成，受理的started快照覆盖页面预估，客户端同时刷新options供下次使用，不能改正在执行的快照。当前输入已不合法→422；无权限403、active冲突409 generation_in_progress、次数不足429 quota_exhausted、配置/凭据不可用503 generation_unavailable，均不调用提供方。

受理事务失败且确定未commit→普通Problem，无started。COMMIT确认丢失→服务端用已分配run ID短时读回：只有完整run/charge确认才继续；确认不了不调用，返回503 temporarily_unavailable，交现有恢复结算，不宣称未扣次。generation POST没有自动幂等重放；前端不得断网重发，用户明确再次生成才是新业务意图。受理后每主体普通/预设共用一个active槽。

## API-302 SSE 精确事件

受理COMMIT确认后立即发送200 SSE及 `generation.started`，**成功写入/flush started后才打开第一次上游**。started写失败→stream_failed结算；上游未调用。上游Open随后失败也走本流failed/settlement_pending，不再改成普通JSON错误。headers沿M002，15秒 `: heartbeat` 仅保活；每次write/flush有10秒截止，成功后重新设置下一次截止，不让慢浏览器无限占用。无Last-Event-ID/重连重放。

所有命名事件增加 `seq:int`，从1严格递增，整个用户run一序列；heartbeat不占seq。以下为**完整data字段**（Result见后）；服务端单一事件writer按产生顺序串行写，terminal不能越过前面的候选事件。

| event | data | 含义 |
|---|---|---|
| `generation.started` | `{seq,run_id,generation_token,snapshot:RunSnapshot}` | 只一次，冻结本次权益 |
| `generation.stage` | `{seq,stage:"generating"|"native_repair"|"content_review"|"content_repair",content_version:1|2}` | 对应该次实际上游发送已确认，非定时或意图进度；重复review可发生在另一版本 |
| `passage.snapshot` | `{seq,content_version:1,passage:string}` | 首稿当前已安全解析的可读累计干净文本；整体替换可见草稿正文；没有学习字段 |
| `generation.candidate` | `{seq,content_version:1|2,result:Result}` | 此稿已原生有效，但未业务定稿；整体替换正文/tags/targets，仍不可保存 |
| `generation.validated` | `{seq,run_id,content_version:1|2,result:Result}` | DB已确认valid和完整最终draft；唯一成功终态，可依身份保存/claim |
| `generation.failed` | `{seq,code:FailureCode,quota_refunded:true,retryable:bool,request_id:string}` | DB已确认失败/原来源退款；不可保存 |
| `generation.cancelled` | `{seq,quota_refunded:false}` | DB已确认主动取消，计一次；不可保存 |
| `generation.settlement_pending` | `{seq,code:"settlement_unconfirmed",request_id:string}` | 数据库终态无法确认；关闭本流，**不是业务终态**，无退款声明；走状态核对 |

`RunSnapshot={configuration_revision:string,effective_plan:{code:visitor|basic|pro|plus,origin:visitor|base|trial},content_service:ContentService}`。origin与计划代码来自run受理事实；不再报告会随时间变化的试用倒计时，UI可用options的trial_ends_at作为独立资料。pipeline版本/内部内容结论不公开。

`Result={passage:string,tags:string[],targets:Target[]}`；Target完整类型沿 [M002书架](../../../M002/technical/api/identity-library.md)：`{entry:string,entry_meaning:string,hint_phrase:string,hint_blanks:[{start:int,end:int}],occurrences:[{surface:string,start:int,end:int}]}`；所有offset按Unicode code point、半开区间；每个原词一个target，顺序=输入顺序；正文与学习字段必须来自同一版本。candidate/validated严格校验完整Result，不从先前草稿补缺字段。

### 可见时序和reducer规则

1. started进入generating、固定snapshot并开放取消。首稿上游已发送才stage=generating；还在打开时保持等待，不宣称上游已工作。
2. passage extractor消除JSON转义与内联标注后，在完整词边界达到32个Unicode字符或完整句边界即首显（先到者）。完整词边界是已确认的空白/标点分隔处；未闭合转义、标注或末词仍缓冲，禁止把未确认的标注前缀当正文。后续有真实新文本才发送累计snapshot，最多每250ms合并一次；字符串闭合刷新尾部。无需完整段落，单段长文也逐步可读；边界缓冲不是额外模型调用。
3. 原生修正仍是version1：续写同稿按同样安全边界并入累计snapshot；仅字段修正不输出不完整学习字段。完整C1原生通过才candidate v1。普通随即完成；增强在R1已发送后stage=content_review，继续保留C1草稿。
4. R1 issues已持久化后，返修实际发送才stage=content_repair，`content_version=2`，保留C1可读草稿并禁保存。**不发送C2 token或passage.snapshot**。C2含必要原生技术修正全部通过后，一条candidate v2原子替换全文、tag、所有targets；其后R2 stage=content_review version2。修稿阶段的native_repair也是version2，仍保留C1直至有效C2。
5. validated与最后candidate版本/Result必须一致；文案均“生成完成”，不显示“审稿通过”，上限定稿一样完成。失败/取消清除可保存结果，丢弃草稿；pending保留草稿视觉但禁保存并显示核对中。
6. 客户端严格校验字段及事件状态：没有started拒收后续；seq重复/倒退、版本倒退、version>2、basic出现内容审稿/返修、终态后再事件均协议错误，停止消费且用当前run核对；不能把异常内容拼入Result。单个run只有validated/failed/cancelled一个业务终态；EOF无终态或pending均未知，不把EOF判成功。后续HTTP取消/状态回执以同run数据库终态收敛，不用到达时间覆盖终态。

```text
event: generation.started
data: {"seq":1,"run_id":"run-example","generation_token":"opaque","snapshot":{"configuration_revision":"opaque-revision","effective_plan":{"code":"pro","origin":"trial"},"content_service":{"native_validation":true,"content_review_enabled":true,"content_repair_limit":1}}}

event: generation.stage
data: {"seq":2,"stage":"generating","content_version":1}

event: passage.snapshot
data: {"seq":3,"content_version":1,"passage":"Mara carried the box into the quiet room."}
```

典型增强序列：started→generating→snapshot*→candidate1→review1→repair2→candidate2→review2→validated2。普通：started→generating→snapshot*→native_repair?→candidate1→validated1。星号可0次；stage仅实际调用确认后发出，不能预先发review/repair再因取消没有调用。

### 失败与状态核对

FailureCode为 `authentication|authorization|rate_limited|provider_unavailable|protocol_error|schema_error|content_validation_failed|generation_timeout|generation_failed`。前六项沿供应商安全分类；审稿schema/证据非法是schema_error，不是内容issues；最后稿原生无效是content_validation_failed；DB关键事实/完成写失败是generation_failed。retryable表示用户将来可新发请求，**不**允许自动重发当前生成；authentication/authorization为false，其余按真实ProviderError（schema/内容通常true），不泄漏上游正文。

新增最小只读核对 `GET /generations/{run_id}/status` V/L，`X-Generation-Token`，无query/body；仅当前主体/能力token拥有者；404不匹配/已删除，410能力过期，503暂不能确认。200 data：

```text
{run_id:string,status:"active"|"valid"|"failed"|"cancelled",
 snapshot:RunSnapshot,content_version:1|2|null,
 result:Result|null,can_save:bool,quota_refunded:bool}
```

status及draft由一次一致读取投影，can_save只表示读时资格，保存仍事务复验；status从原DB状态投影；valid且最终draft仍可用时result完整、version非null、can_save=true（V表示可claim）；active/failed/cancelled三字段为null/null/false。valid但已收录、丢弃或TTL过期时result=null、can_save=false，version仍可从内容结论/usage事实确定。仅failed时quota_refunded=true；active不是确认失败。DB读取失败返回503，不编造failed。此接口不重开上游、不续传、不在刷新后恢复token；token仍只存当前页面内存。只用于当前页面EOF/取消竞态/COMMIT不明核对；立即查一次，若active或503，最多每2秒核对、总10秒，仍未知保留“状态待确认/重新核对”操作，后台原恢复继续处理。不无限轮询，不新建任务平台。

`POST /generations/{run_id}/cancel`原权限/header/body不变。200仍 `{status:cancelled|valid|failed,quota_refunded:bool}`，仅在已确认终态返回；无法确认503 `settlement_unconfirmed`，不得先终止上游再假定取消成功。先CAS提交user_cancelled，再cancel context；完成先赢则返回valid，前端用status读取最终Result；失败先赢则failed/true；重复cancel不再扣/退。HTTP取消成功与流终态重复收敛同一run，不追加一次取消业务事实。

断连、write失败、整体/单次超时属技术失败退款；显式cancel才保留扣次。valid先提交后传输失败保留valid不退款，最终payload从库核对。保存/放弃/claim路径、TTL和幂等继承M002 API-006；服务端检查valid+完整最终draft，不能相信前端candidate/内存result；所有内部调用仍一run一charge。

### 终态与失败示例

以下Result是缩短的协议示例，不满足线上文章字数下限；不能用其代替有效生成fixture。

```text
event: generation.validated
data: {"seq":9,"run_id":"run-example","content_version":2,"result":{"passage":"They learned together.","tags":["学习"],"targets":[{"entry":"learn","entry_meaning":"学习","hint_phrase":"learn through practice","hint_blanks":[{"start":0,"end":5}],"occurrences":[{"surface":"learned","start":5,"end":12}]}]}}

event: generation.failed
data: {"seq":7,"code":"schema_error","quota_refunded":true,"retryable":true,"request_id":"req-example"}

event: generation.settlement_pending
data: {"seq":7,"code":"settlement_unconfirmed","request_id":"req-example"}
```

三例属于不同run结果，不能在同一流顺序发送。schema_error可由R2无法解析触发，即使内容返修已经用尽，也必须技术失败；只有可判定R2 issues和原生有效稿才进入validated。
