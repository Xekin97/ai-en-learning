---
id: API-304
version: M003-BE-01
status: awaiting_user_review
milestone: M003
---

# 预设、独立预览与模式绑定

CAP-304/305、DATA-302–304、PAGE-212/216/217、AC-309/310。继承 [M002 API-202](../../../M002/technical/api/generation-presets.md#5-管理员预览边界)，只列增量；路径省略 `/api/v1`。

## 公开用户生成

`GET /presets/{id}` 原data增加 `effective_plan`、`configuration_revision`、`content_service`，类型同API-301、同锁读取；与原preset/quota/extra_quota/can_start/block_reason并存。目录GET只读已发布样文，不返回后台mode、不按每读者重新审稿。

`POST /presets/{id}/generations/stream` V/L请求仍仅 `{published_version:string}`；内容权益取本人有效计划，固定配置例外仅覆盖原模型/词数/长度范围，不赠内容服务。与普通请求共用API-302全部事件、snapshot、取消/status/保存/claim和预算；entry_kind=preset用于统计。版本改变409 preset_changed、未发布/下架404 preset_unavailable、模型引用失效422、次数不足429，均不发送提供方。

## 后台模式先保存再预览

`GET /admin/generation-options` 保持M002完整model/词表/语言/场景/长度/can_preview枚举，增加 `preview_content_modes:["basic","enhanced"],default_preview_content_mode:"basic"`；与管理员个人计划无关。

`POST /admin/presets` 请求 `{title:string,configuration:PresetConfigurationInput,preview_content_mode:"basic"|"enhanced"}`；`PUT /admin/presets/{id}`同请求另必填expected_revision。新增字段在两者均必填、非null；UI初始basic，不以请求缺字段默认为enhanced。configuration内部与config_hash算法不变，不把mode塞进公开配置。

`GET /admin/presets/{id}` 及POST/PUT/publish原响应 `{preset:AdminPreset,revision:string}` 中，AdminPreset增加必填 `preview_content_mode:basic|enhanced`；可空 `preview` 非null时增加 `preview_content_mode`。published投影仍为原公开样文，不暴露后台模式。列表中若返回AdminPreset亦同增量。

模式变化创建新不可变draft_version、preview=null/draft_state=needs_preview；仅紧邻草稿生成参数及mode都未变的纯标题改动可继承preview。切回先前mode也不能恢复曾经preview。改mode前旧公开版本保持。服务端版本/关联逻辑见DB3-06；前端本地任何mode/配置变化立即禁发布且先保存，不能只改UI后拿旧draft_version直接预览。

`POST /admin/presets/{id}/previews/stream` admin-only，CSRF，严格body：

```json
{"draft_version":"current-version-id","preview_content_mode":"enhanced"}
```

StartPreview比较当前draft_version、保存mode及请求mode；任一不匹配409 revision_conflict（context.current_revision），需重读，不允许直接请求覆盖已保存mode。基础快照false/0；增强true/1；配置数字revision写DB，preview不写plan_origin/group或用户charge。管理员不限预览次数但每次显式启动，仍有有界技术预算/超时，不新增跨管理员预览限额；可有并发预览run，只有匹配版本且空preview_id的完成者能填关联，其他成功run保留事实但不覆盖样文。

## 预览SSE与核对

预览在受理COMMIT确认后先 `preview.started`，其后才Open。与API-302同一编排、seq/草稿版本/reducer、段内首显与整稿替换规则；以下列出用户流对应替换，其他字段不得串用：

| event | 完整data |
|---|---|
| preview.started | `{seq,preview_run_id,preview_token,draft_version,preview_content_mode,content_service:ContentService}` |
| preview.stage | `{seq,stage:generating|native_repair|content_review|content_repair,content_version:1|2}` |
| passage.snapshot | 同API-302，仅当前preview流作用域 |
| preview.candidate | `{seq,content_version:1|2,result:Result}` |
| preview.validated | `{seq,preview_run_id,draft_version,preview_content_mode,content_version:1|2,result:Result,usage:UsageSummary}` |
| preview.failed | `{seq,code:FailureCode,retryable:bool,request_id:string}` |
| preview.cancelled | `{seq}` |
| preview.settlement_pending | `{seq,code:"settlement_unconfirmed",request_id:string}` |

无quota_refunded字段，因为没有用户扣额。失败也可能有真实usage。流valid只证明该run成功，不保证它还是当前draft或已被填入发布关联；前端收到valid后GET当前AdminPreset检查draft_version/mode/preview_run_id匹配才能ready。旧mode晚完成不能解锁新草稿发布。

`POST /admin/preset-previews/{preview_id}/cancel`原X-Preview-Token、{}→200 `{status:valid|failed|cancelled}`，未确认返回503 settlement_unconfirmed；只能requested_by同一管理员token，不能用另一管理员身份取消。

新增 `GET /admin/preset-previews/{preview_id}/status`，同身份/token，200：`{preview_run_id,status:active|valid|failed|cancelled,draft_version,preview_content_mode,content_version:1|2|null,result:Result|null,usage:UsageSummary}`。active/failed/cancelled的version/result均null；valid返回仍保留的完整preview结果，若旧非引用preview按原TTL已清理则result=null（不得重建），version仍按run结论计算。404/410/503同用户status；无新续传/本机token保存，最多10秒短核对后显式重试核对。核对接口不改关联、不重启模型。

UsageSummary保留 `{logical_runs:int,provider_calls:int,input_tokens:int|null,output_tokens:int|null,cost:{amount:string,unit:string}|null,unknown_calls:int}`，新增 `invocation_unknown_calls:int,not_invoked_calls:int`。M003 `provider_calls`仅provider_invoked=true行数；unknown_calls仍表示用量不完整的调用观察行数（不等于发送未知），invocation_unknown_calls是发送NULL，not_invoked_calls是false。已确认发送但费用未报告保持null；统计与聚合不得假装所有预留行已调用。历史legacy真实发送未知，单列invocation_unknown_calls；不反填true。原管理员用量查询GET投影同步加两字段，UI分开显示“已确认调用/调用未确认/用量未知”，不要把unknown_calls相加为调用总数。

## 手动发布

`POST /admin/presets/{id}/publish` 保持 `{expected_revision,draft_version}`；不新增客户端声明“审稿通过”或mode覆盖字段。事务核对当前draft及其保存mode，匹配关联preview的run/config_hash/configuration/mode/valid/完整payload；增强limit_finalized也是valid，允许发布。无匹配成功预览422 `preview_required`（现有ErrPreviewRequired），revision/version不匹配409，非管理员403；任何失败不改published_version/listed。成功原 `{preset,revision}`，重新读取可見样文；模式不会写到用户内容权益。publish响应丢失先GET，不盲重试新revision。取消、失败、pending、candidate片段都不可发布。
