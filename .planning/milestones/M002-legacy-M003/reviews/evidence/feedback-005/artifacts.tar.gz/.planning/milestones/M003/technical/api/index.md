---
id: API-M003
version: M003-BE-01
status: awaiting_user_review
milestone: M003
agent_name: backend-alex
---

# M003 Markdown API 增量

继承 [M002 公共传输/鉴权/错误](../../../M002/technical/api/index.md) 与 [多提供方契约](../../../M002/technical/api/model-connections.md)。统一前缀 `/api/v1`；JSON严格字段、重复键/未知键/类型/null/尾随校验；成功JSON仍 `{data,meta:{request_id}}`，SSE data没有封套。本文类型中未标nullable的字段均必填非null；所有数组即使为空也不可null。所有副作用和只读POST需要原CSRF，cookie身份不变。USER-COMPAT-001：前后端配套切换，移除旧passage.delta生成消费分支，不做旧客户端兼容层，不建OpenAPI。

| 契约 | 能力/数据/页面 | 对原API的增量 |
|---|---|---|
| [API-301/302](generation.md) | CAP-301/302/305；DATA-301–303；PAGE-204/215/216 | API-004选项、API-005生成/终态、API-006保存资格 |
| [API-303](administration.md) | CAP-303；DATA-301；PAGE-208 | API-103计划完整字段、impact/revision/优先级 |
| [API-304](presets.md) | CAP-304/305；DATA-302–304；PAGE-212/216/217 | API-202公开预设和管理员mode/预览/发布 |

接口只暴露调用方所需权益和安全状态；不公开私有review、prompt、provider ID、connection或内部content_outcome。后台usage继承获授权的数值投影。与数据库字段的对应和统计语义以 [DB3](../database.md) 为真源；pipeline与review以 [AI3](../ai-integration.md) 为真源。示例仅展示schema，不是达标文章、产品种子或真实使用数据。
