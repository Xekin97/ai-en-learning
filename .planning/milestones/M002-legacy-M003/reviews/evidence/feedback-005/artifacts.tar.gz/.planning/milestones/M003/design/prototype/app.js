const [copy, fixtures] = await Promise.all([
  fetch("../copy.json").then((response) => {
    if (!response.ok) throw new Error("copy.json");
    return response.json();
  }),
  fetch("./fixtures.json").then((response) => {
    if (!response.ok) throw new Error("fixtures.json");
    return response.json();
  }),
]);

const params = new URLSearchParams(location.search);
const lang = params.get("lang") === "en" ? "en" : "zh";
document.documentElement.lang = lang === "zh" ? "zh-CN" : "en";
const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[char]);
const t = (key) => copy.static[`${key}.${lang}`] ?? `⟦${key}⟧`;
const tt = (key, values) => Object.entries(values).reduce((text, [name, value]) => text.replaceAll(`{${name}}`, value), copy.templates[`${key}.${lang}`] ?? `⟦${key}⟧`);
const href = (changes) => {
  const next = new URLSearchParams(params);
  Object.entries(changes).forEach(([key, value]) => value == null ? next.delete(key) : next.set(key, value));
  return `?${next.toString()}`;
};
const button = (label, changes, className = "btn") => `<a class="${className}" href="${href(changes)}">${esc(label)}</a>`;

function header(admin = false) {
  const language = lang === "zh" ? "EN" : "中文";
  const languageHref = href({lang: lang === "zh" ? "en" : "zh"});
  if (admin) return `<header class="topbar admin-topbar"><div class="container header-inner"><a class="brand" href="${href({page:"plans"})}"><span class="brand-mark" aria-hidden="true">≈</span>${esc(t("brand"))}<small>${esc(t("admin.label"))}</small></a><span class="prototype-mark">${esc(t("prototype.scope"))}</span><div class="header-actions"><a class="btn quiet lang-link" href="${languageHref}">${language}</a><span class="pill">${esc(t("admin.label"))}</span></div></div></header>`;
  return `<header class="topbar"><div class="container header-inner"><a class="brand" href="${href({page:"create"})}"><span class="brand-mark" aria-hidden="true">≈</span>${esc(t("brand"))}</a><nav class="nav" aria-label="Primary"><a href="#">${esc(t("nav.home"))}</a><a href="#">${esc(t("nav.picks"))}</a><a aria-current="page" href="${href({page:"create"})}">${esc(t("nav.learn"))}</a><a href="#">${esc(t("nav.review"))}</a><a href="#">${esc(t("nav.library"))}</a></nav><div class="header-actions"><a class="btn quiet lang-link" href="${languageHref}">${language}</a><span class="avatar" aria-label="Xiao">小</span></div></div></header>`;
}

function adminNav(current) {
  return `<nav class="admin-nav-m003" aria-label="Admin"><a href="#">${esc(t("admin.overview"))}</a><a href="#">${esc(t("admin.models"))}</a><a ${current === "plans" ? 'aria-current="page"' : ""} href="${href({page:"plans"})}">${esc(t("admin.plans"))}</a><a ${current === "presets" ? 'aria-current="page"' : ""} href="${href({page:"presets"})}">${esc(t("admin.presets"))}</a></nav>`;
}

function entitlement(planCode, forceEnhanced) {
  const plan = fixtures.plans[planCode] ?? fixtures.plans.basic;
  const enhanced = plan.editable && plan.enhanced && forceEnhanced !== false;
  const planName = lang === "zh" ? plan.nameZh : plan.nameEn;
  return {plan, enhanced, planName};
}

function stageRail(stage, enhanced) {
  const steps = enhanced ? ["generating", "draft", "review", "repair", "complete"] : ["generating", "draft", "complete"];
  const normalized = stage === "idle" || stage === "cancelled" ? "generating" : stage;
  const current = Math.max(0, steps.indexOf(normalized));
  return `<ol class="stage-rail" aria-label="Generation stages">${steps.map((key, index) => `<li class="${index < current ? "done" : index === current ? "current" : ""}" ${index === current ? 'aria-current="step"' : ""}>${esc(t(`stage.${key}`))}</li>`).join("")}</ol>`;
}

function storyBody(stage) {
  const repaired = stage === "complete" || stage === "repair";
  const text = repaired ? fixtures.draft.repairedText : fixtures.draft.text;
  return `<span class="draft-label">${esc(t(`stage.${stage === "complete" ? "complete" : stage}`))}</span><h2 class="result-title">${esc(fixtures.draft.title)}</h2><p class="story-text" lang="en">${esc(text)}</p><div class="learning-facts">${fixtures.draft.meanings.map((item) => `<p>${esc(item)}</p>`).join("")}</div>`;
}

function createPage() {
  const planCode = ["visitor", "basic", "pro", "plus"].includes(params.get("plan")) ? params.get("plan") : "pro";
  const {enhanced, planName} = entitlement(planCode, params.get("enhanced") !== "0");
  let stage = params.get("stage") || "idle";
  if (!enhanced && ["review", "repair"].includes(stage)) stage = "draft";
  const source = params.get("source") === "preset" ? "preset" : "normal";
  const benefitName = enhanced ? t("benefit.enhanced.name") : t("benefit.base.name");
  const benefitBody = enhanced ? t("benefit.enhanced.body") : t("benefit.base.body");
  const config = source === "preset"
    ? `<div class="setting-row"><span>${esc(t("source.preset"))}</span><strong>${esc(fixtures.preset.title)}</strong></div>`
    : "";
  const settings = `<aside class="panel m003-settings" aria-labelledby="settings-title"><h2 id="settings-title">${esc(t("create.settings"))}</h2>${config}<div class="setting-row"><span>AI ${lang === "zh" ? "模型" : "model"}</span><strong>Model A</strong></div><div class="setting-row"><span>${lang === "zh" ? "场景 · 长度" : "Genre · length"}</span><strong>${lang === "zh" ? "故事 · 简短" : "Story · Brief"}</strong></div><div class="setting-row"><span>${esc(t("create.words"))}</span><div class="word-list">${fixtures.draft.words.map((word) => `<span class="chip" lang="en">${esc(word)}</span>`).join("")}</div></div>${stage === "idle" ? button(t("create.generate"), {stage:"draft"}, "btn primary") : ""}</aside>`;
  let content;
  if (stage === "idle") {
    content = `<div class="empty-service"><div><span class="empty-icon" aria-hidden="true">✎</span><h2>${esc(t("create.empty.title"))}</h2><p>${esc(t("create.empty.body"))}</p></div></div>`;
  } else if (stage === "cancelled") {
    content = `<div class="empty-service" role="status"><div><span class="empty-icon" aria-hidden="true">×</span><h2>${esc(t("stage.cancelled"))}</h2><p>${esc(t("stage.cancelled.body"))}</p>${button(t("action.retry"), {stage:"draft"}, "btn primary")}</div></div>`;
  } else {
    const bodyKey = stage === "draft" ? "stage.draft.body" : stage === "review" ? "stage.review.body" : stage === "repair" ? "stage.repair.body" : "stage.complete.body";
    const next = stage === "draft" ? (enhanced ? "review" : "complete") : stage === "review" ? "repair" : stage === "repair" ? "complete" : null;
    content = `<div class="generation-stage"><article data-region="generation-result">${storyBody(stage)}<p class="stage-note" role="status" aria-live="polite">${esc(t(bodyKey))}</p><div class="generation-actions">${stage === "complete" ? `${button(t("action.save"), {saved:"1"}, "btn primary")}${button(t("action.discard"), {stage:"idle"}, "btn quiet")}` : `${button(t("action.cancel"), {stage:"cancelled"}, "btn")}${button(lang === "zh" ? "演示下一阶段" : "Show next stage", {stage:next}, "btn quiet")}`}</div></article><aside>${stageRail(stage, enhanced)}</aside></div>`;
  }
  const scenarios = `<div class="scenario-links" aria-label="Prototype states"><a href="${href({plan:"basic",enhanced:null,stage:"idle"})}">Basic · idle</a><a href="${href({plan:"pro",stage:"draft"})}">Pro · draft</a><a href="${href({plan:"pro",stage:"review"})}">Pro · review</a><a href="${href({plan:"pro",stage:"repair"})}">Pro · repair</a><a href="${href({plan:"pro",stage:"complete"})}">Pro · complete</a><a href="${href({plan:"pro",stage:"cancelled"})}">Cancelled</a><a href="${href({plan:"pro",source:"preset",stage:"idle"})}">Preset source</a></div>`;
  return `${header()}<main class="container page" id="main"><header class="page-head"><div><h1>${esc(t("create.title"))}</h1><p>${esc(t("create.intro"))}</p></div></header><section id="benefit-summary" class="entitlement-strip" data-enhanced="${enhanced}"><div><strong>${esc(benefitName)}</strong><p>${esc(benefitBody)}</p></div><div class="entitlement-meta">${esc(tt("benefit.plan", {plan:planName}))}<br>${esc(t("benefit.snapshot"))}</div></section><div class="m003-workspace">${settings}<section id="generation-status" class="panel generation-panel" data-stage="${esc(stage)}">${content}</section></div>${scenarios}</main>`;
}

function planTabs(planCode) {
  return `<nav class="plan-tabs" aria-label="Plans">${Object.entries(fixtures.plans).map(([code, plan]) => `<a aria-current="${code === planCode}" href="${href({plan:code,adminState:"edit",next:null})}">${esc(lang === "zh" ? plan.nameZh : plan.nameEn)}</a>`).join("")}</nav>`;
}

function plansPage() {
  const planCode = fixtures.plans[params.get("plan")] ? params.get("plan") : "pro";
  const plan = fixtures.plans[planCode];
  const planName = lang === "zh" ? plan.nameZh : plan.nameEn;
  const adminState = params.get("adminState") || "edit";
  const proposed = plan.editable ? (params.get("next") ? params.get("next") === "on" : plan.enhanced) : false;
  const currentLabel = plan.enhanced ? t("plans.review.on") : t("plans.review.off");
  const proposedLabel = proposed ? t("plans.review.on") : t("plans.review.off");
  let lower = "";
  if (adminState === "preview") {
    lower = `<section id="change-preview" class="change-preview" data-state="preview"><header><h2>${esc(t("plans.preview.title"))}</h2><p>${esc(planName)}</p></header><div class="change-body"><div class="diff-row"><div class="diff-value"><small>${lang === "zh" ? "当前" : "Current"}</small><br><strong>${esc(currentLabel)}</strong></div><span aria-hidden="true">→</span><div class="diff-value"><small>${lang === "zh" ? "保存后" : "After save"}</small><br><strong>${esc(proposedLabel)}</strong></div></div>${!proposed && plan.enhanced ? `<div class="warning-box">${esc(t("plans.disable.warning"))}</div>` : ""}<p><strong>${esc(tt("plans.impact", {basic:plan.basicUsers, trial:plan.trialUsers}))}</strong></p><ul class="impact-list"><li>${esc(t("plans.effect.new"))}</li><li>${esc(t("plans.effect.inflight"))}</li><li>${esc(t("plans.effect.usage"))}</li></ul><div class="actions">${button(t("plans.cancel"), {adminState:"edit",next:null})}${button(t("plans.save"), {adminState:"saved"}, "btn primary")}${button(lang === "zh" ? "演示并发冲突" : "Show conflict", {adminState:"conflict"}, "btn quiet")}</div></div></section>`;
  } else if (adminState === "conflict") {
    lower = `<section id="version-conflict" class="conflict-box" role="alert"><h2>${esc(t("plans.conflict.title"))}</h2><p>${esc(t("plans.conflict.body"))}</p><div class="conflict-compare"><div><small>${esc(t("plans.latest"))}</small><br><strong>${esc(currentLabel)}</strong></div><div><small>${esc(t("plans.local"))}</small><br><strong>${esc(proposedLabel)}</strong></div></div>${button(t("plans.recheck"), {adminState:"preview"}, "btn primary")}</section>`;
  } else if (adminState === "saved") {
    lower = `<div id="save-result" class="success-box" role="status">${esc(t("plans.saved"))}</div>`;
  }
  const switchLabel = proposed ? t("plans.review.on") : t("plans.review.off");
  const controls = `<div class="plan-grid"><section class="service-card"><h2>${esc(t("plans.base.title"))}</h2><p>${esc(t("benefit.base.body"))}</p><div class="service-state"><strong>${esc(t("plans.base.fixed"))}</strong><span class="fixed-badge">✓</span></div></section><section class="service-card" id="content-service"><h2>${esc(t("plans.review.title"))}</h2><p>${esc(t("plans.review.rule"))}</p><div class="service-state"><div><strong id="review-state-label">${esc(switchLabel)}</strong><small>${esc(plan.editable ? t("plans.sameModel") : t("plans.review.locked"))}</small></div><label class="switch"><span class="sr-only">${esc(t("plans.review.title"))}</span><input id="content-review-switch" type="checkbox" ${proposed ? "checked" : ""} ${plan.editable ? "" : "disabled"}><span aria-hidden="true"></span></label></div></section></div><div class="form-footer">${button(t("plans.preview"), {adminState:"preview",next:proposed ? "on" : "off"}, "btn primary")}</div>`;
  const scenarios = `<div class="scenario-links"><a href="${href({plan:"basic",adminState:"edit",next:null})}">Basic locked</a><a href="${href({plan:"pro",adminState:"preview",next:"off"})}">Pro disable preview</a><a href="${href({plan:"plus",adminState:"preview",next:"on"})}">Plus enabled</a><a href="${href({plan:"pro",adminState:"conflict",next:"off"})}">Conflict</a><a href="${href({plan:"pro",adminState:"saved",next:"off"})}">Saved</a></div>`;
  return `${header(true)}<main class="container page admin-shell-m003" id="main">${adminNav("plans")}<div><header class="page-head"><div><p class="eyebrow">WORDWEAVE / ${esc(t("admin.label"))}</p><h1>${esc(t("plans.title"))}</h1><p>${esc(t("plans.intro"))}</p></div></header>${planTabs(planCode)}<section class="panel" data-plan="${esc(planCode)}">${controls}${lower}</section>${scenarios}</div></main>`;
}

function presetsPage() {
  const mode = params.get("mode") === "enhanced" ? "enhanced" : "base";
  const state = params.get("previewState") || "ready";
  const enhanced = mode === "enhanced";
  const modeLabel = t(`preset.mode.${mode}`);
  let result = "";
  if (state === "stale") result = `<div id="preview-result" class="warning-box" role="status" data-state="stale">${esc(t("preset.stale"))}</div>`;
  else if (state === "running") result = `<div id="preview-result" data-state="running"><p class="stage-note" role="status">${esc(t(enhanced ? "stage.review.body" : "stage.wait.body"))}</p>${button(t("action.cancel"), {previewState:"cancelled"})}</div>`;
  else if (state === "cancelled") result = `<div id="preview-result" class="warning-box" role="status" data-state="cancelled">${esc(t("stage.cancelled.body"))}</div>`;
  else result = `<section id="preview-result" class="preview-paper" data-state="ready"><div class="section-head"><h2>${esc(lang === "zh" ? "预览" : "Preview")}</h2><span class="pill">${esc(modeLabel)}</span></div><h3>${esc(fixtures.draft.title)}</h3><p class="story-text" lang="en">${esc(enhanced ? fixtures.draft.repairedText : fixtures.draft.text)}</p><div class="success-box">${esc(t("preset.ready"))}</div></section>`;
  const modeControl = `<fieldset id="preview-mode" class="mode-group"><legend>${esc(t("preset.mode"))}</legend><div class="mode-options"><label class="mode-option"><input type="radio" name="mode" value="base" ${!enhanced ? "checked" : ""}><span><strong>${esc(t("preset.mode.base"))}</strong><br><small>${esc(t("benefit.base.body"))}</small></span></label><label class="mode-option"><input type="radio" name="mode" value="enhanced" ${enhanced ? "checked" : ""}><span><strong>${esc(t("preset.mode.enhanced"))}</strong><br><small>${esc(t("benefit.enhanced.body"))}</small></span></label></div><p class="field-help">${esc(t("preset.mode.note"))}</p></fieldset>`;
  const scenarios = `<div class="scenario-links"><a href="${href({mode:"base",previewState:"ready"})}">Base ready</a><a href="${href({mode:"enhanced",previewState:"running"})}">Enhanced running</a><a href="${href({mode:"enhanced",previewState:"ready"})}">Enhanced ready</a><a href="${href({mode:"enhanced",previewState:"stale"})}">Mode changed</a></div>`;
  return `${header(true)}<main class="container page admin-shell-m003" id="main">${adminNav("presets")}<div><header class="page-head"><div><p class="eyebrow">WORDWEAVE / ${esc(t("admin.label"))}</p><h1>${esc(t("preset.title"))}</h1><p>${esc(t("preset.intro"))}</p></div></header><div class="preset-layout"><aside class="panel preset-list"><h2>${lang === "zh" ? "预设列表" : "Presets"}</h2><button><strong>${esc(fixtures.preset.title)}</strong><br><small>${lang === "zh" ? "有修改草稿" : "Edited draft"}</small></button></aside><section class="panel">${modeControl}<div class="form-footer">${button(t("preset.generate"), {previewState:"running"})}${button(t("preset.publish"), {}, "btn primary")}</div>${result}<p class="usage-note">${esc(tt("preset.usage", {count:fixtures.preset.usage}))}</p></section></div>${scenarios}</div></main>`;
}

const page = params.get("page") || "create";
const app = document.querySelector("#app");
app.innerHTML = page === "plans" ? plansPage() : page === "presets" ? presetsPage() : createPage();
app.setAttribute("aria-busy", "false");

document.querySelector("#content-review-switch")?.addEventListener("change", (event) => {
  location.href = href({next:event.currentTarget.checked ? "on" : "off", adminState:"edit"});
});
document.querySelectorAll('input[name="mode"]').forEach((input) => input.addEventListener("change", (event) => {
  location.href = href({mode:event.currentTarget.value, previewState:"stale"});
}));
