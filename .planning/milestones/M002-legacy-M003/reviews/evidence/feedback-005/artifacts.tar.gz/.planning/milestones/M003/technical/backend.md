---
milestone: M003
stage: technical-design
role: backend-architect/base
agent_name: backend-alex
version: M003-BE-01
status: awaiting_user_review
date: 2026-10-09
---

# M003 后端最小可实施方案

本轮仅技术设计，未改源码/迁移/线上配置，未调用真实提供方。依据已委派接收的 [产品](../handoffs/product.md)、[设计](../handoffs/uiux.md)、[M003-DB-01](database.md) 和 [USER-M003-CONTENT-20261009](../reviews/start.md)，Profile保留consumer-ai-web@1.0.0。确认业务范围沿D3-01–06；本稿的编排/流式/协议是该范围内后端技术选择，不冒充用户逐字段确认或上线批准。当前DB3-09无字段变更需求。

## BE3-01 现状与关键选择

实际后端是Go模块化单体/PostgreSQL，`httpapi/server.go`使用 `ai.NewGateway`，已支持三协议。现有首稿/技术纠正在 `ai/continuation.go`，每次函数调用局部最多2次；`generation_handlers.go`与`preset_preview_handlers.go`分别编排，均先Open后started；当前delta只追加，无法安全容纳整稿替换；preview的settle helper发生DB异常仍返回failed。这些是本次实际修改依据。

选择复用Gateway、原run/charge/draft/usage/preset版本，提取一个请求级 `generation.ExecutePipeline` 给两种HTTP流用；不用新服务/队列/持久审稿平台。普通只调用首稿和原生修正，增强按问题调用审稿/一次整稿返修/一次复审，技术预算跨稿共享。详细循环和六次上限仅维护在 [AI3-01](ai-integration.md#ai3-01-最小流水线与预算)。

真实取舍：省略返修后复审可省一次调用，却不能辨认修后通过与仍有问题，也无法提供本期复审上限的确定性证据；选一次复审，总体最坏6次。重写token立即上屏需要清空可读首稿并承受失败稿/学习字段暂不同步；选C1保留可读、有效C2整体替换。首稿安全正文累计快照解决单段长文首显，不增模型调用；代价是流量略大与边界缓冲，QA测实际首显和间隔，不承诺未测秒数。

## BE3-02 模块与上游追踪

| CAP / DATA / API | 用例与具体代码入口（相对backend/） | 增量职责 |
|---|---|---|
| CAP-301；DATA-301/302；API-301 | `internal/entitlement/service.go` Resolve/Options；`generation/service.go` start；`httpapi/catalog_handlers.go` | 只在胜出计划上读取开关/上限，Options同锁revision；Start/StartPreset快照，卡仅模型/次数，extra不改origin |
| CAP-302；DATA-302/303；API-302 | `internal/generation/pipeline.go`（新增小模块）、`ai/{contract,continuation,gateway,openrouter,protocol_stream,validator}.go` | 统一有界编排、同连接、review解码、整稿重写；validator原严格语义不放松 |
| CAP-303；DATA-301；API-303 | `internal/admin/groups.go` readGroup/validateGroup/GroupImpact/PutGroup/PriorityImpact；`httpapi/{admin_handlers,group_handlers}.go` | 完整新字段严格decode、impact与关闭警告、revision事务；保留四计划 |
| CAP-304；DATA-304；API-304 | `generation/{presets,preset_preview,preset_catalog,preset_cleanup}.go`；`httpapi/{preset_handlers,preset_preview_handlers}.go` | mode纳入版本生成条件/预览/发布；普通用户预设走本人快照；共用pipeline |
| CAP-305；DATA-302/304；全部 | `generation/{usage,preset_usage,settlement,charge}.go`、`ai/usage.go`、`generationtrace/*` | 每次调用事实、发送未知、终态CAS、只读分组诊断；不存意见正文 |

API真源为 [Markdown API索引](api/index.md)，保存/claim/旧学习库/账号删除继承M002，仅最终稿入口变化。新增GET status是为现有 `ReconcileFailure` COMMIT不明、cancel先后与terminal写丢失提供当前页面核对，证据代码 `generation_races_integration_test.go`、`generation_trace_integration_test.go`；不是新后台继续生成能力。

## BE3-03 DB3-03–06 落地职责与事务

| 操作 / 拟函数 | 事务与必须检查 |
|---|---|
| Start/StartPreset → `acceptContentPolicy` | 现有配置共享锁→主体锁→锁后Now→Resolve一份计划→模型/词表/额度→完整v1快照run/entries/Reserve charge/开始事实同事务。快照origin=Plan.Origin，不取charge.plan_code；正常/预设都显式写policy=1、pipeline版本、数字revision、开关/上限。连接BindSpec在锁内执行一次。普通/预设没有mode输入 |
| StartPreview | 配置共享锁→管理员存在→draft/version/mode匹配→模型绑定→preview run完整快照；mode来自已保存版本且与请求一致，基础false/0增强true/1；无用户charge/plan_origin |
| `usageRecorder.Reserve/MarkInvoked/RecordReview/FinishUsage` | 每个owner+call_no唯一，串行分配；Reserve失败不发；review事实先commit再准许repair。事实写入错误回传pipeline，不能只log后成功。调用前后具体发送证据见AI3-05；不持事务等网络 |
| CompleteValid / `validateContentOutcome` | 配置共享锁→主体锁→active CAS→校验快照与逐调用事实→原charge consumed/累计/学习成长分析→最终完整draft同事务。basic不得有内容call；review_passed需R1 pass/无repair；repaired_passed需唯一repair+R2 pass；limit_finalized需唯一repair+R2 issues；所有成功需最终native有效、无pending/indeterminate必需审稿。保留原学习计量，不因内部调用重复记开始/成功 |
| CompletePreview | 配置共享锁→preset行锁→active CAS与内容结论核验→单个完整preset_previews→仅对应version/config_hash/configuration/mode且preview_id空时关联；模式晚完成允许记录独立valid，但不覆盖新draft或published pointer。事务内只查询usage数值，读取失败不得虚构0 |
| SettleTerminal/ReconcileFailure/SettlePreview | active CAS同时写content_outcome=cancelled/failed、原终态及原失败code；用户失败原charge来源退款、取消消费一次，preview无charge；pending Review改indeterminate不造原因。终态已存在读回原值，不覆盖 |
| SavePreset/PublishPreset | mode与生成参数一起版本化；纯标题只检查紧邻旧稿且mode相同才继承预览；Publish配置排他锁+expected revision+当前draft，检查DB3-06完整生成条件和valid payload，不信客户端ready |
| 0017候选迁移/启动 | 实施先核对最大号；按DB3-02/08一次事务初始化+revision一次，写入前schema完整性自检；缺列/非法组合拒绝服务受理，不按默认赠送增强；旧数据/模型/用量/期限不重seed |

完成事务应接受 `PipelineResult{Batch,ContentOutcome}`，内部校验usage事实，不接受HTTP传入outcome。R1/R2的候选版本为内存1/2（可按阶段推导），DB不需要新稿版本表；持久化只保留最终payload和DB3事实。各阶段内部schema严格解析，不将审稿意见当可信指令。配置revision响应用原business.Revision签名，库只存数字快照。

## BE3-04 取消、失败与唯一终态

受理成功先started，started flush失败不发上游；随后每次调用接入共享cancel context。检查取消至少发生在调用预留前、发送前、读取后、原生处理循环内、审稿持久化后和成功CAS前。预留与取消的远端发送不可绝对原子：极短竞态中已经开始的调用可产生费用；但不允许取消确认后编排下一阶段，迟到usage不复活run。stage事件仅发送确认落库后发出，意图不冒充调用。

用户主动cancel先确认user_cancelled提交再触发Registry取消；取消写/读不明不擅自停上游或声明取消成功。HTTP请求断连/write失败/单次180秒或总600秒到期先停upstream，再用background限时ReconcileFailure退款。退款回原base/trial/extra，卡过期不续期，不生成永久额度。valid先提交则断连/取消不能退款、不能把其改failed；反之失败/取消先提交则成功CAS不能写draft。

关键事实或最终提交异常，使用新鲜5秒context查实际run+charge+final draft；读到valid只能发送库中Result（不能用未确认的内存候选），读到cancelled/failed投影其真实终态；无法确认发送settlement_pending（若连接可写）并关闭流，保留现有registry pending failure供maintenance补结算。原 `settlePreview`不能在err时返回“已失败”；改为带error/confirmed的结果，与user统一处理。preview也注册pending失败元数据并沿维护循环有限重试，不新增持久任务表；单例重启仍扫描active preview/run结算failed，不重放模型。active恢复时review pending→indeterminate。

HTTP终态成功只能发生一次；无法送达不等于DB无终态。pipeline停止后关闭Stream、取消计时器、等待receiver退出（有界、关闭body解阻塞），事件写入单goroutine、channel背压可取消，避免最后一块正文被terminal抢先。相同run多次cancel/维护/完成竞争由原CAS控制；保存/claim沿原事务唯一，不产生第二业务请求。

status GET仅用现有 `VerifyRunToken` + 数据库owner检查（不能仅用registry，以便进程重启后核对）；有待保存draft还需与其access_token_hash匹配，并按原expires_at/disposition授权。终态token读取上限沿现有TerminalTokenRetention=1小时；超过返回410，主体/token不匹配/资源删除404。valid draft过30分钟但终态未满1小时：返回valid/result=null/can_save=false；已保存/丢弃同样不可再次返回私有payload。预览采用已有signed previewCapability、requested_by检查及相同1小时终态窗口。无新长期token、正文复制或跨用户恢复入口。

## BE3-05 用量、统计与隐私

DB3-04/07是唯一存储口径。对现有usage统计把 `count(*)`称为实际调用的代码改成provider_invoked=true计数，NULL和false单列。旧policy NULL/legacy只报告历史未采集覆盖量，不能补0或默认basic。token/cost known/partial/unknown沿现有数值精度；发送确认与费用已知两个维度不可混淆。

最小诊断查询（实现到现有generation/preset_usage或测试SQL，不建报表UI）：选定started_at半开时间窗，先按run聚合usage flags/call_counts，再按entry_kind normal/preset及preview独立聚合。提供全部受理N、增强E、实际审稿R（true）、实际返修W（true）、W/N、W/E、W/R；分母0=N/A。失败/取消保留分母，预检拒绝另计。分别报告forced_wording F、contradiction C的实际返修请求数、F∩C、F∪C；other另列。调用数同样按实际repair行计；不把repair_requested或R2 issues算再次返修。

未知区间：对每个指标以已确认true作下界，加“无确认true但存在相关NULL行”的去重run作上界；调用上界加对应NULL行数；false不增。实际审稿、实际返修和原因子集各有自己的未知数，不能用所有NULL乱加；未知原因是保留列为空时单列未分类，不能猜矛盾。新调用预留有stage/reasons，legacy没有则只作历史未知。统计仅支持履约/费用判断，独立内容质量不是数据库计数能证明。

不保存完整Review、问题原句、内部推理、新稿副本或秘密；usage/trace只存允许枚举/版本/耗时/字节计数。新阶段不得经原capture hooks把review prompt/response带入诊断正文；原专用账号诊断授权与24小时政策保持，不扩大到普通账号。保留/删除/claim例外完全沿DB3-07与M002；无为统计保留正文墓碑。

## BE3-06 运维和实施顺序

沿原Docker/PostgreSQL部署，不增服务、队列、基础设施或独立环境变量平台。顺序：迁移/仓储字段与校验→权益投影/计划管理→task-aware Gateway与pipeline→user/preview共用流→预设mode关联→配套前端strict schema/reducer→隔离DB/契约测试。新字段必填，无旧客户端双协议；切换需配套停写/在途结算、备份和升级验证，按DB3-08保留完整旧数据。

设计回退：可撤未采用文档/代码；已有新版业务事实后优先前滚，不能drop列或恢复旧备份丢失事实。紧急关闭增强用原四计划配置和revision，影响新请求、不得中断在途快照或降级正在履约的增强；真实线上关闭/部署需原发布授权，本轮未执行。

## BE3-07 实现与验证矩阵

以下均为**待实现验证**。使用既有Go1.26.7、三协议HTTP替身与隔离PostgreSQL；不能对当前开发/生产库跑破坏用例，不调用收费服务商。与DB3-V01–06合并执行，不重复建设框架。

| 验收 / 本期验证ID | 修改/测试入口与必要断言 |
|---|---|
| AC-301 / BE3-V01 | `ai/{protocol_matrix,corrections}_test.go`、新pipeline_test；普通无review/repair、增强所有stage同model/provider snapshot；普通1/3、增强2/4/6精确序列和上限 |
| AC-302 / BE3-V02 | 新review_test/pipeline_test；pass不修、牵强/矛盾/双类、平淡/开放结尾负例夹具、R2 issues valid+limit_finalized、R2 schema错误failed；问题evidence原句校验，真实语义另评 |
| AC-303 / BE3-V03 | `ai/{schema_boundaries,validator,continuation}_test.go`；C1花2次后C2失效直接失败；C1花1+C2花1合计2；重写漏词/错误学习字段、非法标注/offset、无旧tags/targets混入 |
| AC-304 / BE3-V04 | admin groups集成/HTTP strict decode；四行往返、关闭/0开/1配对、缺/NULL/小数/非法普通开关、403；DB3-V01旧库完整保留及一次初始化 |
| AC-305 / BE3-V05 | group handlers契约/隔离并发；impact before/after/人数/关闭警告、priority影响；0模型调用；两管理员同revision仅1成功、提交ACK丢失、响应封套/field pointer |
| AC-306 / BE3-V06 | entitlement/generation集成；trial优先级、到期、管理员关闭与受理前后两种锁顺序；快照origin/revision/配对一致，用量期限不重置 |
| AC-307 / BE3-V07 | `generation_reservation_integration_test.go`扩展；basic+模型卡+extra仍basic，pro+extra仍增强；没有模型/次数则预检拒绝无call |
| AC-308 / BE3-V08 | `httpapi/{generation_matrix,generation_races,generation_trace}_integration_test.go` + preview tests；started写失败、Open失败、单段首显/Unicode/半转义/半标注、C2原子替换、背压/cancel/EOF/timeout、所有phase注入失败；唯一终态与pending/status严格schema |
| AC-309 / BE3-V09 | `generation/presets_integration_test.go`、`httpapi/m002_presets_integration_test.go`；basic/enhanced/切回/纯标题复用/旧调用晚完/并发完成发布；用户预设权益本人来源，browse零调用，preview无charge且usage独立 |
| AC-310 / BE3-V10 | usage单元/隔离SQL夹具；N/E/R、F/C交并、意图未发送、true/false/NULL、0分母、legacy、R2拒绝不增W；多call不放大run分母、unknown费用非0 |
| AC-311 / BE3-V11 | 原charge/settlement/registry/claim集成；取消valid失败竞争、最后SQL/COMMIT ACK故障、extra跨过期退款、维护/重启复核；内部6call仍1charge，保存claim不调模型/重扣；status权限/TTL/删除 |
| AC-312 / BE3-V12 | 确定性替身记录首安全正文、最大无正文更新、总时间；QA另冻结原词/模型连接/提示/体裁和pipeline，逐句独立评阅自然用词/前提/角色物体因果/主题文体，分别交付率、质量通过、漏检/误报、未确定与调用费；真实批次须另获费用授权 |

新增协议契约夹具同时覆盖user/preview、basic/enhanced、取消完成竞争、未知EOF和mode冲突，供前端严格schema/reducer消费。运行`go test ./internal/ai ./internal/generation ./internal/httpapi ./internal/admin ./internal/entitlement`及相关隔离集成命令以仓库现有测试环境约定为准；实现前不得把本表写成PASS。既有CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX保持原未验证状态。
