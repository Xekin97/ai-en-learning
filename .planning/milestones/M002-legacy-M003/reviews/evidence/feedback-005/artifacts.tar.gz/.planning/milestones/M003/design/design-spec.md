# M003 UI/UX 增量规格

## 当前目标与有效范围

- 版本：`M003-UI-01`，状态 `awaiting_user_review`。产品输入为已接收的 `M003-PRODUCT-01`，来源 `reviews/product-planning.md`、`handoffs/product.md` 与 `product/` 六项原件。
- 确认来源：`USER-M003-CONTENT-20261009` 与 `CQ-01–10`。采用产品的 D3-01–06；D3-05/06 仍是已委派范围内的 `PROPOSED/INFERRED` 设计，不写成用户逐字段原话。
- 本轮只增量覆盖 PAGE-204 普通造文、PAGE-216 预设造文、PAGE-208 计划管理、PAGE-212 后台预设预览，以及 PAGE-215/217 的文案约束；不新增页面、导航、支付、独立审稿入口或报表。
- 复用 M002 `design/theme.css` 与现有造文双栏、后台侧栏/表单、阅读纸张布局。M003 `theme.css` 通过 `@import` 继承冻结的 M002 主题，只增加权益、阶段、差异与冲突样式。
- 本轮替代旧的“生成中→完成”单一反馈：增强请求现在可表达草稿、审稿、返修、完成；普通请求不出现审稿/返修。M002 其余设计继续有效，旧截图不能证明本增量通过。

## 页面—能力—数据追踪

| 页面 | 增量能力 | 数据 | 原型定位 |
|---|---|---|---|
| PAGE-204 / PAGE-216 | CAP-301/302/304：展示本次实际权益、真实阶段、整稿替换、取消与保存资格 | DATA-301–303 | `?page=create`；`#benefit-summary`、`#generation-status`、`[data-region="generation-result"]` |
| PAGE-208 | CAP-303：固定合法组合、差异预览、保存、冲突、新请求与在途快照 | DATA-301/302 | `?page=plans`；`#content-service`、`#change-preview`、`#version-conflict` |
| PAGE-212 | CAP-304：本次基础/增强预览模式，模式变化使旧预览过期，用量单列 | DATA-304 | `?page=presets`；`#preview-mode`、`#preview-result` |
| PAGE-215 / PAGE-217 | CAP-301/304：只显示实际计划权益；精选不承诺审稿通过或赠送增强 | DATA-301、原 DATA-212 | 本轮以 `copy.json` 文案语义交下游，不另建页面原型 |

## 设计目标与表达

视觉焦点仍是短文和当前任务。权益使用一条浅绿说明带，阶段使用窄轨道，二者不抢正文阅读层级。增强色彩沿用 M002 深绿/浅绿；等待或草稿用浅黄，冲突用浅杏并配标题和文字，所有状态均不依赖颜色。

后台将内容服务作为计划表单中的一个完整服务卡：基础校验只读且固定开启；增强开关与“最多1次”合并显示，不出现可编辑次数或只审不修组合。保存前差异作为原表单下方的核对区，不建立配置发布平台。预设继续原“列表＋编辑纸张”结构，只在参数区加入本次预览模式。

## 打开原型与复现场景

在 `.planning/milestones` 执行：

```sh
python3 -m http.server 4174 --bind 127.0.0.1
```

原型必须经 HTTP 打开，因 `app.js` 会读取 `copy.json` 与 `prototype/fixtures.json`，且 M003 增量样式会读取冻结的 M002 主题。目标浏览器为当前 Chromium，桌面 1440×1000、手机 390×844；无远程字体或图片。

| 页面/状态 | 稳定入口 |
|---|---|
| Basic 权益、生成前 | `http://127.0.0.1:4174/M003/design/prototype/?page=create&plan=basic&stage=idle&lang=zh` |
| Pro 草稿/审稿/返修/完成 | 同入口改 `plan=pro&stage=draft|review|repair|complete` |
| 取消 | `?page=create&plan=pro&stage=cancelled&lang=zh` |
| 预设来源 | `?page=create&plan=pro&source=preset&stage=idle&lang=zh` |
| Pro 关闭差异 | `?page=plans&plan=pro&next=off&adminState=preview&lang=zh` |
| 配置并发冲突 | `?page=plans&plan=pro&next=off&adminState=conflict&lang=zh` |
| 保存后读取 | `?page=plans&plan=pro&next=off&adminState=saved&lang=zh` |
| 后台基础/增强预览 | `?page=presets&mode=base|enhanced&previewState=ready&lang=zh` |
| 模式变化、旧预览过期 | `?page=presets&mode=enhanced&previewState=stale&lang=zh` |

上述入口均可用 `lang=en`。夹具只为确定性构图，不代表真实 AI 输出、用户数、服务配置、延迟或质量结果。

## 页面与内容定位

| 区域 | 顺序与规则 | 文案源 |
|---|---|---|
| `#benefit-summary` | 服务名→说明→当前计划→受理快照；不是用户开关。Basic/visitor 仅基础，Pro/Plus 依服务端结果显示基础或增强 | `benefit.*` |
| `#generation-status` | 正文/空态优先，阶段轨道次之；草稿可读但不能保存，返修整篇替换，完成才出现收录/放弃 | `stage.*`、`action.*` |
| `#content-service` | 基础服务卡→增强服务卡→预览差异；visitor/basic 开关禁用且为关闭/0，Pro/Plus 只允许关闭/0或开启/1 | `plans.base.*`、`plans.review.*` |
| `#change-preview` | 当前/保存后→关闭警告→影响人数→新请求/在途/用量影响→取消/保存 | `plans.preview.*`、`plans.effect.*` |
| `#version-conflict` | 冲突标题→未部分保存→服务端最新/本地未保存→重新核对 | `plans.conflict.*` |
| `#preview-mode` | 基础默认→增强最多1次→不赠予读者说明→生成/发布；模式改变后 `#preview-result[data-state=stale]` | `preset.mode.*` |

动态模板：`benefit.plan` 的 `{plan}` 来自本次受理权益；`plans.impact` 的 `{basic}/{trial}` 来自影响预览；`preset.usage` 的 `{count}` 来自后台单列用量。缺值时不猜测数字，应显示后端定义的未知/加载/错误状态。

## 详细规则入口

- Token 与布局：`theme.css`；M002 是主题真源，M003 只维护新增选择器。
- 状态、触发、取消与过渡：`interactions.md`。其中阶段是应用状态，不规定 SSE 事件名、调用顺序、复审次数或额外模型调用。
- 断点、键盘、焦点、读屏与减少动效：`responsive-accessibility.md`。
- 文案：`copy.json`；原型实际 fetch 并渲染该文件，固定文案不得从 HTML/JS 另行改写。
- 示例数据：`prototype/fixtures.json`；前端实现必须改接正式应用模型，不复制示例人数或文章。

## 实现约束与验收

| 验收 ID | 原型定位与来源 | 必须保持的结果 | 检查方法 |
|---|---|---|---|
| UIA-M003-301 | `#benefit-summary`；AC-301/306/307 | 用户看见本次实际权益与计划来源；无用户开关；进行中说明快照 | Basic、Pro、Pro关闭入口检查文本与 `data-enhanced` |
| UIA-M003-302 | `#generation-status`；AC-302/308/311 | 仅增强出现审稿/返修；草稿标明可替换且无保存；完成文案不称“审稿通过”；取消有终态 | 操作各稳定入口，核对轨道、动作与保存可见性 |
| UIA-M003-303 | `#content-service`；AC-304 | 基础校验不可关；普通档固定关闭/0；付费档增强是开/1或关/0；无独立次数输入 | 键盘切四计划并检查开关禁用/标签 |
| UIA-M003-304 | `#change-preview`；AC-305/306 | 预览显示旧新值、影响人数、新请求生效、在途快照、用量/期限不变；取消不保存 | 打开 Pro 关闭预览，按显示顺序核对 |
| UIA-M003-305 | `#version-conflict`；AC-305 | 冲突不部分保存，同时保留最新值和本地输入，须重新预览 | 冲突入口及“重新核对”操作 |
| UIA-M003-306 | `#preview-mode` / `#preview-result`；AC-309 | 基础默认、增强显式；不赠予读者；模式变更使旧预览失效；有效完成才可发布 | 切换 radio，核对 URL/state、提示和用量 |
| UIA-M003-307 | 全部 | 320px 以上无页面横向溢出；交互目标≥44px；焦点可见；状态不用颜色单独表达 | Chromium 1440/390 实际操作与边界检查 |

组件拆分、DOM 和后端协议由下游决定；固定文案、信息顺序、可见状态和结果语义必须保持。流式阶段如何从后端事件映射，由 frontend-bob 在 backend-alex 定稿后记录。

## 设计自检与未决项

- 需求验收模式已保存 6 张代表截图并执行 7 个浏览器场景：桌面 1440px 的 Basic 生成前、Pro 审稿、计划关闭预览；手机 390px 的 Pro 完成、配置冲突、增强预设，以及开关/模式键盘操作。结果 7/7 PASS，无控制台错误、文案缺键或页面横向溢出；证据为 `design/evidence/M003-UI-01-browser.json` 与相邻截图。
- 实际环境：Chromium（Playwright 1.62.1）、Node v22.23.2、本地 HTTP；仅验证静态设计原型。未运行要求 Node 24 的产品工程，也未连接 UAT 3302、真实账号、数据库、模型或部署脚本。
- 人工查看 6 张截图后修正了冲突示例，使“服务端最新为开启/1、本地拟关闭/0”可直接比较；修正后重跑 7/7 PASS。
- 未定义且交下游：SSE/流式事件、调用链、技术失败重试与具体复审编排；设计只消费“受理权益、当前用户可见阶段、最终保存资格和终态”。
- 未验证：768/320px、英文视觉、真实屏幕阅读器、产品代码还原与真实服务端持久化；结构已提供相应规则，不把 1440/390 的原型检查扩大为全站通过。
- 当前无阻塞业务歧义、无新增变更请求。真实精简链路质量、费用和时延不属于本原型可验证结论。
