---
milestone: M003
stage: product-planning
role: product/to-c
agent_name: product-maya
status: awaiting_user_review
version: M003-PRODUCT-02
date: 2026-10-09
---

# M003 产品交接

product-maya 已完成六份产品原件的定向修订，建议 awaiting_user_review；Q3-01 配置范围仍 OPEN。该建议不改变 workflow、不批准自身产物或切阶段，M003-PRODUCT-01 的批准不覆盖本版。

## 输入与需求确认闭环

- 本轮入口：[TRANSITION-M003-005](../reviews/product-revision-005.md)、[用户选择 USER-M003-Q01-B / Q02-A](../reviews/requirements-feedback.md)、[CQ-01–13](../../../../docs/plans/content-review-and-repair.md#2-用户已确认的边界)，确认日期 2026-10-09。
- 当前理解与分类：[D3-01–08、Q3-01](../product/overview.md)。已落实付费计划独立内容上限/初始1、有效稿审校故障交付并计一次、两类纠错配置说明。撤销旧固定开启/1和内容审校技术失败一律退款的解释。
- 基础纠错全请求2次、保护时限与后台只读展示为后端/产品建议，不冒充用户原话；未将 CQ-13 扩大为基础预算可后台编辑。数值范围尚未确认，受影响的正式校验与实施不得固化；已确认修订可以审阅。
- 继承 [M002 已验收交接](../../M002/handoffs/verification.md)（TRANSITION-M002-123）、计划 CAP-103、权益 CAP-216、预设 CAP-218 与原生完整输出；[USER-COMPAT-001](../../M001/reviews/first-release-compatibility-policy.md)、[USER-CLAIM-DELETE-001](../../M001/reviews/claimed-batch-delete-retention-exception.md) 保持。
- 保持 [consumer-ai-web@1.0.0 锁定 Profile](../reviews/evidence/start/locked-profile.yaml)；[模型路由锁](../../../agt/model-routing-v1.lock.json) 选 frontier/high，requested_model=gpt-6-astra、requested_effort=high；actual_model=unknown、usage=unknown。运行映射 product_maya_revision 不改变语义身份。

## 本次原始产物

1. [overview.md](../product/overview.md)：范围、D3-01–08、Q3-01 推荐与取舍。
2. [abilities.md](../product/abilities.md#repair-config-matrix)：两类配置矩阵、混合计数例子、CAP-301–305 与 AC-301–314。
3. [ai-behavior.md](../product/ai-behavior.md)：故障交付、无效稿、取消/断连/结算未知的边界。
4. [data-assets.md](../product/data-assets.md)：DATA-301–304、交付/审校完成/质量证据与调用统计。
5. [pages/index.md](../product/pages/index.md)：PAGE-204/208/212/215/216/217 的配置、权益、未完成提示与保存状态。
6. 本交接单。

## 下游待同步（本轮未修改）

| 责任角色 / 旧原件 | 受影响依赖与完成条件 |
|---|---|
| designer-tony / [UI 交接](uiux.md)、[交互](../design/interactions.md)、[原型](../design/prototype/index.html) | M003-UI-01 旧固定1次展示须改为计划上限；管理页分清基础只读/付费内容可配；故障有效交付可保存且持续显示未完成，预览模式保持明确1次。按 AC-304/308/309/313/314 核对 copy/原型及状态 |
| dba-diana / [DB 交接](database.md)、[数据库](../technical/database.md) | M003-DB-01 固定0/1限制待范围选择后同步；必要终态/保存事实、最近有效整包与配置快照支持Q02，保留唯一结算、数据删除与权限边界。不由产品指定表/API |
| backend-alex / [后端交接](backend-architecture.md)、[后端](../technical/backend.md)、[AI 编排](../technical/ai-integration.md)、[API](../technical/api/index.md) | M003-BE-01 的固定一次循环、禁止回退、所有审校失败退款与本版冲突；按确认范围同步循环/两预算/既有时限、最近有效稿整包、未完成可保存终态和状态查询、调用与业务计次统计。2次基础预算及故障实现由其正式定稿 |
| frontend-bob / 后续前端契约 | 尚未完成本期架构；接收修订后的 UI/后端契约，映射动态N、整体替换、未完成提示/保存、pending核对，不直接沿用旧协议 |

## 追踪、维护与验证

复用六份当前主文档，未新增 CR 或竞争真源。旧版在 [feedback-005/artifacts.tar.gz](../reviews/evidence/feedback-005/artifacts.tar.gz) / [manifest.json](../reviews/evidence/feedback-005/manifest.json) 可恢复；冻结审批/证据及其他专业原件保持。稳定 DATA-301–304、CAP-301–305、PAGE ID 和 AC-301–312 原位保留，新增 AC-313/314，不搬路径。静态检查：6/6必需文件存在且版本一致；逐条本地路径和锚点均可解析（0断链）；CAP/DATA/PAGE稳定定义与AC-301–314引用齐全；旧固定开启1次/审校故障一律退款正文已替换。对修订前快照按清单逐项验证37/37哈希一致；UI/DB/BE原件未改。控制面文件与研发输入由主会话并行更新，不归本次产品写入。检查方法为本地Python路径/锚点/清单哈希核对及定向rg规则复查，不以文档检查冒充运行验收。

本轮输入超出共同契约8k软目标，因需核对 CQ-11–13、计划/体验卡、终态和有效全局约束；已读取整理协议并收敛到现有六份原件，没有全量历史扫描。运行时总输入字符数/token 均 unknown；同口径六份产物修订前16,308字符，修订后约22,000字符（含Markdown）；增加内容为两类配置矩阵、Q02边界、待同步依赖和确认状态，不是历史堆叠。该静态计量不能冒充运行用量。新会话交接测试未执行，本轮静态自检不替代独立接续验证。

## 剩余事项与下一动作

- **OPEN Q3-01**：仅需向用户以普通文字一次问一项，推荐内容开启1–2次、关闭0，Pro/Plus初始1；可选更宽1–3但缺乏效果证据。得到答复后就地记录确认并同步 CAP-303 / AC-304，不调用选项卡工具，不自行切阶段。
- **PROPOSED**：基础2次为技术预算；D3-06 后台基础/增强两模式（增强固定1次）及未完成有效预览提示后可手动发布，为整版待审方案，未追加平台或收费范围。
- **未验证**：AC-301–314 全部待实现验证；精简链路内容质量、漏检率、费用及流式延迟未测。CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX 沿 [workflow 开放事项](../../../workflow/state.yaml) 与 M002 原交接保持，不改写旧失败或扩张为本期全量修复。
- **阻塞范围**：Q3-01 阻止受影响的最终配置数值域定稿与实施；产品原件修订已可审阅。UI/DB/BE 仍待责任角色接收同步，不得沿旧批准宣称本版已通过。
- **下一步**：先反馈两类配置矩阵和混合例子，取得 Q3-01 选择；完成产品审阅后依既有授权由控制角色办理对应接交。无源码、DB迁移、真实收费调用、提交或上线；UAT/发布授权未改变。
