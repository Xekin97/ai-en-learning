---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_design_submission_review
version: M003-UI-12
date: 2026-10-13
---

# CR-310 UI/UX 设计交接

## 输入与确认边界

- `CONFIRMED / USER-M003-REGENERATE-CONFIRM-20261013`：完成后允许编辑下一次配置/词条；按现有 Generate 时才确认永久放弃当前未收录结果；取消保留旧结果与新编辑；不再要求独立放弃。来源为 [requirements-feedback](../reviews/requirements-feedback.md#user-m003-regenerate-confirm-20261013) 与 [CR-310](../changes/CR-310.md)。无剩余业务问题。
- 当前 live 前态由 QA 只读确认：valid 把八个 config controls、选词和 Generate 全禁用，唯一前进路径是 standalone discard。其证据由 QA 写入 `../verification/evidence/cr310-qa/before/baseline.json`；本设计不覆盖该基线。
- 适用 PAGE-204/216 普通游客/登录用户工具台。预设试用只读、collect/guest claim、streaming/pending/saving 防重入、离页保护、已保存记录、CR309 UI11 视觉、CR302/306 开放事项均保持。不涉及 BE/DB/provider/model/admin preview/UAT 数据。
- 入口基线为 `../reviews/evidence/cr310-design-entry-091/before.tar.gz`。请求模型为 `gpt-5.6-sol/high`，实际 serving 无证据，记 `unknown`。

## 当前产物

- [M003-UI-12 正式规格](../design/design-spec.md)：当前首节含状态、精确双语文案、Vue 接点与 UIA-M003-423–426；后部 UI11/UI10/UI09 合同作为未改继承内容。
- [可运行原型](../design/prototype/index.html)、[copy 真源](../design/copy.json)、[样式](../design/theme.css)、[交互](../design/interactions.md)、[响应式与无障碍](../design/responsive-accessibility.md)。原型消费 copy 真源及既有合成 fixture，0 provider call。
- [浏览器报告](../design/evidence/cr310/M003-UI-12-browser.json)：6/6 PASS、console error 0；[桌面可编辑结果](../design/evidence/cr310/01-editable-result-desktop.png)、[桌面中文确认](../design/evidence/cr310/02-confirm-desktop-zh.png)、[移动英文确认](../design/evidence/cr310/03-confirm-mobile-en.png)。
- 设计源码恢复包和 hash 清单：`../design/evidence/cr310/M003-UI-12-source.tar.gz`、`M003-UI-12-source-manifest.json`。归档只含设计真源和验证脚本；不含 mutable CR、control、workflow、handoff 或产品代码。

## frontend-bob 接收映射

1. `GenerationWorkspace.vue` 将 `busy` 拆成真实生成 busy（streaming/pending）、valid 未收录结果保护、leave protection；valid 时普通 fieldset、WordPicker 和同一 Generate 可用，saving 继续保护保存/竞态，presetId 继续只读。
2. final `<h2>` 从 `generation.result.targets` 或完成 request snapshot 读取，禁止 live `words.join()`；正文/释义同样不随下一配置变化。移除结果 actions 内独立 `confirmation='discard'` 按钮，保留 collect/guest claim。
3. Generate 在 `hasUnsavedResult` 时打开现有 `AppDialog` 的 `regenerate` confirmation；默认焦点取消，Escape/X/遮罩/取消保留 result+inputs 并回焦 Generate。同步 `m003.regenerate.title/body/confirm/failure`，实现不得写第二份文案。
4. 确认严格 `await workspace.discard()` 成功后调用一次 generate；失败保留旧 result+新 inputs，显示 failure，generate 调用为 0。现 store `discard()` 只重置 generation，表单字段独立；后端 Discard 幂等且 saved 先胜不改记录，因此当前不需新 BE。
5. 在 `technical/frontend.md` 逐条接收 UIA-M003-423–426，并注明 AppDialog shown/default-focus 最小实现选择、保存/确认防重入与测试定位；之后才交 frontend-claire 实施。

## 验证结果与边界

- 1440 valid Result 同时展示新配置 `discussion`、新词 `harbor/quiet` 与旧标题 `garden · learn · share`；配置/选词/Generate 可用，standalone discard 为 0，无横溢。
- desktop zh 与 390 en 均为真实 `showModal()` top layer；准确 copy、默认取消焦点、Shift+Tab trap、Escape/取消回焦及 result/input 不变通过。discard failure fixture 保持 event 74、旧结果/新输入和 0 new generation；确认成功合成路径为 1 discard → 1 generation。
- 证据只验证设计源；Vue 调用顺序、重复 confirm/save/leave race、guest/learner、preset read-only 与 UAT3014 更新留给 implementation/independent QA。不要重启或真实调用正在运行的 UAT3014。

## 文档维护与下一步

- 当前权威设计入口是本交接与 `design-spec.md` 的 M003-UI-12 首节。失效规则是 valid 锁配置/词、standalone discard prerequisite、live words 标题；旧证据保留为历史，不再实施。
- UI11 的词义共享列表与 CR309 证据完整保留且继续有效。本轮只在现有正文顶部维护当前覆盖规则，没有重写长历史合同；稳定编号和 copy key 已入链。
- 下一角色：`frontend-bob` 做 CR310 最小前端技术接收；完成条件是明确上述五个接点及 UIA-M003-423–426 测试映射。之后由 `frontend-claire` 实施、`qa-quinn` 独立复验并在通过后刷新当前 UAT3014。
- 本交接不自批设计、不迁移阶段、不表示实现/QA/UAT 已通过。

