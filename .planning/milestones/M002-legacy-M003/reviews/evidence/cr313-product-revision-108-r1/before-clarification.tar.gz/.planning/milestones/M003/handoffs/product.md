---
milestone: M003
stage: product-planning
role: product/to-c
agent_name: product-maya
status: awaiting_user_review
version: M003-PRODUCT-12
current_scope: CR-313
date: 2026-10-15
---

# product-maya：CR-313 当前产品交接

已交付按类别导入/导出的 PRODUCT12 产品稿，独立部分可审阅；Q313-01/02 尚待用户答复，受影响的凭据缺省与跨类别替换规则不能作为可执行下游基线。当前仅产品工作，不自批、不切阶段。

## 输入与确认闭环

- [门禁108](../reviews/cr313-product-entry-108.md)、[用户下一步授权](../reviews/evidence/cr313-product-entry-108/authorization.json)、[CR-313 原话/三项答复及当前问题](../changes/CR-313.md)：四类别、整类替换、可选加密密钥已确认，不重问。两项新边界经协调方向用户询问，结论仅以实际答复为准。
- 已核验 M003/product-planning/product/to-c/product-maya，context=single；沿 [锁定Profile1.0.0](../reviews/evidence/start/locked-profile.yaml) 及 [模型锁](../../../agt/model-routing-v1.lock.json)，requested gpt-6-astra/high，actual_model/usage unknown；已沿用完整技能、共同/工作流/产品ToC/路由契约及交接模板。
- 现有固定计划、道具类型/历史保护、计划体验、签到日界及等级/成就领取规则的批准来源与源码依据在[唯一产品稿](../product/config-portability.md#data)。本稿没有把现有逐项合并保存当成全量替换能力。

## 原件与追踪

唯一 scoped 需求真源：[config-portability.md](../product/config-portability.md)。Profile 当前入口分别为 [overview](../product/overview.md)、[data-assets](../product/data-assets.md)、[abilities](../product/abilities.md)、[pages](../product/pages/index.md)、[ai-behavior](../product/ai-behavior.md)，仅更新头部/当前指针，PRODUCT10正文原样保留。

覆盖 DATA-501～506、CAP-501～504、PAGE-501～504、AC-501～512。管理员、四类别、预览/确认/冲突/结果未知、默认无密钥与显式加密、旧运行数据保护均有可观察规则；文件格式、数据库/API、密码算法及映射实现留技术。

## 待决与下一动作

- [Q313-01/02](../product/config-portability.md#open)：缺省凭据、跨类别引用移除两项业务选择待答；AC-510/511对应分支未定，不声称完整可实施。其余不依赖这些选择的范围、资产和操作稿已完成。
- TECH-501/502/503分别交dba-diana/backend-alex/frontend-bob处理身份/引用、原子替换与并发、加密秘密、界面状态接收。先由designer-tony在产品范围接收后交各类别交互原型与正式设计；不在本阶段启动设计或技术工作。
- 产品完成条件：记录两项针对性答复，收敛受影响正文/验收，交用户审阅并由控制面决定阶段。当前无其他关键产品问题；不重复已确认类别、替换或加密选项。

## 保留与验证

[门禁前快照](../reviews/evidence/cr313-product-entry-108/before-product-entry.tar.gz)可恢复原产品入口/交接及CR。PRODUCT11 发音原件、UI14设计源/交接保持；发音产品已在107接收，UI14尚未审阅。M003整体未收尾，CR311/312的QA/UAT接受保持。UAT3015/4174、用户数据和模型配置未动；[QA范围政策](../../../agt/qa-scope-policy.md)不变。

[静态自检](../product/evidence/cr313/check.json)核对新增链接、稳定ID、PRODUCT10正文与发音/UI14完整性；[保留清单](../product/evidence/cr313/preservation-before.json)记录检查基线，[当前产物清单](../product/evidence/cr313/manifest.json)记录版本。无应用测试、真实Key读取、提供方调用或运行时刷新，静态通过不等于实现验收。总实际输入/运行token未知，不以文件字符数冒充token。
