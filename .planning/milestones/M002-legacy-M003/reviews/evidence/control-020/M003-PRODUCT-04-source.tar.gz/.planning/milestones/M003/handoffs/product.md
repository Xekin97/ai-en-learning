---
milestone: M003
stage: product-planning
role: product/to-c
agent_name: product-maya
status: awaiting_user_review
version: M003-PRODUCT-04
date: 2026-10-10
---

# M003 产品交接

product-maya 已完成 **BE3-DEP01 产品展示条款同步**，六份当前原件统一 M003-PRODUCT-04，建议 awaiting_user_review。本轮落实已确认用户修订并引用后台先行方案，无新增业务待决；不批准 BE03 技术字段、UI 或未来实现，不修改 workflow 或激活下游。

## 输入与需求确认闭环

- 本轮入口：[TRANSITION-M003-019 接交检查](../reviews/stream-handoff-018.md)、[USER-M003-STREAM-FIRST](../reviews/requirements-feedback.md#m003-stream-first-后端生成流程先行)（2026-10-10）、[BE03交接的BE3-DEP01及设计接收合同](backend-architecture.md)。状态与注册表已核对为 product-planning / product/to-c / product-maya。
- **CONFIRMED 用户方向**：用户生成页不突出审稿/返修，不显示上限或轮次；先后台设计生成流，再据此更新现有完整页面原型。撤销 PRODUCT03 的“含审稿与最多N次”、草稿/审稿/返修步骤区分及 k/N 强制展示，影响 PAGE-204/216、D3-04、CAP-301/302/304、AC-308/312 与 AI 真实进展段。完整导航、选词/配置、计划、预设和学习交互继续保留。
- **后台技术方案，供原型验证**：BE03 首个基础有效包只提供原词词义预览，最终正文一次出现，最终整包替换预览；普通与内部两轮使用同一公开序列。具体事件/字段/终态以 [API-302](../technical/api/generation.md) 为真源，本产品同步不抄写API字段、不冒充用户批准整版方案。
- **保持的规则**：Q01-B/Q03-RANGE99 的各付费计划整数0–99/初始1、0关闭、按N运行/流程测试最多2次；基础全请求2次只读技术策略、两预算独立；同目标模型、上限定稿、一次业务计次和牵强/矛盾统计。Q02有效稿内容故障须持续提示“内容审校未完成”、可保存并计一次；取消/断连/结算未知边界不变。后台preset基础0/增强1、管理两类预算和实际用量仍保留。产品建议与用户确认分类见 [D3-01–08及Q3-01](../product/overview.md)，此次展示修订不扩大为后台能力删除。
- **未验证效果**：不新增LLM/词典调用，第一有效包之前只诚实等待；首次词义、首次最终正文、最长无新有用内容间隔与总时长需分别记录，目前没有更快或质量改善的实测结论。
- 沿用 [consumer-ai-web@1.0.0](../reviews/evidence/start/locked-profile.yaml)、[M002已验收交接](../../M002/handoffs/verification.md)、[USER-COMPAT-001](../../M001/reviews/first-release-compatibility-policy.md) 与 [USER-CLAIM-DELETE-001](../../M001/reviews/claimed-batch-delete-retention-exception.md)。模型采用 [v1锁](../../../agt/model-routing-v1.lock.json) frontier请求：gpt-6-astra/high；actual serving model与usage unknown，不迁移Profile或模型锁。

## 本次原始产物

1. [overview.md](../product/overview.md)：D3-04、确认范围、方案与证据边界。
2. [data-assets.md](../product/data-assets.md)：DATA-302/303权益元数据与预览/最终资源可见性。
3. [abilities.md](../product/abilities.md)：CAP-301/302/304、AC-308/312；CAP-303/305及其余验收业务规则保持。
4. [pages/index.md](../product/pages/index.md)：PAGE-204/216及文案；管理0–99/两预算和后台模式保留。
5. [ai-behavior.md](../product/ai-behavior.md)：真实进展、整包替换、Q02与时延证据边界。
6. 本交接单。

## 责任交接与下一动作

| ID / owner | 当前结果、接收输入与完成条件 |
|---|---|
| BE3-DEP01 / product-maya | **已同步**：六份PRODUCT04原件撤销旧用户端突出流程/次数条款，采用真实词义预览与最终整包的方案边界；没有改写backend原件中的依赖状态 |
| BE3-DEP02 / designer-tony | 下一步按已授权范围接续完整造文、计划管理、预设管理原型。必须读取 [API-302](../technical/api/generation.md)、[BE03 designer-tony接收合同](backend-architecture.md#designer-tony-接收合同)，实际加载 [stream-v3/index.json](../technical/fixtures/stream-v3/index.json) 所列fixture的wire事件及状态响应，不能猜阶段或用内部证据/计时器编造进度。验证普通/内部两轮相同公开序列、最终v3替换v1全部资源、Q02最近有效包持续提示且可保存、pending/EOF/失败/取消边界与后台预览。播放器可调度合成事件但不声称真实时延；普通同帧完成不延迟。记录fixture版本与可操作场景，交用户查看完整页面后评审 |
| BE3-DEP03 / frontend-bob | 仍由原owner后续接收BE03/UI修订，更新FE01状态映射与mock；不沿用旧stage/candidate或动态k/N。范围与完成条件沿 [BE03跨owner依赖](backend-architecture.md#跨owner同步依赖精确范围)，未在本轮改动或宣布完成 |
| BE3-DEP04 / backend-ethan | 待审代码保护与后续实施对齐仍沿BE03原owner、原授权边界；本轮不接收为通过、不修改实现。DB02不因公开投影新增迁移；没有重开无关DB范围 |

本步产品同步完成条件已达到：已确认方向落实到六份当前原件，技术方案/用户确认/未验证效果区分，稳定ID和依赖去向保留。后续接交由主会话按现有授权处理，本角色不自行迁移。无需再次询问N、Q02或后台先行顺序。

## 维护、检查与剩余事项

- 当前权威入口为六份PRODUCT04；旧PRODUCT03六份文件在修改前已与 [product-006冻结包](../reviews/evidence/product-006/artifacts.tar.gz) 逐字核对6/6一致。旧审批、冻结证据及 [产品02快照](../reviews/evidence/product-02-before-range/artifacts.tar.gz) 保留，本轮仅原位维护正文，不另建报告或竞争真源。
- 定向静态检查通过：6/6版本与日期一致，原有显式稳定锚点全部保留，66处本地链接/锚点无断链；旧显示约束检索仅保留撤销说明/禁止条款及后台管理规则。与冻结03对比，CAP-303/305及AC-301–307/309–311/313–314逐字未变。方法为Python路径/锚点/冻结包对比及定向rg检索。只检查产品文档，不重跑代码、浏览器、模型或fixture执行；BE03已有静态PASS仅为原技术交接证据，不代替UI或运行验收。
- 读取覆盖Skill/共同契约/角色/路由锁、当前控制入口、六份产品原件、STREAM-FIRST与BE03相关章节；超过planning软预算后停止历史扩展，定向完成本同步。运行时总输入字符/token/usage unknown，不拿静态字符冒充运行用量。无新会话交接测试，实际wire消费验证留给设计负责人。
- **无新增业务OPEN/BLOCKED**。AC-301–314仍需相应实现/验证；BE03原型效果、真实质量/费用/时延、取消/断连与结算竞争未在本轮验证。全局CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX继续沿 [workflow开放事项](../../../workflow/state.yaml) 保留。
- 未改后台/API/UI/DB/FE/源码/控制面/冻结证据，未提交Git、部署、调用真实模型或触碰UAT3302。完整原型仍须用户视觉评审，未来实施不由本交接授权。
