---
milestone: M003
version: M003-UI-09-R3
stage: uiux-design
role: uiux/base
agent_name: designer-tony
from: designer-tony
to: frontend-bob
status: design_resolved_pending_fe_acceptance
date: 2026-10-10
---

# UI09-R3 CR-303 设计纠偏交接

## 结论

UI09-R3 只解决 CR-303 的 PAGE-208 两项确定语义冲突：`basicUsers` 与 `trialUsers` 分别显示且不求和；Pro/Plus 的服务 badge 跟随真实 N/开关，N=0 为基础，N=1–99 为增强。UI09-R2 已被用户接受，其 M002 正式视觉基线、760px 居中阅读列、Plan 保留、v5 splice、终态与资格规则均保持不变。本交付将纠偏标记为设计已解决、待 frontend-bob 接收，不代表整体阶段自批。

## 前端原始来源

- `design/design-spec.md`：区域、来源、UIA-M003-401.a–411.a 与数据边界。
- `design/copy.json`：M002 完整 zh/en 固定文案 + `m003.*` 新文案；原型直接消费。
- `design/theme.css`：import M002 theme 后仅追加 M003 区域样式；UI09-R2 的产品实改仍只在此文件。
- `design/prototype/`：可运行正式预览和 demo adapter；`prototype/m002/` 是本版使用的 M002 组件/本地图标快照。
- `design/interactions.md`、`responsive-accessibility.md`。
- `design/evidence/ui09/`、`design/evidence/ui09-r1/`、`design/evidence/ui09-r2/`：冻结基线；`design/evidence/ui09-r3/`：本轮 PAGE-208 报告、截图、恢复包与 manifest。
  - UI09-R3 恢复入口：`design/evidence/ui09-r3/source.tar.gz`；完整 hash 与逐文件清单：`design/evidence/ui09-r3/source-manifest.json`。更早冻结包保持不变。

## 受影响 FE01 接点

1. `/create`：保留 M002 Header/Settings/WordPicker/阅读纸，接入稳定 `#generation-status/#planning-preview/#live-draft/#final-result`；不要把 fixture/timer/query 带入应用。
2. `/admin/plans`：保留全部 M002 计划字段、页头档位优先级编辑入口和单 panel 两栏布局，在后部接入 read-only 2 与 0–99；影响预览/冲突使用实际响应。
3. `/admin/presets`：保留 title、无限制管理选词、四配置、保存草稿/预览/发布/下架；接入 mode、preview namespace、资格和 Q02。
4. `/trial/:presetId`：复用生成内容区与状态规则，保留现有试用外壳。

接收完成条件：UIA-M003-401.a–411.a 可在实际 Vue 页面观察；固定 copy 不再内联分叉；M002 本地资源/自定义控件语义保留；API-302/API-304/DB03 成为真实驱动；生产测试证明 Unicode 码点、代次隔离、Plan 保留、资格与保存。

## 已检查与限制

UI09-R3 对 Pro/Plus 的 N0/N1、开关往返、分别标注的基础/体验人数、横溢与控制台错误完成 31 项有限检查，31 项通过；代表截图见 `design/evidence/ui09-r3/`。UI09-R2 的完整页面和流式行为证据继续有效，因为本次只改 PAGE-208 两处渲染映射。未调用真实模型、API、DB，未验证生产 Vue/DTO 接入；该部分由 frontend-bob 接收后验证。

新增业务待决：无；CR-302 保持 `product_resolved_downstream_pending`，待 FE/实施等接续。CR-303 为 `design_resolved_pending_fe_acceptance`。本交接不切角色；建议独立门检后回到 `technical-design / frontend-bob` 继续 FE02。
