---
milestone: M003
version: M003-UI-09-R3
agent_name: designer-tony
date: 2026-10-10
---

# UI09-R3 交互与状态

## 生成与试用共享区域

- 配置与选词沿用 M002 控件。启动前由应用校验可用模型、长度、释义语言、额度和 request words；点击正常生成按钮创建新 run，清旧临时状态并隔离旧代次。
- 收到 `started` 后才显示已受理；`progress(planning)` 与 `plan_item` 在 `#planning-preview` 逐条追加 scene/sense/phrase。
- `generation.edit` 按 content_version/base_rev/rev/seq/Unicode 码点应用到 `.live-draft-text`。首片建立 `#live-draft`，其后不重建整页、设置或 Plan。
- Plan 在初稿、fixed edit、条件修稿、retained、pending/EOF/finalizing 中保留；完整权威 valid Result 才清 Plan/临时稿并一次建立高亮、tags、学习资源、notice/save。
- pending/EOF/协议异常保留只读内容、禁保存并仅消耗合同提供的有限 status。失败/取消清 Plan 与 partial；取消、重启、切页、popstate/pagehide 均使旧 timer/request 代次失效。
- Q02 显示 `m003.incomplete` 且允许保存；不显示轮次、上限、内部审稿轨道或质量通过声明。

## 稳定性与输入

第一次启动可把结果区带入视野，后续 frame 不抢焦点、不强制滚动。正文不是 live region；`.draft-status[aria-live=polite]` 只读简短状态。相邻 exact duplicate 是 NOOP；seq/rev/range/draft/namespace 错误停止消费并进入有限核对。

## 计划管理

原字段按 M002 顺序保留。`#content-review-enabled` 是 N 的派生开关：关闭写入 N=0；开启恢复最近有效 N（无历史时为 1），不形成第三种业务模式。`#content-repair-limit`：付费计划接受整数 0–99；0 关闭，1–99 开启；访客/基础禁用。服务 badge 跟随该派生状态：N=0 显示基础，N=1–99 显示增强。`#plan-actions` 只有字段有效时可预览/保存。保存前用 `m003.impact` 分别显示 `basicUsers` 与 `trialUsers`；两类可能重叠，不求和。版本冲突保留本地值、呈现远端摘要并要求重新核对，不静默覆盖。

## 预设管理

编辑标题/词/四配置/preview mode 会使旧资格过期。保存草稿不生成；生成预览按所选 namespace 自动消费 actual wire，再有限核对 status。basic 和 enhanced 都有真实 Plan/正文；Plan 保留到完整 preview Result。发布需要 current draft_version、mode、run 与 status valid；Q02 还需勾选确认。取消/切预设/模式/页面使旧代次失效。

## UI09-R3 说明

本次只纠正 PAGE-208 的影响人数映射和关闭态 badge。UI09-R2 的居中阅读列以及其余交互选择器、事件归约、保存/发布资格与中断规则保持不变。

## demo adapter 边界

`scenario/event/status/rev/view` query、fixture 名、合成 timer 和折叠场景条仅用于评审。formal view 隐藏场景条；生产由 API-302/API-304 和应用路由驱动，无 fixture 匹配禁用、手动 step 或 timer 性能承诺。
