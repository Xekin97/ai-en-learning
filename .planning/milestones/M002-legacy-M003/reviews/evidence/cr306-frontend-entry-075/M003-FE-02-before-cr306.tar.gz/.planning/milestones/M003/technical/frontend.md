---
milestone: M003
stage: technical-design
role: frontend-architect/base
agent_name: frontend-bob
status: awaiting_user_review
version: M003-FE-02
date: 2026-10-10
input_version: M003-PRODUCT-07 / M003-BE-06-R1 / M003-DB-03 / M003-UI-09-R3
---

# M003 前端技术方案

当前方案替换 FE01，稳定 FE3 编号保持。交付的是设计，不是已实现/运行通过。UI09-R3 是 UI09-R2 已确认视觉上的 CR-303 两项语义纠偏；API/AI 沿 BE06，wire 为 `m003-stream-v5`。旧 FE01 在 [冻结包](../reviews/evidence/control-040/M003-FE-01-before-revision.tar.gz) 可恢复，不再按旧 stage/snapshot/candidate 方案实施。

## FE3-01 输入、决定与技术边界

**CONFIRMED 输入**：[PRODUCT07](../handoffs/product.md)、[CR-302](../changes/CR-302.md)、[用户确认](../reviews/requirements-feedback.md)的 Q3-02-A、LIVE-TEXT、PLAN-RETAIN、M002-DESIGN-BASELINE、READING-ALIGNMENT、UI09-ACCEPTANCE。所有模式同目标模型真实 Plan→writer；增强 N>0 再一次固定编辑→原生校验→Review/必要条件返修。N0保留规划但关闭增强段；内容N0–99/初始1，流程测试至多2轮，99仅配置/静态。基础恢复全请求固定2是接收的后端技术策略，后台只读、独立于N；后台basic0/enhanced1。前端不执行模型编排、不把一次业务次数等同一次模型调用。

**专业接收**：[BE06-R1交接](../handoffs/backend-architecture.md)、[API-301–304](api/index.md)、[AI3](ai-integration.md)、[DB03](database.md)、[UI09-R3规格](../design/design-spec.md)及[交接](../handoffs/uiux.md)。前端采用上述已接收输入；专业原件的 awaiting_user_review 不撤销 state 中的接交/用户设计确认，也不等于技术总审批已完成。恢复门检为 [TRANSITION-M003-053](../reviews/ui09-r3-frontend-handoff-052.md)。[CR-303](../changes/CR-303.md)两项设计冲突已接收，生产检查归 FE3-V07/08/11。

**技术取舍（本角色方案，待整体验收）**：沿现有 Nuxt 4/Vue 3、useState/store、Zod、eventsource-parser、i18n 和 Go 同源 API，不加框架。保留 SSR 页面/会话/选项读取＋客户端 POST 流：SSR 有助于首屏已有导航、配置与身份，且已具请求级隔离；流式草稿只在客户端活动会话存在。全CSR会重做当前加载与权限壳，SSG不适合私人动态状态，均无当前需求收益。无 CRDT、永久中间稿、自动续传、队列、额外词典/翻译调用或监控平台。

权限继续 [USER-COMPAT-001](../../M001/reviews/first-release-compatibility-policy.md)与[主动删除claim例外](../../M001/reviews/claimed-batch-delete-retention-exception.md)：配套切换契约，无旧流兼容；不复活已删除资源。保留当前后端未提交改动；本轮不改源码/专业上游/控制面，不提交、迁移、部署、真实模型调用或代用户UAT。

## FE3-02 数据层、类型与状态归属

依赖固定为 `HTTP/SSE DTO → 严格schema → mapper → 应用模型/事件 → store/纯reducer → presenter/组件`。SSR通过同一仓储/mapper后注入可序列化应用模型，禁止原响应透传；页面不fetch、不导DTO/schema、不读取snake_case。状态不能反向依赖视图。现有 `plugins/application-ports.server.ts` 的每请求 transport/vault、Nuxt app WeakMap控制器与私有状态注销机制保留。

下表路径相对 `frontend/`；拟新增文件仅在获得实施授权后创建。

| 入口 | 修改职责及实际差距 |
|---|---|
| `app/infrastructure/http/schemas/generation.ts`、`admin.ts`、`presets.ts`、`admin-presets.ts`、`common.ts` | 当前生成只有started/delta/validated；新增v5完整事件、status、ContentService/NativePolicy、preview mode、outcome/notice、busy及revision context；移除旧delta类型。共享schema放generation或就近小文件，不另造协议框架 |
| `app/infrastructure/http/repositories/api-repository.ts`、`admin-presets-repository.ts`、`presets-repository.ts`、`admin-configuration-repository.ts` | 当前普通/preview各自读delta，parser finally会清非validated token；改v5、保留pending能力、status端口、严格body与HTTP busy；发布当前多传confirmed，按API-304移除（不波及下架旧合同） |
| `app/infrastructure/http/mappers/index.ts`、`span-mapper.ts`、`problem-mapper.ts`、`presets-mapper.ts`、`admin-presets-mapper.ts` | 保留已有Unicode Result映射；增加临时Plan/edit应用事件、完整终态/notice/资格、双类人数/真实N/未知usage。当前problem mapper丢context，需显式映射busy/revision，不把任意后端detail当文案 |
| `app/application/shared/models.ts`、`ports.ts`；拟增 `app/application/generation/content-service.ts` | 应用类型与关联规则，端口增两类status；generation/preview凭证与退款联合分离。只提供当前需求的共用预算/终态校验，无Vue/Zod依赖 |
| `app/application/generation/reducer.ts` | 现仅拼接delta；替换为v5 seq/Plan/splice/终态纯归约，共用正文规则但保持namespace区别 |
| `app/application/admin/configuration.ts`、`plan-policy.ts`、`presets.ts` | 完整计划输入/impact、raw N校验、预览输入快照失效、模式/版本/run关联及手动发布资格 |
| `app/runtime/stores/generation.ts`、`presets.ts`、`admin.ts`、`admin-presets.ts` | 现EOF直接failed、preview catch可覆盖结果；新增request epoch、有限核对、取消竞争、busy回退和旧回调隔离；store只用port，不直接读parser |
| `app/presentation/admin/admin-plan-presenter.ts`；拟增 `app/presentation/generation/content-service-presenter.ts` | 模型→固定copy键/变量、区域与动作资格；不暴露版本/N/内部审稿进度，不按Pro/Plus名称推断权益 |

应用状态分四类，避免一个phase同时承担传输、业务和表单事实：

- `attempt`：namespace（generation/preview）、本地requestEpoch、sessionEpoch、streamId/runId、acceptedSnapshot或previewBinding、lastSeq/上一帧指纹、phase（accepted/planning/composing/finalizing）、planId/language/条目、draftId/离开过的ID集合、contentVersion/revision、draftText及码点长度。**没有 acceptedCandidate、repairAttempt 或内部 lastValid 模型**；服务端未发送这些可用事实。
- `terminal`：status、finalContentVersion、完整 result 或 null、outcome/notice、用户 canSave/refund 或管理员 usage。与临时状态不同；`resultUnavailable`是权威valid但payload不可用，不能显示“完整资源已准备好”。
- `request`：idle/starting/streaming/pending/settled，cancel/recheck busy、reconciliationEpoch、明确受理前busy及retryAt。started前保留既有有效结果/ready绑定以便明确busy不抹结果；新请求清旧临时Plan/正文，旧正式结果仍独立绑定原run，不能成为新请求final。已明确放弃的结果不复活。
- `form`：本地原始输入、baseline/remote、editRevision及已预览规范化body；URL仅原有路由/资源ID，无token/临时正文/demo query。

`runtime/session/token-vault.ts`继续只在内存保存能力，generation与`preset-preview:`分键；不进useState/SSR payload、local/sessionStorage、URL、analytics或日志。注销/换账号清私有正文、能力与计时器。仅有 run_id 无token不得查需要能力的status。

### 严格schema与映射要求

wire字段唯一来源为API原件，本文不建立第二份DTO规格。所有必填/nullable/unknown字段及整数界按API；流JSON沿现有JSON.parse校验语法/尾随，再做严格schema；不把后端AI输出的重复键解析职责扩成新的客户端解析器。保持fatal UTF-8与跨chunk解码。规划scene1–600、sense1–256、form1–128、phrase1–256码点，entry必须来自当前请求，数量随真实E；预览只接受两个exact分支，不接受私有role/facts/beats。

ContentService仅false/0或true/1–99，NativePolicy严格为version/scope/max_calls=2/editable=false的真实响应；visitor/basic不得增强。started快照覆盖旧options预估且本run固定，刷新options只用于下次。preview mode与N严格basic0/enhanced1，不包含用户plan或charge。

Result整包校验目标词exact各一次/输入顺序、标签、释义、hint与occurrences；用现有 `Array.from` 码点半开区间校验surface/范围/重叠，再一次映射segments。不得从Plan.sense填entryMeaning，不混合旧稿字段。status的valid允许result=null，can_save=false；完整有效不等于当前仍可保存/发布。

outcome只有basic/review_passed/repaired_passed/limit_finalized/service_incomplete，后者必须notice=content_review_incomplete，其他null；与N/mode、status/refund按API关联检查。历史管理preview/version/outcome可null，不填“审稿通过”。UsageSummary的providerCalls、unknownCalls、invocationUnknownCalls、notInvokedCalls分别映射，null token/费用仍未知，不能相加当实际调用数。

## FE3-03 流读取、版本与reducer

继续POST fetch与eventsource-parser；可把两个仓储重复的读取/命名分派抽到就近 `app/infrastructure/http/repositories/content-stream.ts`，仅共用传输与v5检查，不合并用户/管理员权限。heartbeat无seq，不推动状态。parser缓存上限不能机械保留当前1MiB：需按API允许的完整Result和retained全文及JSON转义计算有界最大帧，provider insert≤2048码点但retained可整稿；实现测试合法大终态不被1MiB截断与越界拒绝，不任意缩小上游输入边界。

| 收到的事件/事实 | 验证和归约结果 |
|---|---|
| started | 第一个命名事件、seq=1、contract_version=v5；完整身份/服务快照校验后留token；绑定当前响应stream_id。预览另核draft_version/mode。相邻完全重复帧按下述NOOP处理 |
| progress planning/composing/finalizing | 只按收到的真实phase推进；不造Review/固定编辑/返修轨道，不能回到planning或在finalizing后编辑；composing前计划项必须已经排空 |
| plan_item | 仅planning期间，同plan_id/受理meaning_language；scene最多1、每个selected entry最多1，保持收到条目的稳定身份/真实顺序，布局仍按scene与词用法区域。只显示已完整收到的scene/sense/phrase，无占位词义 |
| edit | 验seq、draft规则、版本、base_rev=currentRev、rev=base_rev+1、码点范围；原子执行 `prefix(at)+insert+suffix(at+delete_count)`。每次edit只改变正文，不清Plan、不建学习资源；insert为空可真实删尾 |
| validated | 身份匹配、完整Result/终态关联通过才原子清Plan和临时稿，建立最终正文/高亮/tags/targets/notice与资格。最终版本来自权威包，不要求等于最近可见draft或前端曾见过的版本；允许Q02 final下降 |
| failed/cancelled | 权威失败/取消清临时内容并关保存；generation失败refund=true，取消false，preview无quota字段；不从肉眼完整草稿擅自成功 |
| settlement_pending、无终态EOF、协议/网络异常 | 停止不可信流消费，保留已安全应用的Plan+正文、无学习/保存，转有限status核对。不是Q02或退款事实 |

**seq与身份**：所有命名事件从1严格连续；只允许紧邻上条且seq/event/规范化data完全相同的重复NOOP，保留上一帧指纹即可。更旧seq、同seq不同data、跳号、未知事件/字段或错身份均停止并核对，不缓冲重排，不重POST。旧session/request/响应namespace回调直接隔离；当前流身份异常不能当旧回调忽略。终态后关闭流，迟到非终态不覆盖权威结果。

**splice与版本**：revision属于整个stream，切稿/retained不重置。当前draft_id/provider只准尾插且V不变；新provider ID必须未使用过，V不下降，允许首稿/固定编辑或重写首片的一次前缀删替、同V续写；同V不同ID合法。新ID恰好等于现正文的无变化切换可NOOP更新身份，但不制造文字进度；同旧ID无意义空edit拒绝。retained必须新ID，允许V下降，只有服务器提供的恢复文字可用，客户端不能自造lastValid或由恢复帧推断保存资格。

N0合法V=1，增强合法1..N+2（最大101），preview增强1..3。V不是k/N或调用数；首个公开正文未必证明所有前序任务均公开过文字，不要求每个V都已观察。合法例：N2中V1→固定编辑V2→返修V3→V4半稿→retained V3→validated final3/incomplete；固定编辑V2故障可恢复V1；V4完整后审稿故障可final4。status可直接返回未在当前流观察到的最终包。

每帧先顺序验证并归约，再用Vue批更新/单个animation frame提交最新文本；不能把splice的insert串成delta丢掉删除/seq。尾插使用已维护码点长度，不每token重扫全文；非尾插时作一次码点切分，不每tokendiff。终态清理待渲染任务防止旧草稿覆盖Result。保留单份当前正文、有限身份/计划数据和上条指纹，不存事件历史/每版全文。

**Plan生命周期**：首稿、换稿等待、编辑、条件返修、retained、finalizing、pending及EOF均保留初始Plan。固定编辑可换场景，原Plan始终带 `m003.plan.note`，不反推更新、不宣称最终词典。仅权威valid完整Result（含Q02）清Plan并原子建学习资源；valid/result=null不满足，保留已有只读临时内容与结果不可用说明、禁保存。已清除Plan不因后续payload失效复现。失败/取消/新请求清临时内容。

## FE3-04 终态核对、取消、保存与忙碌

沿API-302/304：用户status用X-Generation-Token，preview用X-Preview-Token；status不带临时phase/draft或seq、不续流。立即一次、串行间隔至少2秒、总窗口最多10秒（到期中止未完请求）；其后 `m003.recheck` 每次显式操作读一次，active/503仍pending，不重启无限自动窗口。404/410停止并关保存；token默认终态1小时/待保存draft30分钟沿后端。刷新丢token不新增恢复能力，合法既有资源读取可恢复notice。

核对绑定sessionEpoch＋requestEpoch＋namespace＋runId＋reconciliationEpoch。晚active/503/取消ACK不能覆盖valid；相同DB终态幂等，保存/claim已完成不能被旧status重开。实质终态冲突关闭新保存动作并再核对，不按到达顺序换包。取消返回valid只是种类确认，继续status取得最终Result/notice；不能拿本地草稿当final。

取消前started未到先记意图，拿token后发cancel；不把abort当已取消。重复点击合并一个取消动作；未知503保留pending，完成先赢显示真实完整包，取消先赢清稿且不退款。离开、popstate/pagehide、卸载沿现有离开确认/被动abort，所有controller、绘制/核对任务失效；被动断线不是主动cancel成功或Q02。服务端CAS与费用是权威，取消不表示提供方免费停机。

保存/访客claim只接受当前run的权威完整Result与资格；validated依API授予有效草稿资格，status时尊重can_save，已保存/丢弃/TTL/归属变化后不恢复。原API-006保存/放弃/claim的幂等、归属与删除规则保持。Q02通过SSE、status、当前保存结果、管理preview/published读取持续显示notice；普通完成四outcome统一完成表达，不暴露审稿轮次或宣称独立质量达标。无lastValid失败与取消由服务端处理，前端不由超时/EOF自行推断退款或incomplete。

### 受理前 busy 与受理未知分开

三个POST统一按API-302识别 **HTTP503 + code=generation_busy + context.accepted=false**，严格context仅accepted/retry_after_seconds，秒数1..600且与十进制Retry-After一致。完整验证后映射安全应用失败及retryAt，停止本次等待，保留输入/已保存草稿/既有有效结果或preview ready（仍核原binding）。没有run/token，不query status，不改变本地额度或制造退款，不显示队列位置。

使用既有AppError/再试区域与已批准通用暂不可用文案；本版不自写“未扣次”新文案，也不原样渲染Problem.detail。明确busy才具备未开始/未扣次事实。Retry-After期间禁新提交，结束只解禁；**永不autoPOST**，不会排队。普通泛503/502、解析失败、网络EOF、temporarily_unavailable的COMMIT未知不套busy。若未收到started/token，无法调能力status；保留受理未知说明并重读options可用性，options不是结算证明，新意图仍受服务器同主体active限制。

BE06-R1的20及10/20/50/100均未测，不出现在用户容量承诺或新配置页。浏览器只可记录点击到首Plan/正文/换稿/完整渲染时间，和Go T0/flush指标分开；50ms服务端合并、180s/600s保护截止不是首内容体验目标。

## FE3-05 PAGE-208 配置表单与冲突

保留原四计划、页头全档位优先级入口、模型/长度/词数/滚动24h额度/不限字段、单panel双栏与M002自定义控件。服务区按UI09-R3接入真实NativePolicy只读2、派生开关与N，不硬编码fixture值。visitor/basic始终false/0且控件禁用；Pro/Plus各自0–99，关闭置0、开启恢复最近合法正N（无历史1）；N0徽标基础，合法1–99增强，非法值不作为已保存服务事实。

raw string与合法数值分开；空、负数、小数、100、非整数不截断/四舍五入、不将空转0。非法保留输入/错误/aria-invalid，禁impact/PUT。类型属性只提示，API独立拒绝非法配对/权限。完整body包括原字段和content_review_enabled/content_repair_limit，绝不传native策略字段；quota null不限与0禁止严格区分。

local/baseline/remote分开；保存前impact snapshot包含规范化完整body和revision。任何字段编辑（含原字段、N、开关、切tab）使旧预览与确认失效；迟到impact检查editRevision/plan，不重新解锁。PUT必须等于被确认body。impact按响应显示before/after、warnings、生效边界与真实基础/体验人数；UI09-R3 `m003.impact` 的basic/trial分别映射，可能重叠不求和，不称净失去增强人数。

409 revision_conflict保留local→GET四计划remote→并排比较→用户保留本地编辑后以最新revision重新impact→再次确认。不能把current_revision自动塞进旧PUT；duplicate_priority保留专用含义。PUT丢响应先GET，当前值相同只说明当前配置已保存，不冒充原回执/重复推进revision。取消不PUT，失败不抹输入。

批量priority沿原四行body，无内容字段；显示响应content_service_by_plan/may_change_content_service及新请求/在途/不重置用量/不改试用时间。false不等于有效计划没变。保存后刷新后续options/公开预设与权益摘要，已受理snapshot保持。PAGE-215/217任何权益摘要均从真实ContentService投影，不按计划名推断。

## FE3-06 PAGE-212 预设模式、预览与发布

保留master-detail、title、无限制管理选词（不套用户max_entries）、四配置及保存草稿/预览/取消/发布/下架。options提供preview modes/basic默认/enhanced固定N1；无计划模拟或N选择器。用户 `/trial/:presetId`继续共用GenerationWorkspace，实际增强来自本人权益，公开样文不是权益授予。

1. 本地编辑title/词/配置/mode立即失效ready及Q02确认，递增编辑/请求代次；先保存草稿再按响应draft_version/mode预览。只改title在服务端允许继承preview时，保存后重读绑定可重新判定，不直接沿用本地旧ready。切回旧mode不自动复用历史preview。
2. preview独立namespace/token/epoch，事件用preview.*，Result归约共用FE3-03；无用户refund/charge。valid完整包后清Plan，进入qualifying；GET当前AdminPreset核对当前draft_version＋mode＋preview_run_id及完整payload且valid才ready。valid但未关联/旧run、payload TTL失效、dirty local、切preset均不可发布。
3. 晚mode/旧草稿/旧GET不会覆盖dirty表单或解锁新稿。busy受理前拒绝保留原ready且只在原binding仍匹配时可用；新preview开始与旧正式预览资格分开，不能将旧正文当新run成功。
4. service_incomplete完整有效预览可手动发布，notice在stream/status/GET/ready/确认/发布响应与管理published读取保持。按 `m003.q02.confirm` 明确勾选；变更资格后清确认，绝不自动发布。
5. publish body只含expected_revision/draft_version；UI确认不新增confirmed wire字段。冲突/preview_required/403按实际响应，旧published保持至成功；丢响应先GET，不盲重试。basic final1、enhanced最大3不是质量结论。

## FE3-07 设计转译、组件与页面定位

唯一来源：[规格](../design/design-spec.md)、[copy](../design/copy.json)、[theme](../design/theme.css)、[原型源](../design/prototype/app.js)、[交互](../design/interactions.md)、[响应式](../design/responsive-accessibility.md)。UI09-R2/M002是视觉基线，UI09-R3只纠偏计划页，UI07/08视觉不再有效。浏览原型 formal入口/复现query见规格；这些query、fixtures、after_ms/timer不进入生产。

| PAGE / UIA | 路由、已有组件与拟接入区域 | 应用数据/API |
|---|---|---|
| 204、216 / 401.a、402.a | `/create`、`/trial/:presetId`；保留AppHeader/BrandMark/GenerationSettings/WordPicker/AppSelect，改GenerationWorkspace右侧 `.m003-creation-main`；settings→选词/操作→阅读纸顺序 | options/预设配置、accepted快照，API-301/302/304 |
| 204、216、212 / 402.a–406.a、410.a | 拟增 `presentation/components/GenerationResultPaper.vue`，内含 `PlanningPreview.vue`、`LiveDraft.vue` 与完整结果分区；稳定 `#planning-preview/#live-draft/#final-result`，外壳普通 `#generation-status`、后台 `#preview-result` | 只接应用read model与动作事件，不自行fetch；FE3-03/04 |
| 208 / 407.a | `pages/admin/plans.vue`、admin-plan-presenter；保留M002 tabs/单panel原字段/priority dialog；`#service-settings/#change-preview/#version-conflict/#plan-actions` | local/remote/impact/NativePolicy，API-303，CR303修正 |
| 212 / 408.a、409.a | `pages/admin/presets.vue`，现有PresetWordMeanings/WordPicker/AppSelect/AppDialog；`#preview-mode/#preset-actions`＋共享阅读纸 | PresetInput/previewBinding/qualification/usage，API-304 |
| 215、217 / 继承权益展示 | `/account/items`、`/account/exchange` 的 ItemsWorkspace/ItemEffect 仅在既有目标计划摘要处接真实配置；`/explore` 保留公开预设展示与presets mapper，不重做页面，目录浏览无生成 | 已批准权益投影与原公开结构，API-301/304；不为摘要自造DTO或泄露后台mode |

拆分只隔离临时与完整结果和三处共享阅读区，不重建全站组件库。Plan用planId/entry稳定key，草稿节点不以draftId作key；新稿换身份只更新text，保持Plan/设置/焦点/滚动位置。首点击可定位结果一次，后续不强制滚动；正文不逐片aria-live，简短draft-status polite。正文/英文词语lang=en，义项按受理meaningLanguage，locale与释义语言分开。所有动态内容文本转义，不v-html AI内容；现有本地图标模板复用。

### 文案、Token与资源

扩展现有 `scripts/sync-design.mjs`：M003 copy已经采用 **zh./en.前缀**（FE01的语言后缀假设失效），含M002完整键及m003.*。保留现有m002命名空间/`useDesignCopy`的稳定调用；从本次完整copy按语言前缀去除、点→双下划线转换，新增键可继续用 `copy('m003.plan.note')`，不建第二套运行copy框架。保留已有@/|转义与模板变量。manifest记录UI09-R3 copy/theme/prototype、M002资源hash及转换规则，运行产品不读取planning。

先复用M002本地Lucide/许可证、BrandMark和自定义选择/选词控件；生成图标只按实际需要补齐，不从网络加载字体/素材。theme的M002相对@import构建时合并成已有基础CSS＋M003增量，保留现有合法工程selector转换；不将planning路径留进发布产物，不复制demo场景条样式/fixture提示。准确copy键包括m003.plan.note、draft.*、pending.*、eof/protocol/recheck、incomplete、preview.incomplete、q02.confirm、content.*、impact、effect.*；原型演示专用prototype/fixturematch键不进生产流程。

### 布局、可访问性与性能

桌面设置310px、admin sidebar192px、preset列表240px沿M002；Plan/draft/final共用 `.m003-result-body` max-width760px/margin-inline:auto，无单边预留；窄屏铺满，Plan两列到≤760单列，正文行高桌面1.85/移动1.78，padding/间距逐值消费theme。不固定长正文高度，长文本wrap，不嵌套额外内缩。

≥1100、761–1099、≤760断点、44px目标、skip link、select/combobox/listbox/tabs键盘语义、可见焦点、alert与200%缩放按设计。reduced-motion停书写点，不给终稿打字动画。源码内不额外等待32字/句段或启动文字计时器，收到安全片段即归约；旧1MiB parser与逐帧全文扫描风险在FE3-T01/02解决。仅做本需求必要性能检查，无新缓存/回放平台。

## FE3-08 Mock、验证与验收追踪

本节是**实施/QA计划，未执行**。复用 `tests/unit/generation-stream.test.ts`、`generation-reducer.test.ts`、`generation-lifecycle.test.ts`、`span-mapper.test.ts`、`admin-plan-policy.test.ts`、`token-vault.test.ts`，现有e2e mock-backend/generation-stream-backend/m002-admin-presets fixture。契约Mock从 [v5 fixtures](fixtures/stream-v5/index.json) 的wire/request/status取数据；不把expected/internal_evidence当应用输入，不重跑冻结旧checker证明新显示。`plan_hidden_on_first_edit`是旧历史断言，新的实施测试明确改为保留到权威完整Result。只补busy、对应边界和真实UI动作所缺小fixture。

| 稳定ID | 合并场景与预期 | 来源 / 方法与证据 |
|---|---|---|
| FE3-V01 | 普通、N0、用户预设、后台basic均收到Plan→多片正文→完整valid；Plan不是最终词义，无增强内部阶段 | API-301/302/304；AC-301/306/307/315；UIA402.a/405.a；schema/mapper/reducer＋代表页面实点 |
| FE3-V02 | 增强固定编辑换稿、N1条件返修/上限定稿、N2两次；用户不见k/N，最终同包可保存 | AC-302/314/316；UIA403.a–405.a；wire驱动正文缩短/替换采样；实际调用分离由后端替身证明 |
| FE3-V03 | V2失败恢复V1、V4半稿→retained V3→final3，V4后审稿故障final4；同V基础续写换ID、rev不重置 | API-302；AC-303/311/313/316；纯reducer精确文本/版本/notice＋后端完整包证据 |
| FE3-V04 | Unicode emoji/跨UTF-8及多帧、尾插/删尾/替换/无变化新ID；紧邻重复NOOP；跳seq/错rev/range/复用ID/降版provider/错namespace/非法JSON/未知字段停止；合法大终态与越界 | API-302/304；AC-308；UIA403.a/404.a；parser与reducer定向测试，不为每错类截图 |
| FE3-V05 | EOF/pending保留Plan+稿；status完整valid原子恢复、result=null不清已有Plan且禁保存；10秒停止、手动一次、404/410、无token不自动POST；晚active/503与旧账号回调隔离 | AC-308/311/313；UIA406.a；可控时钟与请求计数/store集成；真实网络定向一条 |
| FE3-V06 | 七类增强故障的权威Q02保持notice；失败退款/取消不退款/结算未知三分；取消早于started、valid先赢、保存/claim之后晚status不重开 | AC-303/311/313；API-302/304；UIA405.a/406.a；契约替身+隔离后端CAS/保存证据，前端不复刻AI故障分类 |
| FE3-V07 | Pro0/Plus99独立往返；初始1来源后端；非法-1/100/小数/空/null/配对拒绝；NativePolicy只读；N0基础badge/N1增强；非管理员拒绝 | AC-304/314；API-303；UIA407.a；raw输入单测、实际表单＋保存后GET；99不跑流程 |
| FE3-V08 | impact两类人数分别显示（可重叠），真实前后N/生效边界；所有字段编辑和晚impact失效；local99/remote2冲突重读重预览；priority与丢响应先GET | AC-305/306；API-303；UIA407.a、CR303-01/02；表单/store/HTTP与DOM检查 |
| FE3-V09 | 后台basic0/enhanced1、先保存、旧mode晚完/旧run关联/切回/dirty/TTL不可ready；Q02确认后手动发布、GET及管理published保留notice；publish无confirmed | AC-309/313/314；API-304；UIA408.a/409.a；两个真实namespace fixture与GET关联/发布后重读 |
| FE3-V10 | usage null费用/发送未知分别呈现；后台无用户扣额、浏览无调用；同用户active冲突不替换已有有效终态 | AC-310/311/314；API-301/304；mapper/请求断言，统计与charge由后端/DB验证 |
| FE3-V11 | create/plans/presets完整页面与trial共享区准确copy/顺序/控件/图标；760px居中、1440/390与768/320无横溢；Plan和草稿共存、终态清理；节点/focus稳定、scroll差≤2px、44px/键盘/200%/reduced-motion | UIA401.a–411.a；规格＋运行DOM/几何/代表截图对照，不只比JSON；CR303生产态复核 |
| FE3-V12 | 记录合成首Plan/正文、换稿等待、无正文间隔与总时长并标合成；独立真实质量/时延/费用/容量保持未知 | AC-312；BE6-C04/C07；有限时间记录不等于线上目标达标，真实模型另需原授权 |
| FE3-V13 | 三POST明确busy保输入/既有结果/preview ready，Retry-After只解禁无autoPOST/status/本地扣退；generic503/坏body/未started EOF不声称未扣次 | API-302 busy/304；BE6-C03；仓储严格HTTP＋store/代表UI操作；不开展容量压测 |

N99只测配置/静态V上界101、102拒绝及preview3/4边界，N2才是最多流程执行；不生成99次事件来宣称链路覆盖。前端无法证明writer真的消费完整Plan或服务器一run一charge，AC-315/316与预算/原因统计须接后端AI3/BE3及DB3验证，不能用UI回放替代。

实施自检写既有 `implementation/frontend-validation.md`：Node24环境中typecheck/lint:boundaries、相关Vitest、定向Playwright、受影响格式/lint与build；依赖边界测试包括SSR请求隔离/mapper输出和视图不得接DTO。先相关失败修复后再跑必要整合，不无故重复全套。QA沿既有coverage/report/ai-evaluation独立验收权限/持久化/结算与质量，不新增测试管理文件。

有限浏览器证据：约13组合并上述业务边界；主要操作用结构化断言，初始截图软上限8、送模4，覆盖三页桌面/窄屏和生成Plan+draft/final代表态；768/320/英文/200%与trial用几何、文本和动作补齐，发现视觉异常再按ID补图。比较同浏览器/视口/DPR/字体/语言/数据/状态，不能遮notice或停止全部动效后声称动效通过。已接收 [UI09-R3报告](../design/evidence/ui09-r3/cr303-report.json)及[UI09-R2源包](../design/evidence/ui09-r2/source.tar.gz)仅证明原型对应状态，不能替代生产Vue/网络/存储检查；无须重做已确认设计。

## FE3-09 实施任务、依赖与后端接点

| 任务 | 修改与完成条件 | 依赖 |
|---|---|---|
| FE3-T01 契约与传输 | FE3-02 schema/model/port/mapper/repository、busy/status/token能力；请求白名单、UTF-8/严格JSON、完整Result与帧上限、移除旧delta；契约Mock可用 | 技术总门禁/实施授权；API-BE06/DB03配套或明确契约Mock |
| FE3-T02 流与终态 | reducer及generation/admin-presets stores：seq/draft/rev/Plan保留、Unicode splice、有限核对/取消/旧epoch隔离、busy不丢有效资源；V01–06/13 | T01；保留现有私有state与vault隔离 |
| FE3-T03 计划管理 | admin configuration/plan-policy/store/presenter/plans.vue：完整表单、两预算、raw N、真实badge/双类人数、impact失效与冲突；V07/08 | T01，UI09-R3/CR303已接收 |
| FE3-T04 预设闭环 | presets models/store/schema/repository/page：mode先保存、namespace与关联ready、Q02人工确认、精确publish、当前notice；V09/10 | T01/02，API-304完整GET/发布合同 |
| FE3-T05 页面与资源 | sync-design/use-design-copy/locales/manifest/theme、共享阅读纸与Plan/草稿组件、GenerationWorkspace、两管理页；先代表生成区准确核对再共享；V11 | T02–04，UI09-R3来源及现M002组件 |
| FE3-T06 联调与交接 | 更新受影响旧fixture，边界/构建、隔离后端联调、有限浏览器与保存/发布重读证据，填写前端验证/交接给QA；未验证项不标通过 | T01–05，配套backend-ethan实现可用 |

后端必备：真实Plan→writer与fixed_edit、v5安全流/统一终态、DB03六stage/七reason/版本CHECK、status保存及preview关联、API-303完整配置、BE06受理前Gate/busy。当前源码仍M002前端delta及待审BE02后端，不能只改前端schema即联调；DB0017是否已应用由实施owner核实后决定修候选/增迁移，本角色不猜测。Go全请求2次、模型180s/整体600s、内容N和唯一charge由后端强制。

部署沿Nuxt node-server＋Go同源代理/会话，配套切换无旧流兼容；普通/用户预设/后台preview三条SSE均须禁buffer/cache/gzip并按BE6排空，最终代理/网络证据待后端实施。保持单副本恢复边界，不提replicas=2、MQ或云资源购买。C_prod尚未测定、20只是目标，FE不验证服务器容量也不写服务承诺。

## FE3-10 当前自检、维护与未决

FE02就地替换FE01旧规则，FE3-01–10/T01–06/V01–12稳定ID保留并增加V13；源到路由/数据/组件/验收接点在本文单处维护。[当前交接](../handoffs/frontend-architecture.md)是恢复入口；[静态核对](evidence/fe02/check.json)、[源清单](evidence/fe02/source-manifest.json)、[恢复包](evidence/fe02/source.tar.gz)定位同一版。旧FE01/UI/v5失败与历史证据不覆盖。新会话接续测试未执行。

本轮仅文档/链接/精确契约/代码差距静态检查，未跑应用、模型、数据库迁移、浏览器或压测。CR303设计冲突已闭环并接收，生产落实仍归T03/T05/V07/08/11；CR302仍下游pending，不能因FE方案完成关闭整个变更。无新增业务待决或设计阻塞；技术总验收与实施启动由控制角色按既有权限办理。

保留CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX及[M002报告](../../M002/verification/report.md#保留事项)原状态。真实质量/误漏报/90%目标、费用、规划语言效果、实际首内容/换稿/总延迟、CPU/RSS/GC、容量/外部额度/备份恢复均未知；不把静态PASS或原型31/31变成产品通过。planning读取超过8k软目标是精确v5/多页面/故障边界与CR303接收所需，未全读历史；运行token/usage unknown，静态文件字符数不冒充实际输入。
