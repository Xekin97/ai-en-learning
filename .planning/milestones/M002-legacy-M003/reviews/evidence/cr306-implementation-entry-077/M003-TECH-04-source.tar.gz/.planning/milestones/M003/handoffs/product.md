---
milestone: M003
stage: product-planning
role: product/to-c
agent_name: product-maya
status: awaiting_user_review
version: M003-PRODUCT-09
date: 2026-10-12
---

# CR-306 产品交接：模型自定义请求参数与真实规划超时

product-maya 已完成本轮最小产品修订；**无当前业务阻塞，可按既有授权交独立门禁接续 backend-alex 的 CR306-BE**。CR-306仍open，真实修复/新视觉/实现尚未验证；不要求用户重新确认已要求的修复方向。建议awaiting_user_review仅是本角色交付状态，本文件不修改workflow、不自行调用守门器或切阶段。

## 输入与需求确认闭环

- [USER-M003-CR306-REPAIR](../reviews/requirements-feedback.md#cr-306-修复编排user-m003-cr306-repair)：用户已看到每模型推理研究后要求“编排一下修复吧”；[门禁068](../reviews/cr306-custom-parameters-gate-068.md)已独立检查回溯授权。CONFIRMED范围为模型推理配置与实际规划超时定向修复，含必要有界真实排障/复验；本产品角色未作真实调用。
- [USER-M003-CUSTOM-PARAMETERS](../reviews/requirements-feedback.md#cr-306-自定义请求参数简化user-m003-custom-parameters)确认每模型高级自定义JSON，管理员按平台文档填写，空对象不追加；取代PRODUCT08的模式/强度控件及能力目录候选。[CAP-306](../product/abilities.md#cap-306)明确禁止覆盖凭据/model/messages/stream/业务schema及URL/headers，既有token/结构化字段保持单一权威、冲突明确反馈。字段名单、合并、体积/深度、存储及错误映射由后端收敛，无须例行逐项审批；新增业务/费用上限/供应商策略再回产品。
- 保留共同规划、增强固定编辑/审稿及两类返修预算、Q02/配额、后台basic0/enhanced1及旧保存/发布边界；[CR-302](../changes/CR-302.md)保留product_resolved_downstream_pending，不在本轮关闭。完整页面→M002正式设计→新视觉用户评审仍必需，修复委派不等于视觉已批准。
- 已接收技术基线仍是TECH03 / BE06-R1、API-AI BE06、DB03、FE02、UI09-R3；依据[TECH03冻结清单](../reviews/evidence/control-054/M003-TECH-03-source-manifest.json)及[验证交接](verification.md)。当前后端六份BE07旧方向草稿尚未提交，由backend-alex接续替换；其文件版本或本次定向回溯不构成接收批准。
- 已完整读取agt-product-planning及共同/工作流/产品ToC、路由和维护契约；采用锁定[Profile1.0.0](../reviews/evidence/start/locked-profile.yaml)和v1路由，requested gpt-6-astra/high，actual_model、usage均unknown。未升级Profile或改变Codex配置。

## 原始产物

1. [overview.md / D3-10](../product/overview.md#d3-10)：本轮范围、确认分类、非目标与真实证据限制。
2. [data-assets.md / DATA-306](../product/data-assets.md#data-306)：每模型JSON对象、受控边界与本次快照，最小诊断/隐私边界。
3. [abilities.md / CAP-306与AC-317–322](../product/abilities.md#cr306-acceptance)：保存/字段安全与冲突/快照/失败/完整链路/完整页面可验证结果。
4. [ai-behavior.md](../product/ai-behavior.md#cr306-reasoning)：推理与业务plan分离、结构化输出和故障结算。
5. [pages/index.md](../product/pages/index.md#cr306-pages)：现有模型管理、普通/预设生成及管理员预览的页面责任。
6. [CR-306产品处理与责任表](../changes/CR-306.md#cr306-product-repair)：CR306-BE/DB/UI/FE/IMPL/QA/UAT的输入、产物及完成条件；本交接不另抄任务表。

## 下一步与完成条件

独立门禁接交后由backend-alex先提交CR306-BE：JSON对象/空对象语义、受保护名单/体积深度、合并与既有字段冲突、存储/既有协议参数位置、同请求快照、保存0调用/上游错误/失败结算及管理/流式fixture。输入是PRODUCT09、原故障/研究和现行技术/实现，不重建旧模式/强度或自动能力目录，不扩全平台参数适配，不把关闭推理当作关闭业务plan。输出应让DB、设计、前端和QA能直接接续AC-317–321；具体接续顺序与责任仅维护在CR-306表中。

目前无需新业务选择；有界专业建议交下一责任角色定稿。新视觉待用户评审是当前明确保留的后续门槛，并非再次请求同一修复授权。原型与正式设计未交付前不能批准尚不存在的视觉；新视觉评审与代码实现、完整真实验证分别记录。

## 维护、自检与未验证项

PRODUCT08七份原件与[068清单](../reviews/evidence/cr306-control-068/product08-before-manifest.json)逐字核对，[冻结包](../reviews/evidence/cr306-control-068/product08-before-custom-parameters.tar.gz)hash一致；PRODUCT07及原故障证据继续保留。PRODUCT09只同步用户新方向及DATA-306/CAP-306/受影响AC/页面/责任表，原业务AC-301–316保留。旧产品交接在冻结包恢复，不维护第二入口。

有限静态检查见[custom-parameters-check.json](../product/evidence/cr306/custom-parameters-check.json)：七份版本/hash、引用/锚点、原业务验收、冻结包、同口径字符数。旧PRODUCT08静态检查不覆盖新版本。运行token/实际总输入unknown；新会话交接测试未执行，静态检查不是独立接收。没有运行模型/业务/浏览器/数据库测试，未改控制面、技术/设计/源码，未停止UAT、重置数据、提交或部署。

未验证：AC-317–322全项；真实首规划/首正文、总时长、格式/业务质量和费用；GLM低档位完整链路；当前未捕获费用仍unknown。三次限时规划诊断不是完整成功。原件见[调研](../verification/model-reasoning-research.md)及[CR-306](../changes/CR-306.md)。CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX及用户UAT权限继续保留，不因产品交付关闭。
