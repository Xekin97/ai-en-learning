---
id: API-301-302
version: M003-BE-07
status: awaiting_user_review
milestone: M003
---

# 权益、动态生成流与唯一终态

CAP-301/302/305，DATA-301–303，PAGE-204/215/216，AC-301–303/306–308/310–314、AC-315/316及UIA-M003-301–303/308。V=访客、L=本人学习者；管理员走独立预览。以下路径省略 `/api/v1`；公共封套/错误继承[index](index.md)。新增字段均必填；只有显式null可空，整数必须JSON整数，拒绝未知/重复字段及尾随JSON。

## API-301 选项和系统基础策略

```text
ContentService = {native_validation:true,content_review_enabled:false,content_repair_limit:0}
               | {native_validation:true,content_review_enabled:true,content_repair_limit:int[1,99]}
NativePolicy = {version:"m003-native-policy-v1",scope:"logical_request",max_calls:2,editable:false}
Plan = visitor|basic|pro|plus
ValidContentOutcome = basic|review_passed|repaired_passed|limit_finalized|service_incomplete
CompletionNotice = "content_review_incomplete"|null
```

ContentService严格关联配对；所有模式都独立规划后writer，content_review_enabled=true还包含一次必经固定编辑及审稿/限次返修，false仅关闭这整个增强段，不关闭规划；visitor/basic固定关闭0。NativePolicy由后端系统常量映射，pipeline版本定位，不来自计划表可编辑值；基础预算覆盖普通初稿或增强固定编辑后及所有后续稿，不能重置；增强编辑前只原生校验取证不花基础预算。用户/管理写接口不得接受native_policy/max_calls等系统字段。

`GET /generation-options` V/L：保留M002完整data，新增 `configuration_revision:string,content_service:ContentService,native_correction_policy:NativePolicy`。原effective_plan仍 `{code:Plan,origin:visitor|base|trial,trial_ends_at:Time|null}`。revision及内容权益同配置共享锁读取；可用性仍检查模型/长度/次数，增强不免预检。页面依实际开关/N，不凭计划名、模型/次数卡推断；试用只取唯一胜出计划。

`POST /generations/stream` 请求仍严格 `{model_id:string,meaning_language:zh|en|ja,scenario:story|discussion|business|news,length:short|medium|long|xlong,entries:string[]}`，64KiB及原词表/配置授权限制不变；不接受content_service/mode/prompt/provider/技术预算。受理事务重新解析当前权益：旧options下输入仍合法则接受，以started覆盖预估并刷新options供下次使用；本次快照之后不变。输入失效422，权限403，active冲突409 generation_in_progress，次数不足429 quota_exhausted，配置/凭据不可用503 generation_unavailable；预检拒绝不调用。

受理事务配置共享锁→主体锁→锁后业务时间→完整快照/模型连接/run/entries/原charge/开始事实同事务。COMMIT确定未成功返回Problem；ACK不明用已分配run ID限时读回，完整run/charge确认才继续，否则503 temporarily_unavailable并交原恢复，不宣称未扣次。POST不自动幂等重放；新生成必须用户新意图，普通/用户预设共享每主体一个active槽。

## API-302 受理前忙碌拒绝（BE06）

以下三个POST在任何run/charge/provider调用之前共用进程准入：[BE6-C02](../capacity-and-deployment.md#be6-c02-并发口径配置与原子准入)。本文是错误结构唯一真源，后台API-304复用。

- `/generations/stream`
- `/presets/{id}/generations/stream`
- `/admin/presets/{id}/previews/stream`

鉴权/CSRF/严格body之后，预检护栏、global/preview/connection容量、维护排空或已知上游冷却不允许受理时返回 **HTTP503 `generation_busy`**，`Content-Type:application/problem+json`、`Cache-Control:no-store`，尚未启动SSE。准入检查与原受理事务顺序由BE6-C02定义：组合容量原子TryAcquire、零等待；不先写run再退款冒充拒绝。

完整例（所有列出字段必填；无其他context字段）：

```http
HTTP/1.1 503 Service Unavailable
Content-Type: application/problem+json; charset=utf-8
Cache-Control: no-store
Retry-After: 5

{"type":"https://wordweave.example/problems/generation-busy","title":"Generation temporarily busy","status":503,"code":"generation_busy","detail":"Generation is temporarily unavailable. Try again later.","request_id":"request-example","field_errors":[],"context":{"accepted":false,"retry_after_seconds":5}}
```

`context={accepted:false,retry_after_seconds:int[1,600]}`。Retry-After使用十进制整数秒并与body完全一致：普通容量满默认5秒；排空/结算健康栅栏默认30秒；已知连接冷却用剩余秒向上取整并限制1..600。它只是建议最早再尝试间隔，不是排队、完成预测或预约承诺。HTTP允许503携Retry-After提示服务暂不可用的重试等待。[RFC9110 Retry-After](https://www.rfc-editor.org/rfc/rfc9110.html#name-retry-after)

FE保留用户输入、停止本次等待，映射安全code到已批准页面的错误/再试区域；可以在该间隔内禁再次提交或显示稍后可试，倒计时结束也**不自动重POST**。没有run_id/token，不查询虚构status，不减少/补退次数，不显示排队位置。已收到明确generation_busy可以说明“本次未开始，未使用生成次数”；只收到网络失败、代理502/503或无法解析body时不能套用此结论，按原受理结果未知边界处理。

登录/读取/保存/取消/status不经过生成槽；仍受各自身份、幂等与正常故障规则。409 generation_in_progress、429 quota_exhausted/既有限流、503 generation_unavailable或temporarily_unavailable与新busy不同：COMMIT/终态未知不得写accepted:false。受理后不发generation_busy SSE事件；容量不会撤回已受理额度或跳过增强阶段。真实上游故障沿原failed/Q02，无有效稿失败退款，有有效稿且满足Q02才带notice完成，不能把本地忙碌变成成功。

## API-302 SSE 精确字段（m003-stream-v5）

[USER-M003-LIVE-TEXT](../../reviews/requirements-feedback.md)取代BE03的词义先行/正文仅最终出现方案。**提供方安全正文片段一到就可只读显示；重写第一片到达才在同一区域切稿并继续增量。**审稿无正文token时保留当前草稿，不公开Review、推理、轮次/上限。v3 learning_ready及旧stage/snapshot/candidate不再发；v5临时plan_item来自真实独立规划，不是最终词义资源，无兼容层。ContentService/N仍用于运行及一致性，不作为用户进度。

受理COMMIT确认后200 SSE并flush started成功才Open；started写失败不调用提供方。headers/no-store、15秒注释心跳、每次write/flush的10秒截止、POST fetch/无Last-Event-ID或续流保持。seq只为实际公开命名事件编号，从1严格连续；心跳无seq。串行writer同流只写一种确认业务终态。

### 身份与完整事件类型

`run_id`是业务生成身份，一次扣次；`stream_id`是该HTTP响应的随机不透明身份，仅保留在本次会话，不新增库字段/恢复功能。客户端以本地request epoch＋namespace＋stream_id绑定回调；started后的帧从其响应流继承身份，不与别的响应混序。`draft_id`是不透明的**可见正文谱系/尝试身份**，只在本流有效；第一次生成、固定编辑、重写、续写调用的首次公开文本，以及恢复稿分别分配新ID。它不是调用次数或内容版号。

`content_version`是业务候选版本V：首稿1、固定编辑2、之后每个内容返修任务依序分配新V（当前链路2+k）；基础恢复不加V，因此同V可有多个draft_id。N0时V=1；增强V在1..N+2（最多101），预览增强最多3，不能作为百分比/当前第几次。终态final_content_version来自lastValid，允许低于先前可见的部分草稿V。

| event | 完整data |
|---|---|
| generation.started | `{seq:int,contract_version:"m003-stream-v5",stream_id:string,run_id:string,generation_token:string,snapshot:RunSnapshot}` |
| generation.progress | `{seq:int,phase:planning|composing|finalizing}` |
| generation.plan_item | `{seq:int,plan_id:string,meaning_language:zh|en|ja,item:PlanPreviewItem}` |
| generation.edit | `{seq:int,draft_id:string,content_version:V,base_rev:int,rev:int,at:int,delete_count:int,insert:string,source:provider|retained}` |
| generation.validated | `{seq:int,run_id:string,final_content_version:V,result:Result,content_outcome:ValidContentOutcome,completion_notice:CompletionNotice}` |
| generation.failed | `{seq:int,code:FailureCode,quota_refunded:true,retryable:bool,request_id:string}` |
| generation.cancelled | `{seq:int,quota_refunded:false}` |
| generation.settlement_pending | `{seq:int,code:"settlement_unconfirmed",request_id:string}` |

`RunSnapshot={configuration_revision:string,effective_plan:{code:Plan,origin:visitor|base|trial},content_service:ContentService,native_correction_policy:NativePolicy}`。`Result={passage:string,tags:string[],targets:Target[]}`；`Target={entry:string,entry_meaning:string,hint_phrase:string,hint_blanks:[{start:int,end:int}],occurrences:[{surface:string,start:int,end:int}]}`。所有必填、数组非null，只有显式null可空；原词全部各一次/输入顺序；offset是Unicode code point半开区间，不是UTF-8字节或JS UTF-16索引。完整资源规则继承 [M002书架](../../../M002/technical/api/identity-library.md)。待完成草稿只展示edit累计的正文，不携带旧版词义、高亮、标签或hint；validated/status valid才一次建立完整Result及资源。

### 实际规划条目的临时预览

`PlanPreviewItem={kind:"scene",text:string}|{kind:"word_use",entry:string,form:string,sense:string,phrase:string}`；两个分支exact keys、非null。scene.text来自完整闭合的Plan.scene；word_use来自一个完整闭合且局部校验成功的Plan.word_uses项：sense=meaning，entry/form/phrase原值，不发role/参与者/facts/beats或推理。长度界同AI3-PLAN。meaning_language为受理语言；scene/sense所选zh/en/ja、form/phrase英文，无额外翻译调用。文本纯文本渲染，禁止当HTML。

每run一个不透明plan_id，所有plan_item同ID/语言；scene最多1条、每selected entry最多1条，在模型真实完成项的顺序中发。局部成功只是暂定内容，后续完整plan失败仍撤去；完整校验前不调用writer。seq与全部正文/状态同一递增序列，plan_item不改变正文rev/V；只能在planning期间消费；writer发送前须排空计划项，composing之后不得再有计划项。预览不能保存/学习/高亮，不把sense放入最终entry_meaning。没有完成项时只保留真实受理/规划状态，不造占位义项。

BE05-R1依据USER-M003-PLAN-RETAIN：第一条及后续正文edit都保留已有规划卡片，场景/本篇义项/搭配与正文同时显示，贯穿初稿、固定编辑、条件返修和retained恢复。固定标明“初始构思，文章和实际用法可能调整”；编辑换场景也不把初始计划伪称实时更新，不从正文反推或额外调用模型刷新计划。

只有权威`validated.result`或`status=valid`携带完整`Result`时，才原子移除全部临时规划并建立最终正文/正式学习字段，包含Q02的service_incomplete及持续notice。retained、finalizing、EOF、pending或仅有valid状态但result=null均不满足此清理条件；未决继续保留已收到规划与草稿、禁保存，结果不可用时按既有状态说明，不拼partial重建。已经完成并清除的规划不因后来查询结果不可用而复现。failed/cancelled清全部临时内容；启动新请求先清旧plan/正文并隔离旧request epoch。不能把计划预览当编辑者必须遵守的承诺。本次仅改变客户端显示生命周期，无新事件、字段、plan_ready、服务端缓冲/存储或保存API。

### edit操作：一个版本化splice表达前进、回退与替换

本节是对USER-M003-EDIT-OPS问题的最小技术建议（PROPOSED，待整版评审），不是完整CRDT，也不冒充RFC6902 JSON Patch。服务器是唯一作者；每条edit在当前正文执行 `text[0:at] + insert + text[at+delete_count:]`，下标均为Unicode code point。`at/delete_count`非负整数且区间不得越界，insert可以为空（真实删尾）；草稿内存的显示revision初始0，每次edit必须 `base_rev=current_rev, rev=base_rev+1`。seq还包含started/progress/终态，rev只计正文编辑，因此两者不能互相倒算。

| 意图 | splice参数 / 真实来源 | 页面结果 |
|---|---|---|
| 首稿首片 | draft_id首次出现；at=0/delete_count=0，insert=首个安全片段，source=provider | 建立临时稿，不等完整包 |
| 同尝试继续写 | 相同draft_id/V；at=当前码点长度，delete_count=0，insert=新的安全片段 | 只追加新增文字 |
| 新固定编辑/重写首片 | 新draft_id，V不下降；新safe prefix与当前正文做一次LCP得到p；at=p，delete_count=旧长度−p，insert=新prefix[p:] | 保留相同前缀，撤回旧后缀并接入新片段；若新prefix完全等于旧前缀可产生纯删除帧；首片未到之前不清稿 |
| 基础续写首片 | 新draft_id，同V；at=旧长度/delete_count=0，insert=双换行＋真实新段首片 | 原子继承明确前缀后追加，其后用新ID继续写 |
| Q02恢复lastValid | 新draft_id，V=lastValid.Version，可下降；source=retained；与完整lastValid正文做一次LCP，再删旧后缀/插入剩余全文 | 真实撤回失败半稿并恢复旧有效正文；仍不可保存，待DB终态确认 |

通用splice数据结构能够修改任意范围，但本版提供方仍输出全文/续写文本，不是模型直接返回edit计划。正常token只做尾插；只有换稿首片和已知lastValid恢复做一次前缀比较，**不每token全文diff、不逐词对齐旧稿、不给模型增加编辑调用**。字段/标注基础纠错本来禁止改变干净正文，继续静默验证，不能为演示区间替换而播出其重复全文或非法改写。未来真实提供方支持编辑片段时可另审来源，不在本次新增能力。

`draft_id`与rev不同：rev在同stream全局递增，切稿/恢复也不重置；draft_id确定文字来源谱系，同V续写仍换ID。新ID不得复用曾离开的旧ID；同当前ID/provider只允许尾插，不能偷偷改前缀；新ID/provider用于首稿/重写/续写；retained必须新ID且当前已有内部lastValid，不得伪称新的token。无内容变化的身份切换只允许新draft_id且一次safe prefix恰好与现稿完全相同，不能用无意义空edit制造进度。

部分草稿每次edit原子执行后清/禁任何学习资源；v4不发learning_ready。学习字段只在validated/status valid同完整Result建立，高亮offset不引用临时文本。无论一个splice删掉多少字符，用户看到的仍是“临时稿”，不是成功后撤销已保存内容。

### 首次输出与合并节奏

公开正文来源链为 `protocolDecoder(text only) → passageExtractor(JSON passage) → annotationParser → bounded public coalescer`。首个已确认词边界（空格/标点分隔）且非空的干净片段立即可发，不再等32字、完整句/段、全部targets或基础校验。正常合并窗口最多50ms（目标最多20次flush/s），达到128码点优先准备flush；单个provider edit.insert最多2048码点，持有待发安全片段不超过16KiB。大上游帧按已收到的片段拆成有界编辑，不人为按字符延迟。结束/切稿前必须立即冲刷安全尾部，可有有限突发；50ms不是严格网络每秒帧数承诺，也不凭时钟新增字/状态。

底层没有新安全文本就不发edit。尾部flush不能受“首次32字”阈值而丢短稿。队列/背压与量级见BE3-09；单稿上限沿原16MiB候选/200万干净码点，不另扩长度。source=retained的单次恢复insert允许完整有效稿剩余正文，沿原上限；复用不可变lastValid对象，不让每个队列元素复制全文。

UTF-8必须完整；外层SSE合法JSON先解码，再仅选正文text类型，不投影reasoning/tool等非文本通道（忽略或拒绝沿adapter原规则）；Review任务不接正文callback。内层JSON转义、跨帧反斜杠、UTF-16高低surrogate配对未完成时缓冲，不发U+FFFD替代。`grapes(grape)`只出grapes，未闭合标签不泄露；自然括号短语等平衡后才能释放。不以正则删半个JSON或XML包裹猜正文。位于JSON之前的XML/围栏不被extractor识别，按原完整输出校验失败；正文内疑似XML标签从`<`开始保留，识别为标签开头（字母、`/`、`!`或`?`）即停止该候选并报协议污染，不能先泄露再擦除；普通比较符不作HTML解释。这个有限前缀门需补到公共extractor安全边界，现代码尚未有XML门。所有已发安全字符必须等于该尝试解析后的干净前缀；闭合后校验不一致就失败，禁止修改已发前缀伪装append。

最长等待受真实提供方、结构化位置和安全缓冲影响；只承诺上述消费规则，不承诺线上首字秒数。原型的 `playback[].after_ms` 仅调度对应wire帧，模拟真实增量节奏，不能用于声称性能；正式客户端不再给完整终稿加打字动画。

### 可见状态与终态状态机

1. started已受理→progress(planning)在规划发送确认事实落库后发一次，完成项到达发plan_item；完整plan校验后才能发writer，progress(composing)在writer发送确认事实落库后发一次；后续内部阶段不逐次发progress。正文edit到达就可读，尚未基础有效也只是草稿。审稿没有新正文时继续保留当前内容和克制的“正在生成/整理中”状态，不输出Review报告或假token。
2. 有效选包完成后冲刷/关闭该稿待发送队列，禁发新模型调用；若当前部分稿不同于lastValid且属于Q02，先edit(source=retained)整体恢复，再progress(finalizing)。只有DB确认valid才validated，随后学习字段与最终正文一起替换并开启保存。finalizing不代表成功，不需要人为停留动画。
3. 增强先V1→固定编辑V2，再两轮条件返修V3→V4，每稿有多条真实edit；公开不显示版本、尝试、k/N。新半稿V4失败可以retained V3→validated final3，固定编辑V2失败可retained V1→validated final1；其余所有业务outcome/notice关联保持：basic仅N0；review_passed增强未返修；repaired_passed末审通过；limit_finalized末审issues且耗尽N；service_incomplete七类内容技术故障有lastValid。前四种notice=null且只说生成完成，第五种持续“内容审校未完成”、可保存且计一次。
4. 非幂等重复/倒退/跳号、未知事件或字段、base_rev/rev不符、区间越界、复用旧draft_id、provider降版或非法非尾插、非法V、未开始就edit、finalizing后edit、outcome/notice冲突：停止消费并查询status，不猜缺片、不buffer重排、不重新POST。当前stream的紧邻重复帧仅在seq与上条完全相同且规范化event/data一致时作无操作（保留上条指纹即可），不能重复执行splice；更旧seq或同seq不同内容均协议异常。重复DB终态status/取消确认则幂等，不二次扣退或保存。旧request epoch/旧HTTP流回调直接隔离；同当前流错误identity不能默默拼接。
5. 无lastValid失败清除可见半稿与临时字段、不可保存，退款沿原来源；主动取消同样清除但不退款。取消/浏览器断连/DB事实错误不是Q02。pending/EOF未知可以保留已看到的草稿并明确待核对、禁保存；不得从retained恢复帧推断成功/已扣退。503/active不覆盖已确认终态；终态冲突锁住新保存并核对。
6. status只读持久最终包（终态snapshot），active不返回逐token/draft/phase；本版不新增active snapshot接口或可续接的编辑日志。缺口后停止当前流并核对，active/503继续待核对，不自动恢复增量或调用模型。EOF漏帧后status valid可直接用完整Result恢复，不要求本地草稿匹配；status valid无结果不能拿partial重建。SSE validated如果正常路径与可见稿不同可用权威完整包替换，但仍需记录契约差异；Q02允许显式回退，保存资格只来自DB。

### 原型直接接收

[stream-v5/index.json](../fixtures/stream-v5/index.json)列出限定场景；`wire[]`是完整 `{event,data}`，每条data可直接序列化为SSE，无缺字段/跳seq。`playback[]`与wire一一对应，只有合成等待时间；`status_responses`是完整成功JSON封套。`expected`和`internal_evidence`仅供检查，不能渲染或决定产品状态。原型正常生成按钮自动消费完整wire，状态查询由真实pending/EOF/协议缺口路径触发；手动逐帧只作辅助检查。

原v5 fixture的`expected.plan_hidden_on_first_edit=true`及旧checker相关断言已由USER-M003-PLAN-RETAIN覆盖，仅保留为BE05历史证据；原型从不消费expected/internal_evidence。当前继续复用相同wire，按 [R1显示政策](../evidence/be05-r1-display-policy.json)保留规划；R1静态检查仅证明原规则；规划保留已接入当前用户确认UI09-R2，FE02仍须验证实际Vue与服务API联动。

安全展示为plan_item的暂定场景/本篇义项/英文搭配（显式“初始构思，文章和实际用法可能调整”）、执行edit后的草稿纯文本、phase映射的克制状态、validated.result及completion_notice、失败code和扣退事实。身份、seq、base_rev/rev、at/delete_count、source、V、snapshot内N/系统预算、outcome内部分类仅供reducer/一致性；不展示为步骤或次数，token不进DOM/URL/localStorage。正文更新期间不强制每帧滚到底，不朗读每个token；用户主动读旧位置时保持阅读位置，换稿身份有明确但克制的“草稿已更新”提示，由UI负责人落实。

### 故障、核对与权限

FailureCode仍 `authentication|authorization|rate_limited|provider_unavailable|protocol_error|schema_error|content_validation_failed|generation_timeout|generation_failed`。仅真正失败终态使用generation.failed；七类内容故障且有完整有效包按 [AI3-02](../ai-integration.md#ai3-02-七类内容故障与保留稿) 发validated/service_incomplete，不先failed再成功。retryable仅表示用户可新意图重试，不自动重发本请求。认证/授权错误false，其他尊重真实ProviderError；不泄露上游正文。DB关键事实失败先核对，不能套内容故障成功。

`GET /generations/{run_id}/status` V/L，X-Generation-Token，无query/body，200：

```text
{contract_version:"m003-stream-v5",run_id:string,status:active|valid|failed|cancelled,snapshot:RunSnapshot,
 final_content_version:V|null,result:Result|null,can_save:bool,quota_refunded:bool,
 content_outcome:ValidContentOutcome|failed|cancelled|null,completion_notice:CompletionNotice}
```

同一一致读取run、charge和结果。status只返回持久终态事实，不新增临时phase、draft_id、stream_id或逐token重放；active的outcome/version/result为null，can_save=false，refund=false；failed/cancelled的outcome同status、version/result=null、can_save=false，只有failed refund=true。valid读取run.final_content_version/outcome并导出notice，不按调用次数猜；有效draft仍可用时result完整/can_save=true（V表示可claim）。已保存的本人学习者可沿既有generation_run_id读取其本人batch组装同一结果，can_save=false；已丢弃/过TTL无结果、已删除batch或visitor已经claim给账号时result=null/can_save=false，仍在允许状态窗口内返回outcome/notice；不可用访客token读归属他人账号的batch。result不可用不抹掉故障提示、不重新生成。

使用VerifyRunToken+DB主体/owner检查，待保存draft还需token digest及原expiry/disposition；终态沿1小时能力窗口，草稿默认30分钟。404不匹配/资源已删除，410能力过期，503 DB暂不能确认；前端404/410停止核对并关闭保存，保留安全说明、重新生成是新意图；503/active短核对后仍未知保持pending。立即查一次，最多每2秒、总10秒，未收敛提供显式“重新核对”，不无限轮询。此GET不调模型、不续流，不把token写本机/URL；刷新丢token不新增恢复能力。已有合法恢复途径重读结果时notice必须稳定，不能把UI“刷新仍有提示”解释为新续传平台。

`POST /generations/{run_id}/cancel` 原权限/header/{}→200 `{status:cancelled|valid|failed,quota_refunded:bool}`，仅确认DB终态才200；未知503 settlement_unconfirmed。先CAS确认取消，再cancel context；完成先赢则valid（可能service_incomplete），用status读取最终包/notice；失败先赢failed/true。重复cancel不二次结算，不把已有内部有效稿或可见草稿当拒绝取消理由。取消本身不触发内容故障交付。

客户端断连/write失败沿原技术失败退款；valid先提交后断连仍valid不退款。execution deadline在有lastValid的内容阶段可带提示完成，其独立完成/核对ctx不继承到期；客户端取消/断连另行检测并参与CAS。保存/放弃/claim沿M002 API-006与原TTL/幂等；服务器要求valid+完整最终资源，无论内部几次调用始终一run一charge，service_incomplete不额外扣次或退款。

<a id="api-306-generation"></a>
## CR-306 受理参数与无业务内容失败

CAP-306 / AC-319–321。公开POST不接受custom_parameters/任意provider参数；公开RunSnapshot/SSE仍m003-stream-v5。服务端在原配置共享锁内按[API-306](administration.md#api-306)验证已保存对象与三协议受控字段，绑定私有快照后才写run/charge。库中对象损坏/非法保护字段/合并冲突在**确定未受理**时503 generation_unavailable、标准Problem context={accepted:false}；没有run/token，不扣或退款、不自动POST。公开错误不回参数或provider详情；管理员从模型配置修正。COMMIT不明继续原temporarily_unavailable，不能声称accepted:false。

不查询目录，不根据参数名字判平台支持或改写；上游在受理后拒绝400/422沿protocol_error，安全子类/HTTP status只在后台诊断，不能回带上游消息。没有自动删参数/改模型/重发。无有效稿失败且DB确认退款才generation.failed/quota_refunded:true；有lastValid的增强故障仍Q02；主动cancel=false退款、断连、DB未知按原唯一终态规则，不把pending写成已退。

reasoning-only、响应头、心跳不产生plan_item/edit，不能记首业务内容。每调用180秒/总600秒的独立deadline保持，不随任何事件重置；[AI7-02](../ai-integration.md#ai7-02-无业务内容失败与最小观测)为计时规则。无完整有效Plan超时用原generation_timeout，完整围栏/畸形为schema_error，writer未发送，无新公开错误枚举。UI只显示真实等待/可取消/失败/已确认退款或待核对，不显示参数、内部推理或假进度。

