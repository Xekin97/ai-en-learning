---
milestone: M003
version: M003-UI-10-R1.1
stage: uiux-design
workflow_stage_unchanged: technical
active_implementation_role: frontend-bob
role: uiux/base
agent_name: designer-tony
status: accepted_visual_scope_contract_clarified
date: 2026-10-12
---

# UI10-R1.1 CR-306 合同文案澄清交接

> `SUPERSEDED / USER-M003-UI10-MODAL-REWORK`：原 UI10 把普通 `[open]` dialog 当作模态交付，不能支持前端接收。原 13 项报告不含 `:modal`、背景隔离、焦点约束和生命周期，相关通过结论失效。旧 `design/evidence/cr306/` 与恢复包保持原样，仅作为失败证据；当前研发不得接收旧稿。UI10-R1 已用真实 top-layer 生命周期整改，新结论只以 `design/evidence/cr306-r1/`、R1 恢复包和本交接为准。

> `CLARIFICATION / M003-UI-10-R1.1`：用户已接受 R1 视觉并接续研发。本小修订只补齐 API-306 已确认的大小、空文本、显式 probe 与快照语义；继承 R1 全部页面、模态布局、交互、截图和 Vue 接点，不重开视觉评审。R1 包、manifest 与报告不可覆盖；增量证据只写入 `design/evidence/cr306-r1-clarification/`。当前工作流仍是 technical / frontend-bob，CR-306 保持 open。

## 使用的输入与确认闭环

- [PRODUCT09](product.md)、[BE07](backend-architecture.md)、[DB04](database.md)、[API-306](../technical/api/administration.md#api-306)、[BE07 fixture 索引](../technical/fixtures/cr306/index.json)和[门禁071](../reviews/cr306-design-entry-gate-071.md)为本版批准输入。
- `USER-M003-CUSTOM-PARAMETERS` 已确认每模型高级 JSON、管理员按服务商文档填写、`{}` 不追加，取代专用推理 mode/effort 与能力目录；保存 0 模型调用、保护系统/凭据、同请求快照和旧业务保留。无须重复确认。
- `USER-M003-M002-DESIGN-BASELINE` 与 `USER-M003-UI-REVIEW-A` 要求完整页面 → M002 正式视觉 → 向用户展示新视觉 → 再接前端。UI10-R1 已完成并获用户接受；R1.1 不改变已接受视觉，只为 frontend-bob 补齐实现所需的既有合同文案。
- 没有仍会改变本版结果的关键假设或业务阻塞。若后续要增加供应商策略、费用上限、自动能力目录或新的业务权益，须回产品；本版没有引入。

## 交互原型输入与正式视觉落实

| 层次 | 使用来源 | 本轮产出与可复现依据 |
|---|---|---|
| 交互原型 | BE07 `technical/fixtures/cr306/index.json` 指向的 management/errors/streams；既有 stream-v5 | 原型直接 fetch 合同 fixture；JSON 编辑、错误、冲突、取消、保存、显式 probe、旧测试失效及等待/失败状态可由下列 URL 重现；交互序列记录于 R1 浏览器报告，且只有完整跑完才可 PASS |
| 正式视觉 | M002 `design/theme.css` 的 admin 栅格与 UI29–31 服务商/模型/对话框组件；当前 `frontend/app/pages/admin/models.vue` 的真实服务商分组和完整表单布局；UI09-R3 完整学习/预设页 | `design/theme.css` 继续 import M002，仅追加 CR-306 JSON 区样式；完整页层级、tokens、双语 copy、响应式和截图均由 UI10-R1 原件交付，不把独立 textarea 草图当正式设计 |
| 可恢复版本 | CR-306 前 UI09-R3 冻结基线、失败 UI10 原包与 UI10-R1 新源包 | `reviews/evidence/cr306-design-baselines/ui-before-cr306.tar.gz` 不变；R1 source tar + manifest 含全部设计真源与 hash |

## 本次产物与直接入口

- [正式规格](../design/design-spec.md)：UIA-M003-412.r1–418.r1、PAGE/CAP/DATA 追踪、稳定区域及全部状态 URL。
- [统一双语文案](../design/copy.json)、[M002 基准主题层](../design/theme.css)、[可运行完整原型](../design/prototype/index.html)、[交互](../design/interactions.md)、[响应式与无障碍](../design/responsive-accessibility.md)。
- PAGE-208 JSON 编辑（中文）：`http://127.0.0.1:4174/M003/design/prototype/?page=models&lang=zh&view=formal&state=edit&rev=ui10-r1.1`
- PAGE-208 保护字段错误（英文，可切 390px）：`http://127.0.0.1:4174/M003/design/prototype/?page=models&lang=en&view=formal&state=error&case=protected_model&rev=ui10-r1.1`
- PAGE-208 列表 / 格式错误 / 冲突 / probe 拒绝 / 保存成功：分别使用 `state=list`、`state=error&case=syntax`、`state=conflict`、`state=probe-error`、`state=saved`。
- PAGE-204/216 无内容超时：`http://127.0.0.1:4174/M003/design/prototype/?page=create&lang=zh&view=formal&scenario=cr306-timeout&event=3&status=0&rev=ui10-r1.1`；将 scenario 换为 `cr306-cancelled` 或 `cr306-settlement_pending`（pending 用 `status=1`）。
- PAGE-212 预览超时：`http://127.0.0.1:4174/M003/design/prototype/?page=presets&lang=zh&view=formal&mode=basic&previewFailure=timeout&event=3&status=0&rev=ui10-r1.1`。

## UI 交付与前端接收合同

- PAGE-208 保留现有服务商分组、模型行和完整弹窗表单。JSON 只进入每模型高级选项；最大输出 tokens 与结构化输出继续是专用单一权威字段。服务商协议仍可选择；“添加服务商”从空连接 + 一个空模型开始；“编辑服务商”必须使用用户点中的 provider，不能硬编码首项。
- JSON 区直接给出 OpenRouter 示例 `{"reasoning":{"enabled":false}}`、`{}` 语义和简短供应商文档提示；具体错误紧贴 textarea。保护字段与 16 KiB / 深度 8 / 重复键 / U+0000 规则收进可键盘展开的说明。格式/安全错误保留该模型原始输入；冲突合并仍按模型保留草稿；probe 与保存都取同一次表单快照。
- PAGE-204/216/212 继续复用 UI09-R3 完整页与 v5 流，只增加 BE07 fixture 已定义的 timeout/fenced/cancelled/pending/preview_timeout 映射。不突出审稿或次数，不投影私有推理，不新造事件。

### R1.1 固定 copy 键与错误映射

| copy 键 | 使用位置 | API-306 来源与实现约束 |
|---|---|---|
| `cr306.custom.empty` | JSON 规则提示 | `{}` 表示不追加；空文本不是 `{}`，按 `invalid_json` 失败 |
| `cr306.custom.size` | 每模型辅助计数 | `{count}` 是解析后规范化紧凑 JSON 的 UTF-8 字节数；无效或尚未完成的 JSON 显示 `—`，不把 raw 字节伪装为紧凑计数。`{limit}` 为 `16 KiB`；不得按带缩进 raw 长度拒绝合法对象 |
| `cr306.error.too_large` | 对应模型 textarea 下方 | `validation_failed / 422`，field code `too_large`；聚合保存路径 `/models/{index}/custom_parameters`，单项/probe 路径 `/custom_parameters`；模板参数 `{limit}` 使用 `16 KiB（16,384 字节）` |
| `cr306.error.request_too_large` | 整表单错误 | 单项 32 KiB、批量 256 KiB 或聚合 2 MiB 的 HTTP 总界返回 `request_too_large / 413`；可无 field，保留全部编辑且不得误贴首模型 |
| `gm.test.note` | 模型段说明 | 显式 probe 可能产生少量费用，固定最大输出 256 tokens；保存不要求先测试 |
| `cr306.probe.rejected` | 当前模型 probe 拒绝 | `model_request_rejected / 422` 且 upstream 400/422 时，提示检查平台参数与固定 256-token 限制；不宣称完整生成或参数效果 |
| `cr306.probe.stale` | 旧 probe 结果 | 当前草稿改变后旧结果失效；管理员仍可直接保存，仅在需要重新验证连接时再次测试 |

PAGE-212 的 ready 失效只指预设编辑器中的本地草稿或预览配置改变。后台模型参数变更只影响之后受理的新请求快照，不追溯改变在途或已完成 run；旧预览/旧 run 可继续作为历史结果展示。权威来源为 `technical/api/administration.md#api-306`、`technical/api/presets.md#api-306-preview` 与 `technical/fixtures/cr306/errors.json` 的 `compact_utf8_16384/16385` 边界。

### 精确 Vue 接点

| 现有接点 | 必须复用 | CR-306 只新增/扩展 |
|---|---|---|
| `frontend/app/presentation/components/AppDialog.vue` | `open/title/bodyKey/notice` props、`close/shown` events、default slot 位于 `.dialog-body`、`#footer` slot；组件内部 `showModal()`、Teleport、backdrop/cancel、feedback modal stack 与 opener restore | 主编辑框仍是 `id="admin-model"`；脏确认继续使用第二个 AppDialog。不得用模板 `[open]`、定位层或页面滚动模拟 modal |
| `frontend/app/pages/admin/models.vue::openProvider(provider?)` | edit 复制被点击 provider 的全部 models；add 建立空连接和一个模型；协议、连接、模型字段、add/remove/test/save 原行为保留 | 每个 `modelEntryDraft` 新增一份 raw JSON string（命名由实现确定），从该 model 的 `customParameters` 初始化；不能使用页面级共享字符串 |
| `modelEntryDraft` / `addEntry()` / `removeEntry()` | 数组顺序、key、model id、display name、description、max output、output mode、enabled 与焦点行为 | 新条目 JSON 初值为 `{}`；移除只移除本项；增删/编辑不得覆盖其他 model 的 JSON |
| `providerConfiguration` / dirty snapshot | 继续生成完整 connection + models 快照，供 dirty、probe、save、merge 共用 | 每个模型解析自己的 raw JSON；合法对象映射到该项 `custom_parameters`，错误保留 raw 字符串并聚焦首个错误字段；`{}` 表示不追加，空文本触发 `invalid_json`；规范化紧凑对象超过 16,384 UTF-8 字节触发 `too_large` |
| `closeModel()` + discard AppDialog | header close、footer cancel、Escape、backdrop进入同一 dirty 规则；继续编辑、放弃、父框关闭和精确 opener restore | 确认层位于父框之上；继续编辑不重建草稿；背景不可交互，底页 scroll 位置不变 |
| `testConnection()` / `refreshDraft()` / `saveModel()` | 显式 test、版本合并、整服务商保存、原有 busy/notice/problem 处理 | test 用当前模型 JSON/专用字段快照并固定最大输出 256 tokens；任一配置变化使旧 test stale，但 test 不是 save 前置；冲突合并逐模型保留 raw JSON；save 0 模型调用，成功才关闭并回列表。无 field 的 413 在表单级显示，不绑定首模型 |

生产样式直接复用 `frontend/app/assets/css/theme.css` 的 `#admin-model[open]`、`#admin-model > h2`、`.dialog-body`、`.dialog-actions` 和 `dialog::backdrop`。新样式只负责 `.custom-json-field/.custom-parameters/.custom-json-guide/.custom-json-error` 及窄屏细节；框体沿现有 max-width 与视口安全边距规则，390px 样例实测宽 354px（左右 18px、上下约 10px），不得另写死 370px。静态原型只是实现可复现的设计输入，不是 CR-306 的真实修复。

## 验证、快照与文档整理

- [现网 AppDialog 只读观察](../design/evidence/cr306-r1/live-appdialog-observation.json)：从 `/admin/models` 有模型 provider 实点进入，`:modal=true`、`.dialog-body` 为 auto scroll、Escape 回精确 trigger、1440/390 无横溢；未保存、测试、删除或调用模型。稳定截图为 `00/01/02-live-*`。
- [R1 定向浏览器报告](../design/evidence/cr306-r1/modal-rework-browser.json)：`completed=true` 且 `result=PASS`；异常会写 `run_error` 并强制 FAIL。覆盖完整列表→指定 provider、top layer/背景隔离、内部滚动/固定头尾、Tab/ShiftTab、Escape/确认/输入保留/焦点恢复、add 与 edit 差异、协议选择、增加模型、每模型 JSON 隔离、390 错误层级、框内点击与真实遮罩点击。
- [独立窄范围接收](../reviews/evidence/cr306-modal-rework-073/revised-modal-receipt.json)为 PASS：复核原 `modal=false` 失败已变为列表实点后的 `:modal=true`，并核对 720px 框体、背景隔离、Escape 精确焦点返回、390px 354px 框宽/无横溢及真实框外点击。
- 代表图：[完整列表](../design/evidence/cr306-r1/10-r1-list-1440.png)、[桌面初始弹窗](../design/evidence/cr306-r1/11-r1-modal-initial-1440.png)、[桌面 JSON](../design/evidence/cr306-r1/12-r1-modal-json-1440.png)、[手机初始弹窗](../design/evidence/cr306-r1/13-r1-modal-initial-390.png)、[手机字段错误](../design/evidence/cr306-r1/14-r1-modal-error-390.png)、[手机叠层确认](../design/evidence/cr306-r1/15-r1-discard-confirm-390.png)。designer-tony 已逐张实际查看；root 已复看关键桌面/手机图。
- R1 恢复包：[M003-UI-10-R1-source.tar.gz](../design/evidence/cr306-r1/M003-UI-10-R1-source.tar.gz)；逐文件 hash、输入 fixture、现网观察与旧基线 hash 见 [manifest](../design/evidence/cr306-r1/M003-UI-10-R1-source-manifest.json)。原失败包 `design/evidence/cr306/M003-UI-10-source.tar.gz` 及报告/截图不改；CR-306 前 UI09-R3 继续由 `reviews/evidence/cr306-design-baselines/ui-before-cr306.tar.gz` 恢复。
- R1.1 增量合同包、逐文件 hash 与定向文案验证见 `design/evidence/cr306-r1-clarification/`；它只覆盖 copy、错误映射和来源记录，不能代替或覆盖已接受的 R1 视觉包。
- 当前权威入口是 `design/design-spec.md` 与本交接。UI09-R3 未受影响业务继续有效；其 CR-306 受影响部分由 UI10-R1 替代，R1.1 提供合同纠正。CR-306 保持 open。
- 证据只证明原型和合成合同状态；未验证生产 Vue、真实 API/DB、供应商参数效果、完整生成速度/质量、模型费用、真实链路或用户 UAT。Profile 仍为 1.0.0；requested `gpt-5.6-sol/high`，actual model 与 usage unknown。

## 未决事项与下一步

- `ACCEPTED / UI10-R1-VISUAL`：用户已接受 PAGE-208 完整页、真实模态和 JSON 高级选项视觉；R1.1 不重新设计。
- `ACTIVE / TECHNICAL-FRONTEND-BOB`：frontend-bob 接收本页固定 copy 键与 API-306 映射；本小修订不切阶段、不替 FE 写实现。
- `OPEN / CR-306`：前端实施、后端实施、独立 QA、完整真实链路与用户 UAT 仍未完成，CR 不关闭。本原型和合同澄清不声明真实修复。

> 本交接单不能切换阶段。阶段迁移必须由用户显式提交给守门器。
