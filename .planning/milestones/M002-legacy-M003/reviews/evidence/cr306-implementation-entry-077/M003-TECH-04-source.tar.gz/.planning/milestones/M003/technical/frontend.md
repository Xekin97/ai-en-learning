---
milestone: M003
stage: technical-design
role: frontend-architect/base
agent_name: frontend-bob
status: awaiting_user_review
version: M003-FE-03
date: 2026-10-12
input_version: M003-PRODUCT-09 / M003-BE-07 / M003-DB-04 / M003-UI-10-R1.1 (R1 visual accepted)
---

# M003 前端技术方案

当前 FE03 是 CR-306 最小架构增量，接收 PRODUCT09 / BE07 / DB04 / UI10-R1已接受视觉及R1.1合同勘误。TECH03 / FE02 的 v5、Plan 保留、计划及预设业务已经实施并有合成 QA，继续作为回归基线；不把整个 M003 重列为未开发。本轮只交设计，新增 JSON/错误映射尚未实施。FE02 两原件由 [075冻结包](../reviews/evidence/cr306-frontend-entry-075/M003-FE-02-before-cr306.tar.gz)恢复；更早 FE01 [冻结包](../reviews/evidence/control-040/M003-FE-01-before-revision.tar.gz)保留。原 UI10 modal=false 及13项依赖模态的结论失效，不能作为本轮实施依据。

## FE3-01 输入、决定与技术边界

**CONFIRMED 继承业务**：[PRODUCT09](../handoffs/product.md)、[CR-302](../changes/CR-302.md)、[用户确认](../reviews/requirements-feedback.md)的 Q3-02-A、LIVE-TEXT、PLAN-RETAIN、M002-DESIGN-BASELINE、READING-ALIGNMENT、UI09-ACCEPTANCE。所有模式同目标模型真实 Plan→writer；增强 N>0 再一次固定编辑→原生校验→Review/必要条件返修。N0保留规划但关闭增强段；内容N0–99/初始1，流程测试至多2轮，99仅配置/静态。基础恢复全请求固定2是接收的后端技术策略，后台只读、独立于N；后台basic0/enhanced1。前端不执行模型编排、不把一次业务次数等同一次模型调用。

**本次接收与确认闭环**：[PRODUCT09](../handoffs/product.md)、[BE07](../handoffs/backend-architecture.md)、[API-306](api/administration.md#api-306)、[AI7](ai-integration.md#ai7-reasoning)、[DB04](../handoffs/database.md)、[UI10-R1](../design/design-spec.md)。USER-M003-CUSTOM-PARAMETERS 已确认每模型高级 JSON/{}不追加/保存0调用；USER-M003-UI10-MODAL-REWORK 要求沿现有 AppDialog；USER-M003-UI10R1-NEXT 在展示 R1 后确认接前端架构。[075](../reviews/cr306-frontend-entry-gate-075.md)已激活 technical-design/frontend-architect/base/frontend-bob/active；[074](../reviews/cr306-modal-rework-review-074.md)只证设计可展示，075才是此次接受来源。R1提交时的“待视觉评审”已由075闭环；当前R1.1原件准确继承其接受范围。具体源码拆分/校验实现是既定范围内专业方案，不新增业务决定。模型路由v1请求 frontier/gpt-6-astra/high，actual serving/usage unknown。

**技术取舍（本角色方案，待整体验收）**：沿现有 Nuxt 4/Vue 3、useState/store、Zod、eventsource-parser、i18n 和 Go 同源 API，不加框架。保留 SSR 页面/会话/选项读取＋客户端 POST 流：SSR 有助于首屏已有导航、配置与身份，且已具请求级隔离；流式草稿只在客户端活动会话存在。全CSR会重做当前加载与权限壳，SSG不适合私人动态状态，均无当前需求收益。无 CRDT、永久中间稿、自动续传、队列、额外词典/翻译调用或监控平台。

权限继续 [USER-COMPAT-001](../../M001/reviews/first-release-compatibility-policy.md)与[主动删除claim例外](../../M001/reviews/claimed-batch-delete-retention-exception.md)：配套切换契约，无旧流兼容；不复活已删除资源。保留当前后端未提交改动；本轮不改源码/专业上游/控制面，不提交、迁移、部署、真实模型调用或代用户UAT。

## FE3-02 数据层、类型与状态归属

依赖固定为 `HTTP/SSE DTO → 严格schema → mapper → 应用模型/事件 → store/纯reducer → presenter/组件`。SSR通过同一仓储/mapper后注入可序列化应用模型，禁止原响应透传；页面不fetch、不导DTO/schema、不读取snake_case。状态不能反向依赖视图。现有 `plugins/application-ports.server.ts` 的每请求 transport/vault、Nuxt app WeakMap控制器与私有状态注销机制保留。

下表路径相对 `frontend/`；TECH03已有实现，表中为持续职责与CR306接续边界。新文件仅在获得实施授权后创建；新增模型配置链路见FE3-11。

| 入口 | 修改职责及实际差距 |
|---|---|
| `app/infrastructure/http/schemas/generation.ts`、`admin.ts`、`presets.ts`、`admin-presets.ts`、`common.ts` | 现有v5完整事件、status、ContentService/NativePolicy、preview mode、outcome/notice与busy保持；本轮只补API306明确未受理分支与管理对象/错误。共享schema放generation或就近小文件，不另造协议框架 |
| `app/infrastructure/http/repositories/api-repository.ts`、`admin-presets-repository.ts`、`presets-repository.ts`、`admin-configuration-repository.ts` | 现有v5/pending能力、status端口、严格body、HTTP busy与精确publish body保持（不波及下架旧合同） |
| `app/infrastructure/http/mappers/index.ts`、`span-mapper.ts`、`problem-mapper.ts`、`presets-mapper.ts`、`admin-presets-mapper.ts` | 保留已有Unicode Result映射；增加临时Plan/edit应用事件、完整终态/notice/资格、双类人数/真实N/未知usage。problem mapper已有busy投影；本轮需显式增加API306的revision/probe/未受理分支，不把任意后端detail当文案 |
| `app/application/shared/models.ts`、`ports.ts`；`app/application/generation/content-service.ts`（FE02拟议路径，现有实现已分散于schema/models/reducer，不为对齐文档补文件） | 应用类型与关联规则及现有两类status端口；generation/preview凭证与退款联合分离。只提供当前需求的共用预算/终态校验，无Vue/Zod依赖 |
| `app/application/generation/reducer.ts` | 现有v5 seq/Plan/splice/终态纯归约继续，共用正文规则但保持namespace区别 |
| `app/application/admin/configuration.ts`、`plan-policy.ts`、`presets.ts` | 完整计划输入/impact、raw N校验、预览输入快照失效、模式/版本/run关联及手动发布资格 |
| `app/runtime/stores/generation.ts`、`presets.ts`、`admin.ts`、`admin-presets.ts` | 现有request epoch、有限核对、取消竞争、busy回退和旧回调隔离保持；store只用port，不直接读parser |
| `app/presentation/admin/admin-plan-presenter.ts`；现有视图内服务投影（FE02曾拟 `content-service-presenter.ts`，本轮不新增） | 模型→固定copy键/变量、区域与动作资格；不暴露版本/N/内部审稿进度，不按Pro/Plus名称推断权益 |

应用状态分四类，避免一个phase同时承担传输、业务和表单事实：

- `attempt`：namespace（generation/preview）、本地requestEpoch、sessionEpoch、streamId/runId、acceptedSnapshot或previewBinding、lastSeq/上一帧指纹、phase（accepted/planning/composing/finalizing）、planId/language/条目、draftId/离开过的ID集合、contentVersion/revision、draftText及码点长度。**没有 acceptedCandidate、repairAttempt 或内部 lastValid 模型**；服务端未发送这些可用事实。
- `terminal`：status、finalContentVersion、完整 result 或 null、outcome/notice、用户 canSave/refund 或管理员 usage。与临时状态不同；`resultUnavailable`是权威valid但payload不可用，不能显示“完整资源已准备好”。
- `request`：idle/starting/streaming/pending/settled，cancel/recheck busy、reconciliationEpoch、明确受理前busy及retryAt。started前保留既有有效结果/ready绑定以便明确busy不抹结果；新请求清旧临时Plan/正文，旧正式结果仍独立绑定原run，不能成为新请求final。已明确放弃的结果不复活。
- `form`：本地原始输入、baseline/remote、editRevision及已预览规范化body；URL仅原有路由/资源ID，无token/临时正文/demo query。

`runtime/session/token-vault.ts`继续只在内存保存能力，generation与`preset-preview:`分键；不进useState/SSR payload、local/sessionStorage、URL、analytics或日志。注销/换账号清私有正文、能力与计时器。仅有 run_id 无token不得查需要能力的status。

### 严格schema与映射要求

wire字段唯一来源为API原件，本文不建立第二份DTO规格。所有必填/nullable/unknown字段及整数界按API；流JSON沿现有JSON.parse校验语法/尾随，再做严格schema；此处只描述既有SSE消费；管理员手写JSON是API306明确新增的重复键感知解析责任，见FE3-11，不得用本段豁免。保持fatal UTF-8与跨chunk解码。规划scene1–600、sense1–256、form1–128、phrase1–256码点，entry必须来自当前请求，数量随真实E；预览只接受两个exact分支，不接受私有role/facts/beats。

ContentService仅false/0或true/1–99，NativePolicy严格为version/scope/max_calls=2/editable=false的真实响应；visitor/basic不得增强。started快照覆盖旧options预估且本run固定，刷新options只用于下次。preview mode与N严格basic0/enhanced1，不包含用户plan或charge。

Result整包校验目标词exact各一次/输入顺序、标签、释义、hint与occurrences；用现有 `Array.from` 码点半开区间校验surface/范围/重叠，再一次映射segments。不得从Plan.sense填entryMeaning，不混合旧稿字段。status的valid允许result=null，can_save=false；完整有效不等于当前仍可保存/发布。

outcome只有basic/review_passed/repaired_passed/limit_finalized/service_incomplete，后者必须notice=content_review_incomplete，其他null；与N/mode、status/refund按API关联检查。历史管理preview/version/outcome可null，不填“审稿通过”。UsageSummary的providerCalls、unknownCalls、invocationUnknownCalls、notInvokedCalls分别映射，null token/费用仍未知，不能相加当实际调用数。

## FE3-03 流读取、版本与reducer

继续POST fetch与eventsource-parser；可把两个仓储重复的读取/命名分派抽到就近 `app/infrastructure/http/repositories/content-stream.ts`，仅共用传输与v5检查，不合并用户/管理员权限。heartbeat无seq，不推动状态。parser缓存上限继续遵守TECH03按合同实现的上界，不能回退为旧1MiB：需按API允许的完整Result和retained全文及JSON转义计算有界最大帧，provider insert≤2048码点但retained可整稿；实现测试合法大终态不被1MiB截断与越界拒绝，不任意缩小上游输入边界。

| 收到的事件/事实 | 验证和归约结果 |
|---|---|
| started | 第一个命名事件、seq=1、contract_version=v5；完整身份/服务快照校验后留token；绑定当前响应stream_id。预览另核draft_version/mode。相邻完全重复帧按下述NOOP处理 |
| progress planning/composing/finalizing | 只按收到的真实phase推进；不造Review/固定编辑/返修轨道，不能回到planning或在finalizing后编辑；composing前计划项必须已经排空 |
| plan_item | 仅planning期间，同plan_id/受理meaning_language；scene最多1、每个selected entry最多1，保持收到条目的稳定身份/真实顺序，布局仍按scene与词用法区域。只显示已完整收到的scene/sense/phrase，无占位词义 |
| edit | 验seq、draft规则、版本、base_rev=currentRev、rev=base_rev+1、码点范围；原子执行 `prefix(at)+insert+suffix(at+delete_count)`。每次edit只改变正文，不清Plan、不建学习资源；insert为空可真实删尾 |
| validated | 身份匹配、完整Result/终态关联通过才原子清Plan和临时稿，建立最终正文/高亮/tags/targets/notice与资格。最终版本来自权威包，不要求等于最近可见draft或前端曾见过的版本；允许Q02 final下降 |
| failed/cancelled | 权威失败/取消清临时内容并关保存；generation失败refund=true，取消false，preview无quota字段；不从肉眼完整草稿擅自成功 |
| settlement_pending、无终态EOF、协议/网络异常 | 停止不可信流消费，保留已安全应用的Plan+正文、无学习/保存，转有限status核对。不是Q02或退款事实 |

**seq与身份**：所有命名事件从1严格连续；只允许紧邻上条且seq/event/规范化data完全相同的重复NOOP，保留上一帧指纹即可。更旧seq、同seq不同data、跳号、未知事件/字段或错身份均停止并核对，不缓冲重排，不重POST。旧session/request/响应namespace回调直接隔离；当前流身份异常不能当旧回调忽略。终态后关闭流，迟到非终态不覆盖权威结果。

**splice与版本**：revision属于整个stream，切稿/retained不重置。当前draft_id/provider只准尾插且V不变；新provider ID必须未使用过，V不下降，允许首稿/固定编辑或重写首片的一次前缀删替、同V续写；同V不同ID合法。新ID恰好等于现正文的无变化切换可NOOP更新身份，但不制造文字进度；同旧ID无意义空edit拒绝。retained必须新ID，允许V下降，只有服务器提供的恢复文字可用，客户端不能自造lastValid或由恢复帧推断保存资格。

N0合法V=1，增强合法1..N+2（最大101），preview增强1..3。V不是k/N或调用数；首个公开正文未必证明所有前序任务均公开过文字，不要求每个V都已观察。合法例：N2中V1→固定编辑V2→返修V3→V4半稿→retained V3→validated final3/incomplete；固定编辑V2故障可恢复V1；V4完整后审稿故障可final4。status可直接返回未在当前流观察到的最终包。

每帧先顺序验证并归约，再用Vue批更新/单个animation frame提交最新文本；不能把splice的insert串成delta丢掉删除/seq。尾插使用已维护码点长度，不每token重扫全文；非尾插时作一次码点切分，不每tokendiff。终态清理待渲染任务防止旧草稿覆盖Result。保留单份当前正文、有限身份/计划数据和上条指纹，不存事件历史/每版全文。

**Plan生命周期**：首稿、换稿等待、编辑、条件返修、retained、finalizing、pending及EOF均保留初始Plan。固定编辑可换场景，原Plan始终带 `m003.plan.note`，不反推更新、不宣称最终词典。仅权威valid完整Result（含Q02）清Plan并原子建学习资源；valid/result=null不满足，保留已有只读临时内容与结果不可用说明、禁保存。已清除Plan不因后续payload失效复现。失败/取消/新请求清临时内容。

## FE3-04 终态核对、取消、保存与忙碌

沿API-302/304：用户status用X-Generation-Token，preview用X-Preview-Token；status不带临时phase/draft或seq、不续流。立即一次、串行间隔至少2秒、总窗口最多10秒（到期中止未完请求）；其后 `m003.recheck` 每次显式操作读一次，active/503仍pending，不重启无限自动窗口。404/410停止并关保存；token默认终态1小时/待保存draft30分钟沿后端。刷新丢token不新增恢复能力，合法既有资源读取可恢复notice。

核对绑定sessionEpoch＋requestEpoch＋namespace＋runId＋reconciliationEpoch。晚active/503/取消ACK不能覆盖valid；相同DB终态幂等，保存/claim已完成不能被旧status重开。实质终态冲突关闭新保存动作并再核对，不按到达顺序换包。取消返回valid只是种类确认，继续status取得最终Result/notice；不能拿本地草稿当final。

取消前started未到先记意图，拿token后发cancel；不把abort当已取消。重复点击合并一个取消动作；未知503保留pending，完成先赢显示真实完整包，取消先赢清稿且不退款。离开、popstate/pagehide、卸载沿现有离开确认/被动abort，所有controller、绘制/核对任务失效；被动断线不是主动cancel成功或Q02。服务端CAS与费用是权威，取消不表示提供方免费停机。

保存/访客claim只接受当前run的权威完整Result与资格；validated依API授予有效草稿资格，status时尊重can_save，已保存/丢弃/TTL/归属变化后不恢复。原API-006保存/放弃/claim的幂等、归属与删除规则保持。Q02通过SSE、status、当前保存结果、管理preview/published读取持续显示notice；普通完成四outcome统一完成表达，不暴露审稿轮次或宣称独立质量达标。无lastValid失败与取消由服务端处理，前端不由超时/EOF自行推断退款或incomplete。

### 受理前 busy 与受理未知分开

三个POST统一按API-302识别 **HTTP503 + code=generation_busy + context.accepted=false**，严格context仅accepted/retry_after_seconds，秒数1..600且与十进制Retry-After一致。完整验证后映射安全应用失败及retryAt，停止本次等待，保留输入/已保存草稿/既有有效结果或preview ready（仍核原binding）。没有run/token，不query status，不改变本地额度或制造退款，不显示队列位置。

使用既有AppError/再试区域与已批准通用暂不可用文案；本版不自写“未扣次”新文案，也不原样渲染Problem.detail。明确busy才具备未开始/未扣次事实。Retry-After期间禁新提交，结束只解禁；**永不autoPOST**，不会排队。普通泛503/502、解析失败、网络EOF、temporarily_unavailable的COMMIT未知不套busy。若未收到started/token，无法调能力status；保留受理未知说明并重读options可用性，options不是结算证明，新意图仍受服务器同主体active限制。

BE06-R1的20及10/20/50/100均未测，不出现在用户容量承诺或新配置页。浏览器只可记录点击到首Plan/正文/换稿/完整渲染时间，和Go T0/flush指标分开；50ms服务端合并、180s/600s保护截止不是首内容体验目标。

## FE3-05 PAGE-208 配置表单与冲突

保留原四计划、页头全档位优先级入口、模型/长度/词数/滚动24h额度/不限字段、单panel双栏与M002自定义控件。服务区按UI09-R3接入真实NativePolicy只读2、派生开关与N，不硬编码fixture值。visitor/basic始终false/0且控件禁用；Pro/Plus各自0–99，关闭置0、开启恢复最近合法正N（无历史1）；N0徽标基础，合法1–99增强，非法值不作为已保存服务事实。

raw string与合法数值分开；空、负数、小数、100、非整数不截断/四舍五入、不将空转0。非法保留输入/错误/aria-invalid，禁impact/PUT。类型属性只提示，API独立拒绝非法配对/权限。完整body包括原字段和content_review_enabled/content_repair_limit，绝不传native策略字段；quota null不限与0禁止严格区分。

local/baseline/remote分开；保存前impact snapshot包含规范化完整body和revision。任何字段编辑（含原字段、N、开关、切tab）使旧预览与确认失效；迟到impact检查editRevision/plan，不重新解锁。PUT必须等于被确认body。impact按响应显示before/after、warnings、生效边界与真实基础/体验人数；UI09-R3 `m003.impact` 的basic/trial分别映射，可能重叠不求和，不称净失去增强人数。

409 revision_conflict保留local→GET四计划remote→并排比较→用户保留本地编辑后以最新revision重新impact→再次确认。不能把current_revision自动塞进旧PUT；duplicate_priority保留专用含义。PUT丢响应先GET，当前值相同只说明当前配置已保存，不冒充原回执/重复推进revision。取消不PUT，失败不抹输入。

批量priority沿原四行body，无内容字段；显示响应content_service_by_plan/may_change_content_service及新请求/在途/不重置用量/不改试用时间。false不等于有效计划没变。保存后刷新后续options/公开预设与权益摘要，已受理snapshot保持。PAGE-215/217任何权益摘要均从真实ContentService投影，不按计划名推断。

## FE3-06 PAGE-212 预设模式、预览与发布

保留master-detail、title、无限制管理选词（不套用户max_entries）、四配置及保存草稿/预览/取消/发布/下架。options提供preview modes/basic默认/enhanced固定N1；无计划模拟或N选择器。用户 `/trial/:presetId`继续共用GenerationWorkspace，实际增强来自本人权益，公开样文不是权益授予。

1. 本地编辑title/词/配置/mode立即失效ready及Q02确认，递增编辑/请求代次；先保存草稿再按响应draft_version/mode预览。只改title在服务端允许继承preview时，保存后重读绑定可重新判定，不直接沿用本地旧ready。切回旧mode不自动复用历史preview。
2. preview独立namespace/token/epoch，事件用preview.*，Result归约共用FE3-03；无用户refund/charge。valid完整包后清Plan，进入qualifying；GET当前AdminPreset核对当前draft_version＋mode＋preview_run_id及完整payload且valid才ready。valid但未关联/旧run、payload TTL失效、dirty local、切preset均不可发布。
3. 晚mode/旧草稿/旧GET不会覆盖dirty表单或解锁新稿。busy受理前拒绝保留原ready且只在原binding仍匹配时可用；新preview开始与旧正式预览资格分开，不能将旧正文当新run成功。
4. service_incomplete完整有效预览可手动发布，notice在stream/status/GET/ready/确认/发布响应与管理published读取保持。按 `m003.q02.confirm` 明确勾选；变更资格后清确认，绝不自动发布。
5. publish body只含expected_revision/draft_version；UI确认不新增confirmed wire字段。冲突/preview_required/403按实际响应，旧published保持至成功；丢响应先GET，不盲重试。basic final1、enhanced最大3不是质量结论。

## FE3-07 设计转译、组件与页面定位

唯一来源：[规格](../design/design-spec.md)、[copy](../design/copy.json)、[theme](../design/theme.css)、[原型源](../design/prototype/app.js)、[交互](../design/interactions.md)、[响应式](../design/responsive-accessibility.md)。UI10-R1模型模态为本次接受源；UI09-R2/M002与UI09-R3未受影响业务继续。UI07/08视觉及原UI10模态不再有效。浏览原型 formal入口/复现query见规格；这些query、fixtures、after_ms/timer不进入生产。

| PAGE / UIA | 路由、已有组件与拟接入区域 | 应用数据/API |
|---|---|---|
| 204、216 / 401.a、402.a | `/create`、`/trial/:presetId`；保留AppHeader/BrandMark/GenerationSettings/WordPicker/AppSelect，改GenerationWorkspace右侧 `.m003-creation-main`；settings→选词/操作→阅读纸顺序 | options/预设配置、accepted快照，API-301/302/304 |
| 204、216、212 / 402.a–406.a、410.a | 现有 `GenerationWorkspace.vue` 与 `pages/admin/presets.vue` 内 Plan/草稿/完整结果分区（FE02拟拆组件未创建，不为本CR强行抽取）；稳定 `#planning-preview/#live-draft/#final-result`，外壳普通 `#generation-status`、后台 `#preview-result` | 只接应用read model与动作事件，不自行fetch；FE3-03/04 |
| 208 / 412.r1–418.r1 | `/admin/models`，现有models.vue、AppDialog及model/provider draft；精确JSON/模态/错误/保存映射见FE3-11/12 | API-306，AC-317/318/322 |
| 208 / 407.a | `pages/admin/plans.vue`、admin-plan-presenter；保留M002 tabs/单panel原字段/priority dialog；`#service-settings/#change-preview/#version-conflict/#plan-actions` | local/remote/impact/NativePolicy，API-303，CR303修正 |
| 212 / 408.a、409.a | `pages/admin/presets.vue`，现有PresetWordMeanings/WordPicker/AppSelect/AppDialog；`#preview-mode/#preset-actions`＋共享阅读纸 | PresetInput/previewBinding/qualification/usage，API-304 |
| 215、217 / 继承权益展示 | `/account/items`、`/account/exchange` 的 ItemsWorkspace/ItemEffect 仅在既有目标计划摘要处接真实配置；`/explore` 保留公开预设展示与presets mapper，不重做页面，目录浏览无生成 | 已批准权益投影与原公开结构，API-301/304；不为摘要自造DTO或泄露后台mode |

保持现有临时/完整结果边界，不为CR306重构阅读组件或组件库。Plan用planId/entry稳定key，草稿节点不以draftId作key；新稿换身份只更新text，保持Plan/设置/焦点/滚动位置。首点击可定位结果一次，后续不强制滚动；正文不逐片aria-live，简短draft-status polite。正文/英文词语lang=en，义项按受理meaningLanguage，locale与释义语言分开。所有动态内容文本转义，不v-html AI内容；现有本地图标模板复用。

### 文案、Token与资源

复用已实施的 `scripts/sync-design.mjs`：M003 copy已经采用 **zh./en.前缀**（FE01的语言后缀假设失效），含M002完整键及m003.*。保留现有m002命名空间/`useDesignCopy`的稳定调用；从本次完整copy按语言前缀去除、点→双下划线转换，新增键可继续用 `copy('m003.plan.note')`，不建第二套运行copy框架。保留已有@/|转义与模板变量。manifest记录本次UI10-R1 copy/theme/prototype及未受影响基线、M002资源hash及转换规则，运行产品不读取planning。

先复用M002本地Lucide/许可证、BrandMark和自定义选择/选词控件；生成图标只按实际需要补齐，不从网络加载字体/素材。theme的M002相对@import构建时合并成已有基础CSS＋M003增量，保留现有合法工程selector转换；不将planning路径留进发布产物，不复制demo场景条样式/fixture提示。准确copy键包括m003.plan.note、draft.*、pending.*、eof/protocol/recheck、incomplete、preview.incomplete、q02.confirm、content.*、impact、effect.*；原型演示专用prototype/fixturematch键不进生产流程。

### 布局、可访问性与性能

桌面设置310px、admin sidebar192px、preset列表240px沿M002；Plan/draft/final共用 `.m003-result-body` max-width760px/margin-inline:auto，无单边预留；窄屏铺满，Plan两列到≤760单列，正文行高桌面1.85/移动1.78，padding/间距逐值消费theme。不固定长正文高度，长文本wrap，不嵌套额外内缩。

≥1100、761–1099、≤760断点、44px目标、skip link、select/combobox/listbox/tabs键盘语义、可见焦点、alert与200%缩放按设计。reduced-motion停书写点，不给终稿打字动画。源码内不额外等待32字/句段或启动文字计时器，收到安全片段即归约；TECH03已处理的流上界与增量归约保持。仅做本需求必要性能检查，无新缓存/回放平台。

## FE3-08 Mock、验证与验收追踪

本节V01–13为**继承验收合同**：已有TECH03开发及独立QA证据见 [前端验证](../implementation/frontend-validation.md)、[QA报告](../verification/report.md)，CR304/305定向复验已PASS；不重置这些事实，也不让旧证据覆盖CR306新字段。V14–19为本次未执行的增量验收。复用 `tests/unit/generation-stream.test.ts`、`generation-reducer.test.ts`、`generation-lifecycle.test.ts`、`span-mapper.test.ts`、`admin-plan-policy.test.ts`、`token-vault.test.ts`，现有e2e mock-backend/generation-stream-backend/m002-admin-presets fixture。契约Mock从 [v5 fixtures](fixtures/stream-v5/index.json) 的wire/request/status取数据；不把expected/internal_evidence当应用输入，不重跑冻结旧checker证明新显示。`plan_hidden_on_first_edit`仅为旧历史断言，现TECH03按权威完整Result保留Plan；本次只补CR306相关边界与真实UI动作所缺fixture。

| 稳定ID | 合并场景与预期 | 来源 / 方法与证据 |
|---|---|---|
| FE3-V01 | 普通、N0、用户预设、后台basic均收到Plan→多片正文→完整valid；Plan不是最终词义，无增强内部阶段 | API-301/302/304；AC-301/306/307/315；UIA402.a/405.a；schema/mapper/reducer＋代表页面实点 |
| FE3-V02 | 增强固定编辑换稿、N1条件返修/上限定稿、N2两次；用户不见k/N，最终同包可保存 | AC-302/314/316；UIA403.a–405.a；wire驱动正文缩短/替换采样；实际调用分离由后端替身证明 |
| FE3-V03 | V2失败恢复V1、V4半稿→retained V3→final3，V4后审稿故障final4；同V基础续写换ID、rev不重置 | API-302；AC-303/311/313/316；纯reducer精确文本/版本/notice＋后端完整包证据 |
| FE3-V04 | Unicode emoji/跨UTF-8及多帧、尾插/删尾/替换/无变化新ID；紧邻重复NOOP；跳seq/错rev/range/复用ID/降版provider/错namespace/非法JSON/未知字段停止；合法大终态与越界 | API-302/304；AC-308；UIA403.a/404.a；parser与reducer定向测试，不为每错类截图 |
| FE3-V05 | EOF/pending保留Plan+稿；status完整valid原子恢复、result=null不清已有Plan且禁保存；10秒停止、手动一次、404/410、无token不自动POST；晚active/503与旧账号回调隔离 | AC-308/311/313；UIA406.a；可控时钟与请求计数/store集成；真实网络定向一条 |
| FE3-V06 | 七类增强故障的权威Q02保持notice；失败退款/取消不退款/结算未知三分；取消早于started、valid先赢、保存/claim之后晚status不重开 | AC-303/311/313；API-302/304；UIA405.a/406.a；契约替身+隔离后端CAS/保存证据，前端不复刻AI故障分类 |
| FE3-V07 | Pro0/Plus99独立往返；初始1来源后端；非法-1/100/小数/空/null/配对拒绝；NativePolicy只读；N0基础badge/N1增强；非管理员拒绝 | AC-304/314；API-303；UIA407.a；raw输入单测、实际表单＋保存后GET；99不跑流程 |
| FE3-V08 | impact两类人数分别显示（可重叠），真实前后N/生效边界；所有字段编辑和晚impact失效；local99/remote2冲突重读重预览；priority与丢响应先GET | AC-305/306；API-303；UIA407.a、CR303-01/02；表单/store/HTTP与DOM检查 |
| FE3-V09 | 后台basic0/enhanced1、先保存、旧mode晚完/旧run关联/切回/dirty/TTL不可ready；Q02确认后手动发布、GET及管理published保留notice；publish无confirmed | AC-309/313/314；API-304；UIA408.a/409.a；两个真实namespace fixture与GET关联/发布后重读 |
| FE3-V10 | usage null费用/发送未知分别呈现；后台无用户扣额、浏览无调用；同用户active冲突不替换已有有效终态 | AC-310/311/314；API-301/304；mapper/请求断言，统计与charge由后端/DB验证 |
| FE3-V11 | create/plans/presets完整页面与trial共享区准确copy/顺序/控件/图标；760px居中、1440/390与768/320无横溢；Plan和草稿共存、终态清理；节点/focus稳定、scroll差≤2px、44px/键盘/200%/reduced-motion | UIA401.a–411.a；规格＋运行DOM/几何/代表截图对照，不只比JSON；CR303生产态复核 |
| FE3-V12 | 记录合成首Plan/正文、换稿等待、无正文间隔与总时长并标合成；独立真实质量/时延/费用/容量保持未知 | AC-312；BE6-C04/C07；有限时间记录不等于线上目标达标，真实模型另需原授权 |
| FE3-V13 | 三POST明确busy保输入/既有结果/preview ready，Retry-After只解禁无autoPOST/status/本地扣退；generic503/坏body/未started EOF不声称未扣次 | API-302 busy/304；BE6-C03；仓储严格HTTP＋store/代表UI操作；不开展容量压测 |

N99只测配置/静态V上界101、102拒绝及preview3/4边界，N2才是最多流程执行；不生成99次事件来宣称链路覆盖。前端无法证明writer真的消费完整Plan或服务器一run一charge，AC-315/316与预算/原因统计须接后端AI3/BE3及DB3验证，不能用UI回放替代。

实施自检写既有 `implementation/frontend-validation.md`：Node24环境中typecheck/lint:boundaries、相关Vitest、定向Playwright、受影响格式/lint与build；依赖边界测试包括SSR请求隔离/mapper输出和视图不得接DTO。先相关失败修复后再跑必要整合，不无故重复全套。QA沿既有coverage/report/ai-evaluation独立验收权限/持久化/结算与质量，不新增测试管理文件。

有限浏览器证据：继承约13组业务边界（不要求本次重跑未受影响项）；主要操作用结构化断言，初始截图软上限8、送模4，覆盖三页桌面/窄屏和生成Plan+draft/final代表态；768/320/英文/200%与trial用几何、文本和动作补齐，发现视觉异常再按ID补图。比较同浏览器/视口/DPR/字体/语言/数据/状态，不能遮notice或停止全部动效后声称动效通过。已接收 [UI09-R3报告](../design/evidence/ui09-r3/cr303-report.json)及[UI09-R2源包](../design/evidence/ui09-r2/source.tar.gz)仅证明原型对应状态，不能替代生产Vue/网络/存储检查；无须重做已确认设计。

## FE3-09 实施任务、依赖与后端接点

T01–06保留稳定ID和已实施事实；本表只列CR306差异。旧任务实现/QA见上述证据，新增完成条件尚未验证。不新建竞争任务系统。

| 任务 | 现有基线与本次修改 / 完成条件 | 依赖 |
|---|---|---|
| FE3-T01 契约与传输 | v5/status/busy已实施；扩展FE3-11模型应用类型、严格对象schema、所有model序列化、mapper及安全Problem分支。管理缺custom字段应失败，公共DTO不新增字段；V14/V17/V19 | 新技术接收/实施门禁；BE07 API306与DB04配套，或明确标识的合同Mock |
| FE3-T02 流与终态 | v5/reducer/取消/pending已实施；仅接API306确定未受理generation_unavailable，按现有流消费5个CR306失败fixture，保留Plan/终态及CR304/305修复；V19 | T01；不重写AI流程/进度/计费 |
| FE3-T03 计划与模型管理 | 计划配置T03既有实现保留；模型新增raw解析/错误定位、model/provider draft与三方合并、显式probe代次与保存0调用；V14–17 | T01，API306；FE3-11/12明确边界 |
| FE3-T04 预设闭环 | basic/enhanced、关联ready/Q02已实施；只验证preview_timeout/未受理与参数改动后新请求快照；不把旧正文当当前ready；V19 | T01/02、BE07；API304原绑定不变 |
| FE3-T05 页面与资源 | UI09-R3已有页面保留；按FE3-12将R1 JSON区域接入现AppDialog/default/footer与每模型高级区，sync-design精确copy/theme，真实模态/焦点/手机；V18 | T03及R1视觉/R1.1合同源，FE3-14已接收其hash |
| FE3-T06 联调与交接 | 只补新增schema/解析/仓储/草稿单测及定向浏览器；隔离BE/DB验证保存读回、probe请求计数与失败；记录V14–19证据及未验证项到原implementation/frontend-validation.md | T01–05；backend-ethan完成BE7/DB4，frontend-claire有实施授权，再交qa-quinn |

后端接点为BE7-01/BE7-DB/AI7：严格校验/浅合入、全写入口0调用、Probe固定30秒/256、BindSpec同份快照、两run安全包、OR业务schema约束与180/600截止；FE不持有run私有snapshot，也不实现供应商路由。USER-M003-NO-DATA-MIGRATION覆盖早期DB0017升级建议；仅修改未发布schema并用可丢弃空库验证，不访问/重置现UAT。现TECH03已实现，不以旧delta描述驱动重建。

部署沿Nuxt node-server＋Go同源代理/会话；配套切换新增必填字段，不为旧客户端做缺字段默认。三路SSE原禁buffer/cache/gzip和排空规则保持，单副本/真实容量未测边界不变。本阶段不启动实现、服务或真实模型。

## FE3-10 当前自检、维护与未决

FE03就地保留FE3-01–10、T01–06、V01–13，新增FE3-11–14与V14–19；FE02过期源码状态和已完成等待步骤已替换。原始方案/交接两文件修订前快照及hash见075。唯一当前入口为[交接](../handoffs/frontend-architecture.md)，本轮[静态检查](evidence/cr306-fe/check.json)、[清单](evidence/cr306-fe/source-manifest.json)及[恢复包](evidence/cr306-fe/source.tar.gz)。上游manifest只作为输入版本，不复刻新权威合同。

仅执行文档/代码接点/链接/fixture/保护hash核对，未运行产品测试、浏览器、SQL、模型或修改UAT。原型R1模态报告只支持设计，不代表Vue/API已完成。保留CR-306 open、CR-302 downstream pending以及CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX原状态。真实质量/90%目标/速度/费用/容量仍未知；下一动作和具体文案依赖在FE3-14。新会话接续测试未执行；planning读取超8k软目标因模型全链路与严格边界核对，未全读历史；文件字符数仅作静态计量，实际tokens/usage unknown。

## FE3-11 CR306 模型配置的类型与严格解析

以下路径相对 `frontend/`，API-306 是字段/限额/保护名单唯一真源。选用现有 textarea 加纯应用解析模块；无需 Monaco/CodeMirror、JSON5、平台SDK或新状态框架。此处严格解析是防止管理员原文重复键被覆盖所必需，不扩成全站解析平台。

| 接点 | 增量与完成条件 |
|---|---|
| `app/application/shared/models.ts`、`ports.ts` | 在既有AdminModelModel/ModelConfigurationInput及NewModelConfiguration的Pick加入必填`customParameters: JsonObject`；ProviderConfigurationInput/ModelBatchConfigurationInput逐项继承，EditableModel也加入。JSON递归类型只含null/bool/finite number/string/array/object，无any；纯类型就近放拟增`application/admin/custom-parameters.ts`，供models引用；公共ModelOption/GenerationRequest/RunSnapshot不加此字段。AdminPort既有list/save/provider/probe签名复用，无新端点 |
| `app/infrastructure/http/schemas/admin.ts` | `adminModelSchema.custom_parameters`必填对象；子值为合法JSON递归值，数字/深度/字符串/体积同API。封套仍strictObject，只有custom对象内部允许未知非保护扩展键，不能对整份DTO改为passthrough；不能 `.default({})` 或null补空。列表、聚合、单项、保存、enable/disable及removal的共享AdminModelDTO都随之更新 |
| `app/infrastructure/http/mappers/index.ts::mapAdminModelDto`、`admin-provider-mapper.ts` | 验证后深复制为应用customParameters；聚合每个模型各自映射。DTO字段止于mapper，页面不读custom_parameters，不污染公开mapper。SSR仅admin私有结果且保持每请求隔离；raw草稿只在编辑会话内 |
| `app/infrastructure/http/repositories/api-repository.ts` | 实际模型写仓储在此，不是admin-configuration-repository。`modelBody`同时覆盖单项create/update/probe；`saveModelProvider`逐models行、`createModels` batch逐行都加入custom_parameters对象，不传raw字符串。batch共用connection临时input所需{}仅为本地构造，不是漏HTTP字段的默认兼容。setModelEnabled仍仅expected_revision；disable不因本地重验对象而被挡，服务端负责enable库对象校验 |
| `app/application/admin/model-draft.ts`、`provider-draft.ts` | `modelDraft/modelEntryDraft`初始化独立raw（建议`customParametersText`），现有modelConfiguration/modelBatchConfiguration/providerConfiguration只从已严格解析的当前raw得到对象；不得解析失败回退旧对象/{}。mergeProviderEntries按稳定modelId与本地key合并，见FE3-12 |
| `app/infrastructure/http/schemas/common.ts`、`mappers/problem-mapper.ts`、`application/shared/models.ts` | Problem.field_errors.field须允许API约定空字符串（当前nonEmptyStringSchema过窄）；错误code仍非空。按code/status严格校验409 current_revision:string、probe 422 upstream_status=400或422，以及确定未受理503 accepted:false；只映射具名应用事实，无任意context/detail透传。既有busy要求Retry-After/context一致不放宽 |
| `app/runtime/stores/admin.ts`、拟增 `app/presentation/admin/custom-parameter-presenter.ts` | 原AdminPort与会话epoch保持；局部presenter将安全field code→批准copy key/字段定位，不把Problem/DTO传模板。可用小函数就近放置，不建设通用表单引擎 |

### raw → 有效对象 → 请求快照

输入时保留raw并更新辅助计数/dirty/test stale，不在每次按键重格式化、不网络校验。`cr306.custom.size`的count仅在可严格解析时显示规范紧凑UTF8字节，否则为“—”；limit为16 KiB，不把无效raw字节称为紧凑大小。局部解析提示不得改raw或替代提交前整体验证。保存前校验全部模型，probe前只校验连接+目标模型；解析结果为带判别的成功对象或本地issue（code、JSON Pointer、可确证的源区间）。失败无HTTP，不构造半份provider配置。读取已保存值时可统一缩进2空格初始化；关闭后重开承诺值等价，不承诺原排版。表单raw、已保存对象、提交时深复制对象分别持有，禁止相互写穿。

解析模块采用有限递归下降/token扫描：读取完整RFC8259语法、字符串转义与合法代理配对；每个object保存**解码后的键**集合，构建对象前检测所有层级重复键，`enabled`与`\u0065nabled`必须冲突。只接受末尾JSON空白，根必须object；空文本、array、null失败。不要用正则扫描键，更不能先JSON.parse整文后检查。对象构造用安全字典/自有属性，不发生原型setter赋值；保护名单仍按API逐层执行。

数字先保留词法token，再检查有限双精度及数学整数安全界±(2^53−1)，指数/小数写法的整数也不能绕过；不可先Number舍入再判断原值。非整数按API双精度往返，NaN/Infinity/无效JSON数词拒绝。根深度1，object/array容器各+1，扫描超过8即时报告too_deep；解码后每层键和值禁止U+0000，字面`\\u0000`不误判。合法配对emoji/其他Unicode保留，不trim字符串内容。

通过语义校验的对象按规范紧凑JSON序列化，`TextEncoder`统计≤16384字节。raw长度不能当规范大小；空白/缩进很长不能仅凭raw长度判too_large；保存限额用紧凑UTF8，不用字符串.length。HTTP整包大小仍由仓储/服务端原32KiB/256KiB/2MiB处理，不能将每模型16KiB乘1000当允许总量。禁止自动截断、四舍五入、删字段或缩小对象后重试。

客户端按API归一键名（小写、去_/-）检查顶层保留及全树敏感/原型键；未知允许扩展保持原大小写和值，不把reasoning.max_tokens误判为顶层总输出冲突。API名单只在该模块一处实现并用合同fixture覆盖。具体受控body相交与平台能力/实际效果属于后端/上游最终校验，前端不复制各阶段body或推测支持矩阵。现有maxOutputTokens/outputMode控件仍唯一权威；不从JSON推导、同步或覆盖它们。

### 错误定位与保留

本地源区间只来自本次解析，可聚焦/选中确证位置；server只承诺JSON Pointer，不虚构行列。`/models/i/custom_parameters/...`按**发出请求时的有序entry key/modelId快照**定位，`/custom_parameters/...`绑定单项/probe目标；按RFC6901解码~1/~0，验证整数索引及前缀，不eval路径。输入已改、模型已移除、session/编辑代次已换的迟到结果不贴到其他模型；保留安全整单提示或忽略已失效probe。

定位到模型后展开其`.generic-model-advanced`，仅滚动父框`.dialog-body`并聚焦对应textarea；aria-invalid/aria-describedby连接错误且原因在帮助前。本地错误与server字段错误分开，修改本项清本项旧错误不清其他行。空field/父级/不可解析路径以及413是整单错误，不假定第一个模型错误，不显示提交值/未经转义路径/上游detail。U+0000键错误仅定位安全父路径，不回显非法键。

field code `invalid_json/duplicate_key/object_required/protected_field/controlled_field_conflict/too_deep/too_large/number_out_of_range/unsupported_character/required`对应批准copy；controlled_field_conflict复用protected说明，空raw用invalid_json，required缺字段属契约错误不能补{}。401/403交原认证/权限流；409保留本地并重读；413保留全表单；probe model_request_rejected绑定当前测试模型，不猜某个JSON字段；原auth/protocol/rate/unavailable分类保持。未识别错误用现有安全通用提示，不显示原Problem.detail。

## FE3-12 CR306 原生模态与草稿生命周期

映射 `PAGE-208/CAP-306/DATA-306/AC-317/318/322 → /admin/models → pages/admin/models.vue → model/provider-draft → AdminPort → API-306`。完整provider列表、原连接/凭据、模型基本字段、删除影响确认与计划引用保持。

| R1区域/行为 | 现有精确接点与本次处理 |
|---|---|
| UIA-M003-412.r1/413.r1 | `AppDialog.vue`保留id/open/title/closeLabel/notice/bodyKey、close/shown、header/default/footer slots、Teleport、showModal、feedback.modal和opener恢复；`#admin-model`用现title/default `.dialog-body`/`#footer`，不得绑定原生open属性替代showModal，也不新增全站modal实现 |
| 初始/关闭 | `openProvider(provider?)`复制**被点中的**provider和全部models；新建空连接+一个原默认模型，新增raw=`{}`，不沿demo enabled=true改现默认false。主框header关闭/footer取消/Escape/backdrop都进`closeModel()`；busy原门禁保留，框内点击不关闭 |
| UIA-M003-414.r1/415.r1 | 每个`.generic-model-item`仍`:key=entry.key`；高级区顺序maxOutputTokens→outputMode→JSON→description。新增`.custom-json-field/.custom-parameters/.custom-json-guide/.custom-json-error`；label/help/error按稳定entry.key唯一关联，不随删除索引错绑 |
| 增删模型 | `addEntry()`加独立{}并沿原模型ID焦点；`removeEntry()`只移除可移除的未保存条目，保持原至少一新行/1000行规则、邻行焦点。已保存模型删除仍走原removal-impact确认，不复制demo任意splice删除已保存模型 |
| UIA-M003-416.r1 | dirty快照包含每项raw，格式空白编辑也dirty；不以语义对象相等忽略用户文本。`model-discard`继续第二AppDialog，“继续编辑”不重建父草稿；放弃清文本/凭据/测试代次，最终返回精确provider触发点。依现组件先结束确认层再结束父层或验证同tick顺序，不能让确认层opener重抢到已关闭父框 |
| UIA-M003-417.r1 | `testConnection()`/`testEpoch`/sessionEpoch现能力扩展；每次测试冻结目标key+解析对象+全部连接/专用字段；编辑任一配置、增删、refresh、关闭、换账号让旧结果stale/迟到回调失效。显示明确stale文案，不能仅watch后静默消失。保存不要求probe成功、不自动probe |
| UIA-M003-418.r1 | 保留现`assets/css/theme.css`的`#admin-model[open]`flex、标题、dialog-body auto scroll、footer与backdrop；R1 720px上限/390实测354px为对照，沿现viewport安全边距，不写死370px。长JSON在控件内处理换行/滚动，页与框不横溢，textarea最小高桌面168/手机156，label/help/error/44px/reduced-motion按源 |

精确原型源为 `design/prototype/app.js::beginModelSession/jsonField/modelEntryView/paintModelDialog/requestModelClose`，样式/copy见FE3-07。旧R1的`raw||'{}'`已由R1.1纠正；当前fixture查找、JSON.parse、state=probe-ok、refresh仅清conflict与保存直接close仍是**合成演示适配**，不移植到Vue；空值、重复键、异步、实际保存读回按API及本方案。R1额外`.m003-model-dialog`样式只能定向转换到既有#admin-model，不全局改所有AppDialog。若共享组件确需修复焦点，仅以本模态真实失败证据驱动，并检查其现有使用处，不能顺带重构。

### 合并、保存及响应竞争

`baseline/local/remote`按当前modelId合并、DOM用原key。同一项raw未改才取remote规范化文本；本地改过（含非法/空白）原文保留，双方同时改同项仍显示冲突提示供管理员核对，不递归合并JSON对象制造第三种参数。远端新增模型并入，local新行保持各自raw；远端删除本地正在编辑的模型不能静默丢文本或重建同ID：保留未提交草稿/冲突提示，禁提交已删除ID，让管理员显式移除或按原新增路径处理。现mergeProviderEntries会直接漏掉无remote的旧行，T03必须补此受影响失败保留边界，无需扩建通用合并系统。

`refreshDraft()`必须GET真实当前provider，再按modelId三方合并并更新baseline/revision，令probe失效；保留本地key/raw/error，不能只把409 current_revision塞旧请求或自动再PATCH。保存点击时冻结全量合法body/ordered keys/编辑代次，busy锁表单且只发一次聚合POST/PATCH；任一模型错误全部保留，不认为其他行已保存。成功以响应映射/重读值更新列表并显示cr306.saved.*，然后关闭/清草稿，保存本身0模型调用；失败不清raw。响应丢失沿unknownCreate和GET核对，不盲重试创建/版本；只有真实当前读回支持“已保存当前配置”，不冒充原请求回执。

probe从列表取已保存model含customParameters，从编辑器取目标raw解析对象；固定256额度是服务端测试合同，不回写模型maxOutputTokens，不自动提高输出/去参数重试。合法但平台拒绝的JSON仍可保存；30秒短测试失败/成功均不替代完整预览和AC-321。多模型切换、旧请求晚结束、save成功后晚probe必须不能复活当前成功提示。

## FE3-13 CR306 流接收与增量验收

公开生成/用户预设/后台preview请求和`m003-stream-v5` SSE不增加custom参数；管理配置仅后台模型页可见，不进入学习者选项、SSR公共payload、URL/storage/analytics或日志。后端快照贯穿Plan/Writer/FixedEdit/native/Review/Rewrite；前端不能改变在途run、推测费用或回读配置覆盖其accepted状态。已有ready预览仅按API304当前draft/mode/run资格判断，模型配置更新不是私自追溯废弃旧run的依据；新预览用新快照，预设本地草稿变化继续令ready失效。

BE07的确定未受理分支是 **HTTP503 generation_unavailable + 严格context={accepted:false}**；与busy不同，无retry_after_seconds/Retry-After cooldown，不造run/token/status/扣次或退款，不自动POST，保留输入/既有独立结果和合法ready。泛503/COMMIT未知仍按FE3-04，绝不从code或网络失败单独认定未受理。仓储为此建立具名AppFailure映射，不放宽busy验证。

CR306 `streams.json` 的timeout→generation_timeout、fenced_plan→schema_error、cancelled、settlement_pending、preview_timeout只走现有失败/取消/pending路径。无公开内容时保持诚实等待，不伪造Plan/倒计时/百分比/内部推理；有已公开Plan/草稿时继续原保留策略。失败/取消清临时内容，pending不宣称退款/成功，valid完整包才建立资源；Q02/取消竞争/有限status、N0/1/2与99静态、CR305书写点及reduced-motion保留。

以下为CR306必需增量，均**未执行**，承接原FE3-V01–13并复用未变化证据：

| ID / AC / UIA | 场景与可观察完成条件 | 实施验证入口/方法 |
|---|---|---|
| FE3-V14 / AC317–318 / 414.r1–415.r1 | {}、多模型不同对象读回等价；缺/null字段严格拒绝；语法/尾随/全部层级解码重复键、空/array/null、代理、NUL与字面反斜线区别、数值指数安全边界、compact16384/16385、depth8/9；raw始终保留 | 新custom-parameters纯单测+现model-connections/strict-contracts；BE07 errors原fixture及边界配方作为期望，不能拿demo JSON.parse证明通过 |
| FE3-V15 / AC317/322 / 414.r1–416.r1 | 两模型分别编辑/新增/移除不会串raw；409三方合并按modelId，本地非法草稿/远端删除/晚GET保留；一次全组失败无行更新，丢响应先GET不自动重复POST | provider-draft.test.ts扩展；模型页实点+请求有序keys断言、服务端atomic独立证据，不用HTTP200替代刷新读回 |
| FE3-V16 / AC317/318 / 417.r1 | probe取当前目标对象/专用字段，任何配置编辑使旧结果stale；晚成功不翻新；422拒绝/401/429/协议失败正确且不显示原始上游；可不测试直接保存/无自动调用，固定256不改typed output | model-connections/m002-admin-contracts与mock请求计数；后端替身证明保存0供应商调用，浏览器0probe不等于服务器0调用 |
| FE3-V17 / AC318/322 / 415.r1 | `/models/1/custom_parameters/a~1b`定位第二模型；空field与413整单；本地offset可定位而server不造行列；移除/改动后晚错误不贴错模型；未知错误安全fallback | common/problem mapper+presenter/模型页DOM、textarea关联、raw逐字比较；不截图每种解析错误 |
| FE3-V18 / AC322 / 412.r1–418.r1 | 完整列表→第二provider/edit与add，:modal/top-layer、背景隔离、只body滚动且头尾固定，四关闭入口统一dirty、嵌套Tab/ShiftTab与继续/放弃/精确opener；1440/390、EN/长JSON/错误帮助顺序，无横溢与44px | 定向浏览器/DOM hit test/focus/scroll+代表视觉对照R1；不能仅检查[open]。初始截图软上限4（桌面/手机初始、JSON错误、叠层），送图2；失败再按ID补图；320/768/200%用几何及键盘补足 |
| FE3-V19 / AC319–320/322 | 5条CR306 wire接现v5，明确未受理与busy/未知不同；无参数泄漏或新学习者控件、无假进度/私有推理；取消/pending/timeout/Q02、Plan保留和完整valid资源不回归，旧preview资格按API | generation-stream/m003-generation-contract/admin-preview-lifecycle与现m003-live代表路径，原V01–13按依赖复用；BE负责同run参数快照/退款，FE不代证 |

本轮后续执行typecheck、lint:boundaries、相关单测与受影响浏览器/构建；沿项目Node24和现测试栈，不安装新编辑器/测试平台。AC319同快照、AC320实际截止/失败结算、AC321真实链路/费用由BE/DB/独立QA给证据；前端合成流不会证明原180秒故障已修复。只在变更触达原边界时扩验，达到本表即交接。

## FE3-14 当前接续与未完成事项

CR306-FE架构已形成，建议提交独立门检；本文件不切阶段或授权实现。当前无新增业务待决，UI owner已完成[R1.1合同勘误](../design/evidence/cr306-r1-clarification/M003-UI-10-R1.1-contract-clarification-manifest.json)，FE已核对源hash与6项有限证据并接收：too_large/413、compact计数缺值、空文本、probe固定256与非保存前置、只影响新请求快照。R1视觉包保持不变，无剩余owner合同阻塞。T01–06/V14–19均为后续实施/QA完成条件，保留CR306 open。

下一责任角色由控制流程激活：先接收FE03与技术组合，再由backend-ethan按BE7/DB4完成统一校验/快照及配套API，frontend-claire按T01→T03/T02→T04/T05→T06完成定向代码与证据，qa-quinn独立接收。真实复验及用户UAT沿原授权与责任边界另行接续；本轮不新增真实调用或用户批准请求。
