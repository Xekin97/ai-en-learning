# M003 TECH03 后端开发验证

日期：2026-10-12（CR-304 定向返修；原 TECH03 验证为 2026-10-10）  
owner：backend-ethan  
源码基线：`45a4ab123c3308fa0a83868b6030c6b84a96f67d`  
结论：CR-304 实现修复及定向开发检查完成，建议 `awaiting_review`；CR 仍为 open，须由独立 QA 复验。这不是 QA PASS、UAT、生产容量或真实模型质量结论。

## CR-304 定向返修验证

- 依据：`TRANSITION-M003-061`、`USER-M003-QA-NEXT`、`qa-fix-gate-060.md` 与开放的 `CR-304`。
- 缺陷：HTTP 503 `generation_busy` 已有 `Retry-After` 和 `accepted:false`，但 Problem context 缺少 API-302 必填的 `retry_after_seconds`。
- 修复：普通生成、用户预设、后台 preview 与模型 probe 统一调用同一个 busy response helper；helper 只计算一次重试秒数，并同时写入十进制 `Retry-After` 与整数 `context.retry_after_seconds`，保证二者一致。context 严格保持 `{accepted:false,retry_after_seconds:int}`，响应保持 503、`application/problem+json` 与 `Cache-Control:no-store`。
- 范围：仅修改 `generation_handlers.go`、`admin_handlers.go`、`capacity_test.go`，并更新本验证和后端交接；未改容量算法、配置、前端、QA 原件、批准契约或控制面。

| 命令 | 结果 | 证据 |
|---|---:|---|
| 三分支 busy 契约定向单测 | PASS，exit 0 | [`01-targeted-httpapi-tests.log`](evidence/cr304-fix/01-targeted-httpapi-tests.log) |
| `go test -count=1 ./internal/httpapi` | PASS，exit 0 | [`02-httpapi-unit.log`](evidence/cr304-fix/02-httpapi-unit.log) |
| 三分支定向 `go test -race` | PASS，exit 0 | [`03-targeted-race.log`](evidence/cr304-fix/03-targeted-race.log) |
| `go vet ./internal/httpapi` | PASS，exit 0 | [`04-vet.log`](evidence/cr304-fix/04-vet.log) |
| 最终格式、diff、归档和哈希核对 | PASS，exit 0 | [`05-static-and-artifact.log`](evidence/cr304-fix/05-static-and-artifact.log) |

新证据、最小源码包、逐文件哈希和当前源码回执位于 [`evidence/cr304-fix`](evidence/cr304-fix/)；原 TECH03 证据和源码 archive 未覆盖。

## 验证环境与数据边界

- Go：`go1.27.0 darwin/arm64`。
- 数据库：本轮自建、可丢弃的本地 PostgreSQL 容器；测试框架为每个 integration 用例创建独立空库并初始化当前完整 schema。
- 未对现有共享/生产数据库运行迁移或升级测试；未新增历史升级脚本。本轮只验证未发布 0017 作为当前空库 schema 的组成部分。
- AI：三协议本地 HTTP 替身及内存 provider；没有真实凭据、收费调用或外部质量批次。
- N=99 只做配置/约束/静态上界验证；流程执行限定 N0/N1/N2。
- 本轮自行创建的测试容器已停止并删除；清理结果见 [`14-test-resource-cleanup.log`](evidence/tech03/14-test-resource-cleanup.log)。

## 最终命令

| 命令 | 结果 | 证据 |
|---|---:|---|
| `go test -count=1 ./...` | PASS，exit 0 | [`07-unit-final.log`](evidence/tech03/07-unit-final.log) |
| `go test -race -count=1 ./internal/ai ./internal/capacity ./internal/generation ./internal/httpapi ./internal/observability` | PASS，exit 0 | [`08-race-final.log`](evidence/tech03/08-race-final.log) |
| `go test -count=1 -tags=integration ./...`（隔离空库） | PASS，exit 0；HTTP 包 177.610s | [`03-full-integration-final-pass.log`](evidence/tech03/03-full-integration-final-pass.log) |
| 增强用户生成三分支与增强 preview 的真实 Gateway+DB HTTP 闭环 | PASS，exit 0 | [`04-enhanced-http-final-pass.log`](evidence/tech03/04-enhanced-http-final-pass.log) |
| 受影响 P0 HTTP 矩阵 | PASS，exit 0 | [`05-p0-http-final-pass.log`](evidence/tech03/05-p0-http-final-pass.log) |
| commit ACK 与终态写失败复测 | PASS，exit 0 | [`06-commit-delivery-retest-pass.log`](evidence/tech03/06-commit-delivery-retest-pass.log) |
| `TestM003*` 当前空库 schema/约束/状态 | PASS，exit 0 | [`11-empty-schema-m003-final.log`](evidence/tech03/11-empty-schema-m003-final.log) |
| `go vet ./...`、两个命令入口 build、`git diff --check` | PASS，均 exit 0 | [`09-static-final.log`](evidence/tech03/09-static-final.log) |
| production Compose overlay 合并与静态断言 | PASS，exit 0；未 pull/build/start/deploy | [`10-compose-static-final.log`](evidence/tech03/10-compose-static-final.log) |

## 失败与修复轨迹

- 首轮完整 integration 为 exit 1：旧 continuation/evidence provider 未响应新增 Plan；旧本地持久化夹具未填写当前 v5 snapshot/usage；growth revision 写死旧初值。原始日志见 [`01-full-integration-initial-fail.log`](evidence/tech03/01-full-integration-initial-fail.log)。
- 第二轮为 exit 1：两个边界夹具在统一 provider 包装器已返回 Plan 后又重复返回一次 Plan，导致未到 commit ACK/terminal writer 注入点。原始日志见 [`02-full-integration-second-fail.log`](evidence/tech03/02-full-integration-second-fail.log)。
- 修复保留真实 v5 Plan、补齐当前事实夹具、按实际初始 revision 断言，并移除重复 Plan；没有删除测试或放宽生产终态事实校验。第三轮完整 integration exit 0。

## 核心行为验证

### AI 与 pipeline

- 所有模式使用同一绑定目标模型和连接，真实独立 planning→generation，Writer 接收完整 Plan；Plan item 覆盖动态条目及 zh/en/ja 定义投影。
- N0 无 fixed_edit/Review；增强先验证首稿事实但不消耗原生恢复，再固定编辑，之后 Review→条件 content_repair；内容预算与最多两次 technical_repair 独立。
- 安全完整但 schema 不合格的首稿可携带有界 machine errors 进入编辑；不可解码/未封口 JSON 不伪装有效。
- Q02 仅七类 stop reason；有 lastValid 才可 `service_incomplete`，取消、断流、DB/usage 未知不走 Q02。
- HTTP 增强闭环实际覆盖：正常四阶段 `review_passed/V2`；N2 两次返修到 `limit_finalized/V4`；第二次返修原生恢复耗尽后回退 `service_incomplete/V3/repair_native_invalid`；增强 preview 为 N1、四阶段、V2 且无用户 charge。

### 协议与增量流

- v5 只发送 started/progress/plan_item/edit/validated/failed/cancelled/settlement_pending；所有命名事件有 seq，整个 stream 使用连续 rev，每次尝试使用 draft_id。
- splice 使用 Unicode 码点；覆盖追加、删尾、替换与 retained 回退。
- 首个安全词边界立即 flush；独立 50ms timer 可在上游停顿时刷新安全前缀；128/2048 码点门槛及有界串行输出、反压均有测试。
- passage 提取为增量状态机，不对每片累计全文反复 JSON 解码；多行 SSE event 有总界；OpenAI chat/responses/Anthropic 三协议都要求明确正常终止事实。

### 数据库与终态

- 当前 0017 允许 Pro/Plus N0 或 N1–99，registered/visitor 固定 N0；v5 六阶段和七原因由 `IS TRUE` 完整组合约束保护。
- `CompletePipeline` 与 `CompletePreviewPipeline` 在同一终态事务锁定 run，核验连续 call_no、目标模型、prompt、provider_invoked、Plan→generation→fixed_edit→Review/repair 顺序、technical≤2、content≤N、末审结果及原因传递，再提交终态和完整包。
- 真实 provider_invoked true/false/NULL、prompt 版本与 usage 保留；一次业务只产生一个 consumed charge。
- `DiagnoseContentFrequency` 对 normal/preset/preview 分母分别计算 F、C、交集、并集、去重 run、调用次数和 unknown 上下界，并同时输出六阶段调用事实。

### 容量、清理与部署

- CapacityGate 在 run/charge/provider 前原子检查 draining、settlement health、global、preview=1、probe=1、preflight、connection group 与 cooldown；拒绝立即 503、Retry-After 1..600，无 run/charge/provider、无排队。
- 多 connection UUID 可映射到同一真实账户 capacity group；未映射连接可保守落入默认组。
- Release/ReleaseUnknown 使用同一 Gate 锁序，500 次并发回归无死锁；健康重开要求所有 pending 最小事实先确认。
- 普通/预设/preview 在取消或写失败后先 cancel/close/join pipeline，再 release；延迟退出替身验证槽不会提前释放。超过有界 join 时先标 settlement unknown，真实退出后才释放。
- 三路 SSE Nginx 均关闭 buffering/cache/gzip 并设置 75s；生产 overlay 固定 digest 镜像、单 backend 副本、资源硬界、20MiB×3 日志、650s/660s 停机窗口及明确 PG 参数。未部署。

### 最小观测

- 指标导出 active global/preview/probe/preflight/connection、active connection group、pending unknown、draining/settlement health。
- busy 原因使用固定白名单：draining、settlement、preflight、cooldown、missing connection key、global、connection、preview、probe；不含用户、密钥或连接动态标签。
- 记录 preflight guard completed/duration、入站请求、首 plan flush、首正文 flush、终态确认时间，并复用 stage duration、HTTP 与 PG pool 指标；不逐 token 写数据库。
- 增强真实 HTTP 用例读取独立 metrics handler，断言首 plan、首正文、终态、preflight 时长和 release 后 active=0。

## 过程复核反馈

root 的 12 项实施中反馈全部有代码和测试对应，详见 [`12-root-review-resolution.md`](evidence/tech03/12-root-review-resolution.md)。

## 未验证与限制

- 未验证真实模型质量、供应商特有输出、真实费用、RPM/TPM、429 实际额度或生产延迟。
- 未在 2C4GiB 生产资源约束下执行 10/20 档容量验收；本机与替身结果不代表生产容量，也不宣称 20 并发可用。
- 未执行真实部署、数据库升级、备份恢复演练、前端浏览器联调或独立 QA/UAT。
- 实际 serving model metadata 仍 unknown；本轮没有据请求路由宣称实际模型身份。
