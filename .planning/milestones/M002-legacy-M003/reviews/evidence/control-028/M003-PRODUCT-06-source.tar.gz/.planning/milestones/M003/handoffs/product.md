---
milestone: M003
stage: product-planning
role: product/to-c
agent_name: product-maya
status: awaiting_user_review
version: M003-PRODUCT-06
date: 2026-10-10
---

# M003 产品交接：研究对齐待决草案

product-maya 已完成研究基线审计、PRODUCT06与CR-302。结论：**需局部重策划生成机制，保留已有权益、管理、终态和正文编辑流能力。** 当前Q3-02未选，建议awaiting_user_review；不能把本草案称为完整可执行方案，不能继续依赖未确认分支的API/DB/UI或实现。

## 输入与确认闭环

- 入口：[TRANSITION-M003-029独立检查](../reviews/research-alignment-return-028.md)；当前product-planning / product/to-c / product-maya。用户授权为 [USER-M003-RESEARCH-ALIGN](../reviews/requirements-feedback.md#m003-research-align-调研基线与-m003-范围复核)，只要求审计与重策划建议，不批准新增调用或实施。
- 实际读取 [研究当前链路及规划/编辑章节](../../../../docs/research/short-passage-quality.md)、[scene-plan-v2](../../../../docs/research/content-quality/scene-plan-v2.txt)、[writer-v2](../../../../docs/research/content-quality/scene-plan-writer-v2.txt)、[final-editor-v1](../../../../docs/research/content-quality/final-editor-v1.txt)、[target-model-v1设计](../../../../docs/research/content-quality/preparation/target-model-v1-design.json)，以及运行/返修/交付统计摘要；未全量读取runs。
- **确认的纠正**：CQ-03不能证明用户取消规划或固定编辑。研究有真实规划输入与每篇实际编辑，BE04则直接首稿/校验/审稿/条件返修；具体证据与差异表在 [CR-302](../changes/CR-302.md)。研发输入已就地撤销错误推导，不改冻结研究证据。
- **建议而非确认**：A共同规划属于生成准备，增强N>0固定编辑一次独立于N；B普通直接生成，仅增强恢复完整研究机制。编辑前无调用校验保留有效初稿以承接Q02是新增适配建议，不能声称研究已经验证。普通不固定编辑，N0关闭增强内容处理；唯一选择见下。
- 保留N0–99/初始1/流程测试2、基础2只读与内容预算分离、同模型、上限定稿、Q02、唯一业务计次、原生保存/取消/断连/pending、basic0/enhanced1、修稿统计、LIVE-TEXT前进/回退/替换与后续成本观测。
- 沿用已读agt-product-planning及角色契约、Profile1.0/v1锁，请求gpt-6-astra/high，actual serving model/usage unknown，不迁移锁或控制面。

## 本次原始产物

- [overview.md](../product/overview.md)：D3-09待决与保留范围，撤销固定构思/编辑非目标。
- [data-assets.md](../product/data-assets.md)：规划候选DATA-305、临时拟用义项与最终释义、规划/编辑独立统计。
- [abilities.md](../product/abilities.md)：CAP-302/304/305，AC-308/312及候选AC-315/316；后两条明确未选前不执行。
- [pages/index.md](../product/pages/index.md)：现有完整页面保持，规划投影/语言是待接收依赖，不直接补原型。
- [ai-behavior.md](../product/ai-behavior.md)：研究机制/新Q02适配与旧技术公式分开，保留完整终态边界。
- 本交接；[CR-302差异表、影响清单与方案](../changes/CR-302.md)；[研发输入修订](../../../../docs/plans/content-review-and-repair.md)。

## 唯一待决问题（Q3-02 / OPEN，由主会话纯文字展示）

**M003采用A“共同规划、增强固定编辑”（推荐），还是B“仅增强走完整研究链路，普通直接生成”？** 若明确希望继续简化，可选C“规划/固定编辑都不恢复”，但它是主动偏离研究、未经等价验证的候选，不是默认。

A正常无修正调用普通2/增强4；B普通1/增强4；当前C普通1/增强2，技术补救与内容返修另计，不代表真实延迟或金额。A/B固定编辑仅N>0、每请求一次，建议不占N或基础2；初稿有效时留lastValid承接编辑故障Q02，没有有效稿仍失败。规划须真正进入writer，预览只是投影。所有这些关键语义在CR-302一并供选择，不拆成常规实现问题或开选择卡，尚未代填用户决定。

推荐A是因为规划在正文存在前组织场景，不属于对普通文章内容返修；实际改稿的固定编辑则归增强。这个解释合理但不是既有用户决定。最新研究14/20可交付中仅7篇独立通过、6篇有重要缺陷、1篇分歧，另6例执行器中断；历史19/20有强模型在线参与，均不能证明候选A或B已达质量目标。

## 后续责任与完成条件

CR-302的影响表是唯一具体接交清单。用户选择后product-maya先收敛选中分支，再交backend-alex复核实际规划输入、有界独立计划接收、固定编辑、N/基础预算/lastValid/故障、调用与usage、时限和版本身份。特别是BE04把稿件版本随内容返修次数推进，固定编辑加入后不能继续等同。编辑字段及规划schema由后端决定，产品不代写。

后端合同明确后designer-tony才补UI06真实规划投影/语言与正文流；frontend-bob同步FE；dba-diana只复核现有事实是否够用，不预设新表；implementer保留工作等待接收；QA区分流程、研究证据和实际质量/成本。原stream-v4可证明旧正文操作输入，不能证明规划/固定编辑已覆盖。不得直接以此草案切阶段或批准未来实施。

## 文档维护与检查

修改前六份PRODUCT05已与 [control026源包](../reviews/evidence/control-026/M003-PRODUCT-05-source.tar.gz) 逐字6/6一致。研发输入原文先保存至 [恢复快照](../product/evidence/research-alignment-06/research-handoff-before-product06.tar.gz) / [hash清单](../product/evidence/research-alignment-06/manifest.json) 后修订。PRODUCT05、[BE04/control024](../reviews/evidence/control-024/M003-BE-04-source.tar.gz)、[UI06源包](../design/evidence/ui06/M003-UI-06-source.tar.gz)及研究冻结原件保持。

本轮只做版本/链接/稳定ID、失效条款、保留业务章节、源包与未提交代码摘要核对；结果：六份PRODUCT06版本一致，96处本地链接/锚点无断链，原显式稳定锚点保留；CAP-303管理矩阵及AC-301–307/309–311/313–314逐字未变。研发输入恢复包/清单hash一致；PRODUCT05、BE04、UI06源包及BE04三份入口hash未变；625个backend/frontend已跟踪及未忽略工作文件的路径/内容联合摘要前后一致，未覆盖未提交代码。旧的禁止规划/固定编辑及无业务待决条款定向检索无残留。未跑新测试/模型/浏览器/服务或成本试验。角色已将输入超软预算范围收敛为研究指定章节、摘要和当前正文，没有递归runs；实际运行输入字符/token未知。

## 未决、风险与边界

- **OPEN CR-302 / Q3-02**：唯一关键用户选择；阻塞其依赖的专业设计和实现，不阻塞已完成的文档纠错。
- **未验证**：A/B分层效果、规划预览zh/ja、固定编辑故障适配、真实质量/费用/首内容/首正文/换稿等待、连接与CPU/RSS/GC等成本；不以调用数或研究通过率代替。
- 保留CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX及UAT独立事实。没有改技术/API/UI/FE/DB/业务源码/控制面/历史、没有提交/部署/真实收费调用或覆盖冻结证据。
