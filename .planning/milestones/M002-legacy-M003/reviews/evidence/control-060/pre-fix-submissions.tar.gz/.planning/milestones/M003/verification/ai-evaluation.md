---
milestone: M003
stage: verification
role: quality/base
agent_name: qa-quinn
status: blocked_on_implementation_fixes
version: M003-QA-01
result: protocol_and_persistence_only
blocking_changes: [CR-304, CR-305]
date: 2026-10-12
---

# M003 AI 验证范围

本轮没有调用真实付费模型，也没有执行自然语言质量评测。`AI-QUALITY-90` 继续为 **UNVERIFIED**；合成 provider 的通过不能证明文章自然度、真实模型遵循率、费用或生产容量。

## 已证明的 AI 流程合同

真实 Go HTTP/SSE、一次性 PostgreSQL 与确定性合成 provider 证明以下工程行为：

- basic N0 只有 planning/generation，终态 `basic V1`；enhanced N1 pass 有 fixed edit/review，终态 `review_passed V2`。
- Q02 在完整有效包仍存在时得到 `service_incomplete V2 + content_review_incomplete`，可 status 恢复并保存；Unknown usage 与数字 0 分开。
- enhanced N2 定向运行得到 `limit_finalized V4`，顺序为 planning、generation、fixed edit、三次 review 与两次 repair；公共流不泄露内部 review/repair 轮次。
- v5 snapshot/splice/replace、Plan 先于 writer、完整 Result、一次扣额、错误 token 隐藏与持久化调用链符合已批准合同。

结构化原件为 [`api-results.json`](evidence/qa-m003-001/api-results.json)、[`db-facts.json`](evidence/qa-m003-001/db-facts.json) 和 [`n2-method-retest-final.json`](evidence/qa-m003-001/n2-method-retest-final.json)。

## 牵强与矛盾频率的证据边界

用户明确要求的“用词牵强/前后矛盾触发返修频率”按批准口径从实际持久化 reason 读取。本轮一个合成 N2 运行记录两次 repair；每次 reason 都为 `forced_wording` 与 `contradiction`。按文章去重后的观测为：分母 1、forced 分子 1、contradiction 分子 1、交集 1、并集 1、repair calls 2。

这证明 reason category、调用链和按运行去重的统计输入可成立。样本是人为触发的单个合成运行，不能作为真实内容中的发生率、模型质量趋势或生产基线。

## 方法更正

首轮 N2 没有进入 repair，是因为合成 Review finding 引用的句子并非待审正文精确子串；产品正确拒绝了无效 finding。只修正合成 evidence 为精确引用、保持产品源码不变后，N2 全部目标通过。首轮与两次定向失败均保留，见 [`method-corrections.json`](evidence/qa-m003-001/method-corrections.json)。

N1 Q02 首轮失败来自 QA 将 required notice 错绑到“必须保留先前 frame”。批准合同要求完整有效包、终态与 notice，不要求在当前完整包已经有效时保留旧 frame。原始事实本身已经满足 Q02，未据此创建产品缺陷。

## 未验证

- `AI-QUALITY-90` 及长期成功率、自然度、词义准确性、文化与年龄适宜性；
- 真实供应商协议波动、真实 token/费用、收费准确性与账单；
- 生产 10/20/50/100 容量、延迟分位数、生产代理与告警；
- 99 次返修执行。本轮只验证 N=99 配置存取和影响失效，实际流程到 N=2。

CR-304/305 是 API/UI 实现阻塞，不改变上述 AI 证据边界。修复后无需扩大真实模型调用范围。
