---
milestone: M003
stage: verification
role: quality/base
agent_name: qa-quinn
status: blocked_on_implementation_fixes
version: M003-QA-01
result: not_started
blocking_changes: [CR-304, CR-305]
date: 2026-10-12
---

# M003 用户验收清单

当前不提交用户验收。独立 QA 已确认 [CR-304](../changes/CR-304.md) 与 [CR-305](../changes/CR-305.md)，必须先由实现角色修复并由 QA 定向复验通过。以下清单已准备，状态均为 **NOT RUN**；自动化与合成 provider 证据不代替用户接受。

## 修复后的最小 UAT

1. **普通生成与 Plan**：用普通账号选择两个词生成短文。确认先看到可读 Plan，再看到连续草稿；两区有明确书写状态，正文更新不抢焦点；完整结果到达后临时 Plan/草稿消失，结果可保存。
2. **增强 pass / Q02**：用有增强权益的账号分别体验正常通过与“内容审校未完成”结果。确认 Q02 明确提示但完整结果仍可保存；刷新或断线后检查状态仍得到同一权威终态。
3. **busy 恢复**：在一个生成已经受理时从另一身份发起生成。确认本次未开始、输入保留、显示等待秒数；倒计时结束只重新允许点击，不自动再次提交。
4. **套餐配置**：管理员分别查看 Pro/Plus。确认 native correction 固定为 2 且不可编辑；内容返修 N 可设 0–99，Pro 与 Plus 互不影响；影响弹窗分开显示 base 与 active trial，不求和。
5. **后台预设**：选择 Enhanced generation 生成预览。确认 Plan 与连续草稿共存；Q02 时必须明确勾选确认才能发布，发布后提示保留；Unknown usage 不显示为 0。
6. **可访问与布局抽查**：只用键盘完成上述主操作；在 200% 和窄屏查看 create/plans/presets，无水平滚动，焦点可见；开启减少动效后书写点停止运动但状态仍可见。

## 接受记录

- 用户执行日期：待定
- 用户使用环境：待定
- 逐项结果：待定
- 用户原文与授权编号：待定
- 保留限制是否接受：待定

用户 UAT 前置条件为 CR-304/305 的实现回执、QA 定向复验 PASS、可供用户操作的当前版本入口。QA 不代填用户结果，不据当前自动证据宣称里程碑已接受。
