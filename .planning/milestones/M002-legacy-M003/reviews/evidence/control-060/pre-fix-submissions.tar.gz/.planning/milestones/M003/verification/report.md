---
milestone: M003
stage: verification
role: quality/base
agent_name: qa-quinn
status: blocked_on_implementation_fixes
version: M003-QA-01
result: fail
blocking_changes: [CR-304, CR-305]
date: 2026-10-12
---

# M003 独立 QA 报告

## 结论

本轮独立 QA 当前 **FAIL，阻塞于实现修复**。确认两项产品缺陷：[CR-304](../changes/CR-304.md) 的 busy 503 Problem 缺少 API-302 必填 `retry_after_seconds`；[CR-305](../changes/CR-305.md) 的真实 Plan/连续草稿缺少批准书写点。其余计划范围已有最短充分证据通过，首轮方法错误未转成产品缺陷。

QA 不修改生产源码、不关闭 CR、不切阶段。修复后只需执行 [`coverage-matrix.md`](coverage-matrix.md#定向复验范围) 两组定向复验；未受影响证据按已核对实现版本与依赖关系复用。

## 接收版本与运行方法

当前验收输入为 M003-PRODUCT-07、TECH-03、FE-02、UI09-R3，视觉继承 UI09-R2/M002。[`implementation-receipt.json`](../reviews/evidence/qa-start-059/implementation-receipt.json) 证明 QA 接收时当前 100 个后端和 45 个前端源码文件与接收包逐文件 hash 一致。独立栈使用随机端口 52388–52392、一次性空 PostgreSQL、合成 provider、真实 Go/Nuxt 与 headless Chromium。

API 首轮共 54 个结构化检查：48 原始通过，1 项确认 CR-304，1 项 N1 Q02 为 QA 断言错误，4 项 N2 同属合成 evidence 不精确的单一方法根因。修正方法且不改产品源码后，N2 `limit_finalized V4`、2 次 repair、3 次 review、reason 持久化和公共流隔离均通过。浏览器最终共 31 项：30 通过，1 项确认 CR-305。

## 已通过行为

- 普通 N0 与增强 N1/N2 均有真实 Plan→writer；SSE seq 连续，v5 snapshot/splice/replace 与完整 Result 可归约；N2 到 2 次返修并最终 V4，内部轮次不暴露到公共流。
- N1 pass、Q02 的终态、notice、status 恢复、错误 token 隐藏与 Q02 保存通过；每个运行只扣一次，usage Unknown 不被当成 0。
- native correction 固定 2 且只读；内容返修 N 为独立字段。Pro 2 与 Plus 99 独立往返；非法边界、非管理员访问、stale revision 和重预览行为符合合同。
- 用户所指“用词牵强/前后矛盾”按实际持久化 reason 核对：同一合成 N2 运行的 `forced_wording`、`contradiction` 分子、交集/并集均按文章去重为 1，repair call 为 2。该观察证明统计口径与事实链，不是质量频率估计。
- 后台 preset enhanced Q02 以键盘选择，Plan/草稿共存，Unknown 与 0 分开；发布按钮先禁用，勾选明确确认后可发布，发布后 notice 与列出结果保留。
- create/plans/presets 在 320/390/768/1440 无横向溢出；Plan/草稿阅读列 704px、左右各 28px；Home 链接在 Plan→草稿变化后保持焦点；有效终态清除临时 Plan/草稿；200% emulation 无溢出且受影响目标高度 ≥46px。

## 失败

| CR | 期望 | 实际 | 影响与责任 |
|---|---|---|---|
| CR-304 | busy 503 的 `context.retry_after_seconds` 为 1..600 且与 `Retry-After` 一致 | header 为 5；body context 只有 `accepted:false` | 严格前端无法可靠解析可恢复 busy；implementation / backend-ethan |
| CR-305 | Plan 与连续草稿显示批准的三点书写状态，正常有动画，reduced-motion 停止 | 两区 DOM 书写点总数为 0；现有 CSS 没有实际节点可作用 | FE3-V11 动效与减弱动效合同不完整；implementation / frontend-claire |

## 方法更正与原件保留

所有首轮失败、脚本错误和定向尝试保留在 [`evidence/qa-m003-001/`](evidence/qa-m003-001/)，未覆盖原件。完整判定链见 [`method-corrections.json`](evidence/qa-m003-001/method-corrections.json)。DOM 结构可与原型不同；最终没有把 `.plan-item` 类名差异列为缺陷。批准 copy 是 `Preset title`、`Essential generation / Enhanced generation`，最终定位以这些可访问名执行。

代表视觉只保存 7 张截图，低于软上限 8；送模查看 2 张。截图用于 Plan/草稿、plans 窄屏、preset Q02 和 200% 代表态，其他判定使用结构化 HTTP/SSE/DB/DOM/几何信号。

## 未验证与范围边界

真实付费模型、自然语言质量与 `AI-QUALITY-90`、真实费用/账单、生产容量/部署/迁移、真实供应商波动、生产 SSE 代理、真机输入法、人工读屏和人工 200% 专项均未验证。合成 provider 结果不能外推这些结论。99 仅验证配置与影响，不执行 99 次返修。

## 资源清理

provider、backend、frontend 均已停止，PostgreSQL 正常退出；52388–52392 全部关闭，一次性工作目录已删除。原件为 [`local-stack-cleanup.json`](evidence/qa-m003-001/local-stack-cleanup.json)。当前没有 QA 服务、端口或临时数据库留待接管。
