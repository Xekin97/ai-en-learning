---
milestone: M003
stage: verification
role: quality/base
agent_name: qa-quinn
status: blocked_on_implementation_fixes
version: M003-QA-01
result: fail
blocking_changes: [CR-304, CR-305]
date: 2026-10-12
---

# M003 独立 QA 覆盖矩阵

## 范围、方法与证据预算

本轮验收 `M003-PRODUCT-07 / M003-TECH-03 / M003-FE-02 / M003-UI-09-R3`，视觉基准为已批准 `M003-UI-09-R2 / M002`。源码版本复用 [`implementation-receipt.json`](../reviews/evidence/qa-start-059/implementation-receipt.json) 对 100 个后端、45 个前端文件的逐文件 hash 零漂移结论，不机械复跑开发单测、lint、typecheck 或 build。

执行使用新证据目录、随机独占端口、一次性空 PostgreSQL、真实 Go/Nuxt/Chromium 与合成 provider。截图保存 7 张，低于软上限 8；实际送模查看 2 张，低于软上限 4。合成 provider 仅证明协议、状态与持久化，不证明自然语言质量、真实费用、真实供应商表现或生产容量。

| QA ID | 批准验收 / 覆盖 | 实际场景与判定方法 | 结果 | 原件 / 阻塞 |
|---|---|---|---|---|
| M003-QA-S01 | AC-301/302/303/308/311/313/315/316；FE3-V01–06 | 普通 N0、增强 N1 pass、N1 Q02、N2 两次返修；真实 HTTP/SSE、v5 snapshot/splice、Plan→writer、固定编辑/Review/repair、完整 Result、notice、保存、一次扣额与 DB 调用链 | **PASS** | [`api-results.json`](evidence/qa-m003-001/api-results.json)、[`n2-method-retest-final.json`](evidence/qa-m003-001/n2-method-retest-final.json)、[`db-facts.json`](evidence/qa-m003-001/db-facts.json) |
| M003-QA-S02 | AC-308/311/313；API-302；FE3-V05/06/13 | N1/Q02 status 恢复、错误 token 隐藏、受理前单槽 busy 503/Retry-After；响应按严格 Problem 契约判定 | **FAIL / BLOCKED** | status/token 通过；busy body 缺 `retry_after_seconds`，见 [CR-304](../changes/CR-304.md) |
| M003-QA-S03 | AC-304/305/306/314；API-303；FE3-V07/08/11 | Pro/Plus 独立 2/99 往返、native2 只读、−1/100/小数/null/enabled0/native写入非法边界、双人数不求和、编辑使 impact 失效、409 后重预览、非管理员拒绝 | **PASS** | API/DB 见首轮原件；真实浏览器 impact/布局见 [`browser-results-final.json`](evidence/qa-m003-001/browser-results-final.json) |
| M003-QA-S04 | AC-309/313/314；API-304；FE3-V09/10/11 | 后台 enhanced Q02 真实 preview SSE；Plan/草稿共存；Unknown 与 0 分开；明确勾选后发布；notice 发布后保留；键盘选择 mode | **PASS** | [`browser-results-final.json`](evidence/qa-m003-001/browser-results-final.json)、[`11-preset-q02-390.png`](evidence/qa-m003-001/11-preset-q02-390.png) |
| M003-QA-S05 | AC-310/314；CAP-305；BE3-V10 | N2 同一运行实际持久化 reason category；按运行去重核对牵强/矛盾分子、交集/并集和 repair 次数 | **PASS（合成事实边界）** | 单个定向运行：分母 1，forced 1，contradiction 1，交集/并集均 1，repair calls 2；[`n2-method-retest-final.json`](evidence/qa-m003-001/n2-method-retest-final.json) |
| M003-QA-S06 | UIA-M003-401.a–411.a；FE3-V11 | create/plans/presets 真实浏览器：键盘、稳定焦点、200% emulation、320/390/768/1440、≥44px、reduced-motion、Plan/草稿共存与终态清理、760px 对称阅读列 | **FAIL / BLOCKED** | 30/31 通过；真实 Plan/草稿缺批准书写点，见 [CR-305](../changes/CR-305.md) 与 [`09-create-plan-draft-final.png`](evidence/qa-m003-001/09-create-plan-draft-final.png) |

## 首轮失败与方法更正

首轮 [`api-results.json`](evidence/qa-m003-001/api-results.json) 固定保留 54 项中的 6 项失败。`busy_503_before_acceptance` 是 CR-304；N1 Q02 的 1 项是 QA 把必需 notice 错绑到“必须保留先前 frame”，原始响应已具备 `service_incomplete + content_review_incomplete`、status 恢复和保存通过；N2 的 4 项来自合成 Review 引用并非待审正文精确子串，产品按合同拒绝了无效 finding。仅修正合成证据后，N2 定向复验全部通过。

浏览器初轮和两次方法尝试也原样保留。原先要求原型 `.plan-item` 类名、用 body 文本推断焦点、假定关闭 dialog 必须留在 DOM，以及使用非批准 radio 文案，均不是产品合同。最终改为实际视觉/交互结果、稳定 Home 链接焦点、hidden-or-unmounted 和批准 copy `Essential generation / Enhanced generation`。更正链见 [`method-corrections.json`](evidence/qa-m003-001/method-corrections.json)；最终只剩 CR-305。

## 定向复验范围

| CR | 修复后最短复验 | 复用依据 | 通过条件 |
|---|---|---|---|
| CR-304 | 单槽环境保持一个已受理请求，再以另一身份提交普通生成；检查 HTTP 503、Problem、`Retry-After`，并在严格前端观察保输入/倒计时解禁且无自动重 POST | 其余 N0/N1/N2/status/token/保存/计费证据与 busy body 字段无依赖 | body `context.retry_after_seconds` 为 1..600 整数且等于 header；`accepted:false`；前端严格解析与行为通过 |
| CR-305 | 普通 create 与后台 preview 各观察 Plan→连续草稿；正常 motion 检查 3 点存在并有批准动画，reduced-motion 检查同节点静止；复核焦点不丢和终态清理 | 所有布局、键盘、横溢、200%、Q02发布证据可复用 | 两处适用页面呈现批准书写点，`aria-hidden`，正常动画存在，reduced-motion 停止；无焦点/清理回归 |

## 明确保留与未验证

- `AI-QUALITY-90`、`CR039-L1`、`CR042-L1`、`W01`、`QA26-MINIMAX` 状态不变。
- 未调用真实付费模型，未验证自然语言质量、真实费用、供应商波动、生产 SSE 代理、生产迁移或 10/20/50/100 容量。
- N 流程实际执行到 2；99 只验证配置存取和影响失效，不执行 99 轮。
- 200% 是 Chromium viewport/screen/DPR emulation；没有真机、人工读屏或人工缩放专项，因此不冒称这些范围通过。
