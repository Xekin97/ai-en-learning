---
milestone: M003
stage: technical-design
role: backend-architect/base
agent_name: backend-alex
status: awaiting_user_review
version: M003-BE-05-R1
date: 2026-10-10
input_version: M003-PRODUCT-07 / CR-302 / M003-DB-03 / M003-BE-04 / M003-FE-01
---

# M003 研究链路对齐与真实规划、编辑流交接

backend-alex依 [TRANSITION-M003-031](../reviews/research-alignment-backend-030.md)及用户Q3-02-A完成BE05，建议awaiting_user_review/for-prototype。未改控制面、不自批或激活下个角色。沿锁定requested gpt-6-astra/high，actual serving metadata未知，Profile1.0/model-routing-v1不迁移。七份当前原件均BE05-R1，BE05/control032、BE04/control024及v3/v4/v5原件保留。

## R1定向接收：规划保留到最终结果

依 [TRANSITION-M003-037](../reviews/planning-retention-backend-036.md)与USER-M003-PLAN-RETAIN完成显示生命周期修订：初始规划与正文同时保留，贯穿首稿/固定编辑/条件返修/retained/pending/EOF；标明“初始构思，文章和实际用法可能调整”。权威validated或status valid**完整Result**到达（含Q02）才移除规划并建立最终学习资源；失败/取消清临时内容，新请求清旧。仅状态valid但无Result不得从partial重建或宣称资源可用。

仅复用现有m003-stream-v5 wire；无新LLM、字段/事件、后端留存缓冲、DB、计费、版本或恢复预算变化。DB03已完成设计接收，本次不重开DB审计。新证据：[R1显示政策](../technical/evidence/be05-r1-display-policy.json)、[限定检查](../technical/evidence/check_be05_r1.py)、[检查结果](../technical/evidence/be05-r1-check.json)。旧v5 expected.plan_hidden_on_first_edit及其checker为冻结历史断言，已被本次用户反馈覆盖；不能据旧PASS声称当前显示验证。

交designer-tony形成UI07-R1：保留已有wire/reducer，edit只更新正文不清plan，Q02 retained同样保留至最终valid整包；正常/增强与preview basic/enhanced一致。原型不得读取expected驱动UI。定向浏览器验证规划在首片/换稿/恢复/pending/EOF仍可见、成功清理、失败/取消清理及新请求隔离，之后仍需用户视觉评审；FE同步同一显示政策。

## 已确认内容方向与本版技术选择

[PRODUCT07](product.md)/[CR-302](../changes/CR-302.md)已确认所有模式独立规划→把完整实际Plan输入writer→首稿。普通/N0/后台basic只走既有原生校验/基础恢复；增强N>0先做初稿无调用原生校验，再必经一次实际固定编辑，之后原生校验/同模型审稿与条件整稿返修。不能用一句prompt取代规划，不能仅Review拒绝时才编辑。编辑允许整体重构，不受旧plan限制。正常普通2、增强4次模型调用；加条件返修k和全请求基础t≤2为4+2k+t，仍一请求一业务次数，N0–99/初始1/流程最多验证2轮、原限时/Q02/取消边界不变。

具体schema、事件形状、编辑可救输入边界和有界解析属于BE05待整版评审技术设计，不冒充用户逐字段批准。完整正常接收、安全非空passage的已知Candidate对象可带缺失/错误tags、targets或原生诊断交固定编辑；截断传输、畸形/重复/未知键JSON、不安全正文不能冒充完整稿。增强编辑前不花基础恢复，有效首稿才成为lastValid；编辑技术故障有包则Q02、无包则失败。没有新业务OPEN，不重问选择A。

逐个已完成场景/词用法投影`plan_item`，所选zh/en/ja暂定义项来自同一次规划；完整Plan含participants/facts/beats/全部用法，完整校验后确实输入writer。初始规划在正文增量/换稿期间持续保留并标为可能调整；权威valid完整Result到达才移除临时预览。沿v4的单后端splice真实前进/删尾/换稿/retained，模型仍产出Candidate，后端算偏移；不增加CRDT、展示调用、译文调用、每tokenDB或活动稿回放。

业务版本首稿1、固定编辑2、随后条件整稿任务递增，基础恢复同V另attempt/draft_id。增强两轮可到4；新半稿失败可回退最近完整有效V。Q02恢复后持续notice且可保存；取消/下行断连/DB未知不冒充成功。

## 当前直接原件与证据

- [后端设计](../technical/backend.md)：BE3-01链路，BE3-03/BE5-DBA精确DB依赖，BE3-08代码接收，BE3-09成本/有界队列与观测。
- [AI任务设计](../technical/ai-integration.md)：AI3-01状态机/编辑输入边界，AI3-PLAN结构/语言/完整输入，AI3-02七类Q02，AI3-03完整研究模板组装，AI3-05六stage用量。
- [API索引](../technical/api/index.md)、[生成/状态](../technical/api/generation.md)、[管理](../technical/api/administration.md)、[预设/预览](../technical/api/presets.md)：m003-stream-v5，8种事件/命名空间，新增真实规划临时条目，保留splice和终态。
- [v5入口](../technical/fixtures/stream-v5/index.json)、[完整包](../technical/fixtures/stream-v5/packages.json)、[生成脚本](../technical/evidence/build_stream_v5_fixtures.py)、[检查脚本](../technical/evidence/check_stream_v5.py)、[检查结果](../technical/evidence/stream-v5-check.json)、[保留hash基线](../technical/evidence/stream-v5-preservation.json)。wire为完整SSE data，不省字段；playback时间仅合成回放，不代表真实API延迟。

## dba-diana 接收合同（DB03已接收的BE05范围）

以下BE05依赖已由 [DB03交接](database.md)接收；待审0017/代码仍需后续实施，本次R1无数据库变更。

1. `ai_call_usage.call_stage`在原generation/technical_repair/content_review/content_repair上增加`planning`与`fixed_edit`，legacy历史不变；两新stage无review verdict/reason_codes/repair_requested，prompt版本和实际发送证据仍必需。
2. 两run表final_content_version针对v5 pipeline改为N0=1、N>0≤N+2；用户最大101，后台enhanced最大3。review_passed正常final2；编辑故障保留首稿可incomplete final1。完整包身份是来源，不能按调用数/返修数倒算版本。已有v4/legacy不能改写成v5事实。
3. `content_stop_reason`加`fixed_edit_native_invalid`（编辑完整输出原生无效/可修预算耗尽）；其网络/协议/限流/超时沿原原因。规划故障无有效稿直接失败，不用Q02 stop_reason。取消/DB未知/下行断连例外保持。
4. 分开规划、固定编辑与缺陷触发条件返修的实际调用/费用/统计；F/C/W只由真实content_repair原因计。DBA判断0017是否已应用并选修候选或新迁移，保留旧数据，不重seed、不默认加计划表/字段。仓储/启动校验与后端完成事务随后由实施owner接续。

## designer-tony 接收合同

原型必须实际读取v5 wire自动播放，internal_evidence/expected只供检查，不能驱动UI。不是从终稿切片造打字；原v4增量reducer可复用，须加入真实规划事件和新业务版规则。

| fixture | 必须可直接观察的结果 |
|---|---|
| basic | 真实完成scene/每词本篇义项依序出现；完整plan送writer；多帧只读首稿，规划与多帧正文同时保留，最终权威valid完整包到达才移除规划并建立学习资源/保存 |
| enhanced-edited-pass | 英文预览，首稿后固定编辑新稿首片才切换，内部Review无正文保持文章，最终V2（不显示V） |
| rewrite-once / rewrite-twice | 编辑之外1/2次条件整稿返修，多片切稿且有实际删尾帧，最多合成2轮，不展示k/N |
| edit-fault-retains-first / rewrite-recovery | 新partial撤回，source=retained恢复最近整包有效稿，再validated＋持续内容审校未完成notice；最终版本允许回退 |
| invalid-first-edit-rescues / invalid-first-edit-fails | 日文暂定义项；首稿无效仍可编辑救稿；编辑失败且无lastValid则清草稿/不可保存/退款，不能拼partial交付 |
| planning-fails | 已有局部临时预览但完整计划缺词失败，清预览，无writer或“跳过规划” |
| native-continuation | 同V另draft的实际续写；仅标注纠错不复播正文 |
| pending-status / eof-unknown / cancelled | DB未知先禁保存、有限状态核对；EOF不是完成；取消清临时内容不退款；active不恢复逐token |
| preview-basic / preview-enhanced | 独立preview namespace、各自真实planning，basic没有编辑/Review、enhanced固定编辑；valid后仍另核当前AdminPreset draft_version/mode/run关联才ready/可发布 |

临时预览只展示scene.text和word_use的entry/form/sense/phrase，明确暂定可调整；不显示role解释/私有Review/步骤计数，不能把sense存为entry_meaning或带到切稿后的学习提示。所有草稿只读，无词义高亮/hint资源，最后完整Result原子对齐。seq/rev/draft/plan identity和Unicode码点供reducer，技术字段不做用户进度。

语言三个fixture只是设计内容，不证明模型语言质量；合成playback只调度已列wire，未知等待不造百分比/假阶段。保留完整页面、正常生成按钮/取消代次隔离/阅读位置，后续视觉评审仍必要。preview无用户quota/can_save，不能混用用户保存资格。

## 其余owner精确依赖

| owner / 追踪 | 接收范围 |
|---|---|
| product-maya / CR-302，D3-09、DATA-305、CAP302/304/305、AC315/316 | PRODUCT07选择A已对齐，不回改其冻结原件；本版具体planning projection/保留至最终完整结果/编辑输入故障边界供产品owner核对措辞与验收，若产生实质新业务才重新澄清 |
| frontend-bob / FE01 FE3-03/04/06–09、FE3-T01/02/05、FE3-V02–06/09/11/12 | 接收BE05-R1及UI07-R1；新增plan_item临时状态/保留至权威valid完整包、新版本界/两个preview模式；保留v4编辑增量、请求epoch/有限status与保存终态，不从内部阶段编动画 |
| backend-ethan / 待审BE02源码，BE3-08 | DB03已接收，仍等待后续实施授权；新增真Plan/task schema/full input、fixed editor、安全完整输入分类、版本分配、六stage/七reason和lastValid、局部增量parser与预算tests；现代码不算BE05实现 |
| designer-tony / 当前UI原型与UI交接 | 旧实现按v4正文流但缺共同Plan/固定editor含义；按上表实际消费v5，中间JSON/版本/计数不露出；不能继续BE03词义only或把N0解释为单调用 |
| QA / AC301–316 | 之后替身验证新调用公式、首稿无调用校验、Plan语言与输入关联、编辑救稿边界、最多2轮、最后包保存/统计及DB唯一结算；独立内容质量/真实时延与费用仍另需授权 |

## 验证范围、资源与下一步

原BE05限定checker历史检查15个场景的文档exact wire字段、seq/rev/Unicode/splice、完整Plan→writer相等与digest、zh/en/ja、动态2/3词、固定编辑在Review之前/不占基础预算、版本/lastValid/保存/预览namespace、持续notice和少量破坏变体。旧结果计数/hash见stream-v5-check.json，其中首片隐藏规划断言不再代表R1显示规则；v3/v4和所有基线backend文件保留，不覆盖旧checker报告。基本正文操作沿v4设计，BE05历史检查重点验证Plan/editor约束；本次R1仅检查版本、显示政策/旧语义残留、链接与冻结文件hash，不重跑v5 checker。未运行真实提供方、新内容质量批次、Go应用/全套、DB迁移、浏览器、压测或UAT3302。

无逐tokenDB/成本平台；BE3-09复用usage/trace/metrics，分开模型等待/实际发送/token费用、后端处理/活跃流、写阻塞、字节和进程CPU/RSS/GC。连接秒不是CPU秒；后续固定并发替身测基线差异和每完成请求均值，不做逐请求精确账单或已测容量承诺。规划新raw上界256KiB，原候选16MiB/正文200万码点及估算80–160MiB病理请求内存风险保持，实际待测。新增规划/编辑调用的真实费用和时延不由合成播放器推算。

建议主会话交designer-tony制作UI07-R1，直接消费原v5 wire并应用R1显示政策；FE/实现依后续合法接交。当前建议awaiting_user_review/for-prototype，不等于批准实施或完成技术总门禁。保留既有质量/费用/延迟/CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX未验证项。
