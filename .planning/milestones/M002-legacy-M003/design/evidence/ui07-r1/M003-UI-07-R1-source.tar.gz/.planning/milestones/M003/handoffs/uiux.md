---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M003-UI-07-R1
date: 2026-10-10
input_version: M003-PRODUCT-07 / M003-BE-05-R1 / M003-DB-03 / M003-FE-01
---

# M003 UI07-R1 交接

## 可直接评审的完整页面

- 造文（Plan 持续 + 固定编辑）：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui07-r1&page=create&scenario=enhanced-edited-pass&event=0&status=0&lang=zh`
- 计划管理：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui07-r1&page=plans&plan=pro&limit=1&adminState=edit&lang=zh`
- 预设管理（增强）：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui07-r1&page=presets&mode=enhanced&event=0&status=0&lang=zh`
- 条件返修：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui07-r1&page=create&scenario=rewrite-once&event=0&status=0&lang=zh`
- 恢复/Q02：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui07-r1&page=create&scenario=rewrite-recovery&event=0&status=0&lang=zh`
- 基础预设：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui07-r1&page=presets&mode=basic&event=0&status=0&lang=zh`

正常按钮自动播放，不需要展开“原型场景”。`lang=en` 只改变 UI 语言；Plan/正文语言仍取 exact request。合成等待来自 `playback[].after_ms`，不代表生产时延、模型质量或成本。

## USER-M003-PLAN-RETAIN / BE05-R1 接收

R1 只改变 Plan 的显示生命周期，继续直接 fetch `technical/fixtures/stream-v5/index.json`、15 个 wire 与 packages。v5 wire/schema、模型调用、DB、计费、版本和预算均未修改；`expected` / `internal_evidence` 不驱动 UI。

- 场景与每个词的暂定义项/搭配位于上方 `#planning-preview.plan-preview`；正文在下方 `.live-draft-text` 独立区域逐片更新。
- 首个 edit 不再清 Plan。首稿、固定编辑、条件返修、retained、finalizing、settlement pending 和 EOF 均保留已收到条目，Plan DOM 不随正文片段重建。
- 文案持续提示“初始构思，文章和实际用法可能调整”。Plan 不声称与编辑后正文实时一致，不触发额外模型刷新，也不把临时 sense/phrase 变成学习资源。
- 只有 validated/status valid 携带权威完整 Result（含 Q02）才清 Plan，并原子建立 passage/tags/targets、高亮、最终学习资源与保存/发布资格。valid 无 Result 不清 Plan或开放保存。
- planning failed、无有效稿 failed、cancelled 与新请求清 Plan/半稿。pending/EOF 保留 Plan 与只读草稿，并继续有限核对。
- basic/enhanced 两个后台 preview 使用同一保留规则，各自按 current draft_version/mode/run 完成资格核对；Q02 仍需人工确认和主动发布。
- PAGE-208 未改：原字段、基础策略 2 只读、内容 0–99、N0 仍规划、影响预览与 revision 冲突均保留。没有新增成本 UI。

## 原件、证据与恢复

- [设计规格](../design/design-spec.md)、[实际文案](../design/copy.json)、[主题](../design/theme.css)
- [原型入口](../design/prototype/index.html)、[交互实现](../design/prototype/app.js)、[管理展示数据](../design/prototype/fixtures.json)
- [交互合同](../design/interactions.md)、[响应式与可访问性](../design/responsive-accessibility.md)
- [R1 浏览器报告](../design/evidence/ui07-r1/M003-UI-07-R1-browser.json)及同目录 3 张代表截图
- [R1 待审源码快照](../design/evidence/ui07-r1/M003-UI-07-R1-source.tar.gz)与 [hash 清单](../design/evidence/ui07-r1/M003-UI-07-R1-source-manifest.json)
- UI07 原报告、截图与 SHA-256 `81a5f72738bb06c1579aa07c4fe1ec622e625b0723d9aef85d6401bf62f32dcf` 快照冻结保留；其“首片收起”结论仅代表历史版本，不冒充 R1 验证。

## 定向浏览器结果

R1 限定验证 5/5 PASS、3 张已目视截图、0 page error。真实按钮覆盖：

- basic 与 rewrite-once 在首正文、换稿和修稿期间持续显示 4 个 Plan 条目；同一 Plan DOM 节点保持，权威 valid 才清除并开放保存。
- rewrite-recovery 在 390px 的 partial/retained 前保持 Plan+正文，无横向溢出；Q02 valid 清 Plan并持续 notice。
- settlement pending 与 EOF 保留 Plan/只读正文；status valid 清 Plan。planning failure、无有效稿 failure 和 cancel 清 Plan/半稿。
- preview-basic 3 个条目、preview-enhanced 4 个条目均在正文期间保留，权威 Result 后清除，原资格/发布行为保持。

root 独立实际点击 `reviews/evidence/ui07-r1-root/actual-click.json` 也通过：Plan 4 项贯穿 draft/两次换稿，final 才清；61 次文本更新，终态前无保存/正式高亮，最终正文与 wire 一致，DOM/history 保持且 0 errors。旧 UI07 九场景矩阵和 BE05 checker均未重跑。

截图已实际查看：桌面造文、390 Q02 partial、后台 enhanced preview 都能同时读到 Plan 与正文；未见横向溢出、步骤点变形、skip-link 常态覆盖或工程说明混入正文。长页面是持续展示的直接结果，视觉自检不代替用户评审。

未验证真实模型/质量/费用/生产时延、网络与 DB 竞争、权限/token、真实 10 秒核对、前端构建、axe、完整键盘/读屏/200% 缩放、Safari/Firefox、UAT3302 或部署。

## frontend-bob 后续复核

1. 接收 BE05-R1 display policy：Plan 与正文使用稳定的独立组件；edit 不清、不重建 Plan，valid 完整 Result/failed/cancel/new request 才按规则清理。
2. Plan 继续只投影 allowlist 字段并标明可能调整；不能基于正文编辑刷新 Plan、增加模型调用或把临时 sense 当最终 entry_meaning。
3. 保留 UI07 的码点 splice、seq/revision/range/draft/version/epoch 校验、滚动焦点稳定和 DB 权威终态资格。
4. generation 与两个 preview 应复用保留策略，但 status/保存/发布资格仍按各自 namespace 和 current draft/mode/run 独立核对。
5. 实施阶段补真实 API、取消/断连/结算竞争、320/768、200% 缩放、axe、完整键盘/读屏、浏览器兼容、成本观测和构建检查。正式产品移除原型场景、fixture 名与合成时序说明。

## 状态

**BLOCKED：无。新增业务待决：无；CR-302 保持 `product_resolved_downstream_pending`，待 FE/实施等接续。** 当前为 `awaiting_user_review`。USER-M003-PLAN-RETAIN、BE05-R1、原型自检或 root 点击都不能代替 UI07-R1 用户视觉/交互批准；本交接不自行进入前端实施。
