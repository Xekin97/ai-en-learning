---
milestone: M003
version: M003-UI-07-R1
agent_name: designer-tony
date: 2026-10-10
---

# UI07-R1 响应式与可访问性

## 布局

| 视口 | 造文 | 计划 / 预设 |
|---|---|---|
| ≥1101px | 配置与结果区约 39/61 双栏；Plan 在上、正文独立区在下；配置 sticky | 管理导航 + 完整内容；预设 Plan 与正文上下排列 |
| 761–1100px | 单列，配置取消 sticky；Plan 仍按可用宽度布局 | 导航保留，内容按宽度降列 |
| ≤760px | 顶栏换行、导航局部横滚；Plan 词卡单列，正文紧随其后，整页无横溢 | 管理导航/tabs/列表局部横滚；预览 Plan 与正文单列 |
| 320–360px | 暂定场景/义项/英文短语自然换行，无页面横溢；状态不压标题 | 数值、错误与按钮完整换行 |

Plan 的 `entry`/`phrase` 与正文标 `lang=en`；义项沿 request meaning language 显示。Plan 与正文并存会增加页面高度，但 edit 不重建 Plan/结果面板或强制滚底；用户主动滚动后，后续片段保持 `scrollY`。终态清除 Plan，学习资源出现在正文后方。

## 键盘、朗读与动效

- skip link 常态离屏，focus-visible 时出现。原生 button/link/input/select/radio/checkbox 语义保留；交互目标至少 44×44px。
- Plan 标题和“初始构思，文章和实际用法可能调整”始终可见；场景/词用法使用 article 分组。正文出现、换稿和 pending 均不移动焦点。
- `.live-draft-text` 不设 live region；`.draft-status` 为 polite。Plan 容器说明为 polite，但追加条目不反复全文朗读。failed 为 alert，pending/成功为 status。
- planning、草稿、pending、EOF、failed/cancelled 均无保存；只有权威 valid 显示保存。Q02 使用文字、边框和暖橙底共同提示。
- occurrences 按 Unicode 码点切片，🌱 的代理对不会使后续 garden/learn/share 高亮错位。
- `prefers-reduced-motion: reduce` 关闭书写点和 spinner 动画；业务事件、Plan 保留与终态资格不变。

## 浏览器验证边界

Chromium R1 定向检查覆盖：basic/增强正文与修稿期间 Plan 持续且 DOM 保持、Q02/pending/EOF 保留、valid/failed/cancel 清除、两种 preview 保留到权威 Result、390 无横溢，并目视桌面/手机同时存在 Plan+正文。旧 UI07 全套未重跑。未执行真实 API/模型/DB、生产延迟、费用、axe、完整键盘/读屏/200% 缩放、Safari/Firefox、前端构建、UAT3302 或部署。
