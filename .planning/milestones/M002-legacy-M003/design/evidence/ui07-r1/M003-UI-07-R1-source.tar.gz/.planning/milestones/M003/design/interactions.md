---
milestone: M003
version: M003-UI-07-R1
agent_name: designer-tony
date: 2026-10-10
---

# UI07-R1 交互与状态

## PAGE-204 正常生成

1. 页面直接使用当前 v5 fixture 的 `request.entries` 与 `request.meaning_language`。UI 语言由 `lang` 决定，两者互不覆盖；选择词与 fixture 不一致时禁用生成，避免同一 wire 冒充其它输入。
2. 用户点击“生成短文”后，从 event=0 自动消费 `wire[]`。每帧只按 `playback[i].after_ms` 合成调度，第一次把结果带入视野，之后不抢焦点、不强制滚底；每帧 `replaceState`，不增加 history。
3. started 才是已受理。planning 中把 `plan_item` 追加到 `#planning-preview.plan-preview`：场景为 `[data-plan-kind=scene]`，词用法为 `[data-plan-kind=word_use]`。只呈现 allowlist 字段；同一 plan 的语言/身份不一致、重复 scene/entry 或形状非法则停止消费并核对。
4. 页面按 generation/preview namespace 选择各自 exact fixture。首个 edit 在 Plan 下方建立独立 `.live-draft-text`，不清除或重建 `#planning-preview`。reducer 校验连续 seq、重复指纹、draft 生命周期、content_version、base_rev/rev 与 Unicode 码点范围，再做 splice。
5. 草稿逐片更新且不可保存。新 draft 首片前保留旧全文；到达后可纯删除/替换。Plan 始终保持初次收到的内容，提示它可能与编辑后文章不同，不做额外模型刷新。
6. validated/status valid 且携带完整 Result 时才清 Plan，以权威整包替换草稿并一次建立 tags、码点高亮、entry_meaning、hint_phrase 和保存资格。临时 sense/phrase 不进入学习资源；Q02 notice 跨保存保持。
7. settlement_pending / EOF 保留 Plan 与只读草稿，并只消费 fixture 提供的有限 status；retained edit 不直接意味着成功。valid 无完整 Result 也不清 Plan或启用保存。
8. planning failed、无有效稿 failed 与 cancelled 清除 Plan/半稿。新请求、取消、重来、切场景/页面/mode、popstate、pagehide、手动 step 都停止旧 timer 并隔离旧代次。

## PAGE-208 计划管理

- 原完整字段继续存在。基础纠错策略固定 2 次只读；内容值为整数 0–99。0 关闭固定编辑/审校/返修，仍执行共同 Plan；1–99 开启增强服务。
- 空、负数、小数、100 不截断，保持输入并禁用影响预览。影响预览不调用模型。
- 保存冲突保留本地值和服务端最新值；必须以新 revision 重读并重新预览。

## PAGE-212 预设管理

- mode/配置改变使旧资格 stale。basic 与 enhanced 分别自动播放自己的 preview wire；Plan 在 preview.edit、固定编辑、pending 期间持续显示，权威完整 Result 才清除。
- preview 草稿没有用户额度、can_save 或发布资格。validated 后用当前 draft_version/mode/run 与有限 status 精确匹配，才把 `#preview-result` 设为 ready 并启用发布。
- Q02 notice 持续，管理员勾选确认后仍需主动点击发布；pending、stale、failed、cancelled 或关联不符均禁用。

## DOM 与朗读稳定性

自动播放保留 `#generation-status`、`.creation-panel`、`#planning-preview`、配置字段和页面滚动；正文开始后只新增一次正文区域，随后仅更新 `.live-draft-text`、简洁状态和动作区。正文不设 live region，避免每片重念；`.draft-status` 使用 polite，失败使用 alert。折叠演示面板可静态定位 event/status，但不是正常操作前置步骤；event>0 审阅 URL 不自动播放。
