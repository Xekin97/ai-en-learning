---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M003-UI-05
date: 2026-10-10
input_version: M003-PRODUCT-04 / M003-BE-03 / M003-FE-01
---

# M003 UI05 交接

## 原始说明与接收边界

designer-tony 按 `TRANSITION-M003-021` 完成 UI05 三个完整页面原型。已落实 `USER-M003-STREAM-FIRST`：用户生成页不突出审稿/返修，不显示上限或轮次；先消费 BE03 的真实公开流，再形成词义先行、最终整包替换的页面。本交付是待用户评审的设计修改，不批准 PRODUCT04、BE03、UI05、FE01 或未来实施，不自行切换工作流。

当前 Profile 仍为 `consumer-ai-web@1.0.0`；模型路由请求锁为 `gpt-5.6-sol/high`，actual_model 与 runtime usage unknown。没有修改 workflow/registry、产品/API/DB/FE/业务代码、冻结证据或 UI04 快照；未提交 Git、部署、调用真实模型/提供方或 UAT3302。

## 可直接评审的完整页面

- 造文完整页：`http://127.0.0.1:4174/M003/design/prototype/?page=create&scenario=basic&event=0&status=0&lang=zh`
- 计划管理完整页：`http://127.0.0.1:4174/M003/design/prototype/?page=plans&plan=pro&limit=1&adminState=edit&lang=zh`
- 预设管理完整页：`http://127.0.0.1:4174/M003/design/prototype/?page=presets&mode=enhanced&event=0&status=0&lang=zh`

三页底部“原型场景”可展开。造文页可直接切 basic、内部两轮同公开流、Q02、pending→valid、EOF、failed/cancelled；预设页可切 enhanced accepted、词义、validated 待资格核对、Q02 ready 与 mode stale。所有 fixture/合成/时延说明只在该折叠层，产品正文不放工程免责声明。`lang=en` 可查看英文界面。

## 接收到的 BE03 合同与实际消费

原型实际 fetch `technical/fixtures/stream-v3/index.json`，再按 `index.files` 读取 8 个 JSON；`wire[]` 逐帧按 `{event,data}` reducer，status 只消费 `status_responses[].body`。fixture 版本为 `M003-BE-03` / `m003-stream-v3`。源码没有复制/改写 BE03 payload，也不从 `internal_evidence`、`expected`、seq/run/token/版本/N/outcome 渲染产品信息。

- 用户流：started=已受理；progress composing=正在生成；learning_ready=仅 garden/learn/share 原词释义且不可保存；progress finalizing=保留释义并更新简洁状态；validated/status valid=一次建立 passage/tags/targets、高亮、释义与提示并开放保存。
- basic 与 enhanced-two-repairs 的公开五事件完全一致。最终 v3 全量替换 preview v1；用户页没有审稿/返修轨道、k/N、上限、百分比、ETA 或额外模型调用。
- Q02 final v2 持续显示“内容审校未完成”且可保存；pending/EOF 不成功、不保存，按 fixture 有限读取 status；failed/cancelled 清空预览。
- 管理预设只消费 `preview.*`。validated 后仍禁用发布；status/current AdminPreset 的 draft_version/mode/preview_run_id 匹配后才 ready，Q02 还需勾选确认。BE03 只提供 enhanced preview fixture，因此基础编辑状态可评审，但播放器不伪造 basic 返回。

## 当前设计原件与恢复来源

- [设计规格](../design/design-spec.md)：PAGE/CAP/DATA/AC/API 与 UIA-M003-401–411，入口、事件归约、有效来源和 FE01 待复核映射。
- [copy.json](../design/copy.json)：原型实际消费的 zh/en 固定文案；公开状态不含内部轮次。
- [theme.css](../design/theme.css)：继承 M002 暖白/深绿，新增流状态、词义持续、完整替换和资格核对样式。
- [完整原型](../design/prototype/index.html)、[交互逻辑](../design/prototype/app.js)、[管理展示数据](../design/prototype/fixtures.json)。生成/预设结果来自 BE03 fixture，不来自本地文章副本。
- [交互](../design/interactions.md)与[响应式/可访问性](../design/responsive-accessibility.md)。
- [浏览器报告](../design/evidence/ui05/M003-UI-05-browser.json)、[检查脚本](../design/evidence/ui05/browser.mjs)与同目录 7 张正式截图。首轮 11/13 报告与初轮截图保存在 [initial](../design/evidence/ui05/initial/)；正式截图不覆盖该记录。
- [UI05 待审源码快照](../design/evidence/ui05/M003-UI-05-source.tar.gz)与[hash 清单](../design/evidence/ui05/M003-UI-05-source-manifest.json)：包含本版设计源、交接、完整 stream-v3 index/8 wire/packages 与 M002 主题依赖，排除 evidence 目录本身以避免递归。快照不代表批准。

## 专业验证结果

Chromium / Playwright 1.62.1 / Node 22.23.2 定向验证 13/13 PASS、7 张正式截图、无 console/page error、缺文案或页面横溢，原型资源记录证明浏览器实际请求 index 与 8 个 wire JSON。覆盖：

- 初始无输出、started 受理、composing、learning_ready 仅词义不可保存、finalizing 释义持续、validated 完整替换；
- enhanced-two-repairs 无内部次数暴露且 final v3 的 share 释义替换为“分享；分担”；
- Q02 手机提示与保存、pending 的 active→valid、EOF 未知、failed/cancelled 清预览；
- 计划完整字段、两预算、0/99/100 非法与 local/remote 冲突；
- 预设 enhanced Q02 从 validated 到资格核对、确认后发布，以及 basic 不误播 enhanced；
- 1440/768/390/320、中英文、skip-link 常态位置、页面级横溢和 reduced-motion。

首轮 11/13 的两项失败是检查脚本在 `browser.newPage()` 创建的页上误用 `context().newPage()`；产品状态与视觉无失败。首轮报告原样保留，脚本改为 `browser.newPage()` 后同一断言通过。实现侧另按视觉复核发现修正过一次：learning_ready 后进入 finalizing 时原先会退回空 spinner；现已持续保留三个释义，validated 才整体替换。人工实际查看 learning 手机、finalizing 桌面、v3 完整结果、Q02 手机、pending→valid、计划99和预设Q02；未发现新的视觉返修项。

未验证：真实模型/供应方、真实延迟与最多10秒自动核对、断连/取消/结算竞争、数据库持久化、权限 token、费用/生成质量、前端构建、axe、全流程 Tab/读屏/200% 缩放、Safari/Firefox、UAT3302、部署。原型文章只演示 fixture 布局，不代表生成质量验收。

## frontend-bob 实施前复核

1. 把 FE3-03/04/06/07/08/09、FE3-T01/02/05、FE3-V02–06/09/11/12 从 UI04 stage/candidate/kN 设计重映射到 UIA-M003-401–411；不沿用 `stage=repair2`、本地计时器或从 plan 推断公开进度。
2. reducer 先校验真实事件，再只投影 allowlist。started、composing、learning_ready、finalizing、validated 与 status active/valid/failed/cancelled 的按钮资格须与本稿一致；finalizing 不撤下已收到词义。
3. validated/status valid 原子建立完整 Result；occurrences 高亮、tags、entry_meaning、hint_phrase 与保存资格一起提交。final v3 不和 preview v1 混字段，迟到 active 不覆盖终态。
4. Q02 notice 在流、status、保存后读取和管理发布链持续存在。pending/EOF 不得保存或发布；真实有限核对沿 API-302/304，不能无限轮询。
5. 计划页保留原字段、基础预算2只读、内容0–99与影响/冲突。预设页保留 basic0/enhanced1；valid 后必须复核当前 AdminPreset 的 version/mode/run，Q02 明示确认后才发布。
6. 正式产品不带原型场景、fixture 名、合成回放、样例/时延说明或本地 query 控制。实施需补真实 320/768、200% 缩放、全键盘/读屏、axe、真实状态计时、权限/刷新持久化和前端工程检查。

## 状态与下一步

**BLOCKED：无。开放 CR：无。** 当前建议 `awaiting_user_review`。请用户先查看三个完整页面；收到明确 UI05 视觉/交互接受后，再由有权限角色接交 frontend-bob 复核并实施。不得用 USER-M003-STREAM-FIRST、PRODUCT04/BE03 待审状态或原型自检代替 UI05 批准。
