---
milestone: M003
version: M003-UI-05
agent_name: designer-tony
status: awaiting_user_review
date: 2026-10-10
input_version: M003-PRODUCT-04 / M003-BE-03 / M003-FE-01
---

# M003-UI-05 完整页面设计规格

## 入口、定位与有效来源

本版按 `USER-M003-STREAM-FIRST` 修订 UI04：用户生成页不突出审稿/返修，也不显示上限、轮次或 k/N；后台计划仍保留内容预算 0–99 与基础预算 2 的只读事实，预设仍保留 basic0/enhanced1。设计入口是造文 PAGE-204、计划管理 PAGE-208、预设管理 PAGE-212；PAGE-216 沿用 PAGE-204 的阅读结果。覆盖 CAP-301–305、DATA-301–304、AC-301–314，稳定界面要求为 UIA-M003-401–411。

| 来源 | 本版用途 | 状态 |
|---|---|---|
| PRODUCT04 `pages/index.md`、`abilities.md`、`data-assets.md`、`ai-behavior.md` | 页面目的、能力和用户展示边界 | 当前产品输入，未把产品评审冒充 UI05 批准 |
| BE03 API-302 / API-304 | 公开事件、终态、有限状态核对、预设发布资格 | 当前原型合同，仍是待审技术方案 |
| `technical/fixtures/stream-v3/index.json` 及其 8 个 wire、`packages.json` | 原型实际 fetch 与 reducer 输入 | 只读；不复制、不改写 payload |
| M002 `design/theme.css` 与现有 PAGE-204/208/212 | 暖白/深绿品牌、导航、页面骨架和阅读交互 | 继续继承 |
| UI04 快照与证据 | 可恢复历史 | 保留，不再是当前评审稿 |

当前源码快照为 `evidence/ui05/M003-UI-05-source.tar.gz`，清单为同目录 `M003-UI-05-source-manifest.json`。快照是待审稿的可恢复来源，不构成批准。

## UIA-M003-401–411

| ID | 设计合同 | PAGE / CAP / DATA / AC | FE01 待复核映射 |
|---|---|---|---|
| UIA-M003-401 | 保留完整顶栏、导航、模型/场景/长度/释义、词库选择、额度、结果和保存外壳；演示输入固定为 `garden/learn/share`，与 fixture 一致 | PAGE-204, CAP-301, DATA-301 | FE3-03/07, FE3-T01 |
| UIA-M003-402 | 只有 `started` 才显示“已受理”；只有真实 `progress.phase=composing` 才显示“正在生成”；不显示百分比、ETA、审稿或返修阶段 | PAGE-204, CAP-301/302, AC-308/312 | FE3-04/07, FE3-V02/03 |
| UIA-M003-403 | `learning_ready` 只建立原词释义预览，不建立标题、正文、标签或提示资源；保存持续禁用；进入 finalizing 后释义持续可读 | PAGE-204, DATA-304, AC-308 | FE3-04/07, FE3-T02 |
| UIA-M003-404 | `validated` 或 status valid 一次建立完整 passage/tags/targets；按 occurrences 高亮，并显示 entry_meaning/hint_phrase；最终 v3 整体替换 v1 预览，不混字段 | PAGE-204/216, CAP-301/302, DATA-304, AC-308/309 | FE3-04/06/07, FE3-V04/05 |
| UIA-M003-405 | Q02 final v2 持续显示“内容审校未完成”且可保存；pending/EOF 不可保存并有限核对；failed/cancelled 清除预览；不读取 internal_evidence/expected | PAGE-204, CAP-302/304, AC-306/309/313 | FE3-06/07/09, FE3-V06/09/12 |
| UIA-M003-406 | 计划完整表单保留既有模型、长度、额度、优先级；基础纠错最多 2 次只读，内容预算为整数 0–99，0 关闭且无只审不修 | PAGE-208, CAP-303, DATA-302, AC-301–305/310 | FE3-08, FE3-T05 |
| UIA-M003-407 | 计划修改先看影响预览；只影响新请求；保存冲突同时显示 local/remote 并要求重新预览；99 只验证字段边界 | PAGE-208, CAP-303, AC-302/303/305/311 | FE3-08, FE3-V11 |
| UIA-M003-408 | 预设完整编辑器保留列表、名称、词汇、四项配置、草稿、预览和发布；basic0/enhanced1 独立于管理员计划 | PAGE-212, CAP-305, DATA-303, AC-307/314 | FE3-09, FE3-T05 |
| UIA-M003-409 | 管理预览只消费 `preview.*`；valid 后还须 GET 当前 AdminPreset，draft_version/mode/preview_run_id 匹配才 ready；Q02 明示确认后手动发布，notice 保留 | PAGE-212, CAP-305, AC-307/314 | FE3-09, FE3-V12 |
| UIA-M003-410 | 1440/768/390/320、zh/en、键盘、44px 触控、焦点/live region/reduced-motion；正文替换不重复朗读全文 | PAGE-204/208/212, AC-308/312 | FE3-07/08/09 |
| UIA-M003-411 | 产品正文只显示用户有意义的状态；fixture 名、事件播放器、时延/样例说明只在折叠“原型场景”层，生产不得带入 | PAGE-204/208/212, CAP-301–305 | FE3-07/08/09 |

## PAGE-204 公开流与结果资格

原型启动时 fetch `stream-v3/index.json`，再按 index.files 加载 JSON。仅消费 `wire[] {event,data}` 与 `status_responses[].body`；显示字段限定为 index.display_allowlist。`seq/run_id/token/content_version/final_content_version/snapshot/internal_evidence/expected/content_outcome` 不渲染为产品信息。

| 输入 | reducer 可见结果 | 保存 |
|---|---|---|
| 无事件 | 空结果 | 禁用 |
| `generation.started` | 已受理，等待生成 | 禁用 |
| `generation.progress(composing)` | 正在生成 | 禁用 |
| `generation.learning_ready` | garden/learn/share 原词释义 | 禁用 |
| `generation.progress(finalizing)` | 正在完成，已收到的释义持续可读 | 禁用 |
| `generation.validated` | 一次建立完整短文、标签、高亮和学习资源 | 启用 |
| Q02 validated / status valid | 完整有效稿 + 持久“内容审校未完成” | 启用 |
| `settlement_pending`、EOF、status active | 待核对，可保留词义预览但不把它当结果 | 禁用 |
| failed / cancelled | 清除词义与正文 | 禁用 |

basic 与 enhanced-two-repairs 对用户都是相同的五事件序列。播放器逐条回放实际事件，不插入本地 stage、不用 setTimeout、不声称真实延迟。pending 只消费 fixture 给出的有限 status 响应；全部读完仍 active 时停在待核对并提供显式重新核对入口。

## PAGE-208 / PAGE-212 管理合同

计划管理不因用户页隐藏内部轮次而删字段：visitor/basic 固定内容 N=0；Pro/Plus 初始 1、允许整数 0–99；0 关闭整个内容服务，1–99 开启；基础技术预算始终只读 2。非法值不截断，禁用影响预览。保存前显示新旧、影响人数、新请求/在途/已用次数边界；revision 冲突不部分保存。

预设模式是后台本次预览配置：basic=0、enhanced=1。当前 BE03 只提供 enhanced 的 `preview-incomplete.json`，所以播放器只回放该 exact mode；基础编辑状态可评审，但不把 enhanced Q02 伪装成 basic 返回。`preview.validated` 只证明 run 有效，发布按钮仍禁用；读取 status/current AdminPreset 且版本、模式、run 匹配后，Q02 管理员勾选确认才可发布。

## 待审范围与边界

UI05 待用户评审：公开生成状态的层级、词义先行与完整替换、Q02 提示强度、计划/预设完整页组合、手机布局和中英文。本轮不批准 PRODUCT04/BE03/FE01，不切换技术或实现阶段。原型不调用真实 API、模型或提供方；未验证真实时延、10 秒轮询、结算竞争、数据库持久化、权限、质量、费用或部署。样例文章只在折叠演示层说明其性质，产品正文不出现工程免责声明。
