---
milestone: M003
version: M003-UI-05
agent_name: designer-tony
date: 2026-10-10
---

# UI05 交互与状态

## 造文 PAGE-204

1. 用户保留原页面的模型、场景、长度、释义语言和词库选词。UI05 演示输入固定为 `garden/learn/share`；删掉任一词会禁用生成，避免输入与所播 fixture 不一致。
2. 点击“生成短文”只回放第一条 `generation.started`，显示“请求已受理”；它不表示模型已开始写作。折叠演示面板的“回放下一事件/剩余事件”只调度实际 `wire[]`，没有计时器或附加模型调用。
3. `progress(composing)` 才显示“正在生成”。`learning_ready` 显示三个原词释义，正文/标题/标签/hint 不存在且不能保存。`progress(finalizing)` 只更新简洁状态，已收到的三个释义持续可读。
4. `validated` 将 passage、tags、targets 作为一个 commit 整体写入结果区，按 occurrences 高亮目标词，显示 entry_meaning 与 hint_phrase，并开放保存。enhanced-two-repairs 的最终 v3 不拼接 learning v1，也不显示内部轮次。
5. Q02 使用 final v2 完整结果，持续显示“内容审校未完成”；保存可用，页面不称审校通过。点击保存只演示产品动作，不新增生成。
6. `settlement_pending` 或 EOF 显示待核对，保存禁用。`重新核对` 依次消费当前 fixture 的 `status_responses[].body`：active 保持待核对，valid 一次建立完整结果；读完后不无限自动轮询。
7. failed/cancelled 清除学习预览和完整结果。取消按钮切换到 BE03 cancelled fixture 的真实终态，不把本地预览当成功。

## 计划管理 PAGE-208

1. 四计划标签、模型、长度、优先级、最大词数、24h 次数与不限开关保留。基础纠错区只读显示“全请求最多2次”，内容服务区独立编辑。
2. visitor/basic 固定 0；Pro/Plus 可输入整数 0–99，0 关闭，1–99 开启。空、负数、小数和 100 均 `aria-invalid=true`，不静默纠正，禁用“预览差异”。
3. 影响预览不调用模型；显示基础策略不变、内容旧/新值、影响人数以及只影响新请求。在途请求保留受理快照，已用次数和体验期不重置。
4. 保存成功后重新读取。revision 冲突显示服务端最新值和本地值；保留本地修改后须基于新 revision 再预览，不能直接复用旧 impact。

## 预设管理 PAGE-212

1. 保留预设列表、名称、garden/learn/share、四项生成配置、保存草稿、预览、用量和发布。mode 变化把旧结果标 stale 并禁用发布。
2. basic0/enhanced1 是本次后台预览模式，不读取管理员计划。本 fixture 包只有 exact enhanced `preview.*` Q02 流；基础模式按钮仍属于正式设计，原型点击会展开演示边界，不伪造结果。
3. enhanced 点击“生成预览”回放 `preview.started`，随后按实际事件推进。learning_ready 仅显示词义，finalizing 继续保留词义。validated 后显示完整预览与 Q02 notice，但发布仍禁用。
4. “核对发布资格”读取 status/current AdminPreset 投影；draft_version、preview_content_mode、preview_run_id 与本 run 全部匹配才 ready。管理员必须勾选 incomplete 确认，再手动发布；notice 不因确认或发布消失。
5. pending/active、过期、failed/cancelled、mode/version/run 不匹配均不可发布，旧线上版本不变。

## 动效、焦点与原型层

事件变化即时渲染；完整结果用 opacity + 4px 的一次替换，reduced-motion 时近乎即时。正文不放 live region，状态用 polite，错误用 alert。开始后焦点可进入 `#generation-status` 一次，后续帧不反复抢焦点；计划 impact/conflict 与预设资格核对聚焦对应容器。fixture 名、事件名、合成回放和时延说明只在折叠原型面板，生产移除整个面板。
