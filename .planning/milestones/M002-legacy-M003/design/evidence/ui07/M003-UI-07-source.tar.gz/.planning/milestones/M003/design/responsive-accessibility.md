---
milestone: M003
version: M003-UI-07
agent_name: designer-tony
date: 2026-10-10
---

# UI07 响应式与可访问性

## 布局

| 视口 | 造文 | 计划 / 预设 |
|---|---|---|
| ≥1101px | 配置与稳定结果区约 39/61 双栏；配置 sticky；Plan 场景占整行、词用法双列 | 管理导航 + 完整内容；计划双策略；预设列表 + 编辑器 |
| 761–1100px | 单列，配置取消 sticky；Plan 仍按可用宽度布局 | 导航保留，内容按宽度降列 |
| ≤760px | 顶栏换行、导航局部横滚；Plan、草稿、资源与动作单列 | 管理导航/tabs/列表局部横滚；表单、预览和冲突单列 |
| 320–360px | 暂定场景/义项/英文短语自然换行，无页面横溢；状态不压标题 | 数值、错误与按钮完整换行 |

Plan 的 `entry`/`phrase` 标 `lang=en`，正文也标 `lang=en`；义项沿 request meaning language 显示，不因页面中文/英文而错误改写。正文允许自然增高，但 edit 不重建结果面板或强制滚底。用户主动滚动后，后续片段保持 `scrollY`；终态资源出现在正文后方。

## 键盘、朗读与动效

- skip link 常态离屏，focus-visible 时出现。原生 button/link/input/select/radio/checkbox 语义保留；交互目标至少 44×44px。
- Plan 标题和说明可见，场景/词用法使用 article 分组；不用颜色或动画单独表达“暂定”。Plan 到正文切换后焦点不移动。
- `.live-draft-text` 不设 live region；`.draft-status` 为 polite。Plan 容器说明为 polite，但追加条目不反复全文朗读。failed 为 alert，pending/成功为 status。
- planning、草稿、pending、EOF、failed/cancelled 均无保存；只有权威 valid 显示保存。Q02 使用文字、边框和暖橙底共同提示。
- occurrences 按 Unicode 码点切片，🌱 的代理对不会使后续 garden/learn/share 高亮错位。
- `prefers-reduced-motion: reduce` 关闭书写点和 spinner 动画；业务事件、Plan 收起与资格逻辑不变。

## 浏览器验证边界

Chromium 定向检查覆盖：1440 规划/固定编辑、390 中文 Q02 恢复和英文 UI/日文义项救稿、basic 仍规划、planning/无有效稿失败清理、pending→valid、EOF、取消后重开、两个 preview 独立 wire/资格、计划 0/99/非法值、最终码点高亮、DOM/history/折叠面板稳定。未执行真实 API/模型/DB、生产延迟、费用、axe、完整键盘/读屏/200% 缩放、Safari/Firefox、前端构建、UAT3302 或部署；这些留给实现与验收。
