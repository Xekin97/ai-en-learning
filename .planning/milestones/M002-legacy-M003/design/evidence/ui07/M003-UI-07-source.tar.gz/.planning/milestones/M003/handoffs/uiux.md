---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M003-UI-07
date: 2026-10-10
input_version: M003-PRODUCT-07 / M003-BE-05 / M003-DB-03 / M003-FE-01
---

# M003 UI07 交接

## 可直接评审的完整页面

- 造文（Plan + 首稿 + 固定编辑）：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui07&page=create&scenario=enhanced-edited-pass&event=0&status=0&lang=zh`
- 计划管理：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui07&page=plans&plan=pro&limit=1&adminState=edit&lang=zh`
- 预设管理（增强真实预览）：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui07&page=presets&mode=enhanced&event=0&status=0&lang=zh`
- 条件返修：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui07&page=create&scenario=rewrite-once&event=0&status=0&lang=zh`
- 恢复/Q02：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui07&page=create&scenario=rewrite-recovery&event=0&status=0&lang=zh`
- 基础预设：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui07&page=presets&mode=basic&event=0&status=0&lang=zh`

正常按钮会自动播放，不需要展开“原型场景”。`lang=en` 可看英文 UI；正文/Plan 语言仍取 fixture request。合成等待来自 `playback[].after_ms`，只用于演示，不代表生产时延、模型质量或成本。

## BE05 / DB03 接收与实际原型

原型直接 fetch `technical/fixtures/stream-v5/index.json`、index 中 15 个 wire 与 packages；未修改这些输入。reducer 只消费 `{event,data}`、有限 `status_responses[].body` 和 playback，不从 `expected` / `internal_evidence` 渲染或决定状态。

- 新增 `generation.plan_item` / `preview.plan_item`：在 `#planning-preview.plan-preview` 中显示暂定场景及 request 中每个词的本篇 sense/phrase；首个正文 edit 清除全部临时条目。完整 Plan 私有事实、plan_id、调用、版本、轮次、上限和 Review 不显示。
- selected words 与 meaning language 来自 exact request：用户场景 3 词，preview-basic 2 词/日文，preview-enhanced 3 词/英文；UI locale 独立。
- edit 继续使用 draft/content version、base_rev/rev/seq、码点 at/delete_count/insert/source 做校验和 splice；相邻完全重复 NOOP。非法帧停止当前播放并进入核对。
- 新稿首片前保留旧全文；首片后可见删尾/替换。草稿纯文本且不可保存。validated/status valid 才建立完整 passage/tags/targets、学习资源与保存/发布资格；临时 sense 不冒充最终 entry_meaning。
- planning failed、无有效稿 failed 和 cancelled 清 Plan/半稿；pending/EOF 保留只读草稿并有限核对；retained 本身不等于成功。Q02 最终包持续提示且可保存。
- 自动播放保留结果面板、配置 DOM、焦点、滚动和 history；取消/重来、场景/mode/页面切换、popstate/pagehide、手动 step 隔离旧代次。静态 event>0 URL 不自播。
- preview-basic 与 preview-enhanced 各自播放真实 v5 namespace。validated 后还核对当前 AdminPreset draft_version/mode/run 才 ready；Q02 仍须人工确认后手动发布。
- PAGE-208 保留原字段、基础策略 2 只读、内容 0–99、影响预览与 revision 冲突。N0 仍有共同 Plan。没有增加成本仪表盘。

## 当前原件、证据与恢复来源

- [设计规格](../design/design-spec.md)、[实际文案](../design/copy.json)、[主题](../design/theme.css)
- [原型入口](../design/prototype/index.html)、[交互实现](../design/prototype/app.js)、[管理展示数据](../design/prototype/fixtures.json)
- [交互合同](../design/interactions.md)、[响应式与可访问性](../design/responsive-accessibility.md)
- [UI07 浏览器报告](../design/evidence/ui07/M003-UI-07-browser.json)、[首轮报告](../design/evidence/ui07/M003-UI-07-browser-first-pass.json)、[两项定向复验](../design/evidence/ui07/M003-UI-07-browser-rerun.json)及同目录 5 张代表截图
- [UI07 待审源码快照](../design/evidence/ui07/M003-UI-07-source.tar.gz)与 [hash 清单](../design/evidence/ui07/M003-UI-07-source-manifest.json)

UI04、UI05、UI05-R1、UI06 快照和证据冻结保留。本稿没有修改 workflow、产品、API、后端、前端、数据库、UAT3302；没有调用真实模型/提供方、提交 Git 或部署。

## 实际浏览器结果

最终聚合 9/9 PASS、5 张代表截图、0 当前 page error。覆盖真实按钮 Plan 先显/首正文收起、增强固定编辑的真实删尾与增长、basic 仍规划、Q02 retained 恢复、planning/无有效稿失败清理、日文暂定义项救稿、pending→valid、EOF、取消后等待并重开、basic/enhanced 两套预览资格、计划 0/99/非法值、1440/390、中英文、Unicode 高亮与 DOM/history 稳定。未重复运行 BE05 fixture checker。

首轮 7/9 中两项失败都发生在浏览器断言读取了不存在的 `expected.result.passage`；v5 的 `expected.final_package` 是包 ID，不是 Result 对象。产品原型没有失败或改动。断言改为读取 exact wire 的 validated `data.result` 后，只复验这两项，2/2 PASS；首轮报告保留。主会话另有独立真实点击证据 `reviews/evidence/ui07-root/actual-click.json`：Plan 4 项先显、首正文收起、61 次文本变化、两次实际删改、valid 前无保存/高亮、最终正文与 wire 一致，settings/result DOM 与 history 保持，0 浏览器错误。

代表截图已目视：桌面 Plan、固定编辑纯删除、390 Q02 终态、390 英文 UI/日文义项救稿、basic 预设 Plan 均未见横向溢出、步骤点变形、skip-link 常态覆盖或工程说明混入产品正文。视觉自检不代替用户评审。

未验证真实模型/质量/费用/生产时延、网络与 DB 竞争、权限和 token 生命周期、真实 10 秒核对、前端构建、axe、完整键盘/读屏/200% 缩放、Safari/Firefox、UAT3302、部署。

## frontend-bob 后续复核

1. 将 FE3-03/04/06–09、FE3-T01/02/04/05 和 FE3-V02–06/09/11/12 映射到 UI07/BE05；新增 plan_item 临时状态和首 edit 收起，不从终稿重建动画。
2. 用 request entries/meaning_language 构建投影，保持 UI locale 独立；完整 Plan 私有数据只送 writer，临时 sense 不进入最终学习资源。
3. 实现码点 splice/occurrences、seq 指纹、revision/range、draft/content version、旧 epoch 与 late-frame 校验；协议错误停止流并查 status。
4. 用稳定组件局部更新正文，保留配置、焦点与用户滚动。新稿首片前保留旧稿；只有 DB 权威 valid 完整包可保存/发布。
5. 两个 preview namespace 和资格分别核对当前 draft/mode/run；管理页保留基础策略 2 只读、内容 0–99、N0 仍规划、影响/冲突及 Q02 人工确认。
6. 实施阶段补真实 API、取消/断连/结算竞争、320/768、200% 缩放、axe、完整键盘/读屏、浏览器兼容、成本观测和构建检查。正式产品移除原型场景、fixture 名与合成时序说明。

## 状态

**BLOCKED：无。新增业务待决：无；CR-302 保持 `product_resolved_downstream_pending`，待 FE/实施等接续。** 当前为 `awaiting_user_review`。PRODUCT07、BE05、DB03、原型自检或 root 独立点击都不能代替 UI07 的用户视觉/交互批准；本交接不自行进入前端实施。
