---
milestone: M003
version: M003-UI-07
agent_name: designer-tony
status: awaiting_user_review
date: 2026-10-10
input_version: M003-PRODUCT-07 / M003-BE-05 / M003-DB-03 / M003-FE-01
---

# M003-UI-07 完整页面设计规格

## 定位、入口与来源

UI07 落实 `USER-M003-Q3-02-A`：所有生成先形成一次真实 Plan，再把完整 Plan 输入 writer；增强模式的首稿之后必经一次固定实际编辑，再按已有规则审校和条件返修。PAGE-204 只把 Plan 中可公开的暂定场景、每个所选词的本篇义项与短语先给用户看；首个正文 edit 到达即整组收起。正文仍在同一稳定阅读区按真实 splice 追加、删尾和替换，不显示调用、版本、轮次、上限或私有 Review。PAGE-208 与 PAGE-212 保留完整管理能力。

| 来源 | UI07 用途 | 接收边界 |
|---|---|---|
| PRODUCT07：D3-09、CAP-301–305、DATA-301–305、AC-301–316 | Plan→writer、增强固定编辑、临时用法与最终学习资源分离 | 已选业务方向；不等于 UI07 批准 |
| BE05 API-302 / API-304、DB03 | v5 事件、splice、终态、预设资格和持久化边界 | 待审技术输入；不声称字段获用户逐项批准 |
| `technical/fixtures/stream-v5/index.json`、15 个 wire、`packages.json` | 原型直接 fetch、合成调度和 reducer 输入 | 只读；`expected` / `internal_evidence` 不驱动 UI |
| M002 `design/theme.css` 与 PAGE-204/208/212 | 暖白深绿品牌、导航、表单、阅读结果 | 继续继承 |
| UI04 / UI05 / UI05-R1 / UI06 证据与快照 | 可恢复历史 | 冻结保留，不是当前评审稿 |

当前可恢复源码为 `evidence/ui07/M003-UI-07-source.tar.gz`，hash 清单为 `evidence/ui07/M003-UI-07-source-manifest.json`。它包含本版设计、交接、M002 主题及完整 v5 index/15 wire/packages；排除 evidence，避免递归。快照是待审提交，不构成批准。

## UIA-M003-401–411

| ID | UI07 设计合同 | 稳定需求 | FE01 待复核 |
|---|---|---|---|
| UIA-M003-401 | 保留完整导航、模型/场景/长度/释义语言、动态所选词、额度、结果与保存外壳；UI 语言和释义语言独立 | PAGE-204, CAP-301, DATA-301/305, AC-308/315 | FE3-03/07, FE3-T01/05 |
| UIA-M003-402 | started 才显示已受理；planning 先依次显示一个暂定场景及每个 request entry 的义项/短语；首个正文 edit 收起全部临时 Plan | PAGE-204, CAP-301/302, DATA-305, AC-308/315/316 | FE3-03/04/07, FE3-V02–04 |
| UIA-M003-403 | `generation.edit` / `preview.edit` 按 Unicode 码点应用；相邻完全重复 NOOP；错序、错 rev、越界、旧 draft 复用或晚帧停止消费并有限核对 | PAGE-204/212, DATA-304, AC-308/309 | FE3-03/04/09, FE3-T02 |
| UIA-M003-404 | 新稿首片到达前保留旧全文；到达后按 splice 可见删尾/替换；草稿纯文本，不沿用旧稿高亮、释义、hint 或暂定 Plan | PAGE-204, CAP-302, AC-308/312/316 | FE3-04/07, FE3-V02–04 |
| UIA-M003-405 | validated/status valid 才原子建立权威 Result、标签、高亮、学习资源与保存；Plan sense 不得冒充 entry_meaning；🌱 后的 occurrence 仍按码点准确 | PAGE-204/216, DATA-303–305, AC-306/309/315 | FE3-04/06/07, FE3-V05/06 |
| UIA-M003-406 | pending/EOF 保留只读草稿并有限核对；retained 只是 edit；planning/无有效稿失败或取消清临时内容且不可保存；Q02 notice 持续 | PAGE-204, CAP-302, AC-306/313/316 | FE3-04/06/07, FE3-V05/06/09 |
| UIA-M003-407 | 计划完整表单保留原字段；基础纠错全请求最多 2 次只读；内容预算整数 0–99，0 关闭固定编辑/审校/返修但仍有 Plan；影响预览及冲突保留 | PAGE-208, CAP-303, DATA-301, AC-301–305/310/311/314–316 | FE3-08, FE3-T03/05 |
| UIA-M003-408 | 预设 basic0/enhanced1 均播放各自 exact v5 wire；basic 有真实 Plan/首稿，enhanced 有固定编辑；不得互借 fixture | PAGE-212, CAP-304/305, DATA-304/305, AC-307/309/314–316 | FE3-06/09, FE3-T04/05 |
| UIA-M003-409 | 预设只在当前 draft_version/mode/run 与有限 status 有效匹配后 ready；Q02 必须确认后手动发布；stale/pending/failed/cancelled 不可发布 | PAGE-212, CAP-304/305, AC-307/309/313/314 | FE3-06/09, FE3-V09 |
| UIA-M003-410 | 自动播放只局部更新结果区；配置、导航、焦点和用户滚动保持；正文不设 live region，不逐片朗读全文 | PAGE-204/212, AC-308/312 | FE3-07/09, FE3-T05 |
| UIA-M003-411 | 1440/768/390/320、zh/en、键盘、44px 触控、reduced-motion；fixture 与合成等待说明只在折叠演示层 | PAGE-204/208/212, CAP-301–305 | FE3-07–09, FE3-V11/12 |

## PAGE-204 造文

正常“生成短文”从 event=0 一键自动消费 exact `wire[]`；等待只取 `playback[i].after_ms`，服务于合成演示，不代表生产时延或模型性能。默认入口为 `enhanced-edited-pass`，便于同时审阅 Plan、首稿和固定编辑；`rewrite-once`、`rewrite-twice`、`rewrite-recovery` 等在折叠演示面板可选。

| 输入 | 用户看到 | 保存 |
|---|---|---|
| started | 请求已受理 | 禁用 |
| progress planning + plan_item | 同一结果区内依次出现暂定场景、每个词的本篇义项/短语；没有正文 | 禁用 |
| 首个及后续 edit | 全部临时 Plan 一次收起；正文从真实 edit 小片开始增长 | 禁用 |
| 新 draft 首 edit | 等待期间保留旧稿；该帧到达后才删尾/替换，并继续增长 | 禁用 |
| progress finalizing | 当前正文持续可读，只更新简洁状态 | 禁用 |
| validated / status valid | 权威完整包原子替换草稿，建立 tags/occurrence 高亮/entry_meaning/hint | 启用 |
| Q02 valid | 最近完整有效稿 + 持续“内容审校未完成” | 启用 |
| pending / EOF / protocol gap | 已收草稿只读保留，提供有限核对 | 禁用 |
| planning failed / 无有效稿 failed / cancelled | 清除 Plan、半稿和临时字段 | 禁用 |

Plan 只允许 `scene.text` 与 `word_use.entry/form/sense/phrase` 的公开投影。`plan_id`、完整 participants/facts/beats、私有 Review、调用、版本、seq/rev/N 都不显示。Plan 的 sense 是本篇暂定义项；最终学习资源只取 validated Result。`request.entries` 决定 2/3 个词，`request.meaning_language` 决定 zh/en/ja 投影，均不由 UI locale 猜测。

## PAGE-208 计划管理

四计划、模型、长度、优先级、词数、日额度与不限开关继续存在。基础纠错全请求最多 2 次且只读；visitor/basic 内容 N=0，Pro/Plus 初始 1 且允许 0–99。0 关闭固定编辑、Review 和条件返修，但不关闭共同规划；1–99 开启增强链路。非法整数保留原输入、`aria-invalid=true` 并禁用影响预览。影响预览显示新旧值、受影响人数、仅新请求/在途快照；revision 冲突要求按远端最新值重新预览。

## PAGE-212 预设管理

预设保留列表、名称、词汇、模型/场景/长度/释义语言、basic/enhanced 模式、保存草稿、真实预览、用量和手动发布。v5 的 `preview-basic` 与 `preview-enhanced` 都由自己的 namespace 和 request 驱动：basic 展示 2 词日文 Plan 后首稿；enhanced 展示 3 词英文 Plan、首稿及固定编辑。validated 后还要以当前草稿/mode/run 对有限 status 响应做资格核对；Q02 需人工勾选确认，勾选不自动发布。

## 当前评审范围

请评审：临时 Plan 的信息量和层级、首正文到达时的收起、固定编辑/条件返修的连续正文感、Q02 恢复、手机阅读、basic/enhanced 两套预设，以及它们与完整计划页的组合。原型不调用真实 API、模型或提供方；没有验证真实生成质量、生产时延、费用、并发/DB 竞争、权限、部署或成本容量。本稿建议 `awaiting_user_review`，不自行进入前端实施。
