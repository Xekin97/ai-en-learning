---
milestone: M003
version: M003-UI-09
agent_name: designer-tony
status: awaiting_user_review
date: 2026-10-10
input_version: M003-PRODUCT-07 / M003-BE-05-R1 / M003-DB-03 / M003-FE-01
visual_baseline: M002 current effective formal design
interaction_baseline: M003-UI-07-R1 plus USER-M003-PLAN-RETAIN
---

# M003-UI-09 正式设计规格

UI09 按 `USER-M003-M002-DESIGN-BASELINE` 重做三张受影响完整页面：视觉、布局和既有字段以 M002 当前有效正式设计为基线，只把已确认的 Plan、连续正文、服务预算和预设预览规则接入原有区域。UI08 把原型视觉误当正式视觉，其冻结包只保留历史恢复用途，不能作为实现来源。UI07-R1 仅继续提供已确认的业务交互，不代表正式视觉批准。

## 可评审入口

前缀：`http://127.0.0.1:4174/M003/design/prototype/`

| 稳定页面 | 正式预览 query | 生产入口 | 本版范围 |
|---|---|---|---|
| PAGE-204 造文 | `?page=create&lang=zh&view=formal&scenario=rewrite-once&event=0&status=0&rev=ui09` | `/create` | M002 设置、选词、阅读纸面 + Plan/连续草稿/权威结果 |
| PAGE-208 计划 | `?page=plans&lang=zh&view=formal&plan=pro&contentLimit=1&rev=ui09` | `/admin/plans` | M002 完整计划字段 + 基础纠错与内容返修配置 |
| PAGE-212 预设 | `?page=presets&lang=zh&view=formal&mode=enhanced&event=0&status=0&rev=ui09` | `/admin/presets` | M002 完整编辑器 + basic/enhanced 实际预览与发布资格 |
| PAGE-216 试用共享区 | PAGE-204 使用 basic 请求的结果区域 | `/trial/:presetId` | 复用 Plan/草稿/结果表达；本版不重做试用页外壳 |

`view=formal` 隐藏合成演示控件。fixture、scenario/event/status query 与回放 timer 都属于 demo adapter，不进入正式产品。

## 原件与来源

| 来源 | 本版用途 | 精确文件/选择器 |
|---|---|---|
| M002 正式品牌与页壳 | 词涟鱼形/涟漪 SVG、暖白/深绿、顶栏、导航、管理侧栏 | `../../M002/design/prototype/app.js` 的 `mark`、header；`../../M002/design/theme.css` |
| M002 造文 | 310px 设置栏、配置 icon、自定义 select、选词器、右侧阅读纸 | `.workspace`、`.creation-settings`、`.generation-word-panel`、`.article`；本版 `#create-settings` |
| M002 计划 | underline tabs、两栏原字段、单 panel | `.tabs`、`.form-grid`、`.admin-options`; `#plan-priority/#plan-max/#plan-limit/#plan-unlimited` |
| M002 预设 | master-detail、标题→无限制管理选词→4 配置→原动作→纸面预览 | `.admin-master-detail`、`#preset-title`、`#preset-words`、`#preset-model/style/length/language` |
| M002 资源 | 本地 Lucide 图标与无外部字体资源 | `prototype/m002/icons.js`、`prototype/m002/assets/lucide.json`；许可证同目录 |
| PRODUCT07 / BE05-R1 / API-302,304 / DB03 | 状态、数据、资格与持久化约束 | 只引用权威合同，不在设计层复制第二套 DTO |
| stream-v5 | demo exact `wire[]` 与有限 status 回放 | `../../technical/fixtures/stream-v5/index.json` 及 15 个 wire；不读 expected/internal_evidence 渲染 |

固定中英文只取 `copy.json`；样式只取 `theme.css`（先 import M002，后追加 `m003-*`）。模型名、用户、额度、2/3 词、文章、Plan、释义、tags 都是动态数据，不是 copy。缺固定 key 显示 `⟦key⟧` 只作为设计自检，生产需记录错误并采用产品定义的安全回退。

## 页面区域与元素顺序

### PAGE-204 / PAGE-216

1. M002 learner header：真实 mark、主导航、locale、平台消息、账号菜单。
2. `.page-head`：`create.title/create.desc`；右侧 quota 来自权益数据。
3. `.workspace` 左侧 `#create-settings.settings.creation-settings`：model(bot) → style(book-open) → length(layers) → meaning language(book-open-text)。
4. 右侧 `.generation-word-panel`：M002 选词器、随机词、搜索 listbox、正常“开始生成”。目标词以 request 为准。
5. 同列 `#generation-status.m003-generation-paper`：结果抬头 → `#planning-preview` → `#live-draft .live-draft-text` → `#final-result`。Plan 和正文各是纸面内分区，不另起过程轨道。
6. authoritative valid 时用完整 Result 原子替换临时区，建立 passage 高亮、tags、学习资源和保存动作。

Plan 只显示 scene 与每个 request entry 的 sense/phrase；提示 key `m003.plan.note`。Plan 从收到首条 plan_item 起一直保留，初稿、固定编辑、条件修稿、retained、pending/EOF/finalizing 均不清；valid 完整 Result、失败、取消或新请求才清。Plan 不宣称与编辑后正文实时一致。

### PAGE-208

M002 管理 header/sidebar → `a.plans` heading（保留全计划“档位优先级”编辑入口与影响确认）→ 访客/基础/Pro/Plus underline tabs → 单 panel：

- 左列：`a.plan.models` 全部模型；`a.plan.lengths` short/medium/long/xlong。
- 右列：`priority` 数字；`words.limit` 数字；`a.plan.limit` 滚动 24h 数字；`a.plan.unlimited`。
- 其后新增 `#service-settings`：基础纠错预算 2（只读）；内容返修 0–99（普通计划不可用，付费计划可配，0 关闭）。不在产品区写测试到 2 次、99 不实跑等验证策略。
- 最后 `#change-preview/#version-conflict/#plan-actions`。影响预览以实际受影响用户数据呈现；冲突来自真实版本保存响应，formal 页面无造冲突按钮。

### PAGE-212

M002 管理 header/sidebar → heading/新建 → `.admin-master-detail`：左预设列表；右编辑 panel 按原顺序：

1. 状态 badge、规则说明、`#preset-title`。
2. 管理选词器 `#preset-words`，不套用户计划选词上限，不显示随机词。
3. model/style/length/meaning language 四字段。
4. 新增 `#preview-mode`：basic / enhanced；模式必须和实际 preview fixture/request 一致。
5. 原动作：保存草稿、生成/取消预览、发布、下架；Q02 仅在 incomplete 时追加确认。
6. `#preview-result` 使用与造文相同 Plan/连续正文/Result 纸面规则；preview namespace 独立。发布必须匹配 current draft_version + mode + run 且 status valid；Q02 还需明确确认。

## UIA-M003-401.a–411.a 正式验收合同

以下保留 UI08 已发布的稳定 ID，UI09 只更新其 M002 视觉基线与可观察结果，不缩写、重编号或退休 `.a`。

| ID | 可观察结果 | 前端接收检查 |
|---|---|---|
| UIA-M003-401.a | PAGE-204 完整导航、M002 310px 配置、原选词/额度/纸面结果与保存外壳；真实 fish/infinity mark 与本地 Lucide icon | M002/UI09 1440/390 对照；`#create-settings/#create-words/#generation-status` 同页 |
| UIA-M003-402.a | started 才受理；Plan 按 wire 追加并在正文上方持续到完整 valid | 正常按钮实点；Plan 先显、首 edit/修稿仍在 |
| UIA-M003-403.a | Unicode 码点 splice 与 occurrence；相邻重复 NOOP；seq/rev/range/draft/version 异常停止并有限核对 | 🌱 后高亮、正文精确等于 Result；复用未改 reducer 证据 |
| UIA-M003-404.a | 新稿首片前保留旧文；可见删尾/替换；只更新稳定正文，不重建 Plan/设置 | 节点 identity、focus、scroll 差≤2px |
| UIA-M003-405.a | 完整 valid Result 才原子建立正文、高亮、tags、targets/save；临时稿无正式资源 | valid 前后状态集成与 Result 精确比对 |
| UIA-M003-406.a | pending/EOF/retained 保留只读 Plan+稿；fail/cancel/new 清；Q02 valid 可存且 notice 持续 | 对应状态定向检查；有限 status |
| UIA-M003-407.a | PAGE-208 保留 M002 全字段、页头档位优先级编辑/影响确认；基础预算2只读；派生开关+N 0–99；影响/冲突重预览 | N0/N99/非法、preview-confirm、conflict-recheck；`admin-interactions.json` |
| UIA-M003-408.a | PAGE-212 保留 M002 标题、无限制管理选词、四配置和原动作；basic/enhanced 各走自身 preview 且 Plan/正文同规则 | 两 actual preview wire 自动播放；不得互借 fixture |
| UIA-M003-409.a | current draft_version/mode/run/status 才 ready；编辑或切模式使旧结果 stale；Q02 需确认后手动发布 | dirty input 保留且旧 publish 禁用；资格组合 |
| UIA-M003-410.a | 每片仅更新稳定正文与简洁状态；不抢焦点/滚动，不把正文设 live region | 61 次正文变化、2 次缩短、settings/result DOM 稳定 |
| UIA-M003-411.a | M002 响应栅格与新增区域在 1440/390 无横溢；目标≥44px；长文换行；skip/reduced motion | UI09 代表截图和横溢检查；320/768/axe/多浏览器留实施复核 |

## 动态数据与容差

- 用户、词、模型、权益、计划、预设来自生产 request/API/路由；Result/Plan 只来自当前 generation/preview namespace。
- 网络事件到达即应用，不显示百分比、内部 stage/reason/version/N/调用次数。demo 的 `playback.after_ms` 不代表生产时延。
- 正文流只更新 `.live-draft-text.textContent` 和简短状态。设置、选词、Plan 节点保持 identity；用户主动滚动后不拉回；渲染前后 scrollY 允许取整误差 ±2px。
- 标题/词义/搭配/正文可任意换行；不截断关键信息。触控/指针目标最小 44×44px。

## 恢复快照

本版待审源码快照为 `evidence/ui09/source.tar.gz`，逐文件 hash 在 `evidence/ui09/source-manifest.json`。快照只表示可恢复交付，不表示用户批准。

## 本版检查边界

UI09 新检查覆盖 M002 外壳继承、三页 1440/390、create 真实点击流、Plan/正文共存和 valid 清理、plans 0/99/非法、basic/enhanced preview 资格与控制台/横溢。UI07-R1 的 v5 reducer 业务证据在 reducer 未改变处仍可参考；UI08 截图不能证明 UI09 视觉。没有验证生产 Vue/DTO、真实模型/数据库/网络时延或用户视觉批准。
