---
milestone: M003
version: M003-UI-09
stage: uiux-design
role: uiux/base
agent_name: designer-tony
from: designer-tony
to: user-review
status: awaiting_user_review
date: 2026-10-10
---

# UI09 正式设计交接

## 结论

UI09 已按用户纠正，以 M002 当前有效正式设计为视觉与页面基线，重做 PAGE-204/208/212，并为 PAGE-216 标出共享生成区域。UI08 将 UI07-R1 原型视觉视为正式基线的解释已失效；其冻结包保留历史，不供实现。UI07-R1/BE05-R1 的 Plan 保留、v5 splice、终态与资格规则继续有效。

## 前端原始来源

- `design/design-spec.md`：区域、来源、UIA-M003-401.a–411.a 与数据边界。
- `design/copy.json`：M002 完整 zh/en 固定文案 + `m003.*` 新文案；原型直接消费。
- `design/theme.css`：import M002 theme 后仅追加 M003 区域样式。
- `design/prototype/`：可运行正式预览和 demo adapter；`prototype/m002/` 是本版使用的 M002 组件/本地图标快照。
- `design/interactions.md`、`responsive-accessibility.md`。
- `design/evidence/ui09/`：M002 基线、UI09 代表截图、浏览器报告、恢复包与 manifest。
  - 恢复入口：`design/evidence/ui09/source.tar.gz`；完整 hash 与逐文件清单：`design/evidence/ui09/source-manifest.json`。

## 受影响 FE01 接点

1. `/create`：保留 M002 Header/Settings/WordPicker/阅读纸，接入稳定 `#generation-status/#planning-preview/#live-draft/#final-result`；不要把 fixture/timer/query 带入应用。
2. `/admin/plans`：保留全部 M002 计划字段、页头档位优先级编辑入口和单 panel 两栏布局，在后部接入 read-only 2 与 0–99；影响预览/冲突使用实际响应。
3. `/admin/presets`：保留 title、无限制管理选词、四配置、保存草稿/预览/发布/下架；接入 mode、preview namespace、资格和 Q02。
4. `/trial/:presetId`：复用生成内容区与状态规则，保留现有试用外壳。

接收完成条件：UIA-M003-401.a–411.a 可在实际 Vue 页面观察；固定 copy 不再内联分叉；M002 本地资源/自定义控件语义保留；API-302/API-304/DB03 成为真实驱动；生产测试证明 Unicode 码点、代次隔离、Plan 保留、资格与保存。

## 已检查与限制

UI09 prototype 已完成三页 1440/390 目视、正常 create 实点、Plan/连续正文/valid、plans 0/99/非法、basic/enhanced preview、console/横溢定向检查。M002 继承由本版前后截图证明；旧 UI08 截图不用于此结论。未调用真实模型、API、DB，未验证真实时延、生产 Vue 或用户对 UI09 的视觉确认。

新增业务待决：无；CR-302 保持 `product_resolved_downstream_pending`，待 FE/实施等接续。当前状态保持 `awaiting_user_review`；本交接不批准前端实施、不切角色。
