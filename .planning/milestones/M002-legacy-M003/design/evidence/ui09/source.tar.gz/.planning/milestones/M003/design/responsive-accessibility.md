---
milestone: M003
version: M003-UI-09
agent_name: designer-tony
date: 2026-10-10
---

# UI09 响应式与无障碍

## 布局

- ≥1100px：继承 M002 create 310px 设置栏 + 右侧内容；admin 192px sidebar；preset 240px list + editor。
- 761–1099px：M002 栅格规则收敛，设置可折叠；新增 Plan/草稿仍在同一阅读纸，不另造横向轨道。
- ≤760px：所有主栅格单列；Plan 用法、服务字段单列；按钮可换行；长义项/搭配/正文 `overflow-wrap:anywhere`。
- 320/390：页面不得横向溢出；标题、选词 token、custom select、管理动作保持可读。长正文不设固定高度。

## 键盘与读屏

- skip link 到 `#main`；nav、tabs、details、word picker combobox/listbox、自定义 select 与全部动作沿 M002 键盘模型。
- 最小交互目标 44×44px；focus 使用 M002 可见轮廓，不以颜色单独表达 invalid/selected/pending。
- `#planning-preview` 有标题；`.plan-item` 保持文档顺序。正文不逐片朗读；简短 `.draft-status` 使用 polite。失败、冲突、非法输入用 `role=alert/status` 与文本说明。
- locale 与 meaning language 分离；正文/词条 `lang=en`，释义保留 request meaning language。动态缺值用 “—”，不制造词义或内部解释。

## 动效与阅读位置

书写点是唯一新增循环动效；`prefers-reduced-motion: reduce` 时完全停止。每帧只改正文 textContent/状态，不重建设置、Plan 或页面，不重置 focus。用户主动滚动后不跟随尾部；首次点击生成可带入结果区域一次。

## UI09 有限验证

已实看 1440 M002/UI09 create/plans/presets、390 create/plans/presets；390 横溢为 0。创建页正常按钮真实回放覆盖 Plan→正文→valid；Plan 与正文并存截图和 final 清理已记录。计划 0/99 有效、100 非法禁保存；两 preview 自动到 valid/可发布。生产 Vue、真实 API/DB/model、320 与 768 的最终实现由 frontend-bob 接收时复核；这些未验证项不被原型截图替代。
