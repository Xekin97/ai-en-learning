---
milestone: M003
version: M003-UI-06
agent_name: designer-tony
date: 2026-10-10
---

# UI06 响应式与可访问性

## 布局

| 视口 | 造文 | 计划 / 预设 |
|---|---|---|
| ≥1101px | 配置与稳定结果区约 39/61 双栏；配置 sticky | 管理导航 + 完整内容；计划双预算；预设列表 + 编辑器 |
| 761–1100px | 单列，配置取消 sticky | 导航保留，内容按宽度降列 |
| ≤760px | 顶栏换行、导航局部横滚；配置、草稿、资源和动作单列 | 管理导航/tabs/列表局部横滚；表单与冲突单列 |
| 320–360px | 草稿按词换行、无页面横溢；状态不压标题 | 数值、错误与按钮完整换行 |

正文区域允许自然增高，但 edit 不重建结果面板、不强制滚到底。用户主动滚动后，后续片段不改变 `scrollY`；终态资源出现在正文后方。英文正文标 `lang=en`，`overflow-wrap:anywhere` 仅作为极端长串保护。

## 键盘、朗读与动效

- skip link 常态离屏，focus-visible 才出现。原生 button/link/input/select/radio/checkbox 语义保留，交互目标至少 44×44px。
- 状态 pill 与可见状态文字共同表达；不使用颜色、百分比或内部版本作为唯一信息。
- `.live-draft-text` 不设 live region，避免每片重念全文；`.draft-status` 为 polite。failed 为 alert，pending/成功为 status。
- 草稿、pending、EOF、failed/cancelled 均没有保存；只有权威 valid 显示“收录到书架”。Q02 使用文字、边框和暖橙底共同提示。
- occurrences 按 Unicode 码点切片，🌱 的代理对不会使后续 garden/learn/share 高亮错位。
- `prefers-reduced-motion:reduce` 关闭书写点和 spinner 动画；业务时序与资格不变。

## 验证边界

Chromium 定向验证覆盖 1440 与 390 中英文、动态多片、纯删除、两次修订与 retained 恢复、滚动/DOM/焦点稳定、最终 Unicode 高亮、pending/EOF/cancel/failure、协议重复/错 rev/越界、预设 enhanced 与 basic 边界、计划 0/99/非法值。未执行真实 API/模型/DB、生产延迟、axe、全读屏、Safari/Firefox、真实 200% 缩放、UAT3302 或部署；这些留给实现与验收。
