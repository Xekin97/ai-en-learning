---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M003-UI-06
date: 2026-10-10
input_version: M003-PRODUCT-05 / M003-BE-04 / M003-FE-01
---

# M003 UI06 交接

## 原始说明与评审入口

designer-tony 按 `TRANSITION-M003-027` 将 PAGE-204 改为真实消费 BE04 versioned splice 的连续正文原型。首稿逐片增长；旧稿在新稿首片到达前保留；纯删除、换稿增长以及 V3 半稿后 retained 恢复都可见。正文仍不显示审稿报告、内部版本、轮次或上限。PAGE-208 与 PAGE-212 保持完整管理页面。

- 造文（默认一次改写）：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui06&page=create&scenario=rewrite-once&event=0&status=0&lang=zh`
- 计划管理：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui06&page=plans&plan=pro&limit=1&adminState=edit&lang=zh`
- 预设管理：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui06&page=presets&mode=enhanced&event=0&status=0&lang=zh`
- 两次改写后恢复/Q02：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui06&page=create&scenario=rewrite-twice-recover&event=0&status=0&lang=zh`

正常按钮会自动播放，不需要展开“原型场景”。`lang=en` 可看英文；合成等待来自 fixture `playback[].after_ms`，不代表生产延迟、性能提升或模型质量。

## BE04 接收与实际实现

原型直接 fetch `technical/fixtures/stream-v4/index.json`、index 中 10 个 wire 与 packages；未修改这些输入。reducer 只消费 `{event,data}`、有限 `status_responses[].body` 和播放等待，不从 `expected` / `internal_evidence` 驱动 UI。

- edit 使用 `draft_id/content_version/base_rev/rev/seq/at/delete_count/insert/source` 校验和应用；位置单位为 Unicode 码点，splice 与最终 occurrences 均不会被 🌱 的 UTF-16 代理对偏移。
- 相邻相同 seq 且事件数据完全相同为 NOOP。跳号、错 rev、越界、非法版本、旧 draft 复用、finalizing 后 edit 等停止当前播放并进入核对，不猜缺片或重新 POST。
- 草稿纯文本且不可保存。validated/status valid 才原子建立完整 passage/tags/targets、学习资源与保存资格。retained edit 本身不等于成功。
- finalizing、pending 和 EOF 保留已收正文；pending 只有限读取样例 status。无有效稿 failed/cancelled 清稿。Q02 最终包持续显示“内容审校未完成”且可保存。
- 自动播放只局部改 `.live-draft-text`、状态与动作；结果面板、配置区、焦点和用户滚动位置保持。每帧 replaceState。取消、重试、场景/mode/页面切换、popstate/pagehide、手动 step 都隔离旧代次。
- 预设只回放 exact enhanced `preview-rewrite`；basic 不借用它。validated 后核对当前草稿/mode/run 才 ready。未来 exact Q02 预览仍需人工确认后手动发布，本 fixture 未伪造 Q02。
- 计划页继续保留原字段、基础预算 2 只读、内容 0–99、影响预览与 revision 冲突。服务成本统计没有被做成产品仪表盘。

## 当前原件和恢复来源

- [设计规格](../design/design-spec.md)、[实际文案](../design/copy.json)、[主题](../design/theme.css)
- [原型入口](../design/prototype/index.html)、[交互实现](../design/prototype/app.js)、[管理展示数据](../design/prototype/fixtures.json)
- [交互合同](../design/interactions.md)、[响应式与可访问性](../design/responsive-accessibility.md)
- [UI06 浏览器报告](../design/evidence/ui06/M003-UI-06-browser.json)、[首轮报告](../design/evidence/ui06/M003-UI-06-browser-first-pass.json)、[次轮报告](../design/evidence/ui06/M003-UI-06-browser-second-pass.json)、[定向复验](../design/evidence/ui06/M003-UI-06-browser-rerun.json)及同目录 5 张代表截图
- [UI06 待审源码快照](../design/evidence/ui06/M003-UI-06-source.tar.gz)与 [hash 清单](../design/evidence/ui06/M003-UI-06-source-manifest.json)，包含完整 v4 index/10 wire/packages、M002 主题和本版设计依赖；排除 evidence，避免递归

UI04、UI05、UI05-R1 快照和证据均冻结保留。本稿不修改 workflow、产品、API、后端、前端、数据库、UAT3302，不调用真实模型或提供方，不提交 Git 或部署。

## 浏览器验证与首轮问题

最终聚合为 10/10 PASS、5 张截图、0 当前 page error；另有主会话独立真实点击证据 `reviews/evidence/ui06-root/actual-click.json`：42 次正文变化，约 990ms 首片、3830ms 缩为 13 码点、6215ms 定稿，最终正文与 fixture 一致，配置 DOM/焦点保留，折叠面板未展开。

首轮 7/10 的两项长度失败来自测试把 URL event 与 DOM 分开读取、跨帧后按 event 精确映射，属于检查方法问题。第三项“取消后重开超时”是真实原型问题：取消后场景停在 cancelled；现以 `resumeScenario` 恢复取消前场景并清理旧代次，次轮通过。次轮 8/10 的主观察器失败来自 `.count()` 与 `textContent()` 跨终态替换导致等待，并连带并发异常组超时；原子读取和顺序定向复验 2/2 通过。三份原始报告均保留，最终报告明确聚合来源。

覆盖：真实按钮多片首稿、纯删除与 V2 增长；V3 半稿及 retained V2/Q02；basic/paid 无改写、同 V 续写；pending→valid、EOF active、cancel/failure；取消后重试与旧 timer；重复 NOOP、错 rev、越界；预设 enhanced 资格和 basic 边界；计划 0/99/非法值；1440/390、中文/英文、DOM/焦点/滚动稳定和最终 Unicode 高亮。没有重复运行 BE04 fixture checker。

未验证：真实模型/提供方、生产延迟、网络与 DB 竞争、真实 10 秒核对、权限与 token 生命周期、费用、生成质量、前端构建、axe、完整键盘/读屏/200% 缩放、Safari/Firefox、UAT3302、部署。

## frontend-bob 后续复核

1. 把 FE3-04/06/07/09、FE3-T02 与 FE3-V02–06/09/12 重映射到 UI06 edit reducer；不得继续使用 learning_ready 或终稿打字动画。
2. 使用码点 splice/occurrences，完整实现 seq 指纹、revision、range、draft/content version、旧 epoch 和晚帧校验；协议错误停止流并查 status。
3. 以稳定组件局部更新正文，保留选择、表单、焦点和用户滚动；不要每片重建页面或朗读全文。
4. 只有 DB 权威 valid 完整包可保存/发布；Q02 notice 跨流/status/保存/发布保持。pending/EOF/retained 都不能推断成功。
5. 管理页继续保留基础预算 2 只读、内容 0–99、影响/冲突和 basic0/enhanced1；预设资格必须核对当前 draft/mode/run。
6. 实现阶段补真实 API、取消/断连/结算竞争、320/768、200% 缩放、axe、完整键盘/读屏、浏览器兼容和构建检查。正式产品移除原型场景、fixture 名与合成时序说明。

## 状态

**BLOCKED：无。开放 CR：无。** 当前为 `awaiting_user_review`。USER-M003-LIVE-TEXT、PRODUCT05、BE04 输入或原型自检都不能代替 UI06 的用户视觉/交互批准；本交接不自行进入前端实施。
