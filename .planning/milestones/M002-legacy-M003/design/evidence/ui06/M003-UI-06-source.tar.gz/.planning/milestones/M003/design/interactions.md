---
milestone: M003
version: M003-UI-06
agent_name: designer-tony
date: 2026-10-10
---

# UI06 交互与状态

## 造文 PAGE-204

1. 用户保留模型、场景、长度、释义语言与选词；演示输入固定为 `garden/learn/share` 以匹配 v4 fixture。删词后禁用生成。
2. 正常点击从当前场景 event=0 自动播放 `wire[]`，每帧只使用对应 `playback[i].after_ms`。第一次将结果带入视野，之后不再聚焦或滚动。每帧 `replaceState`，不堆历史。
3. reducer 先校验 namespace、started、连续 seq、相邻重复指纹、draft 生命周期、content version、base_rev/rev 与码点区间，再用 `Array.from(text)` 做 splice。紧邻完全重复 NOOP；非法帧保留安全草稿、停止播放并进入待核对。
4. edit 后出现纯文本草稿，不继承高亮、释义、hint 或保存资格。旧稿在修订首片到达前持续显示；该 edit 可以纯删除，再由后续 edit 继续增长。finalizing 保留现有全文。
5. validated/status valid 以权威 Result 整体替换草稿，随后显示标签、码点 occurrences 高亮、entry_meaning、hint_phrase 与保存。Q02 notice 不因保存消失。
6. settlement_pending / EOF 保留只读草稿，按 fixture 的有限 status 响应核对；active/503 后仍未知则停住并给“重新核对”，不无限轮询。retained 帧不直接赋予成功或保存资格。
7. failed/cancelled 清稿。取消、重来、切页/场景/mode、popstate、pagehide、手动 step 都终止旧 timer 和代次；重来恢复取消前场景，从 event=0 新播。

## 计划 PAGE-208

- 四计划标签及模型、长度、优先级、词数、日额度、不限开关继续存在。基础纠错固定全请求最多 2 次且只读。
- visitor/basic 固定内容 N=0；Pro/Plus 接受整数 0–99。0 关闭，1–99 开启；空、负数、小数、100 不截断，禁用影响预览。
- 影响预览不调用模型；保存冲突保留本地值、展示服务端最新值，并要求基于新 revision 再预览。

## 预设 PAGE-212

- 保留列表、名称、词汇、四项配置、保存草稿、模式、预览、用量和发布。mode/配置改变使旧资格 stale。
- enhanced 点击“生成预览”自动逐片播放 `preview-rewrite`，validated 后有限核对当前 draft/mode/run 再 ready；basic 没有本包 wire，不误播 enhanced。
- preview 草稿不可发布。ready 才能发布；若未来 exact fixture 带 `content_review_incomplete`，先显示持续 notice 与确认框，勾选也不自动发布。

## 局部渲染与焦点

自动播放只更新 `.live-draft-text`、简洁状态与动作区；`#generation-status`、配置表单、导航及页面滚动位置保持。预设同样只更新 `#preview-result` 内的草稿节点。正文不设 live region，独立 `.draft-status` 用 polite；终态正文也不主动全文朗读。书写点为轻微提示，reduced-motion 时静止。折叠原型面板保留逐帧检查，但不是完成正常操作的前置步骤。
