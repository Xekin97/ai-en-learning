---
milestone: M003
version: M003-UI-06
agent_name: designer-tony
status: awaiting_user_review
date: 2026-10-10
input_version: M003-PRODUCT-05 / M003-BE-04 / M003-FE-01
---

# M003-UI-06 完整页面设计规格

## 定位、入口与来源

UI06 落实 `USER-M003-LIVE-TEXT`：PAGE-204 的首稿与修订稿都在同一稳定阅读区逐片显示，用户能看到追加、删尾和替换；审稿等待保留当前正文，不显示内部报告、版本、轮次或上限。计划 PAGE-208 与预设 PAGE-212 保留 UI05-R1 的完整页面和管理字段。覆盖 CAP-301–305、DATA-301–304、AC-301–314，沿用 UIA-M003-401–411 并以本稿语义更新。

| 来源 | 用途 | 接收边界 |
|---|---|---|
| PRODUCT05 页面、能力、数据与 AI 行为 | 连续草稿、用户可见边界、保存与故障规则 | 产品输入；不等于 UI06 批准 |
| BE04 API-302 / API-304 | versioned splice、终态、有限核对、预设资格 | 待审技术输入；不声称字段获用户逐项批准 |
| `technical/fixtures/stream-v4/index.json`、10 个 wire、`packages.json` | 原型实际 fetch、播放和 reducer 输入 | 只读；不从 `expected` / `internal_evidence` 渲染或决定状态 |
| M002 `design/theme.css` 与 PAGE-204/208/212 | 暖白深绿品牌、导航、表单和阅读结果 | 继续继承 |
| UI04 / UI05 / UI05-R1 证据与快照 | 可恢复历史 | 冻结保留，不是当前评审稿 |

当前可恢复源码为 `evidence/ui06/M003-UI-06-source.tar.gz`，清单为 `evidence/ui06/M003-UI-06-source-manifest.json`。它是待审提交，不构成 UI 批准。

## UIA-M003-401–411

| ID | UI06 设计合同 | 稳定需求 | FE01 待复核 |
|---|---|---|---|
| UIA-M003-401 | 保留完整导航、模型/场景/长度/释义、`garden/learn/share` 选词、额度、结果和保存外壳 | PAGE-204, CAP-301, DATA-301, AC-308 | FE3-03/07, FE3-T01 |
| UIA-M003-402 | 只有 started 显示已受理、progress composing 显示正在生成；edit 到达后正文可读；无百分比、ETA、审稿轨道或 k/N | PAGE-204, CAP-301/302, AC-308/312 | FE3-04/07, FE3-V02/03 |
| UIA-M003-403 | `generation.edit` / `preview.edit` 按 Unicode 码点应用；相邻完全重复 NOOP；错序、错 rev、越界、旧 draft 复用或晚帧停止消费并核对 | PAGE-204/212, DATA-304, AC-308/309 | FE3-04/09, FE3-T02 |
| UIA-M003-404 | 新稿首片到达时才执行删尾/替换；等待期间保留旧全文；草稿为纯文本，不带旧高亮、释义或 hint | PAGE-204, CAP-302, AC-308/312 | FE3-04/07, FE3-V04 |
| UIA-M003-405 | validated/status valid 原子建立权威 Result、学习资源和保存；occurrences 使用码点偏移，🌱 之前/之后均准确；Q02 notice 持续 | PAGE-204/216, DATA-304, AC-306/309 | FE3-06/07, FE3-V05/06 |
| UIA-M003-406 | pending/EOF 保留只读草稿并有限核对；retained 只是编辑帧；无有效稿 failed/cancelled 清稿且不可保存 | PAGE-204, CAP-302, AC-306/313 | FE3-06/07, FE3-V09/12 |
| UIA-M003-407 | 计划完整表单保留原字段；基础纠错全请求最多 2 次只读；内容预算整数 0–99，0 关闭，保存前影响预览，冲突须重预览 | PAGE-208, CAP-303, DATA-302, AC-301–305/310/311 | FE3-08, FE3-T05/V11 |
| UIA-M003-408 | 预设完整编辑器保留 basic0/enhanced1；本包仅 enhanced `preview-rewrite`，不得伪装 basic；当前草稿/mode/run 匹配后才 ready | PAGE-212, CAP-305, DATA-303, AC-307/314 | FE3-09, FE3-T05/V12 |
| UIA-M003-409 | Q02 预设未来出现时 notice 持续且发布前需人工确认；过期、pending、failed、cancelled、stale 不可发布 | PAGE-212, CAP-305, AC-307/314 | FE3-09, FE3-V12 |
| UIA-M003-410 | 同一结果面板局部更新正文；不重建配置、导航或整页，不抢焦点、不强制滚底、不用 live region 朗读每片全文 | PAGE-204/212, AC-308/312 | FE3-07/09 |
| UIA-M003-411 | 1440/768/390/320、zh/en、键盘、44px 触控、reduced-motion；fixture、合成时序和测试说明只在折叠原型层 | PAGE-204/208/212, CAP-301–305 | FE3-07/08/09 |

## PAGE-204 公开流

原型启动时 fetch v4 `index.json` 及 `index.files`，每条播放等待直接取 `playback[i].after_ms`。计时只服务合成演示，不是生产延迟或额外 API 阶段。正常“生成短文”从场景起点自动播放；默认评审场景为 `rewrite-once`。

| 输入 | 用户看到 | 保存 |
|---|---|---|
| started / composing | 已受理、随后正在生成；正文仍空 | 禁用 |
| 首个及后续 edit | 同一阅读区逐片增长；书写点仅为轻提示 | 禁用 |
| 新 draft 首 edit | 保留旧稿直到该帧到达，再按 splice 可见删尾/替换并继续增长 | 禁用 |
| finalizing | 当前全文持续可读，只更新简洁状态 | 禁用 |
| validated / status valid | 权威完整包原子替换草稿，建立 tags/高亮/释义/hint | 启用 |
| Q02 valid | 恢复的完整有效稿 + “内容审校未完成” | 启用 |
| pending / EOF / protocol gap | 已收草稿只读保留，显式有限核对 | 禁用 |
| failed / cancelled | 清除半稿和临时字段 | 禁用 |

`rewrite-once` 可见 V1 多片追加、一次纯删除帧、V2 多片增长；`rewrite-twice-recover` 可见 V3 半稿后 retained 恢复完整 V2，再由 validated 建立 Q02 终态。basic、paid-no-rewrite、native-continuation 分别覆盖普通、不改稿付费与同 V 续写。相邻相同 seq 且规范事件完全一致才 NOOP；任何其它重复/倒退/跳号、base_rev/rev 不符、码点越界、非法版本或复用已退休 draft 都不猜测、不缓冲重排。

## PAGE-208 / PAGE-212

计划页保持 visitor/basic 内容 N=0、Pro/Plus 初始 1 且可配置 0–99；基础预算 2 只读。非法值保留原输入、`aria-invalid=true` 且禁用预览。影响预览显示新旧、受影响人数、仅新请求及在途快照；revision 冲突展示远端与本地并要求重新预览。

预设页保持 basic0/enhanced1 独立于管理员计划。UI06 只回放 v4 的 exact `preview-rewrite` enhanced wire；basic 仍可编辑但不会借用增强样例。preview.validated 后原型以当前编辑器已知 draft/mode/run 做一次有限资格核对再 ready；Q02 条件逻辑仍要求管理员确认后手动发布，本 fixture 没有伪造 Q02 返回。

## 待审范围

待用户评审：连续正文的节奏、可见删尾/换稿、等待时保留全文、Q02 恢复提示、手机阅读、预设增量预览以及原完整管理页组合。原型不调用真实 API、模型或提供方；未验证真实延迟、连接竞争、DB 持久化、权限、费用、生成质量或部署。服务成本统计按 PRODUCT05/BE04 留给后续实施测量，本版不增加产品仪表盘。状态建议 `awaiting_user_review`。
