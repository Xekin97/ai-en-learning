---
milestone: M003
version: M003-UI-10-R1
agent_name: designer-tony
status: ready_for_user_review
date: 2026-10-12
input_version: M003-PRODUCT-09 / M003-BE-07 / M003-DB-04 / CR-306
visual_baseline: M002 current effective formal design
interaction_baseline: M003-UI-09-R3 plus USER-M003-CUSTOM-PARAMETERS
---

# M003-UI-10-R1 模态整改规格（待用户视觉评审）

> `SUPERSEDED / USER-M003-UI10-MODAL-REWORK`：原 UI10 的 PAGE-208 编辑器仅使用 `<dialog open>`，不在 top layer；其 `UIA-M003-412.a–418.a` 中所有依赖“弹窗成立”的结论失效，不得交前端实施。旧报告、截图及 `evidence/cr306/M003-UI-10-source.tar.gz` 原样保留为失败恢复证据。UI10-R1 已按生产 `AppDialog.vue` 的 `showModal()`、Teleport、`.dialog-body`、固定 footer 与焦点恢复行为整改；新结论只由 `evidence/cr306-r1/` 支持。

UI10 按 `USER-M003-CUSTOM-PARAMETERS` 与 `TRANSITION-M003-071` 定向修订 CR-306：在 M002 正式视觉和 UI09-R3 完整页面上，为 PAGE-208 模型管理模块加入每模型自定义请求参数 JSON，并把 BE07 的等待/失败/取消/pending 与预览失败映射到 PAGE-204/216/212。旧的专用推理 mode/effort 和自动能力目录方向失效。UI09-R3 的学习者流程、共同 Plan、计划管理和预设业务保持有效；本版是待用户评审的新视觉，不能据此提前实施。

## UI10-R1 当前目标、范围与追踪

| 页面 / 能力 / 数据 | 本轮设计结果 | 来源 |
|---|---|---|
| PAGE-208 模型管理模块 / CAP-306 / DATA-306 | 保留服务商分组与现有模型表单；在每模型“高级选项”加入 JSON 编辑器。`{}` 不追加自定义参数；最大输出 tokens 与结构化输出仍为专用单一权威字段 | PRODUCT09、API-306、BE07 `management.json` / `errors.json` |
| PAGE-204 / PAGE-216 / CAP-302、306 | 沿 UI09-R3 完整工具台展示真实无公开内容等待、可取消、失败、cancelled、settlement pending；不显示私有推理、轮次、假进度 | BE07 `streams.json`；stream-v5 既有业务流 |
| PAGE-212 / CAP-304、306 | 保留 basic/enhanced 预览、旧结果与发布资格；新增 `preview_timeout` 失败映射，不另建测试页 | BE07 `streams.json`；stream-v5 既有预览 |

- `CONFIRMED`：每模型高级 JSON、管理员按供应商文档填写、`{}` 不追加；保护业务/凭据；保存 0 模型调用；新视觉须用户评审。
- `CONFIRMED`：不再设计专用推理 mode/effort 或能力目录；不改变现有导航、计划、模型选择、最大输出 tokens、结构化输出和 v5 业务流。
- `PROPOSED / 待审`：UI10-R1 的具体视觉、文案层级和响应式结果。没有未确认且会阻塞本版设计的业务假设。
- 历史恢复：UI09-R3 冻结原件为 `../reviews/evidence/cr306-design-baselines/ui-before-cr306.tar.gz`，清单为 `../reviews/evidence/cr306-design-baselines/ui-before-manifest.json`；失败 UI10 包 `evidence/cr306/M003-UI-10-source.tar.gz` 保持不变，UI10-R1 恢复包见 `evidence/cr306-r1/M003-UI-10-R1-source.tar.gz`。

## UI10-R1 直接评审入口

前缀：`http://127.0.0.1:4174/M003/design/prototype/`

| 页面 / 状态 | query（均可直接打开） | 稳定区域 |
|---|---|---|
| PAGE-208 完整服务商分组 | `?page=models&lang=zh&view=formal&state=list&rev=ui10-r1` | `.generic-provider-list` |
| PAGE-208 JSON 编辑 | `?page=models&lang=zh&view=formal&state=edit&rev=ui10-r1` | `#admin-model:modal`、`.dialog-body`、`.custom-parameters` |
| PAGE-208 保护字段错误（EN / 移动同入口） | `?page=models&lang=en&view=formal&state=error&case=protected_model&rev=ui10-r1` | `[role=alert]`、`.custom-parameters[aria-invalid=true]` |
| PAGE-208 格式错误 / 冲突 / 测试拒绝 / 保存成功 | `state=error&case=syntax` / `state=conflict` / `state=probe-error` / `state=saved` | 对话框内 alert 或列表页 status |
| PAGE-204/216 无内容超时 / 取消 / pending | `?page=create&lang=zh&view=formal&scenario=cr306-timeout&event=3&status=0&rev=ui10-r1`；将 scenario 换为 `cr306-cancelled` 或 `cr306-settlement_pending`（pending 用 `status=1`） | `#generation-status` |
| PAGE-212 预览超时 | `?page=presets&lang=zh&view=formal&mode=basic&previewFailure=timeout&event=3&status=0&rev=ui10-r1` | `#preview-result` |

原型直接读取 `../../technical/fixtures/cr306/index.json` 指向的 `management.json`、`errors.json`、`streams.json`，以及既有 stream-v5。`expected`、`internal_evidence`、`boundaries` 和原始 JSON（管理编辑器除外）不渲染。query 与合成数据只用于设计复现，生产路由仍为 `/admin/models`、`/create`、`/trial/:presetId`、`/admin/presets`。

## UI10-R1 页面与内容定位

1. PAGE-208 沿现有管理 header/sidebar、服务商卡、模型行和编辑对话框。表单顺序仍是服务商连接 → 模型基本字段 → 高级选项 → 启用/显式测试 → 取消/保存。
2. 高级选项顺序是最大输出 tokens → 结构化输出 → 自定义请求参数 JSON → 模型说明。只有 JSON 区出现必要的 API 参数示例与保护边界；页面其他区域不散落实义实现细节。
3. JSON 说明同时给出 OpenRouter 示例 `{"reasoning":{"enabled":false}}`、`{}` 语义、16 KiB / 深度 8 / 重复键 / U+0000 规则，以及凭据、model/messages/stream、URL/headers、最大输出与结构化字段的保护边界。
4. 格式、重复键、对象类型、保护字段、深度、数值、U+0000 错误在 textarea 下关联呈现，并保留原始输入。版本冲突保留本地草稿，刷新并合并后要求重新核对。
5. 保存文案明确“保存只更新配置，不会调用模型”；成功后回到完整服务商页，并把此前连接测试标为失效。显式测试只证明本次短流连接，不宣称完整生成、结构化结果或参数效果通过。编辑已测试配置时立即显示旧结果失效。
6. 取消先显示放弃确认；“继续编辑”恢复 JSON 和其他输入。`PAGE-204/216/212` 只复用合同已有终态与文案，不显示内部推理，不新增能力。

固定双语文案键只在 `copy.json` 的 `cr306.*` 与沿用 `gm.*` 中维护；动态服务商、模型与错误样例来自 BE07 fixtures。视觉 Token 只在 `theme.css` 维护；本版新增/修订 `#admin-model:modal`、`.dialog-body`、`.m003-model-dialog`、`.custom-json-field`、`.custom-parameters`，其余复用 M002 组件。

## UI10-R1 验收合同

| ID | 必须保持的可观察结果 | 检查方法 / 证据 |
|---|---|---|
| UIA-M003-412.r1 | PAGE-208 使用完整模型管理列表作背景；从被点击的服务商打开真实 `#admin-model:modal`，不能用 `[open]` 或定位层模拟；新增与编辑标题/初值不同 | 现网只读基线 + R1 列表→指定 provider 实点；`10/11-r1` 截图 |
| UIA-M003-413.r1 | 框体复用 AppDialog：标题固定、`.dialog-body` 独立滚动、footer 固定；背景不可交互且底层 scroll 位置不变 | `:modal=true`、hit test、header/footer rect、page scroll 断言 |
| UIA-M003-414.r1 | 每个模型高级选项分别持有原始 JSON 草稿；`{}`、示例、保护规则与 0 调用说明准确；最大输出和结构化输出仍是单一权威字段 | 多模型不同 raw value；新增模型与协议实点；`12-r1-modal-json-1440.png` |
| UIA-M003-415.r1 | 格式/保护错误紧贴对应 textarea 并保留原始输入；详细安全规则按需展开；版本冲突保留每模型草稿 | BE07 errors fixture → `aria-invalid/aria-describedby`；`14-r1-modal-error-390.png` |
| UIA-M003-416.r1 | 关闭、取消、Escape、遮罩统一进入 dirty 规则；继续编辑保留输入，放弃后关闭；叠层确认限制焦点；最终回到精确 opener | 浏览器实际 Tab/Shift+Tab、Escape、内/外点击、确认层和焦点恢复 |
| UIA-M003-417.r1 | 显式测试只验证短流且按模型取当前快照；任何配置变化使旧测试失效；保存本身 0 模型调用，成功回完整列表 | probe/saved/conflict 文案与每模型草稿映射；API-306 接收合同 |
| UIA-M003-418.r1 | 1440/390 无横溢；手机正常入口从服务商段开始；错误原因在可见区优先于帮助和规则；双语、label/help/error、44px 与 reduced motion 沿 M002 | `modal-rework-browser.json` completed=true/PASS；`13/14/15-r1` 截图 |

R1 浏览器证据为 `evidence/cr306-r1/modal-rework-browser.json`，其中 `completed=true` 且 `result=PASS`；异常中断会记录 `run_error` 并强制失败。现网 AppDialog 只读对照为 `live-appdialog-observation.json`。代表图为同目录 `10-r1-list-1440.png`、`11-r1-modal-initial-1440.png`、`12-r1-modal-json-1440.png`、`13-r1-modal-initial-390.png`、`14-r1-modal-error-390.png`、`15-r1-discard-confirm-390.png`。这些只证明静态正式设计、交互原型与合成合同状态，不证明 Vue/API/DB 实施、供应商参数效果或 CR-306 已修复。

## UI09-R3 未受影响基线入口（继续有效）

前缀：`http://127.0.0.1:4174/M003/design/prototype/`

| 稳定页面 | 正式预览 query | 生产入口 | 本版范围 |
|---|---|---|---|
| PAGE-204 造文 | `?page=create&lang=zh&view=formal&scenario=rewrite-once&event=0&status=0&rev=ui09-r3` | `/create` | M002 设置、选词、阅读纸面 + Plan/连续草稿/权威结果 |
| PAGE-208 计划管理模块（与模型管理模块沿用同一产品编号） | `?page=plans&lang=zh&view=formal&plan=pro&contentLimit=1&rev=ui09-r3` | `/admin/plans` | M002 完整计划字段 + 基础纠错与内容返修配置 |
| PAGE-212 预设 | `?page=presets&lang=zh&view=formal&mode=enhanced&event=0&status=0&rev=ui09-r3` | `/admin/presets` | M002 完整编辑器 + basic/enhanced 实际预览与发布资格 |
| PAGE-216 试用共享区 | PAGE-204 使用 basic 请求的结果区域 | `/trial/:presetId` | 复用 Plan/草稿/结果表达；本版不重做试用页外壳 |

`view=formal` 隐藏合成演示控件。fixture、scenario/event/status query 与回放 timer 都属于 demo adapter，不进入正式产品。

## 原件与来源

| 来源 | 本版用途 | 精确文件/选择器 |
|---|---|---|
| M002 正式品牌与页壳 | 词涟鱼形/涟漪 SVG、暖白/深绿、顶栏、导航、管理侧栏 | `../../M002/design/prototype/app.js` 的 `mark`、header；`../../M002/design/theme.css` |
| M002 造文 | 310px 设置栏、配置 icon、自定义 select、选词器、右侧阅读纸 | `.workspace`、`.creation-settings`、`.generation-word-panel`、`.article`；本版 `#create-settings` |
| M002 计划 | underline tabs、两栏原字段、单 panel | `.tabs`、`.form-grid`、`.admin-options`; `#plan-priority/#plan-max/#plan-limit/#plan-unlimited` |
| M002 预设 | master-detail、标题→无限制管理选词→4 配置→原动作→纸面预览 | `.admin-master-detail`、`#preset-title`、`#preset-words`、`#preset-model/style/length/language` |
| M002 资源 | 本地 Lucide 图标与无外部字体资源 | `prototype/m002/icons.js`、`prototype/m002/assets/lucide.json`；许可证同目录 |
| PRODUCT07 / BE05-R1 / API-302,304 / DB03 | 状态、数据、资格与持久化约束 | 只引用权威合同，不在设计层复制第二套 DTO |
| stream-v5 | demo exact `wire[]` 与有限 status 回放 | `../../technical/fixtures/stream-v5/index.json` 及 15 个 wire；不读 expected/internal_evidence 渲染 |

固定中英文只取 `copy.json`；样式只取 `theme.css`（先 import M002，后追加 `m003-*`）。模型名、用户、额度、2/3 词、文章、Plan、释义、tags 都是动态数据，不是 copy。缺固定 key 显示 `⟦key⟧` 只作为设计自检，生产需记录错误并采用产品定义的安全回退。

## 页面区域与元素顺序

### PAGE-204 / PAGE-216

1. M002 learner header：真实 mark、主导航、locale、平台消息、账号菜单。
2. `.page-head`：`create.title/create.desc`；右侧 quota 来自权益数据。
3. `.workspace` 左侧 `#create-settings.settings.creation-settings`：model(bot) → style(book-open) → length(layers) → meaning language(book-open-text)。
4. 右侧 `.generation-word-panel`：M002 选词器、随机词、搜索 listbox、正常“开始生成”。目标词以 request 为准。
5. 同列 `#generation-status.m003-generation-paper`：结果抬头 → `#planning-preview` → `#live-draft .live-draft-text` → `#final-result`。Plan 和正文各是纸面内分区，不另起过程轨道。
6. authoritative valid 时用完整 Result 原子替换临时区，建立 passage 高亮、tags、学习资源和保存动作。

Plan 只显示 scene 与每个 request entry 的 sense/phrase；提示 key `m003.plan.note`。Plan 从收到首条 plan_item 起一直保留，初稿、固定编辑、条件修稿、retained、pending/EOF/finalizing 均不清；valid 完整 Result、失败、取消或新请求才清。Plan 不宣称与编辑后正文实时一致。

### PAGE-208

M002 管理 header/sidebar → `a.plans` heading（保留全计划“档位优先级”编辑入口与影响确认）→ 访客/基础/Pro/Plus underline tabs → 单 panel：

- 左列：`a.plan.models` 全部模型；`a.plan.lengths` short/medium/long/xlong。
- 右列：`priority` 数字；`words.limit` 数字；`a.plan.limit` 滚动 24h 数字；`a.plan.unlimited`。
- 其后新增 `#service-settings`：基础纠错预算 2（只读）；内容返修 0–99（普通计划不可用，付费计划可配，0 关闭）。不在产品区写测试到 2 次、99 不实跑等验证策略。
- 最后 `#change-preview/#version-conflict/#plan-actions`。影响预览用 `m003.impact` 分别标注 `basicUsers` 与 `trialUsers`；两类用户可能重叠，禁止相加或声称净影响人数。服务 badge 与派生开关/N 保持一致：N=0 显示基础，N=1–99 显示增强。冲突来自真实版本保存响应，formal 页面无造冲突按钮。

### PAGE-212

M002 管理 header/sidebar → heading/新建 → `.admin-master-detail`：左预设列表；右编辑 panel 按原顺序：

1. 状态 badge、规则说明、`#preset-title`。
2. 管理选词器 `#preset-words`，不套用户计划选词上限，不显示随机词。
3. model/style/length/meaning language 四字段。
4. 新增 `#preview-mode`：basic / enhanced；模式必须和实际 preview fixture/request 一致。
5. 原动作：保存草稿、生成/取消预览、发布、下架；Q02 仅在 incomplete 时追加确认。
6. `#preview-result` 使用与造文相同 Plan/连续正文/Result 纸面规则；preview namespace 独立。发布必须匹配 current draft_version + mode + run 且 status valid；Q02 还需明确确认。

## UIA-M003-401.a–411.a 正式验收合同

以下保留 UI08 已发布的稳定 ID，UI09 只更新其 M002 视觉基线与可观察结果，不缩写、重编号或退休 `.a`。

| ID | 可观察结果 | 前端接收检查 |
|---|---|---|
| UIA-M003-401.a | PAGE-204 完整导航、M002 310px 配置、原选词/额度/纸面结果与保存外壳；真实 fish/infinity mark 与本地 Lucide icon | M002/UI09 1440/390 对照；`#create-settings/#create-words/#generation-status` 同页 |
| UIA-M003-402.a | started 才受理；Plan 按 wire 追加并在正文上方持续到完整 valid | 正常按钮实点；Plan 先显、首 edit/修稿仍在 |
| UIA-M003-403.a | Unicode 码点 splice 与 occurrence；相邻重复 NOOP；seq/rev/range/draft/version 异常停止并有限核对 | 🌱 后高亮、正文精确等于 Result；复用未改 reducer 证据 |
| UIA-M003-404.a | 新稿首片前保留旧文；可见删尾/替换；只更新稳定正文，不重建 Plan/设置 | 节点 identity、focus、scroll 差≤2px |
| UIA-M003-405.a | 完整 valid Result 才原子建立正文、高亮、tags、targets/save；临时稿无正式资源 | valid 前后状态集成与 Result 精确比对 |
| UIA-M003-406.a | pending/EOF/retained 保留只读 Plan+稿；fail/cancel/new 清；Q02 valid 可存且 notice 持续 | 对应状态定向检查；有限 status |
| UIA-M003-407.a | PAGE-208 保留 M002 全字段、页头档位优先级编辑/影响确认；基础预算2只读；派生开关+N 0–99；N0 badge 为基础、N1–99 为增强；基础用户/有效体验用户分别呈现且不求和；影响/冲突重预览 | Pro/Plus N0/N1、两类人数标签、N99/非法、preview-confirm、conflict-recheck；`evidence/ui09-r3/cr303-report.json` 与既有 `admin-interactions.json` |
| UIA-M003-408.a | PAGE-212 保留 M002 标题、无限制管理选词、四配置和原动作；basic/enhanced 各走自身 preview 且 Plan/正文同规则 | 两 actual preview wire 自动播放；不得互借 fixture |
| UIA-M003-409.a | current draft_version/mode/run/status 才 ready；编辑或切模式使旧结果 stale；Q02 需确认后手动发布 | dirty input 保留且旧 publish 禁用；资格组合 |
| UIA-M003-410.a | 每片仅更新稳定正文与简洁状态；不抢焦点/滚动，不把正文设 live region | 61 次正文变化、2 次缩短、settings/result DOM 稳定 |
| UIA-M003-411.a | M002 响应栅格与新增区域在 1440/390 无横溢；目标≥44px；长文换行；skip/reduced motion | UI09 代表截图和横溢检查；320/768/axe/多浏览器留实施复核 |

## 动态数据与容差

- 用户、词、模型、权益、计划、预设来自生产 request/API/路由；Result/Plan 只来自当前 generation/preview namespace。
- 网络事件到达即应用，不显示百分比、内部 stage/reason/version/N/调用次数。demo 的 `playback.after_ms` 不代表生产时延。
- 正文流只更新 `.live-draft-text.textContent` 和简短状态。设置、选词、Plan 节点保持 identity；用户主动滚动后不拉回；渲染前后 scrollY 允许取整误差 ±2px。
- 标题/词义/搭配/正文可任意换行；不截断关键信息。触控/指针目标最小 44×44px。

## 恢复快照

本版纠偏源码快照为 `evidence/ui09-r3/source.tar.gz`，逐文件 hash 在 `evidence/ui09-r3/source-manifest.json`；冻结 UI09/UI09-R1/UI09-R2 包保持原 hash。快照只表示可恢复交付，不替代 FE 接收。

## UI09-R3 PAGE-208 语义纠偏

UI09-R3 只解决 CR-303。影响预览继续复用既有 `m003.impact` 文案，但 `basicUsers` 与 `trialUsers` 分别填入具名位置，不进行加法。服务 badge 直接跟随由合法 N 派生的 `reviewOn`：付费计划 N=0/关闭时为基础，N=1–99/开启时为增强。该修订不改变 UI09-R2 已接受的页面视觉、760px 居中阅读列、其他页面或流式交互。

## UI09-R2 阅读列对齐

UI09-R2 依据 `USER-M003-READING-ALIGNMENT` 将 create/preset 共享结果纸面的 Plan、草稿和最终稿统一放入居中的 760px 阅读列；宽屏左右留白对称，窄屏占满可用宽度，内部文本保持左对齐，不设置右侧功能栏。其余 UI09-R1 间距精修保持：create 的 picker/paper 节奏；plans 的服务标题、badge、开关视觉/焦点顺序与双栏字段/help 对齐；presets 的 icon-label、radio/两行说明、配置→模式→动作→预览节奏。桌面正文行高保持 1.85，移动为 1.78，未以压缩内容换取短页面。`copy.json`、prototype reducer/render、fixtures 与 M002 原件均未修改。

## 本版检查边界

UI09-R3 只新增 PAGE-208 的 Pro/Plus N0/N1、开关往返和两类人数独立显示检查；其余 M002 外壳、三页响应式、流式生成与预设证据复用 UI09-R2 及更早未变部分。UI09-R2 已获用户接受，本次纠偏无需重复选择同一视觉方案。没有验证生产 Vue/DTO、真实模型、数据库或网络时延。
