---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_design_submission_review
version: M003-UI-11
date: 2026-10-13
---

# CR-309 UI/UX 设计交接

## 使用的输入与确认边界

- 用户反馈与授权：`USER-M003-GENERATION-VISUAL-CONSISTENCY-20261013`，要求在现有 M002/UI09 系统内统一生成前、中、完成后的同类元素，尤其词义。该授权允许受限设计→前端→QA 闭环，不代表本稿已获用户批准或 UAT 已接受。
- 当前变更：[CR-309](../changes/CR-309.md)；状态入口为 `TRANSITION-M003-086`。整改前完整基线保存在 `../reviews/evidence/cr309-entry-086/before.tar.gz`。
- 路由锁请求为 `gpt-5.6-sol/high`；运行时实际模型没有可验证证据，保持 `unknown`，不据此改变职责或结论。
- 本轮只覆盖 PAGE-204/216/212 的 Plan、草稿、Result 共用结果区。Plan 内容继续是暂定，完整 valid Result 继续是权威；不改业务、copy、API、数据、模型、收费、流协议或 UAT 数据。
- Explore、Library、已发布内容卡和模型管理不在本轮。M003-UI-10-R1.1 与 UI09-R3 未冲突规则继续有效。

## 本次产物

- [当前正式规格](../design/design-spec.md)：CR-309 决定、复现场景、UIA-M003-419–422 与精确 Vue/CSS 接点。
- [可运行原型](../design/prototype/index.html)、[样式真源](../design/theme.css)、[交互](../design/interactions.md)、[响应式与无障碍](../design/responsive-accessibility.md)。`copy.json` 沿用且未修改。
- [浏览器报告](../design/evidence/cr309/M003-UI-11-browser.json) 与同目录截图：1440/390 before/during/after，另含 PAGE-212 during/final。
- [QA 只读前态](../verification/evidence/cr309-qa/before/baseline.md)：记录生产 Plan/final 的列宽、gap、边框、padding 与字体差异；仅作设计输入。
- 当前源码恢复包与逐文件清单：`../design/evidence/cr309/M003-UI-11-source.tar.gz`、`M003-UI-11-source-manifest.json`。

## 设计决定与实现接点

M002 `preset-meanings` 的分隔行列表成为 CR-309 唯一视觉真源。Plan 与 Result 均使用 `dl > div > dt + dd + dd`：Plan 映射 `entry / sense / form · phrase`，Result 映射 `entry / entryMeaning / hintPhrase`。两者共享 17px 阅读字体词条、13px / 1.65 辅助行、10px 行内距、1px 顶分隔线、桌面两列 24px gap、移动单列。Result 的 language label 复用生产本地化名称，不显示 raw `zh/en/ja`。

Plan、草稿、final 同时锁定在 760px 居中 `.m003-result-body`。三类正文共享 `width:100% / margin:18px 0 14px / pre-wrap / anywhere / 1.85`，移动行高 1.78；不得修改全局 `.article`、`.resource-grid` 或 `.preset-meanings`，以免波及 Explore/Library。

前端架构必须先在 `technical/frontend.md` 记录 CR-309 接收映射：

1. 新建仅供 PAGE-204/216/212 使用的 `GenerationVocabularyList.vue`，不要替换 Explore/Library 的 `PresetWordMeanings.vue`。
2. `GenerationWorkspace.vue` 的 Plan 卡片和 final `study-resources/resource-grid` 都改用该组件。
3. `pages/admin/presets.vue` 的 live Plan 行内段落和 final preview 都改用该组件；编辑器外空释义提示保持。
4. `frontend/app/assets/css/theme.css` 只在 M003 尾层加入 `.m003-vocabulary-panel/list` 与受限正文规则。

技术接收可调整组件内部命名，但不能改变 DOM 语义、字段顺序、视觉结果或范围保护。

## 浏览器自检

- 原型在专用 4176 静态服务中使用既有 stream-v5 fixture 检查；未调用真实模型，也未重启或修改 UAT3014。
- `M003-UI-11-browser.json` 为 `4/4 PASS`，console error `0`。1440 结果体前/中/后均为 760px；390 均为 324px且横溢 0。词条 Plan/final 的 computed font、颜色、line-height、margin、padding、border 相同；桌面两列、移动单列。
- 已实际查看 8 张代表图。PAGE-204/216 和 PAGE-212 的 Plan/final 都呈现同一分隔行语法；正文状态变化没有宽度或行距跳变。
- 这些证据只证明正式设计源与合成状态，不证明 Vue 实现、独立 QA 或 UAT。

## 文档整理与历史

- 当前权威入口是本交接与 `design-spec.md` 顶部 CR-309 章节；旧 UI10/UI09 规则保留在规格后部作为未改范围的继承合同。
- 被替代的是 UI09 的 Plan 白底边框卡片表达，以及现实现的 final `resource-grid/resource-card` 和 PAGE-212 live Plan 行内段落；旧审批、失败证据和恢复包未覆盖或删除。
- 稳定验收编号为 UIA-M003-419–422；CR-309 仍 open。无未确认且会改变本次设计结果的业务假设。

## 下一步

- 由控制角色进行设计提交检查；通过后按 Profile 先交 `frontend-bob` 完成 CR-309 前端技术接收，再交 `frontend-claire` 实现。不得从本交接直接跳过技术接收进入实现。
- 技术接收完成条件：在 `technical/frontend.md` 明确共享组件、三处调用、CSS 局部覆盖、本地化 language label、UIA-M003-419–422 与 Explore/Library 保护测试范围。
- 实现后由 `qa-quinn` 做缺陷复验：PAGE-204/216/212 before/during/final 的结构、computed style、1440/390 响应式、暂定/权威语义与无横溢；QA 按既有政策不判断文章质量。

> 本交接不自批设计、不切换阶段，也不表示用户 UAT 或里程碑通过。
