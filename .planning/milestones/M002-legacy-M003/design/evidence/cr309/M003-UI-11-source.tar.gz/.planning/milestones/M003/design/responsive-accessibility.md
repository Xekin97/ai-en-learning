---
milestone: M003
version: M003-UI-11
agent_name: designer-tony
date: 2026-10-13
---

# M003-UI-11 响应式与无障碍

## CR-309 当前规则

- Plan、草稿、Result 在 PAGE-204/216/212 共用最大 760px、居中的 `.m003-result-body`；可用宽度不足时占满。不得让 final 回到全局 `.article` 的 720px / 8px padding，或让 admin preview 使用另一套正文宽度。
- 词条列表在 `>760px` 为两列、24px 列间距；`≤760px` 为单列。每项从 1px 分隔线开始，padding `10px 0`；长词、释义、`form · phrase`、`hintPhrase` 都允许换行且不截断。
- 正文三种状态统一 `pre-wrap/anywhere` 和 `18px 0 14px` margin；行高桌面 `1.85`、移动 `1.78`。390px 代表状态无横溢；320/768 由实现接收时复核。
- 使用 `dl/dt/dd` 保留词条与释义关系；Plan 标题和暂定说明保持可读，Result heading 与本地化 language label 保持关联。列表不设 live region，增量状态仍只由既有 concise polite status 通知。
- 本轮没有新增交互目标或动效；M002 focus、44px 目标和 reduced-motion 规则继续有效。

以下 UI10-R1.1 / UI09 规则在未冲突处继续有效。

R1.1 继承用户已接受的 R1 布局、断点、模态生命周期和无障碍合同，仅澄清 API-306 文案与错误映射；没有新增布局或视觉变更。

## CR-306 模型编辑补充

- ≥761px：服务商分组沿 M002 admin 双栏页壳；编辑器最大宽 720px；标题和 footer 固定，`.dialog-body` 在视口内独立纵向滚动。JSON 区与专用字段保持同一模型卡宽度，编辑器不横向滚动。
- ≤760px：管理导航沿 M002 规则横向可见；服务商 header、模型动作与表单双列改为单列。对话框沿现有 max-width 与视口安全边距规则，390px 样例实测宽 354px（左右 18px、上下约 10px）；固定 footer 保留取消/保存。textarea 最小高 156px，可纵向调整，不允许页面横溢，也不得另写死 370px 框宽。
- 每个 `label[for=custom-parameters-{index}]` 明确关联自己的 textarea；帮助为 `custom-parameters-help-{index}`，错误以 `role=alert` 并由 `aria-describedby` 关联，非法时 `aria-invalid=true`。字节计数是辅助信息，不代替错误文本。
- 关闭按钮、details summary、textarea、测试、取消、保存及确认动作均进入自然 Tab 顺序；真实 `showModal()` 打开时焦点限制在最上层对话框；叠层确认关闭后回父框，父框关闭后回精确触发按钮；底页滚动位置不变。错误保存后实现应聚焦首个错误字段；原型验证 textarea 后一 Tab 到模型说明。
- 错误、成功、测试失效与冲突均有文字，不仅依赖红/绿/黄。代码示例允许换行且按文本渲染；长模型 ID、URL、错误和双语文案使用 `overflow-wrap:anywhere`，JSON 编辑仍保留等宽预格式。
- 交互目标继续使用 M002 的 ≥44px 规则。`prefers-reduced-motion: reduce` 下对话框与状态不做入场动画；错误、保存、probe 和 waiting 状态均即时更新。

## 布局

- ≥1100px：继承 M002 create 310px 设置栏 + 右侧内容；admin 192px sidebar；preset 240px list + editor。
- 761–1099px：M002 栅格规则收敛，设置可折叠；新增 Plan/草稿仍在同一阅读纸，不另造横向轨道。
- ≤760px：所有主栅格单列；Plan 用法、服务字段单列；按钮可换行；长义项/搭配/正文 `overflow-wrap:anywhere`。
- 320/390：页面不得横向溢出；标题、选词 token、custom select、管理动作保持可读。长正文不设固定高度。

## 键盘与读屏

- skip link 到 `#main`；nav、tabs、details、word picker combobox/listbox、自定义 select 与全部动作沿 M002 键盘模型。
- 最小交互目标 44×44px；focus 使用 M002 可见轮廓，不以颜色单独表达 invalid/selected/pending。
- `#planning-preview` 有标题；`.plan-item` 保持文档顺序。正文不逐片朗读；简短 `.draft-status` 使用 polite。失败、冲突、非法输入用 `role=alert/status` 与文本说明。
- locale 与 meaning language 分离；正文/词条 `lang=en`，释义保留 request meaning language。动态缺值用 “—”，不制造词义或内部解释。

## 动效与阅读位置

书写点是唯一新增循环动效；`prefers-reduced-motion: reduce` 时完全停止。每帧只改正文 textContent/状态，不重建设置、Plan 或页面，不重置 focus。用户主动滚动后不跟随尾部；首次点击生成可带入结果区域一次。

## UI09-R2 对齐补充

- create 的 paper 桌面 padding 为 26px / 22–42px / 30px；移动为 20px 16px 24px。Plan、draft、final 共用居中的最大 760px 阅读列，左右留白对称；可用宽度不足时占满。
- Plan 词条列表桌面两列、≤760px 单列；plans 服务桌面先显示右列启用开关，再让基础预算与 N 同行；移动端恢复基础预算→开关→N 的自然单列顺序。badge 不拆字。
- preset radio 与两行说明顶部对齐；icon-label 固定 7px gap；动作允许换行但保持 44px 目标。

## UI09-R2 有限验证

已实看 UI09-R2 的 create 1440/390 对齐，并复用 UI09-R1 的 1440 create/plans/presets、390 create/plans/presets；390 横溢为 0。创建页正常按钮真实回放覆盖 Plan→正文→valid；Plan 与正文并存截图和 final 清理已记录。计划 0/99 有效、100 非法禁保存；两 preview 自动到 valid/可发布。生产 Vue、真实 API/DB/model、320 与 768 的最终实现由 frontend-bob 接收时复核；这些未验证项不被原型截图替代。
