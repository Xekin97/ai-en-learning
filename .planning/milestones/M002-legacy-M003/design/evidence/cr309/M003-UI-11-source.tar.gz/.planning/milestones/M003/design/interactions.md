---
milestone: M003
version: M003-UI-11
agent_name: designer-tony
date: 2026-10-13
---

# M003-UI-11 交互与状态

## CR-309 同类元素连续性

- started/Plan/edit/validated 的业务时序不变。Plan 到达时，`word_use` 逐项追加到共享词条列表；首个 edit 建立正文但不重建 Plan；完整 valid Result 才以权威 `targets` 原子替换暂定列表和草稿。
- 状态替换允许词义、用法和目标数量按 Result 改变，但同一列表槽位的表面、字体、间距、列数规则和阅读宽度不变。Plan 的 `form · phrase` 与 Result 的 `hintPhrase` 都保留，不用占位撑高。
- PAGE-204/216 和 PAGE-212 使用同一列表组件/样式。PAGE-212 编辑或切模式后旧 final 可按原规则保留为 stale；新的 live Plan 使用共享列表，不把旧 final 与新 Plan 合并。
- before/Plan/草稿/final 切换不强制滚动、不抢焦点；正文与列表不是 live region，简短状态继续由既有 polite 区域承载。无新增动效或文案。

以下 UI10-R1.1 与 UI09 交互在未冲突处继续有效。

## CR-306 模型配置

- 完整 PAGE-208 列表常驻底层。从被点击的“编辑服务商”或“添加服务商”触发器调用原生 `showModal()`；编辑使用被点击 provider，新建使用空连接和一个空模型。禁止把普通 `[open]` 元素、整页表单或滚动到页脚的画面当 modal。
- 模态框沿 AppDialog 生命周期：top layer/遮罩阻隔背景；标题与 footer 固定，只有 `.dialog-body` 纵向滚动；打开先把焦点放到框内，Tab/Shift+Tab 留在最上层，关闭回精确 opener，底页 scroll 不变。
- 关闭按钮、footer 取消、Escape 与遮罩走同一个 dirty 判断。脏表单打开第二个 top-layer 放弃确认；继续编辑关闭确认并回父框，放弃才关闭两层并清草稿；框内点击不触发关闭。
- PAGE-208 先展示完整服务商分组和模型列表；“编辑服务商”打开现有完整表单。每模型高级选项保持最大输出、结构化输出、JSON、说明的固定顺序；每项有独立 raw JSON 草稿，添加模型不会覆盖现有项。展开/收起是即时状态，不触发网络请求。
- JSON 文本每次输入只更新草稿与规范化紧凑 JSON 的 UTF-8 字节计数。保存前严格解析对象；服务端按 BE07 校验格式、重复键、紧凑对象不超过 16,384 字节、深度 8、数值、U+0000、保护字段及与专用字段的冲突。原始排版空白不能触发大小误拒绝。失败把焦点关联回对应 `.custom-parameters`，原字符串不格式化、不清空。只有 `{}` 表示不追加参数；空文本按 `invalid_json` 失败。
- 点击“保存服务商”才提交整份服务商配置；保存不调用模型，也不要求先测试。成功关闭对话框并显示保存状态，同时旧连接测试失效。版本冲突保留本地输入，刷新远端版本并合并后要求管理员重新核对，不能静默覆盖。单模型紧凑 JSON 超限用 `validation_failed / 422 / too_large` 关联该字段；请求总量超限用 `request_too_large / 413` 作为表单级错误，没有字段路径时不得误贴首个模型。
- 点击“测试模型”显式发起一次最长 30 秒的短流 probe，固定最大输出 256 tokens；测试中只禁当前必要动作。成功文案只确认短流响应，不证明参数效果、结构化输出或完整生成；上游拒绝提示检查平台参数与固定 256-token 限制。JSON、连接、模型、token 或输出模式改变后，之前的测试结果立即变为失效；管理员仍可直接保存。
- 取消或关闭在有草稿时打开放弃确认；“继续编辑”恢复原 JSON 和其他输入，“放弃修改”才清除本次草稿。Escape 与关闭按钮走同一确认语义；保存/测试进行中由实现阻止重复提交。
- `state/case/tested/stale` query 只用于静态原型复现；生产状态来自现有表单草稿、API-306 problem 和 probe 结果。

## CR-306 生成与预览状态

- PAGE-204/216 的 `timeout`、`fenced_plan`、`cancelled`、`settlement_pending` 逐帧消费 BE07 `streams.json`。无公开 Plan/正文时只显示诚实等待或终态；取消在可取消阶段持续可达；pending 不声明成功或退款。
- PAGE-212 的 `preview_timeout` 使用现有预设编辑器与结果纸，不增加独立测试页。预设编辑器中的本地草稿或预览配置变化后，旧预览可保留为历史展示，但不能满足当前 draft/mode/run 的发布资格。后台模型参数变更只影响之后受理的新请求快照，不追溯改变在途或已完成 run。
- 失败/取消沿 UI09-R3 清理临时内容；pending/EOF 仍保留已有公开 Plan/草稿。本轮 fixture 没有公开业务内容，因此界面不投影内部推理、内部快照、返修次数或假进度。
- 状态切换复用 M002/UI09 的即时 notice 与克制书写动效；错误、保存和测试反馈为状态变化，不增加装饰动画。减少动效时循环书写点停用。

## 生成与试用共享区域

- 配置与选词沿用 M002 控件。启动前由应用校验可用模型、长度、释义语言、额度和 request words；点击正常生成按钮创建新 run，清旧临时状态并隔离旧代次。
- 收到 `started` 后才显示已受理；`progress(planning)` 与 `plan_item` 在 `#planning-preview` 逐条追加 scene/sense/phrase。
- `generation.edit` 按 content_version/base_rev/rev/seq/Unicode 码点应用到 `.live-draft-text`。首片建立 `#live-draft`，其后不重建整页、设置或 Plan。
- Plan 在初稿、fixed edit、条件修稿、retained、pending/EOF/finalizing 中保留；完整权威 valid Result 才清 Plan/临时稿并一次建立高亮、tags、学习资源、notice/save。
- pending/EOF/协议异常保留只读内容、禁保存并仅消耗合同提供的有限 status。失败/取消清 Plan 与 partial；取消、重启、切页、popstate/pagehide 均使旧 timer/request 代次失效。
- Q02 显示 `m003.incomplete` 且允许保存；不显示轮次、上限、内部审稿轨道或质量通过声明。

## 稳定性与输入

第一次启动可把结果区带入视野，后续 frame 不抢焦点、不强制滚动。正文不是 live region；`.draft-status[aria-live=polite]` 只读简短状态。相邻 exact duplicate 是 NOOP；seq/rev/range/draft/namespace 错误停止消费并进入有限核对。

## 计划管理

原字段按 M002 顺序保留。`#content-review-enabled` 是 N 的派生开关：关闭写入 N=0；开启恢复最近有效 N（无历史时为 1），不形成第三种业务模式。`#content-repair-limit`：付费计划接受整数 0–99；0 关闭，1–99 开启；访客/基础禁用。服务 badge 跟随该派生状态：N=0 显示基础，N=1–99 显示增强。`#plan-actions` 只有字段有效时可预览/保存。保存前用 `m003.impact` 分别显示 `basicUsers` 与 `trialUsers`；两类可能重叠，不求和。版本冲突保留本地值、呈现远端摘要并要求重新核对，不静默覆盖。

## 预设管理

编辑标题/词/四配置/preview mode 会使旧资格过期。保存草稿不生成；生成预览按所选 namespace 自动消费 actual wire，再有限核对 status。basic 和 enhanced 都有真实 Plan/正文；Plan 保留到完整 preview Result。发布需要 current draft_version、mode、run 与 status valid；Q02 还需勾选确认。取消/切预设/模式/页面使旧代次失效。

## UI09-R3 说明

本次只纠正 PAGE-208 的影响人数映射和关闭态 badge。UI09-R2 的居中阅读列以及其余交互选择器、事件归约、保存/发布资格与中断规则保持不变。

## demo adapter 边界

`scenario/event/status/rev/view` query、fixture 名、合成 timer 和折叠场景条仅用于评审。formal view 隐藏场景条；生产由 API-302/API-304 和应用路由驱动，无 fixture 匹配禁用、手动 step 或 timer 性能承诺。
