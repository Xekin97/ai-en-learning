# M003-UI-13 交互与 Motion

状态语义只来自 M003-BE-08 `m003-stream-v6`。本文件定义显示结果，不修改 wire。

## 生成与返修

1. 新请求开始时清除上一请求的 Plan/draft，绑定新 request epoch。`plan_item` 逐条追加场景和词义/用法；这些内容在 `validated` 前持续可见。
2. `draft begin(initial)` 后的合法 edit 真实增量发布到正文。正文容器保持原位，不逐 token 滚动、聚焦或朗读；状态区只以 polite live region 报告阶段。
3. `draft begin(replace|continue|restore)` 复制当前完整 published 到私有 working。后续 edit 只改 working，界面继续显示 published。
4. `paragraph_complete(index)` 原子替换对应 published 段。其余段落和旧尾保持；更新节点短暂增加 `.is-changed`。若内容未变则不显示 cue。
5. `body_complete` 原子发布完整 working，并可处理缩短稿的旧尾；Plan 继续，保存仍禁用。只有同 epoch 的 `validated` 完整包可替换为 Result、建立最终学习信息并开放原有保存/claim。
6. `activity=improving` 才显示 `m003.activity.improving`。收到 writing 或离开活动时隐藏。不能从 heartbeat、定时器、composing、长等待推断 improving。

## Motion

- 完整段提交：2px 浅绿左线和从左向右消退的浅绿背景，`1.6s ease-out`。正文位置、字重、行高不变。
- 活动点：沿用 UI11 三点 `1.2s ease-in-out`；它只表示服务端报告的当前真实活动，不表达进度。
- Plan 的三点只在 `phase=planning` 时显示；进入 composing/improving 后移除，完整 Plan 保持静态，避免暗示仍在规划。
- 不做自动滚动、顶部 toast、整页淡入、段落位移或高度折叠动画。长段在完成边界一次出现，避免半段闪烁。
- `prefers-reduced-motion: reduce`：点与段落动画均停止；活动文字继续显示，刚更新段保留静态淡背景，读者仍能识别状态。

## 中断、终态与竞态

- `pending` / EOF / disconnect：保留已发布正文和 Plan，显示现有待核对反馈，禁保存；显式重新核对沿既有 status 流程。
- `failed` / `cancelled`：丢弃 working，进入既有失败/取消结果；无临时段、无保存。Q02 只按显式 discard → restore begin/edit/body_complete → validated 回退，mixed draft 不成为 Result。
- late event、旧 epoch、终态后 edit/activity、非法序列：不改用户界面，进入既有协议核对；不猜片、不重排、不本地拼稿。
- 用户在 replace 等待期间仍可阅读 published。取消、离页、刷新、UI12 再次生成确认、saving 防重入沿现合同；本轮不增加独立按钮。

## CR-311 选词

- Search/Random 使用后端已过滤结果。现有 loading/error/empty/no_candidates 反馈保持；不显示被过滤清单、警告或配置入口。
- 已选、锁定预设及历史目标不重新验证 DATA-307。旧选中 `the` 可移除、可继续生成；新候选列表中不会新增精确 `the`。
- 查询和随机操作的键盘、焦点、IME 与 live announcement 继承当前 WordPicker。

## PAGE-212 共享预览

后台 enhanced preview 与 PAGE-204/216 使用相同 Plan/published/working 转换、活动文案与段落 cue。preview `validated` 后仍走既有资格/发布流程，不出现普通用户保存按钮；basic/paid 选择及预设只读语义不变。

## 设计 harness

折叠的 `[data-design-harness]` 只用于复现 BE08 合成事件。Replay 按 fixture 顺序播放，Next step 导航到确定性 `event=N` URL；不出现在产品实现，也不代表实际时间或内容质量。
