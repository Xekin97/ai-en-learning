---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M003-UI-13
date: 2026-10-13
input_version: M003-PRODUCT-10 / M003-BE-08 / TRANSITION-M003-099
---

# CR-311/312 UI/UX 设计交接

designer-tony 已完成有界正式设计，当前等待用户评审。CR-311/312 仍 open；本交接不批准设计、不切换阶段、不授权 frontend、实现、QA、真实模型调用或 UAT3015 刷新。

## 使用的输入与确认闭环

- `USER-M003-UAT-FOLLOWUP-20261013`：Search/Random 排除常见功能词；保留完整上一稿，完整段才更新，真实等待轻提示。
- `USER-M003-BE08-UI-NEXT-20261013` / `TRANSITION-M003-099`：BE08 已接收，正式设计按 M002、UI11、UI12 现有完整页面完成。
- 产品真源：[PRODUCT10](product.md)、[CAP-302/307 与 AC-323–328](../product/abilities.md#uat097-acceptance)、[DATA-307](../product/data-assets.md#data-307)、[页面职责](../product/pages/index.md)。
- 技术唯一语义：[CR312 wire](../technical/api/generation.md#cr312-wire)、[CR311 candidates](../technical/api/generation.md#cr311-candidates)、[BE08 fixtures](../technical/fixtures/cr311-312/index.json)。无新持久化影响。
- M002 居中 760px 阅读列、窄屏铺满、UI11 统一词义列表、UI12 完成结果可编辑与再次生成 AppDialog 均保持。此前 CR302/306/307/309/310 已完成事项不再作为当前待办；其历史批准和证据原位保留。
- 当前无业务假设待确认；新设计本身尚未获得用户视觉批准。requested model 为锁定 routing-v1 的 `gpt-5.6-sol/high`，actual serving unknown。

## 当前设计原件

- [M003-UI-13 设计规格](../design/design-spec.md)：PAGE-204/216/212、UIA-M003-427–434、准确 Vue/CSS/状态映射与稳定 URL。
- [可运行原型](../design/prototype/index.html)、[copy 真源](../design/copy.json)、[theme](../design/theme.css)、[交互](../design/interactions.md)、[响应式与无障碍](../design/responsive-accessibility.md)。
- [浏览器报告](../design/evidence/cr312/M003-UI-13-browser.json)：10/10 PASS，console error 0，provider call 0。
- 代表图：[桌面完整段提交](../design/evidence/cr312/01-paragraph-commit-desktop-zh.png)、[390 英文](../design/evidence/cr312/02-paragraph-commit-mobile-en.png)、[后台预览](../design/evidence/cr312/03-admin-preview-paragraph-commit.png)。三张均已实际目视；冲突状态文案与已完成 Plan 动点已清理后定向复验。
- [source check](../design/evidence/cr312/source-check.json)、[当前 source archive](../design/evidence/cr312/M003-UI-13-source.tar.gz)与[当前 manifest](../design/evidence/cr312/M003-UI-13-source-manifest.json)；[修订前快照](../design/evidence/cr312/before.tar.gz)与[before manifest](../design/evidence/cr312/before-manifest.json)。失败方法原件 `browser-run-01-failure.txt` 与 `M003-UI-13-browser-run-02/03/04/05-failed.json` 保留，不用于通过结论。

## 最易评审入口

当前静态服务已在 `127.0.0.1:4174` 提供：

- 中文完整流程：<http://127.0.0.1:4174/M003/design/prototype/?page=create&lang=zh&scenario=cr312-shorter&event=11&demo=open>。页面底部“原型场景”已展开，点击“播放完整过程”即可从 Plan/初稿开始，看到“正在完善内容”、半段不显示、完整段原位替换、body complete 后继续等待及最终 Result；再次点击可重播。
- 英文窄屏参考：<http://127.0.0.1:4174/M003/design/prototype/?page=create&lang=en&scenario=cr312-shorter&event=15&view=formal>（浏览器宽度 390px）。
- PAGE-212 后台预览：<http://127.0.0.1:4174/M003/design/prototype/?page=presets&lang=zh&mode=enhanced&event=15>。

“原型场景”折叠区和 Replay/Next 控制仅属于设计 harness，不进入产品 UI；回放时长不代表生产延迟或内容质量。

## 前端接收映射

1. reducer 维护私有 working 与可见 published：initial edit 可发布；replace/continue/restore edit 只写 working；`paragraph_complete(index)` 发布一段，`body_complete` 发布完整正文但不开放保存，`validated` 才进入权威 Result。
2. `GenerationWorkspace.vue` 正文改读 published；局部段更新不得重建工作台、滚顶或丢焦点。Plan 与 `GenerationVocabularyList.vue` 保持到 validated。唯一活动状态位仅在真实 `activity=improving` 显示 `m003.activity.improving`。
3. `admin/presets.vue` enhanced preview 使用同一 reducer/视图，最终仍无普通保存；basic/paid、预设只读、发布资格不变。
4. Search/Random 只渲染 API 合规候选，前端不复制 DATA-307；旧已选、锁定预设、历史目标不追溯拒绝。现有 empty/no_candidates 足够，不新增警告或管理模块。
5. failed/cancelled 丢弃 working；pending/disconnect 保留 published/Plan 但禁保存；Q02 只按显式 restore/body_complete/validated。旧 epoch/late events 不改 UI。
6. UI12 Result snapshot、完成后编辑、再次 Generate 的 AppDialog、discard→generate 顺序、权限及 saving/in-flight 保护继续有效。

## 验证范围与未决项

浏览器需求验收仅覆盖设计源：desktop/narrow、zh/en、Search/Random、真实回放 wait→half→paragraph→body→valid、长段、Q02、pending/failed/cancelled、PAGE-212、reduced motion、阅读位置和焦点。已有 cr309/cr310 证据只作为未改 UI11/UI12 基线复用。

未执行 Vue/API/Go/SQL、真实数据库、真实模型、实现构建、独立 QA 或 UAT3015；文章内容质量不评级。CR-311/312 的应用行为全部仍未实现/未验证。保留 CR039-L1、CR042-L1、AI-QUALITY-90、W01、QA26-MINIMAX 和 QA/model-quality 边界。

## 下一步

先由用户查看上述中文完整流程并明确接受或提出设计调整。接受后才由 `frontend-bob` 接收 [UIA-M003-427–434](../design/design-spec.md#实现验收)，完成 v6 reducer、共享预览、WordPicker 与 UI12 回归的前端技术映射；之后按门禁分别交实现、独立 QA 和 UAT3015 刷新。

> 本交接不能切换阶段。当前仍是 `uiux-design / designer-tony / awaiting_user_review` 的设计建议状态。
