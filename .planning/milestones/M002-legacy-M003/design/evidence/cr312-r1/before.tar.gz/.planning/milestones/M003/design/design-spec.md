---
milestone: M003
version: M003-UI-13
agent_name: designer-tony
status: awaiting_user_review
date: 2026-10-13
input_version: M003-PRODUCT-10 / M003-BE-08 / TRANSITION-M003-099
visual_baseline: M002 plus accepted M003-UI-11 and M003-UI-12
---

# M003-UI-13 / CR-311、CR-312 正式设计

## 当前目标与有效范围

- `CONFIRMED / USER-M003-UAT-FOLLOWUP-20261013`：搜索与随机选词排除 DATA-307 的 41 个常见功能词；返修期间保留完整上一稿，只在新段完整后原位替换，并以轻量真实状态反馈等待。
- `CONFIRMED / USER-M003-BE08-UI-NEXT-20261013`：用户接受 BE08 并授权 designer-tony 基于 M002、UI11、UI12 完成有界正式设计。API 唯一语义来源为 `technical/api/generation.md#cr312-wire` 与 `#cr311-candidates`。
- 页面追踪：`PAGE-204` 登录造文、`PAGE-216` 游客/预设试用、`PAGE-212` 后台预设共享预览；能力为 `CAP-302`、`CAP-307`，数据为 `DATA-307`，验收为 `AC-323–328`。
- M002 现有完整页面、居中 760px 阅读列、窄屏铺满、UI11 统一词义列表、UI12 完成结果可编辑及再次生成确认均继续有效。普通/付费权益、预设只读、保存/claim、AppDialog、离页保护不变。
- 本版不新增页面、仪表盘、stopword 管理、审稿详情、轮次、上限、百分比、ETA 或推理展示；不新增 AI 请求。文章内容质量不属于产品 QA 评分。
- 当前稿为待用户评审的新设计，不继承旧设计批准。修订前十份原件为 `evidence/cr312/before.tar.gz` 与 `before-manifest.json`；UI11/UI12 已接受基线分别保存在 `evidence/cr309/`、`evidence/cr310/`。

## 设计目标与表达

主任务仍是阅读正在生成的短文。页面不切换容器、不跳回顶部：初稿正文在原阅读列真实增量出现；返修从完整上一稿开始，半段只保存在内部 working draft，完整段才在原位置替换。未更新段落继续显示上一稿，`body_complete` 才允许删除多余旧尾，但仍不代表完成或可保存。

改变提示使用短暂浅绿渐变与 2px 左线，保持正文排版和行高，不制造独立卡片。真实 `activity=improving` 在正文头部显示“小点 + 正在完善内容 / Refining the story”；提示不声称进度或完成时间。Plan 的场景、词义、form/phrase 与正文并列保留，直到权威 `validated` 完整结果到达，随后一次替换为 Result 的正文、tags 和学习信息。

CR-311 不增加说明条或告警。现有 Search/Random 直接展示已过滤候选；查询 `the` 可返回 `theater`、`another`，不会返回精确 `the`。旧已选 `the`、锁定预设和历史内容仍按原样显示并可继续作为生成目标。

## 打开原型与复现场景

仓库根目录运行：

```sh
python3 -m http.server 4174 --bind 127.0.0.1 --directory .planning/milestones
```

当前入口：`http://127.0.0.1:4174/M003/design/prototype/`。原型消费 `copy.json`、`theme.css` 与 BE08 `technical/fixtures/cr311-312/*.json`；不调用 provider。折叠的“原型场景”是设计 harness，不进入产品界面；可播放或逐事件检查。

| 页面/能力 | 稳定状态入口 | 定位与预期 |
|---|---|---|
| PAGE-204/216 初稿完成、开始完善 | `?page=create&lang=zh&scenario=cr312-shorter&event=11&demo=open` | `#planning-preview`、`#live-draft`；完整旧稿和 Plan 可见 |
| 半段仍不可见 | 同上 `event=13` 或 `event=14` | `.live-draft-text` 仍为完整旧稿，无改变提示 |
| 完整第一段提交 | 同上 `event=15` | 仅第一段更新；`[data-paragraph-index="0"].is-changed` |
| body 完成但非 valid | 同上 `event=17` | 旧尾按完整正文边界删除；Result/保存均不存在 |
| 权威最终整包 | 同上 `event=19` | `#final-result` 出现完整正文、tags、词义与保存动作 |
| 长段分片 | `?page=create&lang=en&scenario=cr312-large-paragraph&event=24&demo=open` | 多个 edit 后仍显示完整旧稿；不显示长半段 |
| Q02 恢复 | `?page=create&lang=zh&scenario=cr312-q02-mid-draft&event=19&demo=open` | mixed draft 不保存；保留稿在 `body_complete` 前不覆盖 published |
| pending/失败/取消 | `scenario=cr312-pending|cr312-failed|cr312-cancelled`，终态 event | 恢复现有必要反馈；不可保存；无审稿细节 |
| PAGE-212 共享预览 | `?page=presets&lang=zh&mode=enhanced&event=15` | `#preview-result` 内同一 Plan、旧稿和逐段提交规则 |
| CR-311 旧目标保留 | `?page=create&lang=zh&scenario=cr312-shorter&event=0&words=the,art&demo=open` | 已选 `the` 保留；新搜索/随机只使用合规候选 |
| 英文窄屏 | 任一 create 入口加 `lang=en`，390×844 | “Refining the story”；单列词义列表，无横向溢出 |

静态截图固定到指定 event；真实过渡用 harness“播放完整过程”。正式视图可加 `view=formal` 隐藏 harness。

## 页面与内容定位

| 页面/区域 | 元素顺序与显示条件 | 文案键 | 原型/工程映射 |
|---|---|---|---|
| PAGE-204/216 选词 | 已选词 → Search → 过滤后的候选/现有空态 → Random | 继承 `wordsearch`、`random`、`picker.*` | `#create-words`；`GenerationWorkspace.vue` → `WordPicker` |
| 工作台进行中 | 生成纸标题/状态 → Plan 场景 → Plan 词义列表 → 完整 published 正文 → 活动提示 | `m003.plan.*`、`m003.draft.*`、`m003.activity.improving` | `#generation-status`、`#planning-preview`、`#live-draft`；`GenerationVocabularyList.vue` 保持 |
| 完整段变化 | published 正文中对应段落，短暂 cue；不移动焦点/滚动 | 无新增可见文案 | `.m003-story-paragraph.is-changed`；CSS 在 `theme.css` |
| 最终结果 | 标题 → 权威正文/tags → UI11 词义列表 → notice → 保存/claim | 继承 `m003.complete*`、`m003.resources`、`collect` | `#final-result`；仍读 Result snapshot，不读下一次配置 |
| PAGE-212 预览 | 与进行中同顺序；后台资格/发布反馈在共享预览之外保持 | 同上及既有 `m003.preview.*` | `#preview-result`；`admin/presets.vue` 复用相同 published view-model |
| UI12 再次生成 | 编辑配置/词 → Generate → AppDialog | `m003.regenerate.*` | `#regenerate-confirm`；原行为保持 |

`copy.json` 是固定双语文案唯一来源；原型直接 fetch。`m003.harness.*` 仅用于设计 harness，不同步到产品。AI 正文、Plan、Result、目标词和状态为 API 变量，不硬编码为产品文案。

## 状态与实现约束

详细交互见 `interactions.md`，响应式/无障碍见 `responsive-accessibility.md`。前端接收必须保留以下映射：

1. generation reducer 同时维护私有 `working` 与用户可见 `published`。首稿 edit 可直接更新 published；replace/continue/restore 的 edit 只写 working。`paragraph_complete(index)` 才原子发布该段，`body_complete` 才发布完整 working 并处理旧尾。
2. `GenerationWorkspace.vue` 的 `generation.streamedText` 区域改读 published；Plan 和 UI11 `GenerationVocabularyList` 不因 activity、draft 或 `body_complete` 清除。只有权威 `validated` 完整包进入 Result 和保存资格。
3. `activity=improving` 只驱动文案键 `m003.activity.improving`。禁止由本地计时器、heartbeat 或 composing 推断活动；无真实 activity 时不显示此提示。
4. 段更新只改正文子节点，不调用 `scrollIntoView`、不聚焦正文、不重建工作台外层。late/旧 epoch 事件不得改变 UI。`prefers-reduced-motion` 下取消 cue 动画和点动画，保留静态状态与淡背景。
5. failed/cancelled 丢弃临时 working；pending/disconnect 保留当前 published、Plan 和必要核对反馈但禁保存；Q02 只接受服务端显式 restore/body_complete/validated，不从 mixed draft 拼 Result。`body_complete` 绝不打开保存。
6. PAGE-212 preview 使用同一 reducer/视图规则，preview 最终仍不可保存；普通/付费、基础/增强和 UI12 再次生成确认语义不变。
7. Search/Random 从后端候选结果直接渲染，不在浏览器复制 DATA-307。不得对已选/预设/历史词再做前端拒绝；`no_candidates` 继续现有空态，不新增“被过滤词”列表。

## 实现验收

| ID | 必须保持的结果 | 检查方法与充分证据 |
|---|---|---|
| UIA-M003-427 | Search/Random 只显示合规新候选；`the` 查询不返回精确词但可返 theater/another；旧已选 the 可见且可生成；无警告/管理入口 | API fixture + WordPicker 组件/浏览器交互；PAGE-204/216 与 PAGE-212 picker 使用处 |
| UIA-M003-428 | 首稿真实增量；Plan 场景、词义、用法持续可见；无虚假 improving | reducer 序列 + event 9/11 浏览器状态 |
| UIA-M003-429 | replace 半段不可见；完整段才原位替换；旧尾保留至 body_complete；变化 cue 轻量且不滚顶 | event 13→15→17 的 published/working、scrollY/焦点断言与代表截图 |
| UIA-M003-430 | improving 只来自 activity；准确双语；无轮次/比例/ETA/审稿详情；body_complete 无保存，validated 才显示权威 Result 与保存资格 | DOM 文案/禁词断言、event 12/17/19 |
| UIA-M003-431 | Q02、failed、cancelled、pending/disconnect 恢复最近 published 或现有终态反馈；临时 mixed 不保存；late/旧流隔离 | BE08 fixtures + reducer 单元测试 + 代表浏览器路径 |
| UIA-M003-432 | PAGE-212 enhanced preview 与 PAGE-204/216 使用同一 Plan/published/段提交结果；不出现普通保存动作 | desktop preview 浏览器操作及状态断言 |
| UIA-M003-433 | 1440 居中 ≤760px，390 铺满且无横溢；读者位置与焦点稳定；reduced motion 无动画仍有可见 cue | 桌面/窄屏截图、bounding box、scrollY/focus、media emulation |
| UIA-M003-434 | UI11 词义结构和 UI12 完成后编辑/再次生成 AppDialog、预设只读、权限与 basic/paid 语义无回归 | 复用 cr309/cr310 已有证据 + 受影响组件回归；新实现后独立 QA |

原型 DOM 与 Vue DOM 可不同，但上述用户结果不可改变。固定 copy、颜色/间距和 motion 分别以 `copy.json`、`theme.css`、`interactions.md` 为准。

## 设计自检与未决项

- 当前设计源为 M003-UI-13 工作区修改；浏览器证据写入 `evidence/cr312/`。只证明设计原型和 BE08 合成输入，不证明应用实现、真实 API、独立 QA、文章质量或 UAT3015。
- 原型、copy、theme、interaction、responsive 与 BE08 fixture 的键/状态将在 `M003-UI-13-browser.json` 和 `source-check.json` 中核对；截图仅保存必要代表状态。
- 现有应用仍是旧 reducer/展示，frontend-bob 必须在用户评审后接收 UIA-M003-427–434；本稿不授权实施或刷新 UAT。
- CR-311、CR-312 保持 open。当前无需要用户重新选择的业务问题；唯一待决是用户是否接受本轮正式视觉与交互结果。
