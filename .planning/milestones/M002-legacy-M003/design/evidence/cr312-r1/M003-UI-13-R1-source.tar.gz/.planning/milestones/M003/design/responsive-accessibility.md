# M003-UI-13-R1 响应式与无障碍

## 布局

- `>760px`：沿 M002 完整页面与工作台宽度；生成纸内部 `.m003-result-body` 居中且 `max-width:760px`。Plan、published 正文和 Result 共用同一阅读列；UI11 词义列表为两列、24px 列间距。
- `≤760px`：生成纸横向 padding 16px，阅读列铺满可用宽度；词义列表单列。正文 `overflow-wrap:anywhere`，不截断长词或 Unicode；目标触控高度至少 44px。
- 段落 cue 使用负 12px 外移和 10px 内缩，仍在生成纸 padding 内；390px 视口不得产生横向滚动。
- PAGE-212 预览复用同一阅读列和断点，不新增后台专属结果宽度。

## 阅读位置与动态更新

- `paragraph_complete` 只替换对应正文子节点；不得重建页面头、配置、选词器、生成纸或 Plan。更新前后不调用 `scrollIntoView`、`focus` 或 window scroll。
- 当前焦点若位于取消按钮、配置或选词器，段落发布后保持在原控件。正文区域不成为自动焦点目标。
- 视口在更新段下方时保持当前 `scrollY`；若上方段落长度改变，浏览器自然布局变化之外不得主动校正到顶部或底部。实现可用可见段锚点补偿布局高度差，但不能强制滚到 changed 段。
- 正文 token/edit 不进入 live region，避免逐字朗读。`m003.activity.improving` 与 pending/终态反馈为 `role=status`、`aria-live=polite`，同一活动不重复宣布。

## 键盘、语义与语言

- Search/Random、选词、Generate、Cancel、UI12 AppDialog 焦点与键盘合同保持。设计 harness 只在非 formal 原型出现，使用普通 button/link。
- Plan 使用 section/header、场景和 `dl` 词义列表；published 正文保持 `lang=en`。中文/英文状态文案跟随页面语言；目标词和英文用法保持 `lang=en`。
- 变化颜色不是唯一信号：短暂左线/背景同时出现；不新增常驻“已修改”文字，以免每轮堆积。对屏幕阅读器不逐段播报，仅 activity/阶段状态可读。
- 最终 Result 标题、正文和词义取同一权威 snapshot；UI12 下一次配置改变不改当前 Result accessible name。

## 减少动态与对比

- `prefers-reduced-motion:reduce` 时取消三点位移、段落渐变及 dialog 动画；活动文字、静态三点和淡背景保留。
- cue 的浅绿背景只作辅助，正文使用原 ink 色；左线与背景不得降低文字对比。焦点环、mark 和现有警告/错误样式沿 M002/UI11。

## 验证视口

- Desktop：1440×1050，DPR 1；检查 760px 居中阅读列、半段/提交/body/valid、PAGE-212 preview。
- Narrow：390×844，DPR 1；英文 event 15，检查单列、`Refining the story`、无横溢。
- Reduced motion：1440×1050，`reducedMotion=reduce`；检查 animation-name 为 none、cue 仍可见。
- Reader position：在正文区域产生实际页面滚动后推进 event 14→15，记录 scrollY 与 activeElement；允许浏览器因上方段高度变化产生自然小幅差异，不允许跳至 0、底部或 changed 段。
