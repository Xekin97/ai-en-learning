---
milestone: M003
version: M003-UI-05-R1
agent_name: designer-tony
date: 2026-10-10
---

# UI05-R1 响应式与可访问性

## 布局合同

| 视口 | PAGE-204 | PAGE-208 / PAGE-212 |
|---|---|---|
| ≥1101px | 配置与结果约 39/61 双栏；配置 sticky；结果保持阅读宽度 | 190px 管理导航；计划双预算并列；预设 250px 列表 + 编辑器 |
| 761–1100px | 单列，配置取消 sticky | 导航可保留；计划/预设内容按可用宽度降列 |
| ≤760px | 顶栏换行、主导航局部横滚；配置/正文/释义单列；动作换行且 ≥44px | 管理导航/计划 tabs/预设列表局部横滚；表单、差异、冲突单列 |
| 320–360px | 页面不横溢；文章可换行；状态 pill 不压标题 | 数值和错误完整可见；按钮自然换行 |

目标证据视口为 1440×1000 与 390×844，并对 320/768 做几何断言。中文、英文均不得出现页面级横向滚动；允许导航、tabs 和列表自身横滚。

## 键盘、触控与状态

- skip link 常态移出视口，focus-visible 后显示，不覆盖额度或状态。`#main` 可程序聚焦。
- button/link/input/select/radio/checkbox 触控目标至少 44×44px；focus ring 使用 M002 `--focus`。原生表单语义保留。
- 造文状态 pill 是辅助摘要，不作为唯一信号；可见标题/正文同时说明状态。无百分比 progressbar、ETA、k/N 或颜色唯一表达。
- `learning_ready` 的释义卡为普通内容；polite 只朗读“词义已准备好”，不朗读三卡全文。finalizing 保留卡片，只更新状态；validated 完整正文不进入 live region。
- pending/EOF、词义预览、failed/cancelled 均无保存按钮；valid 才出现“收录到书架”。Q02 notice 使用橙色底、边框与文字。
- 计划非法值以 label、`aria-invalid`、错误文字和禁用按钮共同表达。冲突用 alert，成功用 status。
- 预设 validated 未核对时明确显示资格核对按钮；核对匹配后仍需 Q02 checkbox，勾选不自动发布。

## 缩放与动效

200% 缩放按有效 CSS 宽度进入单列，sticky 动作不得遮住 notice。文章 `overflow-wrap:anywhere`，英文 passage 标 `lang=en`。`prefers-reduced-motion:reduce` 将 spinner、switch 和结果替换接近即时；不改变业务状态或按钮资格。

## 验证边界

UI05-R1 沿用 UI05 的 13/13 页面检查，另以真实按钮点击定向检查自动主路径、释义/finalizing 持续、完成资格、取消和重来代次隔离、导航/手动 step 停止旧 timer、enhanced 预设自动到 Q02 ready，共 4/4 PASS。合成节奏检查不替代实现阶段的 axe、全流程 Tab、200% 缩放、读屏、Safari/Firefox、真实 10 秒有限核对、真实 API/DB/模型验证。
