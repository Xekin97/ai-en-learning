---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M003-UI-05-R1
date: 2026-10-10
input_version: M003-PRODUCT-04 / M003-BE-03 / M003-FE-01
---

# M003 UI05-R1 交接

## 原始说明与接收边界

designer-tony 按 `TRANSITION-M003-021` 完成 UI05，并在同一合法阶段修复用户指出的“正常生成按钮只停在已受理”缺陷，形成 UI05-R1。用户生成页不突出审稿/返修，不显示上限或轮次；正常按钮现在自动消费 BE03 的真实公开流，形成词义先行、finalizing 保留释义、最终整包替换的连续演示。本交付仍是待用户评审的设计修改，不批准 PRODUCT04、BE03、UI05-R1、FE01 或未来实施，不自行切换工作流。

当前 Profile 仍为 `consumer-ai-web@1.0.0`；模型路由请求锁为 `gpt-5.6-sol/high`，actual_model 与 runtime usage unknown。没有修改 workflow/registry、产品/API/DB/FE/业务代码、冻结证据或 UI04 快照；未提交 Git、部署、调用真实模型/提供方或 UAT3302。

## 可直接评审的完整页面

- 造文完整页：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui05-r1&page=create&scenario=basic&event=0&status=0&lang=zh`
- 计划管理完整页：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui05-r1&page=plans&plan=pro&limit=1&adminState=edit&lang=zh`
- 预设管理完整页：`http://127.0.0.1:4174/M003/design/prototype/?rev=ui05-r1&page=presets&mode=enhanced&event=0&status=0&lang=zh`

造文页直接点击“生成短文”即可自动走完约 5.5 秒的合成 wire 回放，无需展开“原型场景”；enhanced 预设点击“生成预览”约 6.4 秒到 Q02 ready，确认框仍需用户勾选。三页底部“原型场景”保留手动边界检查。所有 fixture/合成/时延说明只在该折叠层，产品正文不放工程免责声明。`lang=en` 可查看英文界面。

## 接收到的 BE03 合同与实际消费

原型实际 fetch `technical/fixtures/stream-v3/index.json`，再按 `index.files` 读取 8 个 JSON；`wire[]` 逐帧按 `{event,data}` reducer，status 只消费 `status_responses[].body`。fixture 版本为 `M003-BE-03` / `m003-stream-v3`。源码没有复制/改写 BE03 payload，也不从 `internal_evidence`、`expected`、seq/run/token/版本/N/outcome 渲染产品信息。

- 用户流：started=已受理；progress composing=正在生成；learning_ready=仅 garden/learn/share 原词释义且不可保存；progress finalizing=保留释义并更新简洁状态；validated/status valid=一次建立 passage/tags/targets、高亮、释义与提示并开放保存。
- basic 与 enhanced-two-repairs 的公开五事件完全一致。最终 v3 全量替换 preview v1；用户页没有审稿/返修轨道、k/N、上限、百分比、ETA 或额外模型调用。
- Q02 final v2 持续显示“内容审校未完成”且可保存；pending/EOF 不成功、不保存，按 fixture 有限读取 status；failed/cancelled 清空预览。
- 管理预设只消费 `preview.*`。validated 后仍禁用发布；status/current AdminPreset 的 draft_version/mode/preview_run_id 匹配后才 ready，Q02 还需勾选确认。BE03 只提供 enhanced preview fixture，因此基础编辑状态可评审，但播放器不伪造 basic 返回。
- R1 自动播放器只调度 exact wire/status fixture：事件间隔由静态原型 timer 提供，不是 API 阶段或生产时延。自动帧用 `replaceState`；取消、重来、切页面/场景/mode、popstate/pagehide 与手动 step 会递增播放代次并清除旧 timer。

## 当前设计原件与恢复来源

- [设计规格](../design/design-spec.md)：PAGE/CAP/DATA/AC/API 与 UIA-M003-401–411，入口、事件归约、有效来源和 FE01 待复核映射。
- [copy.json](../design/copy.json)：原型实际消费的 zh/en 固定文案；公开状态不含内部轮次。
- [theme.css](../design/theme.css)：继承 M002 暖白/深绿，新增流状态、词义持续、完整替换和资格核对样式。
- [完整原型](../design/prototype/index.html)、[交互逻辑](../design/prototype/app.js)、[管理展示数据](../design/prototype/fixtures.json)。生成/预设结果来自 BE03 fixture，不来自本地文章副本。
- [交互](../design/interactions.md)与[响应式/可访问性](../design/responsive-accessibility.md)。
- UI05 冻结证据、原报告和原快照继续保留在 `design/evidence/ui05/`，未覆盖或改写。
- [R1 浏览器报告](../design/evidence/ui05-r1/M003-UI-05-R1-browser.json)、[检查脚本](../design/evidence/ui05-r1/browser.mjs)与同目录 3 张截图。
- [UI05-R1 待审源码快照](../design/evidence/ui05-r1/M003-UI-05-R1-source.tar.gz)与[hash 清单](../design/evidence/ui05-r1/M003-UI-05-R1-source-manifest.json)：包含本版设计源、交接、完整 stream-v3 index/8 wire/packages 与 M002 主题依赖，排除 evidence 目录本身以避免递归。快照不代表批准。

## 专业验证结果

Chromium / Playwright 1.62.1 / Node 22.23.2 定向验证 13/13 PASS、7 张正式截图、无 console/page error、缺文案或页面横溢，原型资源记录证明浏览器实际请求 index 与 8 个 wire JSON。覆盖：

- 初始无输出、started 受理、composing、learning_ready 仅词义不可保存、finalizing 释义持续、validated 完整替换；
- enhanced-two-repairs 无内部次数暴露且 final v3 的 share 释义替换为“分享；分担”；
- Q02 手机提示与保存、pending 的 active→valid、EOF 未知、failed/cancelled 清预览；
- 计划完整字段、两预算、0/99/100 非法与 local/remote 冲突；
- 预设 enhanced Q02 从 validated 到资格核对、确认后发布，以及 basic 不误播 enhanced；
- 1440/768/390/320、中英文、skip-link 常态位置、页面级横溢和 reduced-motion。

首轮 11/13 的两项失败是检查脚本在 `browser.newPage()` 创建的页上误用 `context().newPage()`；产品状态与视觉无失败。首轮报告原样保留，脚本改为 `browser.newPage()` 后同一断言通过。实现侧另按视觉复核发现修正过一次：learning_ready 后进入 finalizing 时原先会退回空 spinner；现已持续保留三个释义，validated 才整体替换。人工实际查看 learning 手机、finalizing 桌面、v3 完整结果、Q02 手机、pending→valid、计划99和预设Q02；未发现新的视觉返修项。

R1 针对用户真实点击追加 4/4 PASS、3 张截图：造文主路径 `accepted 2ms → composing 668ms → learning 1912ms → finalizing 4222ms → valid 5460ms`，释义持续约 3.5 秒，完成前无保存、完成后可保存，demo 保持折叠且 history 不增长；取消跨过旧完成时点仍 cancelled，重来后完整序列干净；导航和手动 step 后旧 timer 不再推进；enhanced 预设约 6.36 秒到 ready，Q02 checkbox 未勾且发布禁用。主会话另以独立真实点击复核 `idle → accepted 48ms → composing 750ms → learning 1951ms → finalizing 4253ms → valid 5558ms`，0 page errors，记录在 `reviews/evidence/ui05-autoplay/after-root-click.json`。

未验证：真实模型/供应方、真实延迟与最多10秒自动核对、断连/取消/结算竞争、数据库持久化、权限 token、费用/生成质量、前端构建、axe、全流程 Tab/读屏/200% 缩放、Safari/Firefox、UAT3302、部署。原型文章只演示 fixture 布局，不代表生成质量验收。

## frontend-bob 实施前复核

1. 把 FE3-03/04/06/07/08/09、FE3-T01/02/05、FE3-V02–06/09/11/12 从 UI04 stage/candidate/kN 设计重映射到 UIA-M003-401–411；不沿用 `stage=repair2`、本地计时器或从 plan 推断公开进度。
2. reducer 先校验真实事件，再只投影 allowlist。started、composing、learning_ready、finalizing、validated 与 status active/valid/failed/cancelled 的按钮资格须与本稿一致；finalizing 不撤下已收到词义。
3. validated/status valid 原子建立完整 Result；occurrences 高亮、tags、entry_meaning、hint_phrase 与保存资格一起提交。final v3 不和 preview v1 混字段，迟到 active 不覆盖终态。
4. Q02 notice 在流、status、保存后读取和管理发布链持续存在。pending/EOF 不得保存或发布；真实有限核对沿 API-302/304，不能无限轮询。
5. 计划页保留原字段、基础预算2只读、内容0–99与影响/冲突。预设页保留 basic0/enhanced1；valid 后必须复核当前 AdminPreset 的 version/mode/run，Q02 明示确认后才发布。
6. 正式产品不带原型场景、fixture 名、合成回放、样例/时延说明或本地 query 控制。实施需补真实 320/768、200% 缩放、全键盘/读屏、axe、真实状态计时、权限/刷新持久化和前端工程检查。

## 状态与下一步

**BLOCKED：无。开放 CR：无。** 当前建议 `awaiting_user_review`。请用户先查看三个 UI05-R1 完整页面并直接点击正常生成按钮；收到明确视觉/交互接受后，再由有权限角色接交 frontend-bob 复核并实施。不得用 USER-M003-STREAM-FIRST、PRODUCT04/BE03 待审状态或原型自检代替 UI05-R1 批准。
