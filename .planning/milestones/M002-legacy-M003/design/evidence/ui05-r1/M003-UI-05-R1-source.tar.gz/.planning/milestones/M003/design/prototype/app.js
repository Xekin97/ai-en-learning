const streamFixtureBase = "../../technical/fixtures/stream-v3/";
const [copy, fixtures, streamIndex] = await Promise.all([
  fetch("../copy.json").then((response) => {
    if (!response.ok) throw new Error("copy.json");
    return response.json();
  }),
  fetch("./fixtures.json").then((response) => {
    if (!response.ok) throw new Error("fixtures.json");
    return response.json();
  }),
  fetch(`${streamFixtureBase}index.json`).then((response) => {
    if (!response.ok) throw new Error("stream-v3/index.json");
    return response.json();
  }),
]);
const streamEntries = await Promise.all(streamIndex.files.map(async (file) => {
  const response = await fetch(`${streamFixtureBase}${file}`);
  if (!response.ok) throw new Error(`stream-v3/${file}`);
  return [file.replace(/\.json$/, ""), await response.json()];
}));
const streamFixtures = Object.fromEntries(streamEntries);

const params = new URLSearchParams(location.search);
const lang = params.get("lang") === "en" ? "en" : "zh";
document.documentElement.lang = lang === "zh" ? "zh-CN" : "en";
const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[char]);
const t = (key) => copy.static[`${key}.${lang}`] ?? `⟦${key}⟧`;
const tt = (key, values) => Object.entries(values).reduce((text, [name, value]) => text.replaceAll(`{${name}}`, value), copy.templates[`${key}.${lang}`] ?? `⟦${key}⟧`);
const qurl = (changes) => {
  const next = new URLSearchParams(params);
  Object.entries(changes).forEach(([key, value]) => value == null ? next.delete(key) : next.set(key, String(value)));
  return `?${next.toString()}`;
};
const link = (label, changes, className = "btn") => `<a class="${className}" href="${qurl(changes)}">${esc(label)}</a>`;
const icon = (name) => `<span class="ui-icon" aria-hidden="true">${({home:"⌂",spark:"✦",book:"▤",review:"✓",shelf:"▥",dashboard:"◫",chart:"⌁",model:"◎",plans:"▦",users:"◉",gift:"◇",notice:"◌",preset:"▧"})[name] ?? "•"}</span>`;
const planCodes = ["visitor", "basic", "pro", "plus"];
let playbackEpoch = 0;
let playbackTimer = null;

function stopPlayback() {
  playbackEpoch += 1;
  if (playbackTimer !== null) clearTimeout(playbackTimer);
  playbackTimer = null;
}

function writeState(changes, focusId, replace = false) {
  history[replace ? "replaceState" : "pushState"]({}, "", qurl(changes));
  for (const [key, value] of Object.entries(changes)) value == null ? params.delete(key) : params.set(key, String(value));
  render();
  if (focusId) requestAnimationFrame(() => document.getElementById(focusId)?.focus());
}

function update(changes, focusId) {
  writeState(changes, focusId, false);
}

function replaceUpdate(changes, focusId) {
  writeState(changes, focusId, true);
}

function startAutoPlayback(preview = false) {
  const pageAtStart = preview ? "presets" : "create";
  const modeAtStart = params.get("mode") === "enhanced" ? "enhanced" : "base";
  if (preview && modeAtStart !== "enhanced") {
    stopPlayback();
    update({demo:"open"}, "preview-mode");
    return;
  }
  const fixtureName = preview ? "preview-incomplete" : (streamFixtures[params.get("scenario")] && params.get("scenario") !== "preview-incomplete" ? params.get("scenario") : "basic");
  const fixture = streamFixtures[fixtureName];
  stopPlayback();
  const epoch = playbackEpoch;
  const waits = [0, 700, 1200, 2300, 1300];
  let eventCount = 0;
  let statusCount = 0;
  const stillCurrent = () => {
    if (epoch !== playbackEpoch || (params.get("page") || "create") !== pageAtStart) return false;
    if (preview) return (params.get("mode") === "enhanced" ? "enhanced" : "base") === modeAtStart;
    return (params.get("scenario") || "basic") === fixtureName;
  };
  const advanceStatus = () => {
    if (!stillCurrent() || statusCount >= fixture.status_responses.length) return;
    statusCount += 1;
    replaceUpdate({status:statusCount});
    if (statusCount < fixture.status_responses.length) playbackTimer = setTimeout(advanceStatus, 850);
    else playbackTimer = null;
  };
  const advanceEvent = () => {
    if (!stillCurrent() || eventCount >= fixture.wire.length) return;
    eventCount += 1;
    replaceUpdate({event:eventCount,status:0,saved:null,stale:null,confirmed:null,published:null}, eventCount === 1 ? (preview ? "preview-result" : "generation-status") : null);
    if (eventCount < fixture.wire.length) playbackTimer = setTimeout(advanceEvent, waits[eventCount] ?? 1200);
    else if (preview && fixture.status_responses.length) playbackTimer = setTimeout(advanceStatus, 850);
    else playbackTimer = null;
  };
  advanceEvent();
}

function shellHeader(admin = false) {
  const languageHref = qurl({lang: lang === "zh" ? "en" : "zh"});
  if (admin) return `<a class="skip-link" href="#main">${lang === "zh" ? "跳到主要内容" : "Skip to content"}</a><header class="topbar admin-topbar"><div class="container header-inner"><a class="brand" href="${qurl({page:"plans"})}"><span class="brand-mark" aria-hidden="true">≈</span><span>${esc(t("brand"))}<small>${esc(t("admin.label"))}</small></span></a><span class="prototype-mark">${esc(t("prototype.scope"))}</span><div class="header-actions"><a class="btn quiet lang-link" href="${languageHref}">${lang === "zh" ? "EN" : "中文"}</a><span class="pill">${esc(t("admin.label"))}</span><button class="btn quiet" type="button">${lang === "zh" ? "退出" : "Sign out"}</button></div></div></header>`;
  return `<a class="skip-link" href="#main">${lang === "zh" ? "跳到主要内容" : "Skip to content"}</a><header class="topbar"><div class="container header-inner"><a class="brand" href="${qurl({page:"create"})}"><span class="brand-mark" aria-hidden="true">≈</span>${esc(t("brand"))}</a><nav class="nav" aria-label="${lang === "zh" ? "主导航" : "Primary"}"><a href="#">${icon("home")}${esc(t("nav.home"))}</a><a href="#">${icon("spark")}${esc(t("nav.picks"))}</a><a aria-current="page" href="${qurl({page:"create"})}">${icon("book")}${esc(t("nav.create"))}</a><a href="#">${icon("review")}${esc(t("nav.review"))}</a><a href="#">${icon("shelf")}${esc(t("nav.library"))}</a></nav><div class="header-actions"><span class="quota-mini">${esc(t("create.quota"))}</span><a class="btn quiet lang-link" href="${languageHref}">${lang === "zh" ? "EN" : "中文"}</a><span class="avatar" aria-label="Xiao">小</span></div></div></header>`;
}

function adminNav(current) {
  const items = [
    ["dashboard", "admin.overview"], ["chart", "admin.metrics"], ["model", "admin.models"],
    ["plans", "admin.plans"], ["users", "admin.users"], ["gift", "admin.growth"],
    ["notice", "admin.notices"], ["preset", "admin.presets"],
  ];
  return `<nav class="admin-nav-m003" aria-label="${esc(t("admin.label"))}">${items.map(([glyph, key]) => {
    const id = key.split(".").at(-1);
    const target = id === "plans" || id === "presets" ? qurl({page:id}) : "#";
    return `<a ${current === id ? 'aria-current="page"' : ""} href="${target}">${icon(glyph)}<span>${esc(t(key))}</span></a>`;
  }).join("")}</nav>`;
}

function footer() {
  return `<footer class="container footer"><span>${esc(t("footer"))}</span></footer>`;
}

function scenarioBar(items) {
  return `<details class="scenario-bar" ${params.get("demo") === "open" ? "open" : ""}><summary>${esc(t("common.prototypeNav"))}</summary><p class="demo-note">${esc(t("prototype.fixtureNote"))}</p><div>${items.join("")}</div></details>`;
}

function readLimit(plan, raw = params.get("limit")) {
  const text = plan.editable ? String(raw ?? plan.limit) : "0";
  const integer = /^\d+$/.test(text);
  const value = integer ? Number(text) : Number.NaN;
  return {raw:text, value, valid:integer && value >= 0 && value <= 99};
}

function createSettings(words, busy) {
  const candidates = ["garden", "learn", "share"];
  return `<section class="panel creation-panel" aria-labelledby="create-settings-title"><div class="section-head"><div><p class="step-kicker">01</p><h2 id="create-settings-title">${esc(t("create.settings"))}</h2></div><span class="required-note">${lang === "zh" ? "必填" : "Required"}</span></div><div class="config-fields"><label class="field creation-model"><span>${icon("model")}${esc(t("create.model"))}</span><select id="create-model" ${busy ? "disabled" : ""}><option value="model-a">Model A · General English</option><option value="model-b">Model B · Narrative</option></select></label><div class="creation-options"><label class="field"><span>${esc(t("create.style"))}</span><select ${busy ? "disabled" : ""}><option>${esc(t("create.story"))}</option><option>${lang === "zh" ? "对话" : "Dialogue"}</option></select></label><label class="field"><span>${esc(t("create.length"))}</span><select ${busy ? "disabled" : ""}><option>${esc(t("create.short"))}</option><option>${lang === "zh" ? "中等" : "Medium"}</option></select></label><label class="field"><span>${esc(t("create.meaning"))}</span><select ${busy ? "disabled" : ""}><option>${esc(t("create.chinese"))}</option><option>English</option></select></label></div></div><div class="word-picker"><div class="section-head compact"><div><p class="step-kicker">02</p><h2>${esc(t("create.words"))}</h2></div><span class="word-count">${words.length} / 8</span></div><label class="field"><span class="sr-only">${esc(t("create.search"))}</span><input id="word-search" type="search" placeholder="${esc(t("create.search"))}" ${busy ? "disabled" : ""} aria-describedby="word-search-help"></label><p id="word-search-help" class="field-help">${esc(t("create.searchHint"))}</p><div class="candidate-row">${candidates.map((word) => `<button class="candidate" type="button" data-add-word="${word}" ${busy || words.includes(word) ? "disabled" : ""}>+ ${word}</button>`).join("")}</div><div class="selected-words">${words.length ? words.map((word) => `<span class="chip"><span lang="en">${esc(word)}</span><button type="button" data-remove-word="${esc(word)}" ${busy ? "disabled" : ""} aria-label="${lang === "zh" ? "移除" : "Remove"} ${esc(word)}">×</button></span>`).join("") : `<p class="empty-line">${lang === "zh" ? "还没有选择单词" : "No words selected yet"}</p>`}</div></div></section>`;
}

function initialStreamState() {
  return {lifecycle:"idle", accepted:false, phase:null, learning:null, result:null, notice:null, canSave:false, pending:false, error:null, refunded:null};
}

function applyStreamEvent(state, frame) {
  const next = {...state};
  const kind = frame.event.split(".").at(-1);
  const data = frame.data ?? {};
  if (kind === "started") Object.assign(next, initialStreamState(), {lifecycle:"accepted", accepted:true});
  if (kind === "progress") Object.assign(next, {lifecycle:data.phase === "composing" ? "composing" : "finalizing", phase:data.phase, pending:false});
  if (kind === "learning_ready") Object.assign(next, {lifecycle:"learning", learning:data.entries ?? [], result:null, canSave:false});
  if (kind === "validated") Object.assign(next, {lifecycle:"valid", learning:null, result:data.result, notice:data.completion_notice ?? null, canSave:true, pending:false});
  if (kind === "settlement_pending") Object.assign(next, {lifecycle:"pending", pending:true, canSave:false});
  if (kind === "failed") Object.assign(next, {lifecycle:"failed", learning:null, result:null, error:data.code, refunded:data.quota_refunded, canSave:false, pending:false});
  if (kind === "cancelled") Object.assign(next, {lifecycle:"cancelled", learning:null, result:null, refunded:data.quota_refunded, canSave:false, pending:false});
  return next;
}

function applyStatus(state, response, preview = false) {
  const data = response?.body?.data;
  if (!data) return {...state, lifecycle:"pending", pending:true, canSave:false};
  if (data.status === "valid" && data.result) return {...state, lifecycle:"valid", learning:null, result:data.result, notice:data.completion_notice ?? null, canSave:preview ? false : data.can_save === true, pending:false, statusData:data};
  if (data.status === "failed" || data.status === "cancelled") return {...state, lifecycle:data.status, learning:null, result:null, error:data.status === "failed" ? "content_validation_failed" : null, refunded:data.quota_refunded, canSave:false, pending:false, statusData:data};
  return {...state, lifecycle:"pending", pending:true, canSave:false, statusData:data};
}

function resolveFixture(name, preview = false) {
  const fixture = streamFixtures[name] ?? streamFixtures[preview ? "preview-incomplete" : "basic"];
  const eventCount = Math.max(0, Math.min(fixture.wire.length, Number(params.get("event") ?? 0)));
  let state = fixture.wire.slice(0, eventCount).reduce(applyStreamEvent, initialStreamState());
  const terminal = ["valid", "failed", "cancelled"].includes(state.lifecycle);
  if (eventCount === fixture.wire.length && !terminal && state.lifecycle !== "pending") state = {...state, lifecycle:"pending", pending:true, canSave:false, eof:true};
  const statusCount = Math.max(0, Math.min(fixture.status_responses.length, Number(params.get("status") ?? 0)));
  for (const response of fixture.status_responses.slice(0, statusCount)) state = applyStatus(state, response, preview);
  return {fixture, eventCount, statusCount, state};
}

function highlightedPassage(result) {
  const marks = (result.targets ?? []).flatMap((target) => (target.occurrences ?? []).map((range) => ({...range, entry:target.entry}))).sort((a, b) => a.start - b.start);
  let cursor = 0;
  let html = "";
  for (const mark of marks) {
    html += esc(result.passage.slice(cursor, mark.start));
    html += `<mark data-entry="${esc(mark.entry)}">${esc(result.passage.slice(mark.start, mark.end))}</mark>`;
    cursor = mark.end;
  }
  return html + esc(result.passage.slice(cursor));
}

function resultArticle(result, notice, context = "create") {
  return `<article class="article-result result-replace"><div class="result-meta"><span class="draft-label">${esc(t(context === "preset" ? "preset.resultReady" : "stream.complete"))}</span></div><h2>${esc(t("create.storyHeading"))}</h2><p class="story-text" lang="en">${highlightedPassage(result)}</p><div class="chips result-tags">${(result.tags ?? []).map((tag) => `<span class="chip">${esc(tag)}</span>`).join("")}</div><section class="study-resources"><h3>${esc(t("create.resources"))}</h3><div class="resource-grid">${(result.targets ?? []).map((target) => `<article class="resource-card"><h4 lang="en">${esc(target.entry)}</h4><p>${esc(target.entry_meaning)}</p><p class="muted" lang="en">${esc(target.hint_phrase)}</p></article>`).join("")}</div></section>${notice === "content_review_incomplete" ? `<p class="stage-note incomplete-note" role="status">${esc(t(context === "preset" ? "preset.incomplete" : "stream.incomplete"))}</p>` : `<p class="stage-note" role="status">${esc(t(context === "preset" ? "preset.ready" : "stream.completeBody"))}</p>`}</article>`;
}

function streamBody(state, fixture) {
  if (state.lifecycle === "idle") return `<div class="result-empty"><span class="empty-glyph" aria-hidden="true">Aa</span><h2>${esc(t("create.empty.title"))}</h2><p>${esc(t("create.empty.body"))}</p><p class="muted">${esc(t("create.startHint"))}</p></div>`;
  if (state.result) return resultArticle(state.result, state.notice);
  if (state.lifecycle === "learning") return `<div class="learning-preview" aria-live="polite"><span class="draft-label">${esc(t("stream.meaningsReady"))}</span><h2>${esc(t("stream.meaningsTitle"))}</h2><p>${esc(t("stream.meaningsBody"))}</p><div class="resource-grid">${state.learning.map((entry) => `<article class="resource-card"><h3 lang="en">${esc(entry.entry)}</h3><p>${esc(entry.entry_meaning)}</p></article>`).join("")}</div></div>`;
  if (state.lifecycle === "finalizing" && state.learning) return `<div class="learning-preview" aria-live="polite"><span class="draft-label">${esc(t("stream.meaningsReady"))}</span><h2>${esc(t("stream.meaningsTitle"))}</h2><p class="stream-inline-status">${esc(t("stream.finalizingBody"))}</p><div class="resource-grid">${state.learning.map((entry) => `<article class="resource-card"><h3 lang="en">${esc(entry.entry)}</h3><p>${esc(entry.entry_meaning)}</p></article>`).join("")}</div></div>`;
  if (state.lifecycle === "failed" || state.lifecycle === "cancelled") return `<div class="result-empty" role="${state.lifecycle === "failed" ? "alert" : "status"}"><span class="empty-glyph" aria-hidden="true">!</span><h2>${esc(t(state.lifecycle === "failed" ? "stage.failure.title" : "stage.cancelled"))}</h2><p>${esc(t(state.lifecycle === "failed" ? "stage.failure.body" : "stage.cancelled.body"))}</p></div>`;
  if (state.pending) return `<div class="pending-with-preview" role="status">${state.learning ? `<div class="resource-grid">${state.learning.map((entry) => `<article class="resource-card"><h3 lang="en">${esc(entry.entry)}</h3><p>${esc(entry.entry_meaning)}</p></article>`).join("")}</div>` : ""}<div class="pending-card"><span class="empty-glyph" aria-hidden="true">…</span><h2>${esc(t("stage.pending.title"))}</h2><p>${esc(t(state.eof ? "stream.eofBody" : "stage.pending.body"))}</p>${fixture.status_responses.length ? `<button id="generation-recheck" class="btn primary" data-action="recheck-generation">${esc(t("action.recheck"))}</button>` : ""}</div></div>`;
  const key = state.lifecycle === "accepted" ? "stream.accepted" : state.lifecycle === "finalizing" ? "stream.finalizing" : "stream.composing";
  return `<div class="preview-running" role="status" aria-live="polite"><div class="spinner" aria-hidden="true"></div><h2>${esc(t(key))}</h2><p>${esc(t(`${key}Body`))}</p></div>`;
}

function fixturePlayer(fixtureName, fixture, eventCount, statusCount, preview = false) {
  const eventLabel = eventCount < fixture.wire.length ? fixture.wire[eventCount].event : t("prototype.eventsComplete");
  const statusLabel = statusCount < fixture.status_responses.length ? `${fixture.status_responses[statusCount].http_status} · ${fixture.status_responses[statusCount].body?.data?.status ?? "unknown"}` : t("prototype.statusComplete");
  return `<div class="fixture-player"><p><strong>${esc(fixtureName)}</strong> · ${esc(streamIndex.fixture_version)}</p><p>${esc(t("prototype.nextEvent"))}: <code>${esc(eventLabel)}</code></p><div class="fixture-actions">${eventCount < fixture.wire.length ? `<button class="btn" data-action="next-event">${esc(t("prototype.playNext"))}</button><button class="btn quiet" data-action="play-all">${esc(t("prototype.playAll"))}</button>` : ""}${fixture.status_responses.length ? `<button class="btn quiet" data-action="next-status" ${statusCount >= fixture.status_responses.length ? "disabled" : ""}>${esc(t("prototype.checkStatus"))} · ${esc(statusLabel)}</button>` : ""}</div>${preview ? `<p class="demo-note">${esc(t("prototype.previewFixtureScope"))}</p>` : ""}</div>`;
}

function createPage() {
  const fixtureName = streamFixtures[params.get("scenario")] && params.get("scenario") !== "preview-incomplete" ? params.get("scenario") : "basic";
  const {fixture, eventCount, statusCount, state} = resolveFixture(fixtureName);
  const words = (params.get("words") ?? "garden,learn,share").split(",").filter(Boolean);
  const exactWords = words.length === 3 && ["garden", "learn", "share"].every((word) => words.includes(word));
  const busy = ["accepted", "composing", "learning", "finalizing", "pending"].includes(state.lifecycle);
  const saved = params.get("saved") === "1" && state.canSave;
  const controls = state.lifecycle === "idle" ? `<button class="btn primary large" data-action="generate" ${exactWords ? "" : "disabled"}>${icon("spark")}${esc(t("create.generate"))}</button>` : state.canSave ? `${saved ? `<span class="success-inline" role="status">✓ ${esc(t("create.saved"))}</span>` : `<button class="btn primary" data-action="save-story">${esc(t("action.save"))}</button>`}<button class="btn quiet" data-action="restart">${esc(t("action.discard"))}</button>` : ["failed", "cancelled"].includes(state.lifecycle) ? `<button class="btn primary" data-action="restart">${esc(t("action.retry"))}</button>` : `<button class="btn" data-action="cancel-generation">${esc(t("action.cancel"))}</button>`;
  const scenarios = scenarioBar([
    link("Initial", {scenario:"basic",event:0,status:null,saved:null}), link("Basic", {scenario:"basic",event:5,status:null,saved:null}), link("Same public flow · internal two repairs", {scenario:"enhanced-two-repairs",event:5,status:null,saved:null}), link("Q02", {scenario:"incomplete-last-valid",event:5,status:null,saved:null}), link("Pending → valid", {scenario:"pending-resolves",event:5,status:0,saved:null}), link("EOF unknown", {scenario:"eof-unknown",event:3,status:0,saved:null}), link("Failed", {scenario:"failed-no-valid",event:3,status:null,saved:null}), link("Cancelled", {scenario:"cancelled",event:4,status:null,saved:null}),
    fixturePlayer(fixtureName, fixture, eventCount, statusCount),
  ]);
  return `${shellHeader()}<main class="container page" id="main" tabindex="-1"><header class="page-head"><div><p class="eyebrow">WORDWEAVE / ${esc(t("nav.create"))}</p><h1>${esc(t("create.title"))}</h1><p>${esc(t("create.intro"))}</p></div><span class="pill quota-detail">${esc(t("create.quota"))}</span></header><div class="creation-layout">${createSettings(words, busy)}<section id="generation-status" class="panel result-panel" data-state="${esc(state.lifecycle)}" tabindex="-1"><div class="result-head"><div><p class="step-kicker">03</p><h2>${esc(t("create.resultTitle"))}</h2></div>${state.lifecycle !== "idle" ? `<span class="stream-status">${esc(t(`stream.state.${state.lifecycle}`))}</span>` : ""}</div><div class="result-body">${streamBody(state, fixture)}</div><div class="sticky-actions">${controls}</div></section></div>${scenarios}</main>${footer()}`;
}

function planTabs(current) {
  return `<nav class="plan-tabs" aria-label="${esc(t("plans.title"))}">${Object.entries(fixtures.plans).map(([code, plan]) => `<a aria-current="${code === current}" href="${qurl({plan:code,limit:null,adminState:"edit",remote:null})}"><span>${esc(lang === "zh" ? plan.nameZh : plan.nameEn)}</span><small>${code === "visitor" || code === "basic" ? t("plans.review.off") : tt("plans.review.on", {limit:plan.limit})}</small></a>`).join("")}</nav>`;
}

function existingPlanFields(planCode, disabled) {
  return `<section class="plan-section existing-settings"><div class="section-head"><div><p class="step-kicker">01</p><h2>${esc(t("plans.existing.title"))}</h2><p class="muted">${esc(t("plans.originalKept"))}</p></div><button class="btn" type="button">${esc(t("common.priority"))}</button></div><fieldset ${disabled ? "disabled" : ""}><div class="plan-existing-grid"><fieldset class="option-box"><legend>${esc(t("plans.models"))}</legend><label><input type="checkbox" checked> Model A · General English</label><label><input type="checkbox" checked> Model B · Narrative</label><label><input type="checkbox"> Model C · Compact</label></fieldset><fieldset class="option-box"><legend>${esc(t("plans.lengths"))}</legend><label><input type="checkbox" checked> ${esc(t("create.short"))}</label><label><input type="checkbox" checked> ${lang === "zh" ? "中等" : "Medium"}</label><label><input type="checkbox"> ${lang === "zh" ? "长文" : "Long"}</label></fieldset><div class="numeric-fields"><label class="field"><span>${esc(t("plans.priority"))}</span><input type="number" min="0" value="${({visitor:10,basic:20,pro:30,plus:40})[planCode]}"></label><label class="field"><span>${esc(t("plans.words"))}</span><input type="number" min="1" value="8"></label><label class="field"><span>${esc(t("plans.daily"))}</span><input type="number" min="0" value="${planCode === "visitor" ? 3 : planCode === "basic" ? 10 : 30}"></label><label class="check-line"><input type="checkbox" ${planCode === "plus" ? "checked" : ""}> ${esc(t("plans.unlimited"))}</label></div></div></fieldset></section>`;
}

function plansPage() {
  const planCode = fixtures.plans[params.get("plan")] ? params.get("plan") : "pro";
  const plan = fixtures.plans[planCode];
  const planName = lang === "zh" ? plan.nameZh : plan.nameEn;
  const parsed = readLimit(plan);
  const state = params.get("adminState") || "edit";
  const proposed = parsed.valid ? parsed.value : null;
  const enabled = parsed.valid && proposed > 0;
  const label = (value) => value === 0 ? t("plans.review.off") : tt("plans.review.on", {limit:value});
  let outcome = "";
  if (state === "preview" && parsed.valid) outcome = `<section id="change-preview" class="change-preview" data-state="preview"><header><p class="step-kicker">03</p><h2 tabindex="-1">${esc(t("plans.preview.title"))}</h2><p>${esc(planName)}</p></header><div class="change-body"><div class="policy-unchanged"><strong>${esc(t("plans.base.title"))}</strong><span>${esc(t("plans.base.fixed"))}</span></div><div class="diff-row"><div class="diff-value"><small>${esc(t("plans.current"))}</small><strong>${esc(label(plan.limit))}</strong></div><span aria-hidden="true">→</span><div class="diff-value"><small>${esc(t("plans.after"))}</small><strong>${esc(label(proposed))}</strong></div></div>${proposed === 0 && plan.limit > 0 ? `<p class="warning-box">${esc(t("plans.disable.warning"))}</p>` : ""}<p class="impact-emphasis">${esc(tt("plans.impact", {basic:plan.basicUsers, trial:plan.trialUsers}))}</p><ul class="impact-list"><li>${esc(t("plans.effect.new"))}</li><li>${esc(t("plans.effect.inflight"))}</li><li>${esc(t("plans.effect.usage"))}</li></ul><div class="actions"><button class="btn" data-action="cancel-plan">${esc(t("plans.cancel"))}</button><button class="btn primary" data-action="save-plan">${esc(t("plans.save"))}</button><button class="btn quiet" data-action="conflict-plan">${esc(t("plans.conflictDemo"))}</button></div></div></section>`;
  else if (state === "conflict" && parsed.valid) {
    const remote = Math.max(0, Math.min(99, Number(params.get("remote") ?? 2)));
    outcome = `<section id="version-conflict" class="conflict-box" role="alert"><h2 tabindex="-1">${esc(t("plans.conflict.title"))}</h2><p>${esc(t("plans.conflict.body"))}</p><div class="conflict-compare"><div><small>${esc(t("plans.latest"))}</small><strong>${esc(label(remote))}</strong></div><div><small>${esc(t("plans.local"))}</small><strong>${esc(label(proposed))}</strong></div></div><button class="btn primary" data-action="repreview-plan">${esc(t("plans.recheck"))}</button></section>`;
  } else if (state === "saved" && parsed.valid) outcome = `<div class="success-box" id="save-result" role="status"><strong>✓ ${esc(t("plans.saved"))}</strong><span>${esc(label(proposed))}</span></div>`;
  const scenarios = scenarioBar([link("Basic read-only", {plan:"basic",limit:null,adminState:"edit"}),link("Limit 0", {plan:"pro",limit:0,adminState:"preview"}),link("Limit 99", {plan:"pro",limit:99,adminState:"saved"}),link("Invalid −1", {plan:"pro",limit:-1,adminState:"edit"}),link("Invalid 100", {plan:"pro",limit:100,adminState:"edit"}),link("Invalid 1.5", {plan:"pro",limit:1.5,adminState:"edit"}),link("Remote 2 / local 99", {plan:"pro",limit:99,adminState:"conflict",remote:2}),`<p class="demo-note fixture-scope">${esc(t("prototype.planBoundary"))}</p>`]);
  return `${shellHeader(true)}<main class="container page admin-shell-m003" id="main" tabindex="-1">${adminNav("plans")}<div class="admin-main"><header class="page-head"><div><p class="eyebrow">WORDWEAVE / ${esc(t("admin.label"))}</p><h1>${esc(t("plans.title"))}</h1><p>${esc(t("plans.intro"))}</p></div></header>${planTabs(planCode)}<form class="panel plan-form" data-plan="${planCode}" data-limit-valid="${parsed.valid}" onsubmit="return false">${existingPlanFields(planCode, false)}<section class="plan-section service-settings"><div class="section-head"><div><p class="step-kicker">02</p><h2>${lang === "zh" ? "纠错与内容服务" : "Corrections and content service"}</h2></div><span class="pill">${esc(planName)}</span></div><div class="plan-grid"><section class="service-card system-policy" id="basic-correction-policy"><span class="service-kicker">${lang === "zh" ? "全部计划" : "All plans"}</span><h3>${esc(t("plans.base.title"))}</h3><p>${esc(t("plans.base.body"))}</p><div class="service-state"><strong>${esc(t("plans.base.fixed"))}</strong><span class="fixed-badge">${lang === "zh" ? "只读" : "Read only"}</span></div></section><section class="service-card" id="content-service"><span class="service-kicker">${plan.editable ? (lang === "zh" ? "付费权益" : "Paid benefit") : (lang === "zh" ? "普通权益" : "Standard benefit")}</span><h3>${esc(t("plans.review.title"))}</h3><p>${esc(t("plans.review.rule"))}</p><div class="service-state"><div><strong>${esc(parsed.valid ? label(proposed) : t("plans.review.invalid"))}</strong><small>${esc(plan.editable ? t("plans.sameModel") : t("plans.review.locked"))}</small></div><label class="switch"><span class="sr-only">${esc(t("plans.review.title"))}</span><input id="content-review-switch" type="checkbox" ${enabled ? "checked" : ""} ${plan.editable ? "" : "disabled"}><span aria-hidden="true"></span></label></div><label class="limit-field" for="content-repair-limit"><span>${esc(t("plans.review.limit"))}</span><input id="content-repair-limit" type="number" inputmode="numeric" min="0" max="99" step="1" value="${esc(parsed.raw)}" ${plan.editable ? "" : "disabled"} aria-invalid="${!parsed.valid}" aria-describedby="limit-help${parsed.valid ? "" : " limit-error"}"></label><p id="limit-help" class="field-help">${esc(plan.editable ? t("plans.review.limit.help") : t("plans.review.locked"))}</p>${parsed.valid ? "" : `<p id="limit-error" class="field-error" role="alert">${esc(t("plans.review.invalid"))}</p>`}</section></div><div class="form-footer"><button class="btn primary" data-action="preview-plan" ${parsed.valid ? "" : "disabled"}>${esc(t("plans.preview"))}</button></div></section>${outcome}</form>${scenarios}</div></main>${footer()}`;
}

function presetPreview(mode, resolved, stale) {
  const {fixture, state, statusCount} = resolved;
  if (stale) return `<div id="preview-result" class="warning-box" role="status" data-state="stale" tabindex="-1">${esc(t("preset.stale"))}</div>`;
  if (mode === "base" || state.lifecycle === "idle") return `<div id="preview-result" class="preview-empty" data-state="idle" tabindex="-1"><span class="empty-glyph">Aa</span><p>${esc(t("preset.draftNote"))}</p></div>`;
  if (state.result) {
    const matched = statusCount > 0 && state.statusData?.draft_version === fixture.wire[0]?.data?.draft_version && state.statusData?.preview_content_mode === mode && state.statusData?.preview_run_id === fixture.wire[0]?.data?.preview_run_id;
    return `<div id="preview-result" data-state="${matched ? "ready" : "validating"}" tabindex="-1">${resultArticle(state.result, state.notice, "preset")}${matched ? "" : `<div class="qualification-check" role="status"><p>${esc(t("preset.qualificationPending"))}</p><button class="btn primary" data-action="next-status">${esc(t("preset.checkQualification"))}</button></div>`}</div>`;
  }
  if (state.lifecycle === "learning") return `<div id="preview-result" class="learning-preview" data-state="learning" tabindex="-1"><span class="draft-label">${esc(t("stream.meaningsReady"))}</span><h3>${esc(t("stream.meaningsTitle"))}</h3><p>${esc(t("stream.meaningsBody"))}</p><div class="resource-grid compact-resources">${state.learning.map((entry) => `<article class="resource-card"><h4 lang="en">${esc(entry.entry)}</h4><p>${esc(entry.entry_meaning)}</p></article>`).join("")}</div></div>`;
  if (state.lifecycle === "finalizing" && state.learning) return `<div id="preview-result" class="learning-preview" data-state="finalizing" tabindex="-1"><span class="draft-label">${esc(t("stream.meaningsReady"))}</span><h3>${esc(t("stream.meaningsTitle"))}</h3><p>${esc(t("stream.finalizingBody"))}</p><div class="resource-grid compact-resources">${state.learning.map((entry) => `<article class="resource-card"><h4 lang="en">${esc(entry.entry)}</h4><p>${esc(entry.entry_meaning)}</p></article>`).join("")}</div></div>`;
  if (state.lifecycle === "failed" || state.lifecycle === "cancelled") return `<div id="preview-result" class="warning-box" role="status" data-state="${state.lifecycle}">${esc(t(state.lifecycle === "failed" ? "stage.failure.body" : "stage.cancelled.body"))}</div>`;
  if (state.pending) return `<div id="preview-result" class="preview-empty" role="status" data-state="pending" tabindex="-1"><span class="empty-glyph">…</span><h3>${esc(t("stage.pending.title"))}</h3><p>${esc(t("stage.pending.body"))}</p>${fixture.status_responses.length ? `<button class="btn primary" data-action="next-status">${esc(t("action.recheck"))}</button>` : ""}</div>`;
  const key = state.lifecycle === "accepted" ? "stream.accepted" : state.lifecycle === "finalizing" ? "stream.finalizing" : "stream.composing";
  return `<div id="preview-result" class="preview-running" data-state="${state.lifecycle}" tabindex="-1"><div class="spinner" aria-hidden="true"></div><h3>${esc(t(key))}</h3><p>${esc(t(`${key}Body`))}</p></div>`;
}

function presetsPage() {
  const mode = params.get("mode") === "enhanced" ? "enhanced" : "base";
  const resolved = resolveFixture("preview-incomplete", true);
  const stale = params.get("stale") === "1";
  const exactMode = mode === resolved.fixture.wire[0]?.data?.preview_content_mode;
  const qualified = exactMode && resolved.statusCount > 0 && resolved.state.statusData?.status === "valid" && resolved.state.statusData?.draft_version === resolved.fixture.wire[0]?.data?.draft_version && resolved.state.statusData?.preview_content_mode === mode && resolved.state.statusData?.preview_run_id === resolved.fixture.wire[0]?.data?.preview_run_id;
  const canPublish = qualified && resolved.state.result && !stale;
  const confirmed = params.get("confirmed") === "1";
  const incomplete = resolved.state.notice === "content_review_incomplete";
  const publishConfirm = canPublish && incomplete ? `<label class="publish-confirm"><input id="publish-confirm" type="checkbox" ${confirmed ? "checked" : ""}> <span>${esc(t("preset.publishConfirm"))}</span></label>` : "";
  const scenarios = scenarioBar([link("Base editor · no supplied wire", {mode:"base",event:0,status:0,stale:null,confirmed:null}),link("Enhanced accepted", {mode:"enhanced",event:1,status:0,stale:null,confirmed:null}),link("Meanings only", {mode:"enhanced",event:3,status:0,stale:null,confirmed:null}),link("Q02 valid · qualification pending", {mode:"enhanced",event:5,status:0,stale:null,confirmed:null}),link("Q02 ready to confirm", {mode:"enhanced",event:5,status:1,stale:null,confirmed:null}),link("Mode changed", {mode:"enhanced",event:5,status:1,stale:1,confirmed:null}),fixturePlayer("preview-incomplete", resolved.fixture, resolved.eventCount, resolved.statusCount, true)]);
  return `${shellHeader(true)}<main class="container page admin-shell-m003" id="main" tabindex="-1">${adminNav("presets")}<div class="admin-main"><header class="page-head"><div><p class="eyebrow">WORDWEAVE / ${esc(t("admin.label"))}</p><h1>${esc(t("preset.title"))}</h1><p>${esc(t("preset.intro"))}</p></div><button class="btn primary">${esc(t("common.new"))}</button></header><div class="preset-layout"><aside class="panel preset-list"><h2>${esc(t("preset.list"))}</h2><button class="admin-record selected"><strong>${esc(fixtures.preset.title)}</strong><span>${esc(t("preset.edited"))}</span></button><button class="admin-record"><strong>${lang === "zh" ? "雨夜书店" : "Rainy night bookshop"}</strong><span>${esc(t("preset.published"))}</span></button></aside><section class="panel preset-editor"><div class="editor-state"><span class="pill">${esc(t("preset.edited"))}</span><p>${esc(t("preset.draftNote"))}</p></div><form onsubmit="return false"><div class="preset-title-field"><label class="field"><span>${esc(t("preset.name"))}</span><input value="${esc(fixtures.preset.title)}" required></label><p class="field-help">${esc(t("preset.nameHint"))}</p></div><section class="editor-section"><div class="section-head compact"><h2>${esc(t("preset.words"))}</h2><span class="word-count">3 / 8</span></div><div class="selected-words"><span class="chip">garden</span><span class="chip">learn</span><span class="chip">share</span></div><label class="field"><span class="sr-only">${esc(t("create.search"))}</span><input type="search" placeholder="${esc(t("create.search"))}"></label></section><section class="editor-section"><h2>${esc(t("preset.settings"))}</h2><div class="preset-config-grid"><label class="field"><span>${esc(t("create.model"))}</span><select><option>Model A · General English</option></select></label><label class="field"><span>${esc(t("create.style"))}</span><select><option>${esc(t("create.story"))}</option></select></label><label class="field"><span>${esc(t("create.length"))}</span><select><option>${esc(t("create.short"))}</option></select></label><label class="field"><span>${esc(t("create.meaning"))}</span><select><option>${esc(t("create.chinese"))}</option></select></label></div></section><fieldset id="preview-mode" class="mode-group"><legend>${esc(t("preset.mode"))}</legend><div class="mode-options"><label class="mode-option"><input type="radio" name="mode" value="base" ${mode === "base" ? "checked" : ""}><span><strong>${esc(t("preset.mode.base"))}</strong><small>${esc(t("benefit.base.body"))}</small></span></label><label class="mode-option"><input type="radio" name="mode" value="enhanced" ${mode === "enhanced" ? "checked" : ""}><span><strong>${esc(t("preset.mode.enhanced"))}</strong><small>${esc(tt("benefit.enhanced.body", {limit:1}))}</small></span></label></div><p class="field-help">${esc(t("preset.mode.note"))}<br>${esc(t("preset.mode.limit"))}</p></fieldset><div class="editor-actions"><button class="btn" data-action="save-preset">${esc(t("common.saveDraft"))}</button><button class="btn" data-action="generate-preview">${esc(t("preset.generate"))}</button><button id="preset-publish" class="btn primary" data-action="publish-preset" ${!canPublish || (incomplete && !confirmed) ? "disabled" : ""}>${esc(t("preset.publish"))}</button></div>${publishConfirm}<p class="usage-note">${esc(tt("preset.usage", {count:fixtures.preset.usage}))}</p></form><section class="preview-section"><div class="section-head"><h2>${esc(t("preset.previewHeading"))}</h2><span>${esc(t("preset.usageTitle"))}</span></div>${presetPreview(mode, resolved, stale)}</section>${params.get("published") === "1" ? `<p class="success-box" role="status">✓ ${esc(t("preset.publishedToast"))}</p>` : ""}</section></div>${scenarios}</div></main>${footer()}`;
}

function bind() {
  document.querySelectorAll("[data-add-word]").forEach((button) => button.addEventListener("click", () => {
    const words = new Set((params.get("words") ?? "garden,learn,share").split(",").filter(Boolean)); words.add(button.dataset.addWord); update({words:[...words].join(",")}, "word-search");
  }));
  document.querySelectorAll("[data-remove-word]").forEach((button) => button.addEventListener("click", () => {
    const words = (params.get("words") ?? "garden,learn,share").split(",").filter((word) => word && word !== button.dataset.removeWord); update({words:words.join(",")}, "word-search");
  }));
  document.querySelector("#content-review-switch")?.addEventListener("change", (event) => update({limit:event.currentTarget.checked ? (/^[1-9]\d?$/.test(document.querySelector("#content-repair-limit")?.value || "") ? document.querySelector("#content-repair-limit").value : 1) : 0,adminState:"edit"}, "content-review-switch"));
  document.querySelector("#content-repair-limit")?.addEventListener("change", (event) => update({limit:event.currentTarget.value,adminState:"edit"}, "content-repair-limit"));
  document.querySelectorAll('input[name="mode"]').forEach((input) => input.addEventListener("change", (event) => {
    stopPlayback();
    update({mode:event.currentTarget.value,event:0,status:0,stale:1,confirmed:null,published:null,demo:event.currentTarget.value === "base" ? "open" : null}, "preview-mode");
  }));
  document.querySelector("#publish-confirm")?.addEventListener("change", (event) => update({confirmed:event.currentTarget.checked ? 1 : null}, "publish-confirm"));
  document.querySelectorAll("[data-action]").forEach((button) => button.addEventListener("click", () => {
    const action = button.dataset.action;
    const page = params.get("page") || "create";
    const preview = page === "presets";
    const fixture = streamFixtures[preview ? "preview-incomplete" : (params.get("scenario") || "basic")];
    const eventCount = Number(params.get("event") ?? 0);
    const statusCount = Number(params.get("status") ?? 0);
    if (action === "generate") startAutoPlayback(false);
    if (action === "next-event") { stopPlayback(); update({event:Math.min(fixture.wire.length, eventCount + 1),saved:null}, preview ? "preview-result" : "generation-status"); }
    if (action === "play-all") { stopPlayback(); update({event:fixture.wire.length,saved:null}, preview ? "preview-result" : "generation-status"); }
    if (action === "next-status" || action === "recheck-generation") { stopPlayback(); update({status:Math.min(fixture.status_responses.length, statusCount + 1)}, preview ? "preview-result" : "generation-status"); }
    if (action === "cancel-generation") { stopPlayback(); update({scenario:"cancelled",event:streamFixtures.cancelled.wire.length,status:0,saved:null}, "generation-status"); }
    if (action === "restart") { stopPlayback(); update({scenario:"basic",event:0,status:0,saved:null}, "generation-status"); }
    if (action === "save-story") update({saved:1}, "generation-status");
    if (action === "preview-plan") update({adminState:"preview"}, "change-preview");
    if (action === "cancel-plan") update({adminState:"edit",limit:null}, "content-service");
    if (action === "save-plan") update({adminState:"saved"}, "save-result");
    if (action === "conflict-plan") update({adminState:"conflict",remote:2}, "version-conflict");
    if (action === "repreview-plan") update({adminState:"preview",remote:null}, "change-preview");
    if (action === "save-preset") update({savedDraft:1}, "preview-mode");
    if (action === "generate-preview") startAutoPlayback(true);
    if (action === "publish-preset") update({published:1}, "preset-publish");
  }));
}

function render() {
  const page = params.get("page") || "create";
  document.title = `${t("brand")} · ${page === "plans" ? t("plans.title") : page === "presets" ? t("preset.title") : t("create.title")}`;
  const app = document.querySelector("#app");
  app.innerHTML = page === "plans" ? plansPage() : page === "presets" ? presetsPage() : createPage();
  app.setAttribute("aria-busy", "false");
  bind();
}

window.addEventListener("popstate", () => { stopPlayback(); location.reload(); });
window.addEventListener("pagehide", stopPlayback);
render();
