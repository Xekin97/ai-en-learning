---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M003-UI-13-R3
date: 2026-10-13
input_version: M003-PRODUCT-10 / M003-BE-08 / TRANSITION-M003-099 / USER-M003-UI13-RICH-SAMPLE-20261013
---

# CR-311/312 UI/UX 设计交接

designer-tony 已完成 UI13-R3 丰富样例修订，当前等待用户评审。CR-311/312 仍 open；本交接不批准设计、不切换阶段，不授权 frontend、实现、QA、真实模型调用或 UAT3015 刷新。

## 本轮决定

- 默认 create 与 PAGE-212 enhanced preview 改用现有前端 M002 书店 sample：标题 `A story around the corner.`，六词 `wander / gentle / curious / steady / weave / delight`，最终短文四段。
- 最终六词和英文短文来自 `frontend/app/presentation/home/sample-stories.ts` 第一个 record，源 SHA-256 为 `511c6dd7525ccc9339366c432b6142380263172a0f21c61ddbe6ca443a2d9e59`。最终正文只把句间空格改为段落换行；`weave` 中文释义也原样复用。
- 原 source 没有完整生成包。六条 Plan/场景/用法、其余五条中文释义、六条 final phrase、初稿、三段返修、tags 和 v6 envelopes 均明确标为 design synthetic data；没有模型/provider 调用，也不声称来自前端 mock 或真实任务。
- design-owned `fixtures/ui13-r3-bookshop.json` 提供 29 个 create events 及同内容的 PAGE-212 preview events。四段中三段有实质修改、一段保持不变；半段不发布，完整段才提交。
- R1 文案与 R2 交互保持：稳定节点、220ms 段落交接、240ms Plan 收拢、Cancel 同节点持焦、valid 时配置/WordPicker 解禁、reduced motion 和所有终态/权限/保存边界均不变。已有 shorter/longer/boundary 用例继续保留。

## 最易评审入口

静态服务已在 `127.0.0.1:4174`：

- 中文完整流程：<http://127.0.0.1:4174/M003/design/prototype/?page=create&lang=zh&scenario=ui13-r3-bookshop&event=17&demo=open&rev=ui13-r3>。页面底部点击“播放完整过程”，可重复重播；先看六条 Plan 和四段初稿，再看三段原位返修与最终六条释义。
- 英文窄屏：<http://127.0.0.1:4174/M003/design/prototype/?page=create&lang=en&scenario=ui13-r3-bookshop&event=24&view=formal&rev=ui13-r3>，浏览器宽度 390px。
- PAGE-212：<http://127.0.0.1:4174/M003/design/prototype/?page=presets&lang=zh&mode=enhanced&event=17&rev=ui13-r3>，点击“生成预览”。

Harness 可回放前端公开样例改编场景和 BE08 技术合成 fixture，不进入产品；其节奏不代表线上耗时或文章质量。

## 前端接收映射

1. `generation/reducer.ts` 继续维护 working/published；不改 `paragraph_complete`、`body_complete`、`validated`、pending/Q02/terminal 语义。视觉层不能触发保存或发布。
2. `GenerationWorkspace.vue` 保持 generation paper/status DOM；Plan item key 用 `kind + entry`，paragraph key 用服务端 index，passage 不以 phase/rev/全文为 key。首稿直接 patch text，完整变化段才运行 220ms replace。
3. rich sample 验收数据为六条 Plan、四段正文、三改一不变、六个 target mark/meaning/phrase；不要把 fixture 正文或词义硬编码进产品组件。最终 targets 使用 Unicode/codepoint offset。
4. Plan→Result 先提交 authoritative Result/动作，再以 retained passage + in-flow exit slot 做 240ms settle。同步解除普通配置/WordPicker disabled；Cancel 在同一 button node 变为 Generate 并保持焦点。退出 slot `aria-hidden` 且结束即移除。
5. `GenerationVocabularyList.vue` 只在 valid snapshot 接入最终 targets；Plan meanings 与 final meanings 不能混成可保存快照。`admin/presets.vue` enhanced preview 复用同一 presenter/motion，preview 无普通保存。
6. CSS token 保持 160/180/220/240ms 与 `cubic-bezier(.2,.72,.2,1)`；reduced motion 关闭过渡并保留静态 cue。取消/新 epoch 清 timer/ghost/class/inline style，旧 callback 必须 epoch + `isConnected` guard。

## 原件与证据

- [R3 设计规格](../design/design-spec.md)、[交互](../design/interactions.md)、[响应式/无障碍](../design/responsive-accessibility.md)、[rich fixture](../design/fixtures/ui13-r3-bookshop.json)、[theme](../design/theme.css)、[prototype](../design/prototype/index.html)；[copy](../design/copy.json) 的产品 R1 文案未变，仅校正 design harness 来源说明。
- [fixture integrity](../design/evidence/cr312-r3/fixture-integrity.json) PASS：source hash/最终文本归一化、29 event seq/rev、六个 target codepoint offset、半段不可见、三改一不变及 create/PAGE-212 一致。
- [R3 browser report](../design/evidence/cr312-r3/M003-UI-13-R3-browser.json) 6/6 PASS、console error 0、provider call 0：desktop 完整回放、PAGE-212、390px 中英、六条 Plan/最终释义、四段换行及 final 配置可编辑。
- 最易目视：[桌面丰富 Plan 与返修](../design/evidence/cr312-r3/01-rich-revision-desktop-zh.png)、[390px 中文最终](../design/evidence/cr312-r3/03-rich-final-mobile-zh.png)。另有[桌面最终](../design/evidence/cr312-r3/02-rich-final-desktop-zh.png)和[390px 英文返修](../design/evidence/cr312-r3/04-rich-revision-mobile-en.png)。
- [R3 source archive](../design/evidence/cr312-r3/M003-UI-13-R3-source.tar.gz)、[manifest](../design/evidence/cr312-r3/M003-UI-13-R3-source-manifest.json)、[修订前快照](../design/evidence/cr312-r3/before.tar.gz)。三次 browser harness 错误和一次 integrity 路径错误原样保留，修正后仅执行约定范围。
- UI13 原 10/10、R1 copy 与 R2 motion 证据分别冻结在 `evidence/cr312/`、`evidence/cr312-r1/`、`evidence/cr312-r2/`，本轮不重复全协议或 motion 矩阵。以上只证明设计原型，不证明 Vue/API/真实模型/独立 QA/UAT。

## 未决与下一步

唯一未决是用户是否接受 R3 丰富样例及现有 R2 连续性体验。接受后才由 frontend-bob 接收 [UIA-M003-427–437](../design/design-spec.md#实现验收)；CR-311/312 保持 open，应用当前仍未实现/未验证。
