---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M003-UI-13-R2
date: 2026-10-13
input_version: M003-PRODUCT-10 / M003-BE-08 / TRANSITION-M003-099 / USER-M003-UI13-MOTION-20261013
---

# CR-311/312 UI/UX 设计交接

designer-tony 已完成 UI13-R2 造文连续性修订，当前等待用户评审。CR-311/312 仍 open；本交接不批准设计、不切换阶段，不授权 frontend、实现、QA、真实模型调用或 UAT3015 刷新。

## 本轮决定

- 保持 M002 完整页、760px 阅读列、UI11 词义列表、UI12 完成结果/再次生成确认及 R1 全部双语文案。无新页面、折叠场景、状态、接口或调用。
- 生成纸外层、状态槽、Plan、published paragraph 和 passage 使用稳定节点。Plan item 180ms 原位显现；首稿 edit 立即显示且不做假逐字机。
- 返修 `paragraph_complete`/replace body 的变化段在同一节点做 220ms 旧文→新文和高度交接；未变段不动。浅绿左线/cue 与交接同步，不再单独长动画。
- `validated` 当下建立 Result 与原动作；同一 passage node 保持，Plan 只在 240ms 内淡出并收拢，学习资源进入。保存资格不等待 animation，旧 Plan 不长期保留。
- 状态固定槽位 160ms 轻淡换；improving 只来自真实 activity。取消/失败/新 epoch 立即清理 callback。reduced motion 近即时但保留节点和静态 cue。

## 最易评审入口

静态服务已在 `127.0.0.1:4174`：

- 中文完整流程：<http://127.0.0.1:4174/M003/design/prototype/?page=create&lang=zh&scenario=cr312-shorter&event=11&demo=open&rev=ui13-r2>。页面底部点击“播放完整过程”；可重复点击重播。重点看第一段交接、旧尾收拢及最终正文留在原阅读位置。
- 英文窄屏：<http://127.0.0.1:4174/M003/design/prototype/?page=create&lang=en&scenario=cr312-shorter&event=11&demo=open&rev=ui13-r2>（浏览器 390px 后点击 Replay full process）。
- PAGE-212：<http://127.0.0.1:4174/M003/design/prototype/?page=presets&lang=zh&mode=enhanced&event=11&rev=ui13-r2>，点击“生成预览”。

Harness 只回放 BE08 synthetic fixture，不进入产品；其节奏不代表线上耗时或内容质量。

## 前端接收映射

1. `generation/reducer.ts` 继续维护 working/published；不改 `paragraph_complete`、`body_complete`、`validated`、pending/Q02/terminal 语义。视觉层不能触发保存或发布。
2. `GenerationWorkspace.vue` 保持 generation paper/status DOM；Plan item key 用 `kind + entry`，paragraph key 用服务端 index，passage 容器不以 phase/rev/全文为 key。首稿 patch text；完成变化段才加 replace phase。
3. Plan→Result 先提交 authoritative Result/动作，再以 retained passage + in-flow exit slot 做 240ms FLIP/height settle。同步解除普通配置/WordPicker 的 disabled；Cancel 在同一 button node 原位变为 Generate，保持焦点。exit slot `aria-hidden` 且结束即移除；不得保留新业务场景数据或新增折叠区。
4. `GenerationVocabularyList.vue` 只在 valid snapshot 接入最终 targets；Plan meanings 和最终 meanings 不能因 transition 混成一个可保存快照。
5. `admin/presets.vue` enhanced preview 复用相同 keyed presenter/motion；preview 无普通保存。basic/paid、预设只读和资格不变。
6. CSS token：160/180/220/240ms，`cubic-bezier(.2,.72,.2,1)`；只用 opacity、3px 内位移、height、passage transform。reduced motion 关闭 animation/transition并保留 static cue。
7. 可见锚点上方高度变化时补偿 top delta；不滚到 changed 段、不改焦点。cancel/new epoch 清 timer/ghost/class/inline style，旧 callback 必须 epoch + `isConnected` guard。

## 原件与证据

- [R2 设计规格](../design/design-spec.md)、[交互](../design/interactions.md)、[响应式/无障碍](../design/responsive-accessibility.md)、[theme](../design/theme.css)、[prototype](../design/prototype/index.html)；[copy](../design/copy.json) 未变，继续使用 R1 文案。
- R2 [motion report](../design/evidence/cr312-r2/M003-UI-13-R2-motion.json) 9/9 PASS、console error 0、provider call 0。覆盖短/长段、body→valid、cancel callback 清理、390 英文、reduced motion、PAGE-212；针对 valid 局部 patch 的配置/WordPicker 解禁和 Cancel→Generate 持焦定向检查也通过。5 张图按 [捕获预算](../design/responsive-accessibility.md#验证视口与捕获预算)目视通过。
- 代表图：[段前](../design/evidence/cr312-r2/01-paragraph-before-desktop-zh.png)、[段中](../design/evidence/cr312-r2/02-paragraph-during-desktop-zh.png)、[段后](../design/evidence/cr312-r2/03-paragraph-after-desktop-zh.png)、[最终交接](../design/evidence/cr312-r2/04-final-handoff-desktop-zh.png)、[390 英文](../design/evidence/cr312-r2/05-paragraph-during-mobile-en.png)。
- R2 [source archive](../design/evidence/cr312-r2/M003-UI-13-R2-source.tar.gz)、[manifest](../design/evidence/cr312-r2/M003-UI-13-R2-source-manifest.json)、[修订前快照](../design/evidence/cr312-r2/before.tar.gz)。失败记录保留为 `motion-run-01-failed.txt` 与 `motion-run-02-failed.json`，随后只复验受影响路径。
- UI13 原 10/10 和 R1 copy 证据分别冻结在 `evidence/cr312/`、`evidence/cr312-r1/`；R2 不重复无关协议矩阵。以上只证明设计原型，不证明 Vue/API/真实模型/独立 QA/UAT。

## 未决与下一步

唯一未决是用户是否接受 R2 连续性体验。接受后才由 frontend-bob 接收 [UIA-M003-427–436](../design/design-spec.md#实现验收)；CR-311/312 保持 open，应用当前仍未实现/未验证。
