const [copy, fixtures] = await Promise.all([
  fetch("../copy.json").then((response) => {
    if (!response.ok) throw new Error("copy.json");
    return response.json();
  }),
  fetch("./fixtures.json").then((response) => {
    if (!response.ok) throw new Error("fixtures.json");
    return response.json();
  }),
]);

const params = new URLSearchParams(location.search);
const lang = params.get("lang") === "en" ? "en" : "zh";
document.documentElement.lang = lang === "zh" ? "zh-CN" : "en";
const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[char]);
const t = (key) => copy.static[`${key}.${lang}`] ?? `⟦${key}⟧`;
const tt = (key, values) => Object.entries(values).reduce((text, [name, value]) => text.replaceAll(`{${name}}`, value), copy.templates[`${key}.${lang}`] ?? `⟦${key}⟧`);
const qurl = (changes) => {
  const next = new URLSearchParams(params);
  Object.entries(changes).forEach(([key, value]) => value == null ? next.delete(key) : next.set(key, String(value)));
  return `?${next.toString()}`;
};
const link = (label, changes, className = "btn") => `<a class="${className}" href="${qurl(changes)}">${esc(label)}</a>`;
const icon = (name) => `<span class="ui-icon" aria-hidden="true">${({home:"⌂",spark:"✦",book:"▤",review:"✓",shelf:"▥",dashboard:"◫",chart:"⌁",model:"◎",plans:"▦",users:"◉",gift:"◇",notice:"◌",preset:"▧"})[name] ?? "•"}</span>`;
const planCodes = ["visitor", "basic", "pro", "plus"];

function update(changes, focusId) {
  history.pushState({}, "", qurl(changes));
  for (const [key, value] of Object.entries(changes)) value == null ? params.delete(key) : params.set(key, String(value));
  render();
  if (focusId) requestAnimationFrame(() => document.getElementById(focusId)?.focus());
}

function shellHeader(admin = false) {
  const languageHref = qurl({lang: lang === "zh" ? "en" : "zh"});
  if (admin) return `<a class="skip-link" href="#main">${lang === "zh" ? "跳到主要内容" : "Skip to content"}</a><header class="topbar admin-topbar"><div class="container header-inner"><a class="brand" href="${qurl({page:"plans"})}"><span class="brand-mark" aria-hidden="true">≈</span><span>${esc(t("brand"))}<small>${esc(t("admin.label"))}</small></span></a><span class="prototype-mark">${esc(t("prototype.scope"))}</span><div class="header-actions"><a class="btn quiet lang-link" href="${languageHref}">${lang === "zh" ? "EN" : "中文"}</a><span class="pill">${esc(t("admin.label"))}</span><button class="btn quiet" type="button">${lang === "zh" ? "退出" : "Sign out"}</button></div></div></header>`;
  return `<a class="skip-link" href="#main">${lang === "zh" ? "跳到主要内容" : "Skip to content"}</a><header class="topbar"><div class="container header-inner"><a class="brand" href="${qurl({page:"create"})}"><span class="brand-mark" aria-hidden="true">≈</span>${esc(t("brand"))}</a><nav class="nav" aria-label="${lang === "zh" ? "主导航" : "Primary"}"><a href="#">${icon("home")}${esc(t("nav.home"))}</a><a href="#">${icon("spark")}${esc(t("nav.picks"))}</a><a aria-current="page" href="${qurl({page:"create"})}">${icon("book")}${esc(t("nav.create"))}</a><a href="#">${icon("review")}${esc(t("nav.review"))}</a><a href="#">${icon("shelf")}${esc(t("nav.library"))}</a></nav><div class="header-actions"><span class="quota-mini">${esc(t("create.quota"))}</span><a class="btn quiet lang-link" href="${languageHref}">${lang === "zh" ? "EN" : "中文"}</a><span class="avatar" aria-label="Xiao">小</span></div></div></header>`;
}

function adminNav(current) {
  const items = [
    ["dashboard", "admin.overview"], ["chart", "admin.metrics"], ["model", "admin.models"],
    ["plans", "admin.plans"], ["users", "admin.users"], ["gift", "admin.growth"],
    ["notice", "admin.notices"], ["preset", "admin.presets"],
  ];
  return `<nav class="admin-nav-m003" aria-label="${esc(t("admin.label"))}">${items.map(([glyph, key]) => {
    const id = key.split(".").at(-1);
    const target = id === "plans" || id === "presets" ? qurl({page:id}) : "#";
    return `<a ${current === id ? 'aria-current="page"' : ""} href="${target}">${icon(glyph)}<span>${esc(t(key))}</span></a>`;
  }).join("")}</nav>`;
}

function footer() {
  return `<footer class="container footer"><span>${esc(t("footer"))}</span></footer>`;
}

function scenarioBar(items) {
  return `<details class="scenario-bar"><summary>${esc(t("common.prototypeNav"))}</summary><p class="demo-note">${esc(t("create.articleSample"))} ${esc(t("prototype.scope"))}</p><div>${items.join("")}</div></details>`;
}

function readLimit(plan, raw = params.get("limit")) {
  const text = plan.editable ? String(raw ?? plan.limit) : "0";
  const integer = /^\d+$/.test(text);
  const value = integer ? Number(text) : Number.NaN;
  return {raw:text, value, valid:integer && value >= 0 && value <= 99};
}

function entitlement(planCode) {
  const plan = fixtures.plans[planCode] ?? fixtures.plans.basic;
  const parsed = readLimit(plan);
  const limit = parsed.valid ? parsed.value : plan.limit;
  return {plan, limit, enhanced:plan.editable && limit > 0, planName:lang === "zh" ? plan.nameZh : plan.nameEn};
}

function createSettings(words, busy) {
  return `<section class="panel creation-panel" aria-labelledby="create-settings-title"><div class="section-head"><div><p class="step-kicker">01</p><h2 id="create-settings-title">${esc(t("create.settings"))}</h2></div><span class="required-note">${lang === "zh" ? "必填" : "Required"}</span></div><div class="config-fields"><label class="field creation-model"><span>${icon("model")}${esc(t("create.model"))}</span><select id="create-model" ${busy ? "disabled" : ""}><option value="model-a">Model A · General English</option><option value="model-b">Model B · Narrative</option></select></label><div class="creation-options"><label class="field"><span>${esc(t("create.style"))}</span><select ${busy ? "disabled" : ""}><option>${esc(t("create.story"))}</option><option>${lang === "zh" ? "对话" : "Dialogue"}</option></select></label><label class="field"><span>${esc(t("create.length"))}</span><select ${busy ? "disabled" : ""}><option>${esc(t("create.short"))}</option><option>${lang === "zh" ? "中等" : "Medium"}</option></select></label><label class="field"><span>${esc(t("create.meaning"))}</span><select ${busy ? "disabled" : ""}><option>${esc(t("create.chinese"))}</option><option>English</option></select></label></div></div><div class="word-picker"><div class="section-head compact"><div><p class="step-kicker">02</p><h2>${esc(t("create.words"))}</h2></div><span class="word-count">${words.length} / 8</span></div><label class="field"><span class="sr-only">${esc(t("create.search"))}</span><input id="word-search" type="search" placeholder="${esc(t("create.search"))}" ${busy ? "disabled" : ""} aria-describedby="word-search-help"></label><p id="word-search-help" class="field-help">${esc(t("create.searchHint"))}</p><div class="candidate-row"><button class="candidate" type="button" data-add-word="wander" ${busy || words.includes("wander") ? "disabled" : ""}>+ wander</button><button class="candidate" type="button" data-add-word="weave" ${busy || words.includes("weave") ? "disabled" : ""}>+ weave</button><button class="candidate" type="button" data-add-word="lantern" ${busy || words.includes("lantern") ? "disabled" : ""}>+ lantern</button></div><div class="selected-words">${words.length ? words.map((word) => `<span class="chip"><span lang="en">${esc(word)}</span><button type="button" data-remove-word="${esc(word)}" ${busy ? "disabled" : ""} aria-label="${lang === "zh" ? "移除" : "Remove"} ${esc(word)}">×</button></span>`).join("") : `<p class="empty-line">${lang === "zh" ? "还没有选择单词" : "No words selected yet"}</p>`}</div></div></section>`;
}

function stageRail(stage, enhanced) {
  const steps = enhanced ? ["generating", "draft", "review", "repair", "complete"] : ["generating", "draft", "complete"];
  const normalized = stage.startsWith("review") ? "review" : stage.startsWith("repair") ? "repair" : ["complete", "incomplete", "saved"].includes(stage) ? "complete" : stage === "draft" ? "draft" : "generating";
  const index = Math.max(0, steps.indexOf(normalized));
  return `<ol class="stage-rail" aria-label="${lang === "zh" ? "生成阶段" : "Generation stages"}">${steps.map((key, i) => `<li class="${i < index ? "done" : i === index ? "current" : ""}" ${i === index ? 'aria-current="step"' : ""}><span>${i < index ? "✓" : i + 1}</span>${esc(t(`stage.${key}`))}</li>`).join("")}</ol>`;
}

function storyResult(stage, repairCount, limit) {
  const repaired = repairCount > 0 || ["complete", "incomplete", "saved"].includes(stage);
  const text = repaired ? fixtures.draft.repairedText : fixtures.draft.text;
  const statusLabel = stage.startsWith("repair") ? tt("stage.repair.label", {count:repairCount}) : stage === "incomplete" ? t("stage.incomplete.title") : t(`stage.${stage.startsWith("review") ? "review" : stage === "saved" ? "complete" : stage}`);
  const body = stage === "incomplete" ? t("stage.incomplete.body") : stage.startsWith("repair") ? tt("stage.repair.body", {count:repairCount, limit}) : stage.startsWith("review") ? t("stage.review.body") : stage === "draft" ? t("stage.draft.body") : params.get("outcome") === "limit" ? t("stage.limit.body") : t("stage.complete.body");
  const passage = esc(text).replace(/\b(wander(?:ed)?|weav(?:e|er))\b/gi, (match) => `<mark>${match}</mark>`);
  return `<article class="article-result"><div class="result-meta"><span class="draft-label">${esc(statusLabel)}</span></div><h2>${esc(fixtures.draft.title)}</h2><p class="story-text" lang="en">${passage}</p><div class="chips result-tags">${fixtures.draft.tags.map((tag) => `<span class="chip">${esc(tag)}</span>`).join("")}</div><section class="study-resources"><h3>${esc(t("create.resources"))}</h3><div class="resource-grid">${fixtures.draft.targets.map((target) => `<article class="resource-card"><h4 lang="en">${esc(target.entry)}</h4><p>${esc(target.meaning)}</p><p class="muted" lang="en">${esc(target.hint)}</p></article>`).join("")}</div></section><p class="stage-note ${stage === "incomplete" ? "incomplete-note" : ""}" role="status" aria-live="polite">${esc(body)}</p></article>`;
}

function createPage() {
  const planCode = planCodes.includes(params.get("plan")) ? params.get("plan") : "pro";
  const {enhanced, limit, planName} = entitlement(planCode);
  let stage = params.get("stage") || "idle";
  if (!enhanced && (stage.startsWith("review") || stage.startsWith("repair") || stage === "incomplete")) stage = "draft";
  const repairCount = ["repair2", "review2"].includes(stage) ? 2 : stage === "repair1" ? 1 : 0;
  const words = (params.get("words") || "wander,weave").split(",").filter(Boolean);
  const busy = !["idle", "complete", "incomplete", "failure", "pending", "cancelled", "saved"].includes(stage);
  const benefitBody = enhanced ? tt("benefit.enhanced.body", {limit}) : t("benefit.base.body");
  let result = "";
  if (stage === "idle") result = `<div class="result-empty"><span class="empty-glyph" aria-hidden="true">Aa</span><h2>${esc(t("create.empty.title"))}</h2><p>${esc(t("create.empty.body"))}</p><p class="muted">${esc(t("create.startHint"))}</p></div>`;
  else if (["pending", "failure", "cancelled"].includes(stage)) {
    const title = stage === "cancelled" ? t("stage.cancelled") : t(`stage.${stage}.title`);
    const body = stage === "cancelled" ? t("stage.cancelled.body") : t(`stage.${stage}.body`);
    result = `<div class="result-empty" role="${stage === "failure" ? "alert" : "status"}"><span class="empty-glyph" aria-hidden="true">${stage === "pending" ? "…" : "!"}</span><h2>${esc(title)}</h2><p>${esc(body)}</p>${stage === "pending" ? `<button id="generation-recheck" class="btn primary" data-action="recheck-generation" ${params.get("recheck") === "checking" ? 'disabled aria-busy="true"' : ""}>${esc(t(params.get("recheck") === "checking" ? "action.rechecking" : "action.recheck"))}</button>` : `<button class="btn primary" data-action="restart">${esc(t("action.retry"))}</button>`}</div>`;
  } else result = storyResult(stage, repairCount, limit);
  const next = stage === "generating" ? "draft" : stage === "draft" ? (enhanced ? "review1" : "complete") : stage === "review1" ? "repair1" : stage === "repair1" ? (limit >= 2 ? "review2" : "complete") : stage === "review2" ? "repair2" : "complete";
  const controls = stage === "idle" ? `<button class="btn primary large" data-action="generate" ${words.length ? "" : "disabled"}>${icon("spark")}${esc(t("create.generate"))}</button>` : busy ? `<button class="btn" data-action="cancel-generation">${esc(t("action.cancel"))}</button><button class="btn quiet" data-action="next-stage" data-next="${next}">${esc(t("create.nextStage"))}</button>` : ["complete", "incomplete"].includes(stage) ? `<button class="btn primary" data-action="save-story">${esc(t("action.save"))}</button><button class="btn quiet" data-action="restart">${esc(t("action.discard"))}</button>` : stage === "saved" ? `<span class="success-inline" role="status">✓ ${esc(t("create.saved"))}</span><button class="btn" data-action="restart">${esc(t("action.retry"))}</button>` : "";
  const scenarios = scenarioBar([
    link("Basic", {plan:"basic",limit:null,stage:"idle",recheck:null}), link("Repair 2 / 2", {plan:"pro",limit:2,stage:"repair2",recheck:null}),
    link("Limit complete", {plan:"pro",limit:2,stage:"complete",outcome:"limit"}), link("Review incomplete", {plan:"pro",limit:2,stage:"incomplete",recheck:null}),
    link("Pending", {plan:"pro",stage:"pending",recheck:null}), link("No valid draft", {plan:"pro",stage:"failure",recheck:null}),
  ]);
  return `${shellHeader()}<main class="container page" id="main" tabindex="-1"><header class="page-head"><div><p class="eyebrow">WORDWEAVE / ${esc(t("nav.create"))}</p><h1>${esc(t("create.title"))}</h1><p>${esc(t("create.intro"))}</p></div><span class="pill quota-detail">${esc(t("create.quota"))}</span></header><section id="benefit-summary" class="entitlement-strip" data-limit="${limit}" data-enhanced="${enhanced}"><div class="benefit-icon" aria-hidden="true">${enhanced ? "✦" : "✓"}</div><div><strong>${esc(t(enhanced ? "benefit.enhanced.name" : "benefit.base.name"))}</strong><p>${esc(benefitBody)}</p></div><div class="entitlement-meta"><strong>${esc(tt("benefit.plan", {plan:planName}))}</strong><span>${esc(t("benefit.snapshot"))}</span></div></section><div class="creation-layout">${createSettings(words, busy)}<section id="generation-status" class="panel result-panel" data-stage="${esc(stage)}" tabindex="-1"><div class="result-head"><div><p class="step-kicker">03</p><h2>${esc(t("create.resultTitle"))}</h2></div>${stage !== "idle" ? stageRail(stage, enhanced) : ""}</div><div class="result-body">${result}</div><div class="sticky-actions">${controls}</div></section></div>${scenarios}</main>${footer()}`;
}

function planTabs(current) {
  return `<nav class="plan-tabs" aria-label="${esc(t("plans.title"))}">${Object.entries(fixtures.plans).map(([code, plan]) => `<a aria-current="${code === current}" href="${qurl({plan:code,limit:null,adminState:"edit",remote:null})}"><span>${esc(lang === "zh" ? plan.nameZh : plan.nameEn)}</span><small>${code === "visitor" || code === "basic" ? t("plans.review.off") : tt("plans.review.on", {limit:plan.limit})}</small></a>`).join("")}</nav>`;
}

function existingPlanFields(planCode, disabled) {
  return `<section class="plan-section existing-settings"><div class="section-head"><div><p class="step-kicker">01</p><h2>${esc(t("plans.existing.title"))}</h2><p class="muted">${esc(t("plans.originalKept"))}</p></div><button class="btn" type="button">${esc(t("common.priority"))}</button></div><fieldset ${disabled ? "disabled" : ""}><div class="plan-existing-grid"><fieldset class="option-box"><legend>${esc(t("plans.models"))}</legend><label><input type="checkbox" checked> Model A · General English</label><label><input type="checkbox" checked> Model B · Narrative</label><label><input type="checkbox"> Model C · Compact</label></fieldset><fieldset class="option-box"><legend>${esc(t("plans.lengths"))}</legend><label><input type="checkbox" checked> ${esc(t("create.short"))}</label><label><input type="checkbox" checked> ${lang === "zh" ? "中等" : "Medium"}</label><label><input type="checkbox"> ${lang === "zh" ? "长文" : "Long"}</label></fieldset><div class="numeric-fields"><label class="field"><span>${esc(t("plans.priority"))}</span><input type="number" min="0" value="${({visitor:10,basic:20,pro:30,plus:40})[planCode]}"></label><label class="field"><span>${esc(t("plans.words"))}</span><input type="number" min="1" value="8"></label><label class="field"><span>${esc(t("plans.daily"))}</span><input type="number" min="0" value="${planCode === "visitor" ? 3 : planCode === "basic" ? 10 : 30}"></label><label class="check-line"><input type="checkbox" ${planCode === "plus" ? "checked" : ""}> ${esc(t("plans.unlimited"))}</label></div></div></fieldset></section>`;
}

function plansPage() {
  const planCode = fixtures.plans[params.get("plan")] ? params.get("plan") : "pro";
  const plan = fixtures.plans[planCode];
  const planName = lang === "zh" ? plan.nameZh : plan.nameEn;
  const parsed = readLimit(plan);
  const state = params.get("adminState") || "edit";
  const proposed = parsed.valid ? parsed.value : null;
  const enabled = parsed.valid && proposed > 0;
  const label = (value) => value === 0 ? t("plans.review.off") : tt("plans.review.on", {limit:value});
  let outcome = "";
  if (state === "preview" && parsed.valid) outcome = `<section id="change-preview" class="change-preview" data-state="preview"><header><p class="step-kicker">03</p><h2 tabindex="-1">${esc(t("plans.preview.title"))}</h2><p>${esc(planName)}</p></header><div class="change-body"><div class="policy-unchanged"><strong>${esc(t("plans.base.title"))}</strong><span>${esc(t("plans.base.fixed"))}</span></div><div class="diff-row"><div class="diff-value"><small>${esc(t("plans.current"))}</small><strong>${esc(label(plan.limit))}</strong></div><span aria-hidden="true">→</span><div class="diff-value"><small>${esc(t("plans.after"))}</small><strong>${esc(label(proposed))}</strong></div></div>${proposed === 0 && plan.limit > 0 ? `<p class="warning-box">${esc(t("plans.disable.warning"))}</p>` : ""}<p class="impact-emphasis">${esc(tt("plans.impact", {basic:plan.basicUsers, trial:plan.trialUsers}))}</p><ul class="impact-list"><li>${esc(t("plans.effect.new"))}</li><li>${esc(t("plans.effect.inflight"))}</li><li>${esc(t("plans.effect.usage"))}</li></ul><div class="actions"><button class="btn" data-action="cancel-plan">${esc(t("plans.cancel"))}</button><button class="btn primary" data-action="save-plan">${esc(t("plans.save"))}</button><button class="btn quiet" data-action="conflict-plan">${esc(t("plans.conflictDemo"))}</button></div></div></section>`;
  else if (state === "conflict" && parsed.valid) {
    const remote = Math.max(0, Math.min(99, Number(params.get("remote") ?? 2)));
    outcome = `<section id="version-conflict" class="conflict-box" role="alert"><h2 tabindex="-1">${esc(t("plans.conflict.title"))}</h2><p>${esc(t("plans.conflict.body"))}</p><div class="conflict-compare"><div><small>${esc(t("plans.latest"))}</small><strong>${esc(label(remote))}</strong></div><div><small>${esc(t("plans.local"))}</small><strong>${esc(label(proposed))}</strong></div></div><button class="btn primary" data-action="repreview-plan">${esc(t("plans.recheck"))}</button></section>`;
  } else if (state === "saved" && parsed.valid) outcome = `<div class="success-box" id="save-result" role="status"><strong>✓ ${esc(t("plans.saved"))}</strong><span>${esc(label(proposed))}</span></div>`;
  const scenarios = scenarioBar([link("Basic read-only", {plan:"basic",limit:null,adminState:"edit"}),link("Limit 0", {plan:"pro",limit:0,adminState:"preview"}),link("Limit 99", {plan:"pro",limit:99,adminState:"saved"}),link("Invalid −1", {plan:"pro",limit:-1,adminState:"edit"}),link("Invalid 100", {plan:"pro",limit:100,adminState:"edit"}),link("Invalid 1.5", {plan:"pro",limit:1.5,adminState:"edit"}),link("Remote 2 / local 99", {plan:"pro",limit:99,adminState:"conflict",remote:2})]);
  return `${shellHeader(true)}<main class="container page admin-shell-m003" id="main" tabindex="-1">${adminNav("plans")}<div class="admin-main"><header class="page-head"><div><p class="eyebrow">WORDWEAVE / ${esc(t("admin.label"))}</p><h1>${esc(t("plans.title"))}</h1><p>${esc(t("plans.intro"))}</p></div></header>${planTabs(planCode)}<form class="panel plan-form" data-plan="${planCode}" data-limit-valid="${parsed.valid}" onsubmit="return false">${existingPlanFields(planCode, false)}<section class="plan-section service-settings"><div class="section-head"><div><p class="step-kicker">02</p><h2>${lang === "zh" ? "纠错与内容服务" : "Corrections and content service"}</h2></div><span class="pill">${esc(planName)}</span></div><div class="plan-grid"><section class="service-card system-policy" id="basic-correction-policy"><span class="service-kicker">${lang === "zh" ? "全部计划" : "All plans"}</span><h3>${esc(t("plans.base.title"))}</h3><p>${esc(t("plans.base.body"))}</p><div class="service-state"><strong>${esc(t("plans.base.fixed"))}</strong><span class="fixed-badge">${lang === "zh" ? "只读" : "Read only"}</span></div></section><section class="service-card" id="content-service"><span class="service-kicker">${plan.editable ? (lang === "zh" ? "付费权益" : "Paid benefit") : (lang === "zh" ? "普通权益" : "Standard benefit")}</span><h3>${esc(t("plans.review.title"))}</h3><p>${esc(t("plans.review.rule"))}</p><div class="service-state"><div><strong>${esc(parsed.valid ? label(proposed) : t("plans.review.invalid"))}</strong><small>${esc(plan.editable ? t("plans.sameModel") : t("plans.review.locked"))}</small></div><label class="switch"><span class="sr-only">${esc(t("plans.review.title"))}</span><input id="content-review-switch" type="checkbox" ${enabled ? "checked" : ""} ${plan.editable ? "" : "disabled"}><span aria-hidden="true"></span></label></div><label class="limit-field" for="content-repair-limit"><span>${esc(t("plans.review.limit"))}</span><input id="content-repair-limit" type="number" inputmode="numeric" min="0" max="99" step="1" value="${esc(parsed.raw)}" ${plan.editable ? "" : "disabled"} aria-invalid="${!parsed.valid}" aria-describedby="limit-help${parsed.valid ? "" : " limit-error"}"></label><p id="limit-help" class="field-help">${esc(plan.editable ? t("plans.review.limit.help") : t("plans.review.locked"))}</p>${parsed.valid ? `<p class="boundary-note">${esc(t("plans.validationNote"))}</p>` : `<p id="limit-error" class="field-error" role="alert">${esc(t("plans.review.invalid"))}</p>`}</section></div><div class="form-footer"><button class="btn primary" data-action="preview-plan" ${parsed.valid ? "" : "disabled"}>${esc(t("plans.preview"))}</button></div></section>${outcome}</form>${scenarios}</div></main>${footer()}`;
}

function presetPreview(mode, state) {
  const enhanced = mode === "enhanced";
  if (state === "none") return `<div class="preview-empty"><span class="empty-glyph">Aa</span><p>${esc(t("preset.draftNote"))}</p></div>`;
  if (state === "stale") return `<div id="preview-result" class="warning-box" role="status" data-state="stale" tabindex="-1">${esc(t("preset.stale"))}</div>`;
  if (state === "running") return `<div id="preview-result" class="preview-running" data-state="running" tabindex="-1"><div class="spinner" aria-hidden="true"></div><h3>${esc(enhanced ? t("stage.review") : t("stage.generating"))}</h3><p>${esc(t(enhanced ? "stage.review.body" : "stage.wait.body"))}</p></div>`;
  if (state === "pending") return `<div id="preview-result" class="preview-empty" role="status" data-state="pending" tabindex="-1"><span class="empty-glyph">…</span><h3>${esc(t("stage.pending.title"))}</h3><p>${esc(t("stage.pending.body"))}</p><button id="preset-recheck" class="btn primary" data-action="recheck-preset" ${params.get("recheck") === "checking" ? 'disabled aria-busy="true"' : ""}>${esc(t(params.get("recheck") === "checking" ? "action.rechecking" : "action.recheck"))}</button></div>`;
  if (state === "cancelled") return `<div id="preview-result" class="warning-box" role="status" data-state="cancelled">${esc(t("stage.cancelled.body"))}</div>`;
  const previewText = esc(enhanced ? fixtures.draft.repairedText : fixtures.draft.text).replace(/\b(wander(?:ed)?|weav(?:e|er))\b/gi, (match) => `<mark>${match}</mark>`);
  return `<article id="preview-result" class="preview-paper" data-state="${state}" tabindex="-1"><div class="section-head"><div><p class="step-kicker">${esc(t("preset.previewHeading"))}</p><h3>${esc(fixtures.draft.title)}</h3></div><span class="pill">${esc(t(`preset.mode.${mode}`))}</span></div><p class="story-text" lang="en">${previewText}</p><div class="resource-grid compact-resources">${fixtures.draft.targets.map((target) => `<article class="resource-card"><h4 lang="en">${esc(target.entry)}</h4><p>${esc(target.meaning)}</p></article>`).join("")}</div><div class="${state === "incomplete" ? "warning-box incomplete-note" : "success-box"}">${esc(t(state === "incomplete" ? "preset.incomplete" : "preset.ready"))}</div></article>`;
}

function presetsPage() {
  const mode = params.get("mode") === "enhanced" ? "enhanced" : "base";
  const state = params.get("previewState") || "none";
  const canPublish = ["ready", "incomplete"].includes(state);
  const confirmed = params.get("confirmed") === "1";
  const scenarios = scenarioBar([link("Base ready", {mode:"base",previewState:"ready",recheck:null}),link("Enhanced running", {mode:"enhanced",previewState:"running",recheck:null}),link("Enhanced ready", {mode:"enhanced",previewState:"ready",recheck:null}),link("Review incomplete", {mode:"enhanced",previewState:"incomplete",confirmed:null,recheck:null}),link("Pending", {mode:"enhanced",previewState:"pending",recheck:null}),link("Mode changed", {mode:"enhanced",previewState:"stale",recheck:null})]);
  const publishConfirm = state === "incomplete" ? `<label class="publish-confirm"><input id="publish-confirm" type="checkbox" ${confirmed ? "checked" : ""}> <span>${esc(t("preset.publishConfirm"))}</span></label>` : "";
  return `${shellHeader(true)}<main class="container page admin-shell-m003" id="main" tabindex="-1">${adminNav("presets")}<div class="admin-main"><header class="page-head"><div><p class="eyebrow">WORDWEAVE / ${esc(t("admin.label"))}</p><h1>${esc(t("preset.title"))}</h1><p>${esc(t("preset.intro"))}</p></div><button class="btn primary">${esc(t("common.new"))}</button></header><div class="preset-layout"><aside class="panel preset-list"><h2>${esc(t("preset.list"))}</h2><button class="admin-record selected"><strong>${esc(fixtures.preset.title)}</strong><span>${esc(t("preset.edited"))}</span></button><button class="admin-record"><strong>${lang === "zh" ? "雨夜书店" : "Rainy night bookshop"}</strong><span>${esc(t("preset.published"))}</span></button></aside><section class="panel preset-editor"><div class="editor-state"><span class="pill">${esc(t("preset.edited"))}</span><p>${esc(t("preset.draftNote"))}</p></div><form onsubmit="return false"><div class="preset-title-field"><label class="field"><span>${esc(t("preset.name"))}</span><input value="${esc(fixtures.preset.title)}" required></label><p class="field-help">${esc(t("preset.nameHint"))}</p></div><section class="editor-section"><div class="section-head compact"><h2>${esc(t("preset.words"))}</h2><span class="word-count">2 / 8</span></div><div class="selected-words"><span class="chip">wander <button type="button" aria-label="Remove wander">×</button></span><span class="chip">weave <button type="button" aria-label="Remove weave">×</button></span></div><label class="field"><span class="sr-only">${esc(t("create.search"))}</span><input type="search" placeholder="${esc(t("create.search"))}"></label></section><section class="editor-section"><h2>${esc(t("preset.settings"))}</h2><div class="preset-config-grid"><label class="field"><span>${esc(t("create.model"))}</span><select><option>Model A · General English</option></select></label><label class="field"><span>${esc(t("create.style"))}</span><select><option>${esc(t("create.story"))}</option></select></label><label class="field"><span>${esc(t("create.length"))}</span><select><option>${esc(t("create.short"))}</option></select></label><label class="field"><span>${esc(t("create.meaning"))}</span><select><option>${esc(t("create.chinese"))}</option></select></label></div></section><fieldset id="preview-mode" class="mode-group"><legend>${esc(t("preset.mode"))}</legend><div class="mode-options"><label class="mode-option"><input type="radio" name="mode" value="base" ${mode === "base" ? "checked" : ""}><span><strong>${esc(t("preset.mode.base"))}</strong><small>${esc(t("benefit.base.body"))}</small></span></label><label class="mode-option"><input type="radio" name="mode" value="enhanced" ${mode === "enhanced" ? "checked" : ""}><span><strong>${esc(t("preset.mode.enhanced"))}</strong><small>${esc(tt("benefit.enhanced.body", {limit:1}))}</small></span></label></div><p class="field-help">${esc(t("preset.mode.note"))}<br>${esc(t("preset.mode.limit"))}</p></fieldset><div class="editor-actions"><button class="btn" data-action="save-preset">${esc(t("common.saveDraft"))}</button>${state === "running" ? `<button class="btn" data-action="cancel-preset">${esc(t("action.cancel"))}</button>` : `<button class="btn" data-action="generate-preview">${esc(t("preset.generate"))}</button>`}<button id="preset-publish" class="btn primary" data-action="publish-preset" ${!canPublish || (state === "incomplete" && !confirmed) ? "disabled" : ""}>${esc(t("preset.publish"))}</button></div>${publishConfirm}<p class="usage-note">${esc(tt("preset.usage", {count:fixtures.preset.usage}))}</p></form><section class="preview-section"><div class="section-head"><h2>${esc(t("preset.previewHeading"))}</h2><span>${esc(t("preset.usageTitle"))}</span></div>${presetPreview(mode, state)}</section>${params.get("published") === "1" ? `<p class="success-box" role="status">✓ ${esc(t("preset.publishedToast"))}</p>` : ""}</section></div>${scenarios}</div></main>${footer()}`;
}

function bind() {
  document.querySelectorAll("[data-add-word]").forEach((button) => button.addEventListener("click", () => {
    const words = new Set((params.get("words") || "wander,weave").split(",").filter(Boolean)); words.add(button.dataset.addWord); update({words:[...words].join(",")}, "word-search");
  }));
  document.querySelectorAll("[data-remove-word]").forEach((button) => button.addEventListener("click", () => {
    const words = (params.get("words") || "wander,weave").split(",").filter((word) => word && word !== button.dataset.removeWord); update({words:words.join(",")}, "word-search");
  }));
  document.querySelector("#content-review-switch")?.addEventListener("change", (event) => update({limit:event.currentTarget.checked ? (/^[1-9]\d?$/.test(document.querySelector("#content-repair-limit")?.value || "") ? document.querySelector("#content-repair-limit").value : 1) : 0,adminState:"edit"}, "content-review-switch"));
  document.querySelector("#content-repair-limit")?.addEventListener("change", (event) => update({limit:event.currentTarget.value,adminState:"edit"}, "content-repair-limit"));
  document.querySelectorAll('input[name="mode"]').forEach((input) => input.addEventListener("change", (event) => update({mode:event.currentTarget.value,previewState:"stale",confirmed:null,published:null}, "preview-mode")));
  document.querySelector("#publish-confirm")?.addEventListener("change", (event) => update({confirmed:event.currentTarget.checked ? 1 : null}, "publish-confirm"));
  document.querySelectorAll("[data-action]").forEach((button) => button.addEventListener("click", () => {
    const action = button.dataset.action;
    if (action === "generate") update({stage:"generating",saved:null}, "generation-status");
    if (action === "next-stage") update({stage:button.dataset.next}, "generation-status");
    if (action === "cancel-generation") update({stage:"cancelled"}, "generation-status");
    if (action === "restart") update({stage:"idle",recheck:null,outcome:null,saved:null}, "generation-status");
    if (action === "save-story") update({stage:"saved"}, "generation-status");
    if (action === "recheck-generation") update({recheck:"checking"}, "generation-recheck");
    if (action === "preview-plan") update({adminState:"preview"}, "change-preview");
    if (action === "cancel-plan") update({adminState:"edit",limit:null}, "content-service");
    if (action === "save-plan") update({adminState:"saved"}, "save-result");
    if (action === "conflict-plan") update({adminState:"conflict",remote:2}, "version-conflict");
    if (action === "repreview-plan") update({adminState:"preview",remote:null}, "change-preview");
    if (action === "save-preset") update({savedDraft:1}, "preview-mode");
    if (action === "generate-preview") update({previewState:"running",recheck:null,published:null}, "preview-result");
    if (action === "cancel-preset") update({previewState:"cancelled"}, "preview-result");
    if (action === "recheck-preset") update({recheck:"checking"}, "preset-recheck");
    if (action === "publish-preset") update({published:1}, "preset-publish");
  }));
}

function render() {
  const page = params.get("page") || "create";
  document.title = `${t("brand")} · ${page === "plans" ? t("plans.title") : page === "presets" ? t("preset.title") : t("create.title")}`;
  const app = document.querySelector("#app");
  app.innerHTML = page === "plans" ? plansPage() : page === "presets" ? presetsPage() : createPage();
  app.setAttribute("aria-busy", "false");
  bind();
}

window.addEventListener("popstate", () => location.reload());
render();
