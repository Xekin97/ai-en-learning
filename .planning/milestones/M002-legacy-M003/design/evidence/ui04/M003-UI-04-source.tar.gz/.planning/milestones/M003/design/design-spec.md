---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M003-UI-04
date: 2026-10-10
input_version: M003-PRODUCT-03 / M003-BE-02 / M003-FE-01
---

# M003 完整页面设计规格

## 当前目标与有效范围

- **CONFIRMED / 本轮用户要求**：`USER-M003-UI-REVIEW-A` 选择 A，把 M003 新增区域放回已有完整页面，补齐可交互设计，先展示给用户评审，再实施前端。来源：[requirements-feedback.md](../reviews/requirements-feedback.md#M003-UI-REVIEW-设计展示与评审反馈)。本文件生成不表示 UI04 已获视觉批准。
- **完整页范围**：PAGE-204 造文、PAGE-208 计划管理、PAGE-212 首页预设管理。保留现有导航、布局、选词/模型/场景/长度/释义、计划模型/长度/额度/优先级、预设列表/草稿/配置/发布操作；整合 CAP-301–304、DATA-301–304 和 API-301–304 对应 UI。
- **有效业务约束**：普通权益只含漏词/格式/学习字段基础纠错；每请求全程最多 2 次技术预算为已接收 BE02 只读策略。付费计划内容返修上限 N 为独立整数 0–99、初始 1，0 关闭整个内容审校，1–99 开启；没有只审不修模式。内容流程验证最多运行 2 次返修，99 仅核字段/配置边界。内容故障且已有完整基础有效稿时保留最近有效稿、持续提示“内容审校未完成”、可保存且计一次。来源：CAP-302/303、AC-301–314、USER-M003-Q01-B/Q02-A/Q03-RANGE99。
- **仍有效的品牌来源**：M002 当前暖白画布、深绿主色、阅读衬线正文、圆角纸张层次和现有产品/管理台导航；源码基线为 `frontend/app/pages/create.vue`、`frontend/app/presentation/components/GenerationWorkspace.vue`、`frontend/app/pages/admin/plans.vue`、`frontend/app/pages/admin/presets.vue` 及现有布局。
- **可恢复来源**：UI04 当前待审源码快照为 `evidence/ui04/M003-UI-04-source.tar.gz`，清单为 `evidence/ui04/M003-UI-04-source-manifest.json`；包含本版规格、文案、主题、原型、交互、响应式、UI 交接和直接依赖的 M002 主题，不含 evidence 目录以避免递归。工作区基于仓库 commit `45a4ab123c3308fa0a83868b6030c6b84a96f67d`。UI03 冻结包 `reviews/evidence/design-011/artifacts.tar.gz` 与 FE01 冻结包 `reviews/evidence/technical-012/artifacts.tar.gz` 继续原位保留。UI04 快照只用于准确复现待审提交，不表示批准。
- **失效的当前设计用法**：UI03 的三个增量卡片原型不能作为 USER-M003-UI-REVIEW-A 的完整页评审稿。其业务语义和冻结证据仍保留为历史；当前受影响设计标准由 UI04 全套文件替换。
- **范围外**：PAGE-216 读者预设生成沿 PAGE-204 的同一生成体验和既有 `/trial/:presetId` 完整页面实现边界；PAGE-215/217 无新增布局。本轮不重做整站、不改 API/代码/数据库、不调用真实模型、不做 UAT3302、不声称样例文章质量通过。

## 设计目标与表达

主任务是让用户或管理员在原页面上下文中理解 M003 能力，而不是先理解一张独立规则卡。造文页采用“配置与选词 / 生成结果”双栏工作台，权益摘要置于主工作区之前；先让用户看到可读首稿，审校时正文留在原位，整包返修后整体替换。计划页沿用四计划标签与一个完整表单，先放原模型/长度/额度/优先级，再把两类预算并排解释，最后进入影响预览或冲突恢复。预设页沿用主从编辑器，配置、模式、动作与结果在一个连续页面内完成。

视觉继承 M002 的暖白、深绿与阅读纸张，管理页面保持密度，学习页面扩大正文呼吸空间。绿色承担主要动作和当前状态，米黄承担草稿/上限定稿，橙色承担审校未完成或冲突；任何状态同时有文字和结构，不依赖颜色。仅使用 CSS/文本符号与现有字体栈，无新图片、远程字体或外部资源。

## 打开原型与复现场景

- 服务根：项目已有静态服务 `http://127.0.0.1:4174/`，根目录为 `app/.planning/milestones`；UI04 入口为 `http://127.0.0.1:4174/M003/design/prototype/`。本地命令等价于在 `.planning/milestones` 目录启动静态 HTTP 服务；直接双击会因 `fetch` 文案源受限而不支持。
- 原型实际加载 `../copy.json`、`../theme.css`、`prototype/fixtures.json` 和 `prototype/app.js`。固定 UI 文案从 `copy.json` 消费；fixture 仅为确定布局，非真实用户、计划、调用、成本、延迟或质量证据。
- 推荐视口：1440×1000、768×1024、390×844、320×700；系统字体即可。页面 `#app[aria-busy=false]` 且无 `⟦key⟧` 表示来源加载完成。

| 页面 / 稳定 ID | 入口与默认完整页 | 关键状态入口 | 原型定位 |
|---|---|---|---|
| PAGE-204 / CAP-301/302 / DATA-301–303 | `?page=create&plan=pro&limit=2&stage=idle&lang=zh` | `stage=repair2` 第 2 次返修；`stage=complete&outcome=limit` 上限定稿；`stage=incomplete` 有效稿审校未完成；`stage=pending&recheck=available|checking`；`plan=basic` 普通权益 | `#benefit-summary`、`.creation-panel`、`#generation-status` |
| PAGE-208 / CAP-303 / DATA-301 | `?page=plans&plan=pro&limit=1&adminState=edit&lang=zh` | `limit=0&adminState=preview`；`limit=99&adminState=saved`；`limit=-1|100|1.5|空`；`limit=99&adminState=conflict&remote=2`；`plan=basic` 只读 | `.existing-settings`、`#basic-correction-policy`、`#content-service`、`#change-preview`、`#version-conflict` |
| PAGE-212 / CAP-304 / DATA-304 | `?page=presets&mode=base&previewState=none&lang=zh` | `mode=enhanced&previewState=running|ready|incomplete|pending|stale`；incomplete 加 `confirmed=1` 可发布；pending 加 `recheck=checking` | `.preset-list`、`.preset-editor`、`#preview-mode`、`#preview-result`、`#preset-recheck`、`#preset-publish` |

所有入口支持 `lang=en`。页面底部“原型场景”仅用于评审快速切换，不进入正式产品。

## 页面与内容定位

| 页面 / 区域 | 元素顺序与职责 | 文案键 / 资源 | 显示规则 |
|---|---|---|---|
| PAGE-204 顶栏与页头 | 品牌→现有导航→额度→语言/账号；标题与说明 | `brand.*`、`nav.*`、`create.*`；CSS `.topbar/.page-head` | 移动端导航在顶栏内局部横滚，页面本身不横溢 |
| `#benefit-summary` | 权益名称→动态说明→实际计划→受理快照 | `benefit.*`、模板 `benefit.plan/enhanced.body` | basic/visitor 为基础；Pro/Plus 按服务端 N，0 仍为基础；用户不能切换 |
| `.creation-panel` | 模型→场景/长度/释义→词库搜索/候选/已选词→生成 | `create.settings/model/style/length/meaning/search*` | 生成期间字段禁用；预设生成实际实现为锁定配置，但沿相同结果区 |
| `#generation-status` | 区域标题→常数规模阶段轨道→目标词高亮/标签/学习资源/持久 notice→取消或保存 | `stage.*`、`action.*`、`create.resources` | 审校保留当前完整稿；返修整包有效后整体替换。limit 正常完成但不称通过；incomplete 保留最近有效稿且可保存；pending/无有效稿不可保存 |
| PAGE-208 四计划标签 | 访客/基础/Pro/Plus 与当前内容服务摘要 | 模板 `plans.review.on`、`plans.review.off` | 保留四行；Pro/Plus N 独立，不继承 |
| `.existing-settings` | 模型多选→长度多选→优先级/选词上限/24h额度/不限 | `plans.existing.*`、`plans.models/lengths/priority/words/daily/unlimited` | 维持现有表单和保存上下文，不因 M003 隐藏 |
| `#basic-correction-policy` / `#content-service` | 两类预算并列→基础只读→内容开关/N→边界说明→差异预览 | `plans.base.*`、`plans.review.*`、`plans.validationNote` | visitor/basic 内容服务只读 0；Pro/Plus 严格整数 0–99，非法不自动截断且不可预览 |
| `#change-preview` / `#version-conflict` | 基础策略不变→内容旧/新值→撤回警示→人数/新请求/在途/用量→保存；冲突远端/本地同时保留 | `plans.preview/effect/conflict/latest/local/recheck.*` | 预览不调用模型；保存冲突不部分保存，保留本地输入并重新预览 |
| PAGE-212 `.preset-editor` | 状态→名称→预设词汇→四项配置→预览模式→草稿/生成/发布→用量→预览结果 | `preset.*`、`create.model/style/length/meaning` | 生成参数或 mode 变化使旧预览 stale；先保存 mode 对应草稿再预览 |
| `#preview-mode` / `#preview-result` | basic 0 / enhanced 固定 1→状态/完整稿/notice→发布 | `preset.mode.*`、`preset.ready/incomplete/stale/pendingPublish` | 不读取管理员 Pro/Plus；incomplete 需显式确认后手动发布；pending/过期/无效不可发布；`重新核对/核对中…` 原位 |

动态 N、计划名、影响人数、阶段 k/N、正文与用量均来自应用模型。原型正文来自 `fixtures.json`。`create.articleSample` 只在页面底部折叠的“原型场景”说明层显示，与 `prototype.scope` 一起说明样例边界；不属于 `#generation-status`、预设结果或任何正式产品流程，前端实现不得带入生产界面。

## 详细规则入口

- 布局、颜色、字级、间距、层次与必要动效：`theme.css`；继承 M002 token 后由“`M003-UI-04 full-page composition`”段覆盖完整页结构。
- 状态、触发、结果、错误、中断和连续操作：`interactions.md`。
- 目标视口、键盘/焦点、触控、长内容、语言和减少动效：`responsive-accessibility.md`。
- 资源：无新增位图、SVG、远程字体或第三方资源；字符图标仅为原型表达，前端继续使用现有 `AppIcon/BrandMark`。

## 实现约束与验收

| 验收 ID | 页面 / 原型定位 | 必须保持的结果 | 允许差异 | 检查方法与充分证据 |
|---|---|---|---|---|
| UIA-M003-401 | PAGE-204 `.topbar/.creation-panel/#generation-status` | 完整导航、模型/场景/长度/释义、选词与结果操作都在同页；新增权益/阶段不替换原功能 | Vue 组件/DOM 可不同 | 运行页可见顺序、表单可操作、生成到保存连续点击；代表桌面/手机截图 |
| UIA-M003-402 | `#benefit-summary` | actual plan 与动态 N；0 时仅基础；受理后快照不随管理变更 | plan 名与实时数值由 API | basic、N2、N99 的文本/属性；不得按计划名猜 |
| UIA-M003-403 | `#generation-status` | 首稿先可读；审校保留稿；第 2 次内容返修可复现；上限定稿无故障/通过承诺 | 正文为真实应用数据 | N2 连续操作到 repair2；limit complete notice 与保存资格 |
| UIA-M003-404 | `data-stage=incomplete/pending` | incomplete 显示最近完整有效整稿、持久警示、可保存、计一次；pending 显式有限核对且不可保存 | 自动核对时长由 FE01/BE02 | 手机视觉、按钮资格、available→checking；不调用新生成 |
| UIA-M003-405 | PAGE-208 `.existing-settings` | 原模型/长度/额度/优先级表单与 M003 两类预算同时存在 | 字段组件可复用当前实现 | 桌面/手机完整页可见，不以独立卡片替代 |
| UIA-M003-406 | `#basic-correction-policy/#content-service` | 基础策略全计划只读、最多 2；普通内容 0；付费 N 独立整数 0–99，0 关闭，无只审不修 | BE02 真值替代 fixture | 四计划、开关/数字联动与可访问名称 |
| UIA-M003-407 | `#content-repair-limit` | 0/99 合法；-1/100/1.5/空非法，非法不可预览；99 只字段边界 | 原生或等价校验 UI | 属性、错误、按钮状态；不执行模型调用/99 轮流程 |
| UIA-M003-408 | `#change-preview/#version-conflict` | 显示基础不变、旧新 N、人数、新请求/在途/用量；冲突 local99/remote2 同时保留且需重预览 | 人数取真实 impact | 实际操作预览→保存/冲突；刷新读取由实现验证 |
| UIA-M003-409 | PAGE-212 `.preset-editor` | 列表、名称、词汇、模型、场景、长度、释义、草稿保存、预览与发布都在完整页 | 现有组件拆分不变更结果 | basic/enhanced 切换、保存草稿、生成结果、发布连续操作 |
| UIA-M003-410 | `#preview-mode/#preview-result/#preset-publish` | basic0/enhanced1 独立于计划 N；mode stale；incomplete 明示后可手动发布；pending/过期不可发布 | 发布确认可用现有对话框 | ready/incomplete/pending 的 notice 与按钮资格；核对按钮 available/checking |
| UIA-M003-411 | 全部完整页 | 中文/英文固定文案来自 copy；≥320px 无页面横向溢出；交互目标≥44px；焦点可见；状态不只靠颜色 | 系统字体抗锯齿与自然换行 | Chromium 1440/768/390/320、文案缺键、边界与截图人工检查；键盘/200%/读屏留实现验证 |

UIA-M003-401–411 是 UI04 的当前待审验收。FE01 中 UIA-M003-301–309 的业务映射仍有效，但其“UI03 增量原型可作为最终还原基线”的描述需要 frontend-bob 在实施前复核并映射到 401–411；不修改冻结 FE01 原件。

## 设计自检与未决项

验证模式为需求验收。证据预算：13 个去重场景（其中 6 个边界字段场景）、最多 6 张本地截图；视觉缺陷需要复验，因此实际人工查看 8 张。首轮结构断言 13/13 PASS，但人工查看在 `evidence/ui04/initial/` 发现阶段轨道伪元素变形成绿色椭圆、说明窄列竖排、skip link 被 full-page 捕获，以及产品流程混入研发说明；该轮报告与截图保留。修正继承样式、焦点目标和说明层级，并补回既有目标词高亮、标签和学习资源后定向复验。当前结果见 `evidence/ui04/M003-UI-04-browser.json`：Chromium / Node 22 / Playwright 1.62.1，13/13 PASS，6 张截图，检查 1440/768/390、中文/英文、连续生成到第 2 次返修、审校未完成可保存、两类预算、0/99/非法输入、影响预览/冲突、预设 incomplete/pending 和无页面横向溢出；截图状态与文件名一致。

静态检查：`copy.json` 与 `fixtures.json` 可解析，`app.js` 通过 `node --check`，HTTP 入口 200；浏览器无 console/page error、无缺失文案标记。未执行真实模型、真实 10 秒轮询、API/权限/数据库结算、刷新持久化、键盘完整走查、200% 缩放、读屏、Safari/Firefox 或 UAT3302。原型自检只证明 UI04 设计可评审，不证明前端实现或真实内容质量。

当前无新增业务选择、开放 CR 或设计阻塞。**PROPOSED**：用户评审 UI04；若接受，再由 frontend-bob 复核 FE3-07/08/T05/V11 与 UIA-M003-401–411、更新接收映射，之后才由有权限流程进入前端实施。
