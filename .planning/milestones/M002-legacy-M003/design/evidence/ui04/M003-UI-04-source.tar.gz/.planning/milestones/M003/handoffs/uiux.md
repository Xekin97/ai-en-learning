---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M003-UI-04
date: 2026-10-10
input_version: M003-PRODUCT-03 / M003-BE-02 / M003-FE-01
---

# M003 UI/UX 交接

## 使用的输入与需求确认

- 当前业务阶段和身份为 `uiux-design / uiux/base / designer-tony`，Profile 锁仍为 `consumer-ai-web@1.0.0`；未迁移 Profile。模型路由请求 `gpt-5.6-sol/high`，actual_model 与 runtime usage 未提供，均为 unknown。
- `USER-M003-UI-REVIEW-A` 已确认选择 A：把新增区域放回造文、计划管理、预设管理的现有完整页面，补齐可交互设计后先给用户评审，再实施前端。来源：[requirements-feedback.md](../reviews/requirements-feedback.md#M003-UI-REVIEW-设计展示与评审反馈)。这不是 UI04 视觉批准或前端实施授权。
- 业务依据为 M003-PRODUCT-03 的 PAGE-204/208/212、CAP-301–304、DATA-301–304、AC-301–314；API 细节以 API-301–304 和 BE02 为准。Q01-B/Q02-A/Q03-RANGE99 已确认：付费计划 N 独立、初始 1、整数 0–99/0 关闭；内容技术故障有完整基础有效稿则提示后保留、可保存并计一次；内容流程测试最多 2 次，99 只核配置边界。
- 基础纠错全请求最多 2 次为已接收 BE02 只读策略，与内容 N 独立、不因换稿重置。后台预设 basic0/enhanced1 独立于管理员计划。pending 有限核对与显式 `重新核对/核对中…` 保留 UI03/CR-301 语义。
- UI03 冻结原件为 `reviews/evidence/design-011/artifacts.tar.gz`；FE01 冻结原件为 `reviews/evidence/technical-012/artifacts.tar.gz`。本轮未覆盖、删除或改写冻结历史；UI03 增量卡片退出当前完整页评审标准。

## 本次原始产物

- [M003-UI-04 设计规格](../design/design-spec.md)：完整页入口、PAGE/CAP/DATA/API 追踪、UIA-M003-401–411、有效/待审/失效范围。
- [copy.json](../design/copy.json)：中英文固定文案与动态模板，原型实际 fetch 使用。
- [theme.css](../design/theme.css)：继承 M002 暖白/深绿品牌 token，并定义三个完整页面的布局、状态、响应式与 reduced-motion。
- [完整页原型](../design/prototype/index.html)、[交互逻辑](../design/prototype/app.js)、[样例夹具](../design/prototype/fixtures.json)。fixture 只展示布局，不证明模型质量、用量、费用或延迟。
- [交互与状态](../design/interactions.md)：造文、计划、预设三条连续流程，pending、故障、中断和动效。
- [响应式与可访问性](../design/responsive-accessibility.md)：1440/768/390/320、键盘/焦点/触控/缩放/读屏边界。
- [当前浏览器报告](../design/evidence/ui04/M003-UI-04-browser.json)、[验证脚本](../design/evidence/ui04/browser.mjs)及同目录 6 张截图。首轮视觉缺陷证据保留在 [initial](../design/evidence/ui04/initial/)；没有用最终截图覆盖失败表现。
- [UI04 待审源码快照](../design/evidence/ui04/M003-UI-04-source.tar.gz)与[快照清单](../design/evidence/ui04/M003-UI-04-source-manifest.json)：包含同版设计源码、交接和 M002 直接主题依赖，排除 evidence 目录本身；只用于复现当前待审稿，不构成批准。

## 可直接评审的完整页面

- 造文完整页：`http://127.0.0.1:4174/M003/design/prototype/?page=create&plan=pro&limit=2&stage=idle&lang=zh`
- 计划管理完整页：`http://127.0.0.1:4174/M003/design/prototype/?page=plans&plan=pro&limit=2&adminState=edit&lang=zh`
- 预设管理完整页：`http://127.0.0.1:4174/M003/design/prototype/?page=presets&mode=enhanced&previewState=none&lang=zh`

造文页可从选词/模型连续点到草稿、审校、第 2 次返修、定稿与保存；计划页可改 N、预览影响、保存或演示冲突；预设页可切 basic/enhanced、生成、核对、确认 incomplete 后发布。底部“原型场景”提供边界快捷入口，并承载样例/模拟说明，不混入正常产品流程。三页均可改 `lang=en`。

## UI 交付与接收

UI04 保留真实现有页面骨架：造文含顶栏/导航、模型/场景/长度/释义、词库选词、额度、正文目标词高亮、标签、学习资源与保存；计划含四计划、模型/长度/额度/优先级、原保存上下文；预设含列表、名称、词汇、四项配置、草稿、预览、用量与发布。M003 能力准确嵌入这些任务，不再以独立增量卡片代替完整页。

frontend-bob 在前端实施前需要复核 M003-FE-01：

1. 把 FE3-07/08/T05/V11 从 UI03 增量定位更新映射到 UI04 的 UIA-M003-401–411；401–411 扩展完整页与保留项，不改变 API-301–304 或 AC-301–314。
2. `GenerationWorkspace.vue` 保留已有目标词 `mark`、tags、学习资源卡与保存/放弃；增加权益摘要、阶段与 notice 时不得降级这部分阅读交互。预设管理沿现有完整编辑器增加 mode/result，不替换已有字段。
3. 文案同步脚本继续以当前 `copy.json` 为源；生产不带原型场景、fixture、模拟说明或“继续演示下一阶段”。前端不自行同义改写 fixed copy。
4. 真实 DOM/组件可不同，但必须保持页面内容顺序、完整功能、动态 N/k、资格、整包替换、响应式和焦点结果。计划 conflict 同时保留 local/remote；预设 incomplete 明示确认才可发布。
5. 实施验证补 320/768、全流程键盘、200% 缩放、读屏抽查、真实 10 秒有限核对、HTTP/权限/刷新持久化和 reduced-motion。原型证据不能替代 API/DB/真实模型或产品实现验证。

## 浏览器验证与证据边界

模式为需求验收，预算为 13 个去重场景、6 张保存截图；视觉缺陷复验使人工查看实际为 8 张。首轮自动结构/几何断言为 13/13 PASS，但人工查看发现阶段轨道继承伪元素后圆点拉伸、中文说明窄列竖排、skip link 被 full-page 捕获、研发说明混入产品流程；这些首轮材料保留在 `evidence/ui04/initial/`。修复样式/焦点/文案层级并补回目标词高亮、标签与学习资源后定向复验。

当前报告为 Chromium / Playwright 1.62.1 / Node 22.23.2：13/13 PASS、6 张截图、8 次人工图像查看、无 console/page error、无缺失 copy、无页面横向溢出。覆盖桌面/手机、中文/英文、连续到第 2 次返修、incomplete 可保存、两预算、0/99/-1/100/1.5/空、影响预览/保存/冲突、预设 enhanced/incomplete/pending、发布资格。截图 `01-create-repair2-1440.png` 当前真实停在 repair2，文件名与状态一致。

未验证：真实模型/供应方、真实 10 秒计时和 HTTP 终态、权限 token、数据库结算与持久化、前端构建、Safari/Firefox、完整键盘/200%/读屏、UAT3302、部署。样例文章只供布局，不代表质量验收通过。Node 24 是正式工程要求，本静态原型使用现有 Node 22，不把它写成产品实现通过。

## 文档整理、追踪与未决

- 当前权威入口是 UI04 `design-spec.md` 和本交接；copy/theme/prototype/interactions/responsive 同版本。当前可恢复版本由 `design/evidence/ui04/M003-UI-04-source.tar.gz` 与同名 manifest 定位；UI03 冻结审批、失败/通过证据与 FE01 冻结包原位保留。
- 覆盖 PAGE-204/208/212（PAGE-216 沿 PAGE-204 结果体验）、CAP-301–304、DATA-301–304、API-301–304、AC-301–314、UIA-M003-401–411。未更改 PAGE-215/217 或其他全站页面。
- 文档/JSON/JS 与本地 HTTP 静态自检已完成；未提交 Git。读取按稳定 ID 定向完成，未递归全载 planning；runtime token/费用 unknown。
- **BLOCKED：无。开放 CR：无。** 当前唯一待审是用户对 UI04 三个完整页的视觉与交互反馈。UI04 不自批，建议状态 `awaiting_user_review`；阶段迁移仍由用户和控制角色决定。

## 下一步建议

请用户直接打开三个完整页评审。若要求调整，由 designer-tony 同步修改同版本全套来源并复验；若用户明确接受 UI04，再由 frontend-bob 先完成 FE01 映射复核，由后续有权限角色实施。不能用 USER-M003-UI-REVIEW-A、UI03 旧接收或本轮自检代替 UI04 批准。
