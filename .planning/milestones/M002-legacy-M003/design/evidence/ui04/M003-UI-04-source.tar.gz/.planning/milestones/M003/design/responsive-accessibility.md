---
milestone: M003
version: M003-UI-04
agent_name: designer-tony
date: 2026-10-10
---

# UI04 响应式与可访问性

## 视口与布局

| 范围 | 造文 PAGE-204 | 管理 PAGE-208/212 |
|---|---|---|
| `≥1101px` | 最大容器 1440；权益摘要三段；配置/选词与结果约 39/61 双栏；配置可 sticky，结果纸张保持阅读宽度 | 190px 侧栏 + 主区。计划四标签同排、原字段三列、两类预算两列；预设 250px 列表 + 编辑器 |
| `761–1100px` | 配置与结果单列，配置取消 sticky；结果阶段保持横向常数轨道 | 150–190px 侧栏可保留；计划原字段两列、数值区整行；预算单列；预设可继续双栏，空间不足时由内容最小宽度转单列 |
| `≤760px` | 顶栏换行，主导航自身横滚；权益摘要改两行；配置字段、正文/释义单列；结果阶段在区域内横滚；底部动作至少 44px | 管理导航改区域内横滚；计划标签横滚；表单、两预算、差异/冲突单列；预设列表横滚，编辑器单列，动作栏换行 sticky |
| `320–360px` | 容器左右 10px；不缩小正文至不可读；按钮可换行；阶段每项 92px，滚动而不压字 | 所有数值输入保持可见；冲突双方上下排列；页面不得横向溢出，只有导航/标签/阶段是明确局部滚动容器 |

目标验证视口为 1440×1000、768×1024、390×844、320×700。长英文按钮允许自然换行；不以截断隐藏计划名、N、notice、错误或冲突值。文章正文 `overflow-wrap:anywhere`，样例为英文并标 `lang=en`；界面切换中英文不重写生成正文或词义数据。

## 触控、键盘与焦点

- button/link/select/number/radio/checkbox 的可操作区域至少 44×44px；紧邻操作间距至少 8px。原生 checkbox/radio/number/select 保留，不用只有视觉外壳的 div。
- 焦点环使用 `--focus` 3px 与 4px offset；switch、mode card 的隐藏原生输入把 `:focus-visible` 投影到可见表面。禁用控件仍通过邻近文案解释原因。
- 顶部提供 skip link 到 `#main`；主区 `tabindex=-1`。键盘顺序按视觉顺序：导航→页头动作→表单→主动作→结果/保存→原型场景。正式实现不包含原型场景。
- 造文开始后焦点保留在发起按钮位置或移动到 `#generation-status` 标题一次；阶段更新不反复抢焦点。取消/完成后主动作保持可达。
- 计划产生 impact 时把焦点移到 `#change-preview h2`；冲突移到 `#version-conflict h2`。重新核对后返回 impact 标题。保存成功使用 status，不强制抢焦点。
- 预设 mode 变化后焦点留在所选 radio；生成结果只通过 status/polite 通知。incomplete 确认 checkbox 与发布按钮相邻；勾选后不自动发布。现有离开、发布和取消确认对话框继续 focus trap，关闭后回触发按钮。

## 名称、状态与朗读

- `#benefit-summary` 是有可见标题/说明的只读 region；动态 N 和计划名作为文本输出。开关有“AI 内容审稿与返修”名称；N 输入由 label 和 `aria-describedby=limit-help [limit-error]` 关联。
- 造文阶段轨道使用有序列表与当前 step，不使用百分比 progressbar。`#generation-status` 上 `data-stage` 仅供定位；可见文字才是用户信息。
- 草稿正文不放进 live region。`stage-note` 用 polite；failure/validation/conflict 用 alert；pending、保存成功、发布成功用 status。状态均有文字、结构和按钮资格，不只靠绿/橙色。
- `重新核对` 点击后同一按钮变为 `核对中…`、`disabled`、`aria-busy=true`，避免重复操作。active/503 返回后恢复可点但保持 pending；终态出现后焦点可移到终态标题。
- pending、失效预览、非法 N 和无有效稿状态的保存/发布按钮禁用或不存在；不能只用颜色表达不可用。

## 缩放、内容与减少动效

- 200% 浏览器缩放时按有效 CSS 宽度进入单列；不得让 sticky 动作遮挡错误、notice 或最后一行内容。固定页头/侧栏均可取消 sticky。
- 文案允许 200% 字体和中文/英文扩展；关键按钮可换行但不裁切。计划 N 最长两位，输入不依靠 placeholder 解释 0 的含义。
- `prefers-reduced-motion: reduce`：switch、正文替换和 spinner 均接近即时；不影响阶段或资格。无自动滚屏、视差或闪烁。
- 对比方向继承 M002：深绿/暖白正文、蓝色焦点。橙色 notice 文字仍用深色；浅绿 selected 状态有边框/文字双重信号。正式实现需按现有 axe/浏览器工具复核实际 token 对比。

## 已检查与实现阶段待检查

UI04 原型已在 Chromium 检查 1440/768/390 的中文/英文、无页面横溢、关键按钮/输入状态和 6 张代表视觉图；320 规则由 CSS 与结构断言覆盖但未保存截图。实际浏览器视觉检查发现移动阶段标签过窄，已改为 92px 局部横滚并复验。

前端实现必须补：320×700 与 768×1024 实际截图/边界、全流程 Tab、focus trap/恢复、200% 缩放、真实计时/reduced-motion、axe 与至少一次人工读屏抽查。未执行真实 iOS/Android、Safari/Firefox 或高对比模式；不得用本原型 PASS 代替这些实现验证。
