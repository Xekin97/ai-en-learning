---
milestone: M003
version: M003-UI-09-R1
agent_name: designer-tony
date: 2026-10-10
---

# UI09-R1 响应式与无障碍

## 布局

- ≥1100px：继承 M002 create 310px 设置栏 + 右侧内容；admin 192px sidebar；preset 240px list + editor。
- 761–1099px：M002 栅格规则收敛，设置可折叠；新增 Plan/草稿仍在同一阅读纸，不另造横向轨道。
- ≤760px：所有主栅格单列；Plan 用法、服务字段单列；按钮可换行；长义项/搭配/正文 `overflow-wrap:anywhere`。
- 320/390：页面不得横向溢出；标题、选词 token、custom select、管理动作保持可读。长正文不设固定高度。

## 键盘与读屏

- skip link 到 `#main`；nav、tabs、details、word picker combobox/listbox、自定义 select 与全部动作沿 M002 键盘模型。
- 最小交互目标 44×44px；focus 使用 M002 可见轮廓，不以颜色单独表达 invalid/selected/pending。
- `#planning-preview` 有标题；`.plan-item` 保持文档顺序。正文不逐片朗读；简短 `.draft-status` 使用 polite。失败、冲突、非法输入用 `role=alert/status` 与文本说明。
- locale 与 meaning language 分离；正文/词条 `lang=en`，释义保留 request meaning language。动态缺值用 “—”，不制造词义或内部解释。

## 动效与阅读位置

书写点是唯一新增循环动效；`prefers-reduced-motion: reduce` 时完全停止。每帧只改正文 textContent/状态，不重建设置、Plan 或页面，不重置 focus。用户主动滚动后不跟随尾部；首次点击生成可带入结果区域一次。

## UI09-R1 间距补充

- create 的 paper 桌面 padding 为 26px / 22–42px / 30px；移动为 20px 16px 24px。draft 与 final 共用同一左边界，正文最大 760px。
- Plan 卡桌面两列、≤760px 单列；plans 服务桌面先显示右列启用开关，再让基础预算与 N 同行；移动端恢复基础预算→开关→N 的自然单列顺序。badge 不拆字。
- preset radio 与两行说明顶部对齐；icon-label 固定 7px gap；动作允许换行但保持 44px 目标。

## UI09-R1 有限验证

已实看 UI09-R1 的 1440 create/plans/presets、390 create/plans/presets；390 横溢为 0。创建页正常按钮真实回放覆盖 Plan→正文→valid；Plan 与正文并存截图和 final 清理已记录。计划 0/99 有效、100 非法禁保存；两 preview 自动到 valid/可发布。生产 Vue、真实 API/DB/model、320 与 768 的最终实现由 frontend-bob 接收时复核；这些未验证项不被原型截图替代。
