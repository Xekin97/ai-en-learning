---
milestone: M003
version: M003-UI-08
agent_name: designer-tony
status: awaiting_user_review
date: 2026-10-10
input_version: M003-PRODUCT-07 / M003-BE-05-R1 / M003-DB-03 / M003-FE-01
baseline: M003-UI-07-R1 accepted by USER-M003-FORMAL-DESIGN
---

# M003-UI-08 正式设计规格

## 交付定位

UI08 把用户已确认的 UI07-R1 原型收敛为可实施的正式设计来源。视觉方向、三张完整页面、Plan 与正文同时保留至权威 valid、正文 splice 更新、管理配置和预设资格均不改业务含义。本版补齐区域定位、固定文案真源、动态数据边界、Token/资源、状态与中断、响应式/键盘/动效以及前端还原检查依据。它不是把原型 JavaScript 指定为生产架构。

- 已确认基线：`USER-M003-FORMAL-DESIGN` 确认 UI07-R1 视觉/交互，冻结包 SHA-256 `a5c13ab895754a70b89f6427218ba02ec3e61c36b14c40677fc41620158eb142`。
- 当前正式原件：本文件、`copy.json`、`theme.css`、`prototype/`、`interactions.md`、`responsive-accessibility.md` 与 `handoffs/uiux.md`，版本统一为 `M003-UI-08`。
- 业务来源：PRODUCT07 的 PAGE-204/208/212/216、CAP-301–305、DATA-301–305、AC-301–316；BE05-R1/API-302/API-304/DB03 只作行为与数据来源，不在本文件复制第二套协议。
- 视觉来源：`../../M002/design/theme.css`；UI08 只增加 M003 状态色、布局、44px 目标、流式正文和后台页面规则。
- FE01 仍是旧设计输入。UI08 只给出差异与接收条件，由 frontend-bob 后续更新架构；本角色不改 FE01 或业务源码。

## 评审入口

以下为本地正式设计预览。`view=formal` 隐藏原型场景和样例标记，页面仍由本地 adapter 回放 fixture，不能当生产实现或真实时延证据。

| 页面 | 正式预览 | 生产入口 | 当前评审状态 |
|---|---|---|---|
| PAGE-204 造文 | `?view=formal&rev=ui08&page=create&scenario=rewrite-once&event=0&status=0&lang=zh` | `/create` | 正常按钮一键生成；Plan 在上、正文在下 |
| PAGE-208 计划管理 | `?view=formal&rev=ui08&page=plans&plan=pro&limit=1&adminState=edit&lang=zh` | `/admin/plans` | 完整原字段、两类服务、影响预览与冲突 |
| PAGE-212 预设管理 | `?view=formal&rev=ui08&page=presets&mode=enhanced&event=0&status=0&lang=zh` | `/admin/presets` | 完整编辑器、两模式预览、资格与发布 |
| PAGE-216 首页体验 | PAGE-204 的 `scenario=basic` 作为生成结果视觉代表 | `/trial/:presetId` | 复用生成结果/Plan/正文状态；入口与预设数据由应用提供 |

完整 URL 前缀为 `http://127.0.0.1:4174/M003/design/prototype/`。英文将 `lang=zh` 改为 `lang=en`；释义语言仍取 request，不随 UI locale 改写。

## 正式来源与演示边界

| 类别 | 正式产品来源 | UI08 演示 adapter | 禁止进入生产的演示细节 |
|---|---|---|---|
| 选词、模型、额度、用户、计划、预设 | 当前用户/词库/模型/权益/计划/预设接口和路由状态 | `prototype/fixtures.json` 与 v5 fixture `request` | Xiao、7/2、Model A/B/C、3 个示例词、样例预设名 |
| 生成/预览事件 | API-302/API-304 的当前 run 与有限 status | exact `technical/fixtures/stream-v5/wire[]` | fixture 名、`event/status` URL、手动 step、样例匹配禁用 |
| 片段节奏 | 网络到达即应用；不得伪造百分比 | `playback[i].after_ms` 合成回放 | timer 数值、演示用速度或性能结论 |
| 终态与资格 | BE05-R1/DB03 权威 Result、current draft/mode/run | fixture 的 valid/Q02/status response | `qualified/stale/confirmed/published/adminState/remote` query 模拟，以及 `plans.conflictDemo` 人工造冲突按钮 |
| 固定 UI 文案 | `copy.json` | 同一文件直接 fetch | app 内另写一套 zh/en 固定文案 |
| 动态正文/义项/模型名 | request、wire、Result、模型/词库数据 | fixture payload，逐值 HTML escape | 把 AI 文本或模型名搬入固定 copy |

正式预览通过 `view=formal` 只隐藏演示层，仍保留 adapter 以便审阅；生产应用不识别 `view/rev/scenario/event/status/demo/words/qualified/stale/confirmed/published/adminState/remote` 这些演示参数。

## 页面区域合同

文案键写基础名，运行时只能从 `copy.json` 取 `.zh` 或 `.en`；动态数据列出的字段不可替换为固定示例。

### PAGE-204 / PAGE-216

| 顺序 | 区域与稳定定位 | 固定 copy keys | 动态数据 / 资源 | 状态与可观察结果 |
|---|---|---|---|---|
| 1 | 顶栏 `.topbar`、`.brand`、`.nav`、`.quota-mini` | `brand`, `common.skip`, `common.primaryNavLabel`, `nav.home`, `nav.picks`, `nav.create`, `nav.review`, `nav.library`, `common.languageToEnglish`, `common.languageToChinese`, `create.quotaSummary` | session user/avatar、quota；图标来自 `icon()` 的 code-native glyph，品牌 `≈` 为装饰 | skip 常态离屏；键盘 focus 时出现；当前页 `aria-current=page` |
| 2 | 页头 `.page-head` | `common.eyebrow`, `create.title`, `create.intro`, `create.quotaSummary` | `{section}`、quota `{remaining}/{extra}` | 标题与额度不因流事件重建 |
| 3 | 生成配置 `#create-settings` | `create.settings`, `common.required`, `create.model`, `create.style`, `create.story`, `common.dialogue`, `create.length`, `create.short`, `common.medium`, `create.meaning`, `create.chinese`, `common.english`, `common.japanese` | model list、request meaning language | run active 时冻结会改变请求的控件；失败/取消/重来后恢复 |
| 4 | 选词 `#word-picker` | `create.words`, `create.search`, `create.searchHint`, `common.selectionCount`, `common.addWord`, `common.removeWord`, `common.wordsEmpty` | vocabulary results、selected entries、最大数 | 数量由数据决定，不固定 2/3/8；无选择时显示空态，超限由应用校验 |
| 5 | 结果外壳 `#generation-status`、`.result-head` | `create.resultTitle`, `stream.state.*` 对应已定义 lifecycle key | run state | 外壳 DOM 稳定；started 前不得显示已受理 |
| 6 | Plan `#planning-preview`、`.plan-item[data-plan-kind]` | `stream.planLabel`, `stream.planTitle`, `stream.planNote`, `stream.planScene` | `plan_item` 公开 allowlist：scene text 或 entry/form/sense/phrase | 收到即追加；首正文、换稿、pending/EOF/finalizing 保留；完整 valid/失败/取消/新请求清除 |
| 7 | 临时正文 `#live-draft .live-draft-text` | `stream.draftLabel`, `stream.draftTitle`, `stream.draftBody`, `stream.finalizingBody`, `stream.eofBody`, `stream.protocolBody`, `stage.pending.*`, `action.recheck` | generation.edit / preview.edit splice 文本 | 只更新正文 text/status；不可保存、无高亮/释义/hint；新稿首片前保留旧稿 |
| 8 | 最终结果 `#final-result` | `stream.complete`, `create.storyHeading`, `create.resources`, `stream.completeBody`, `stream.incomplete` | valid Result passage/tags/targets/occurrences | 整包一次替换，清 Plan，按 Unicode 码点高亮并启用保存；Q02 notice 持续 |
| 9 | 动作 `#generation-actions` | `create.generate`, `action.cancel`, `action.retry`, `action.save`, `action.discard`, `create.saved` | canSave / saved | pending/草稿禁保存；失败/取消显示重试；valid 才显示保存 |

PAGE-216 复用 5–9 的状态与视觉合同。其预设信息、登录态和体验额度取产品入口数据，不继承 adapter 示例用户或 query。

### PAGE-208

| 顺序 | 区域与稳定定位 | 固定 copy keys | 动态数据 / 资源 | 状态与可观察结果 |
|---|---|---|---|---|
| 1 | 管理导航 `.admin-nav-m003`、页头 `.page-head` | `brand`, `admin.label`, `admin.*`, `common.skip`, `common.signOut`, `common.eyebrow`, `plans.title`, `plans.intro` | 当前管理员与权限 | 当前项 `aria-current=page`；窄屏横向局部滚动 |
| 2 | 计划 tabs `#plan-tabs` | `plans.review.off`, `plans.review.on` | plan code/name/current limit | 当前计划高亮；名称来自计划数据 |
| 3 | 原字段 `#plan-existing-settings` | `plans.existing.title`, `plans.originalKept`, `common.priority`, `plans.models`, `plans.lengths`, `plans.priority`, `plans.words`, `plans.daily`, `plans.unlimited`, `create.short`, `common.medium`, `common.long` | model/length/priority/quota values | 与现有完整页面同表单提交边界 |
| 4 | 服务配置 `#service-settings`、`#basic-correction-policy`、`#content-service` | `plans.service.title`, `plans.audience.all`, `plans.audience.paid`, `plans.audience.standard`, `plans.base.*`, `plans.review.*`, `plans.sameModel`, `common.readOnly` | plan entitlement、N 0–99 | 基础预算 2 只读；内容 N 为整数，非法保留原值并 `aria-invalid=true` |
| 5 | 动作 `#plan-actions` | `plans.preview` | form validity | 非法输入禁用预览；预览不调用模型 |
| 6 | 影响 `#change-preview` | `plans.preview.title`, `plans.current`, `plans.after`, `plans.disable.warning`, `plans.impact`, `plans.effect.*`, `plans.cancel`, `plans.save` | latest/local values、affected counts | 保存前显示新旧与影响；0 的业务含义清楚；99 不显示测试说明 |
| 7 | 冲突/保存 `#version-conflict` / `#save-result` | `plans.conflict.*`, `plans.latest`, `plans.local`, `plans.recheck`, `plans.saved` | revision / reread value | 冲突无部分保存；以新 revision 重预览 |

### PAGE-212

| 顺序 | 区域与稳定定位 | 固定 copy keys | 动态数据 / 资源 | 状态与可观察结果 |
|---|---|---|---|---|
| 1 | 管理导航与页头 | 与 PAGE-208 顶栏相同；`preset.title`, `preset.intro`, `common.new` | admin/session | 完整后台外壳保持 |
| 2 | 列表 `#preset-list` | `preset.list`, `preset.edited`, `preset.published` | preset title/status | 标题来自预设数据，不写入 copy |
| 3 | 编辑器 `#preset-editor`、`#preset-settings` | `preset.name`, `preset.nameHint`, `preset.words`, `preset.settings` 及 PAGE-204 配置键 | draft fields、model/entries/meaning language | 保存草稿与预览资格分离 |
| 4 | 模式 `#preview-mode` | `preset.mode`, `preset.mode.base`, `preset.mode.enhanced`, `preset.mode.note`, `preset.mode.limit`, `benefit.base.body`, `benefit.enhanced.body` | preview mode | basic0/enhanced1；不读取管理员计划档 |
| 5 | 动作 `#preset-actions` | `common.saveDraft`, `preset.generate`, `preset.publish`, `preset.publishConfirm`, `preset.usage` | draft dirty、current run qualification、usage | publish 默认禁用；Q02 需确认且仍由用户主动发布 |
| 6 | 预览 `#preview-result` | PAGE-204 Plan/正文/结果键，以及 `preset.resultReady`, `preset.qualificationPending`, `preset.ready`, `preset.incomplete`, `preset.stale`, `preset.pendingPublish` | preview namespace wire、current draft_version/mode/run/status | basic/enhanced 各走自身 wire；完整 valid 后还需资格核对；stale/pending/failed/cancelled 禁发布 |

## 文案与数据格式

`copy.json` 是固定界面文案唯一来源，顶层 `static` 与 `templates` 均提供 `.zh/.en`。UI08 原型实际 fetch 同一文件；字面 key 检查为 0 missing。模板与变量如下：

| 模板 | 变量 | 规则 |
|---|---|---|
| `common.eyebrow` | `section` | 取对应页面固定标题 |
| `common.selectionCount` | `selected`, `maximum` | 都取当前数据；不固定 2/3/8 |
| `common.addWord` / `common.removeWord` | `word` | 仅用于可访问名称，word 取词库数据 |
| `create.quotaSummary` | `remaining`, `extra` | 取权益快照；未知值显示 `—`，不能据此开放操作 |
| `benefit.plan` | `plan` | plan 名来自数据 |
| `benefit.enhanced.body`, `plans.review.on` | `limit` | 当前配置整数；用户生成页不展示 N/轮次 |
| `plans.impact` | `basic`, `trial` | 取影响预览响应 |
| `preset.usage` | `count` | 后台预览用量 |

模板缺失变量统一渲染 `—`。必填输入缺失使用字段校验，不用 `—`；可选动态行缺失时整行省略；模型/权限/终态等决定动作的数据缺失时保持动作禁用并显示现有错误/待核对状态。AI 正文、Plan 内容、释义、模型名、计划名、预设名、用户与额度都不是固定 copy。结构性 `01/02/03`、`≈`、`Aa`、箭头和对勾为装饰或顺序标识，必须 `aria-hidden` 或由相邻文字给出名称。

## 样式 Token 与资源

| 用途 | 真源 / selector | 正式值或规则 |
|---|---|---|
| 品牌基础 | `M002/design/theme.css :root` | `--canvas #f8f6ef`, `--paper #fffef9`, `--ink #193d36`, `--green #21654e`, `--focus #266ea1`, `--radius 22px`, `--container 1440px` |
| M003 状态 | `M003/design/theme.css :root` | `--review-wash #eef3e4`, `--pending-wash #f7edd0`, `--conflict-wash #fff0e2`, `--target-min 44px`, `--motion-writing 1200ms` |
| 字体 | M002 `--ui`, `--reading`, `--mono` | 系统字体栈；不加载远程字体 |
| 动效 | M002 `--fast 140ms`, `--motion 240ms`, `--ease`; UI08 `--motion-writing` | 仅开关、结果淡入、书写点和 spinner；reduced-motion 归零 |
| 图标 | `prototype/app.js icon()`、`.ui-icon`; `.brand-mark`, `.empty-glyph` | code-native glyph，无外部图片/SVG/Figma 依赖；实现可映射现有 `AppIcon.vue`，语义不由 glyph 单独承担 |
| 阅读区 | `.story-text`, `.live-draft-text`, `.plan-use`, `.resource-card` | 正文最大宽 760px；长词 `overflow-wrap:anywhere`；临时正文无 mark/资源 |
| 焦点 | M002 `:focus-visible`, `.skip-link`, `.switch`, `.mode-option` | 3px `--focus`，offset 3–4px；不得仅以颜色表达错误或选择 |

允许还原容差：颜色必须直接使用 Token；布局断点与最小目标不可漂移；容器/间距/圆角可在相邻 Token 级别内调整（±2px），正文行高可 ±0.05，字体大小可 ±1px。不得用逐像素截图替代状态与可访问性检查。

## UIA-M003-401–411 正式验收映射

| ID | 来源 | 正式设计行为 | 可观察结果 | 检查方式 / 容差 | FE01 差异 |
|---|---|---|---|---|---|
| UIA-M003-401.a | PAGE-204, CAP-301, DATA-301/305 | 完整导航、配置、选词、额度、结果与保存外壳；UI locale 与 meaning language 分离 | `#create-settings/#word-picker/#generation-status` 同页存在 | DOM + zh/en 目视；顺序固定 | FE3-03/07 需接新区域合同 |
| UIA-M003-402.a | CAP-301/302, AC-308/315/316 | started 才受理；Plan 条目按 wire 追加且在正文上方持续 | Plan 先出现；首 edit 后仍在 | 正常按钮实点；不可用 URL 直接跳过 | FE3-03/04/07 新增 plan projection |
| UIA-M003-403.a | DATA-304, AC-308/309 | 码点 splice、相邻重复 NOOP、seq/rev/range/draft/version 异常停止并有限核对 | 🌱 后高亮正确；异常不继续污染 | reducer 单元/集成；正文须等于 Result | FE3-03/04/09 替换旧流处理 |
| UIA-M003-404.a | CAP-302, AC-308/312/316 | 新稿首片前保留旧文；正文局部更新，不重建 Plan/配置/外壳 | 可见删尾/替换；焦点与 scroll 保持 | 节点 identity + scroll 差≤2px | FE3-04/07 需稳定组件边界 |
| UIA-M003-405.a | PAGE-204/216, DATA-303–305, AC-306/309/315 | 完整 valid Result 才原子建立正文、高亮、tags、targets 与 save | valid 前无正式资源/save；final 一次建立 | 状态集成 + Unicode occurrence | FE3-04/06/07 接 DB 权威终态 |
| UIA-M003-406.a | AC-306/313/316 | pending/EOF/retained 保留只读 Plan+稿；fail/cancel/new 清；Q02 valid 可存且 notice 持续 | 各清理/保留边界准确 | 针对状态用例；有限 status 次数取 API | FE3-04/06/07/09 补异常边界 |
| UIA-M003-407.a | PAGE-208, CAP-303, AC-301–305/310/311/314 | 完整原字段；基础预算 2 只读；内容整数 0–99；影响与冲突 | 非法值原样、aria-invalid、禁预览；0/99 可表达 | 表单边界 + revision 冲突 | FE3-08 接正式布局/copy |
| UIA-M003-408.a | PAGE-212, CAP-304/305, AC-307/309/314–316 | basic/enhanced 各走自身 preview；Plan/正文/结果同显示政策 | basic 真实规划首稿；enhanced 另有 fixed edit | namespace 集成；不得互借 fixture | FE3-06/09 接两模式状态 |
| UIA-M003-409.a | PAGE-212, AC-307/309/313/314 | current draft_version/mode/run/status 才 ready；Q02 需确认后手动发布 | stale/pending/failed/cancel 禁用发布 | 资格组合测试 | FE3-06/09 不复用 learner canSave |
| UIA-M003-410.a | AC-308/312 | 每片仅更新稳定正文与简洁状态；不抢焦点/滚动，不把正文设 live region | 配置节点、Plan 节点、focus、scroll 稳定 | 节点 identity；正文变化记录；scroll ±2px | FE3-07/09 组件更新策略 |
| UIA-M003-411.a | PAGE-204/208/212, CAP-301–305 | 1101+/901–1100/761–900/≤760/≤360；320/768；44px；键盘；reduced motion | 无页面横溢、长词换行、skip 可用、动效归零 | Chromium 320/768 + 实施期 axe/多浏览器 | FE3-07–09/V11/12 补实现验证 |

## 验证结果与边界

UI08 限定 Chromium 检查最终 8/8 PASS、0 page/console error：320 长场景/义项/短语与正文、正式预览隐藏 demo、skip 键盘焦点、44px 命中区、reduced-motion、320 最终长阅读、768 英文计划、768 中文预设，以及固定 copy 字面 key 0 missing。代表截图已实际查看。自动检查首轮 skip-link 导航造成执行上下文重载，修复为显式聚焦 `#main`；随后 reduced-motion 的 `0.01ms` 浏览器序列化为 `1e-05s`，仅修正断言。自动 8/8 后目视发现 768 预设编辑器过窄，新增 `max-width:900px` 管理页堆叠并定向复验，首轮截图与报告保留。

UI07-R1 已验证的 v5 正常点击、Plan 保留、61 次正文变化、终态与 390 视觉仍适用于未改业务交互；UI08 不重跑 15-wire 矩阵。未验证生产 API/DB/模型、真实时延/费用、前端构建、权限、Safari/Firefox、完整读屏、200% 缩放、axe 或 UAT3302。正式设计预览通过不代表应用实现通过。
