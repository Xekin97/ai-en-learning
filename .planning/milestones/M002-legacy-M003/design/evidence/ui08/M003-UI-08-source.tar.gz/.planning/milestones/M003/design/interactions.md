---
milestone: M003
version: M003-UI-08
agent_name: designer-tony
date: 2026-10-10
---

# UI08 正式交互与状态

## 产品交互入口

生产入口由应用路由提供：PAGE-204 `/create`、PAGE-208 `/admin/plans`、PAGE-212 `/admin/presets`、PAGE-216 `/trial/:presetId`。用户按正常按钮触发请求；不要求展开演示控制，不读取 fixture 名、事件序号或合成计时参数。UI 事件/Result/资格的字段与终态只引用 BE05-R1、API-302/API-304 和 DB03。

## PAGE-204 / PAGE-216 生成

1. **编辑输入**：模型、场景、长度、释义语言与所选词来自应用状态。用户修改后保留键盘焦点；必填/上限错误在字段附近显示。启动前保存该请求快照。
2. **启动**：点击 `#generation-actions [data-action=generate]` 后清理旧临时 Plan/草稿/notice，建立新 request generation；只在收到 started 后显示“请求已受理”。第一次状态进入结果区视野，之后不抢焦点或滚底。
3. **规划**：planning/plan_item 依次建立 `#planning-preview`。只展示公开 scene 与每个 request entry 的 form/sense/phrase；不显示 plan_id、私有 facts/beats/review、seq/rev/version/调用/预算。提示始终说明它是初始构思，正文和实际用法可能调整。
4. **临时正文**：首个 edit 在 Plan 下方建立一次 `#live-draft`。之后按 Unicode 码点 splice 更新 `.live-draft-text`；临时稿只读、无正式高亮/tags/targets/save。新 draft 到来前保留旧全文，首片到来才执行删尾/替换。
5. **等待与编辑**：fixed edit、条件修稿、retained、finalizing、pending、EOF 全程保留已收到的 Plan 与正文。Plan 不随正文编辑刷新，不触发额外模型调用。`.draft-status[aria-live=polite]` 只朗读简短状态，正文不设 live region。
6. **成功**：validated 或有限 status valid 必须带完整权威 Result。`#final-result` 一次替换临时稿，清 Plan，建立 passage/tags/targets/occurrence 高亮并启用保存。Q02 的 `content_review_incomplete` notice 随保存持续，不写成质量通过。
7. **未决**：pending/EOF/协议异常保留只读 Plan/草稿，禁保存，只提供有限“重新核对”。status 次数由 API 响应决定，不无限轮询。valid 无完整 Result 不清临时视图，也不启用保存。
8. **失败/取消**：planning failure、无有效稿 failure、cancel 清 Plan/半稿并禁保存。取消按钮发出当前 run 取消并立即隔离旧 generation；服务端晚帧不得污染新请求。
9. **重试/新请求/导航**：retry/restart 创建新 generation。取消、重启、切页、路由返回、pagehide 都使旧代次失效；旧 draft_id 不能复用。返回页面时从服务端状态重建，不从演示 query 恢复。
10. **保存**：只在 DB 权威 canSave 条件满足时显示。保存中的按钮防重复提交；成功后显示 `create.saved`，失败保持完整结果并给出可重试错误，不重新调用模型。

## reducer 与视图更新约束

- 相邻完全重复事件为 NOOP；seq 不连续、rev/base_rev 不匹配、码点越界、旧 draft 复用或 namespace 不符停止消费并进入有限核对。
- 正文 splice 和 occurrence 都按 Unicode 码点；不能直接用 JS UTF-16 `length/slice`。🌱 之后的目标词仍须准确高亮。
- `#generation-status`、`#create-settings`、`#planning-preview`、`#live-draft` 在各自生命周期中保持节点 identity。正文片只写 textContent 和简洁状态；不重建整页。
- 用户主动滚动离开结果区域后不自动拉回；每片前后 `scrollY` 允许渲染取整误差 ±2px。控件 focus 不因事件变化移动。

## PAGE-208 计划管理

- 切换 `#plan-tabs` 读取对应最新 revision。原模型、长度、优先级、选词上限、滚动额度和不限开关仍在同一保存边界。
- 基础纠错为所有计划全请求最多 2 次的只读系统策略。内容服务 visitor/basic 固定 0；付费计划输入整数 0–99，0 关闭整个内容审校，1–99 开启。
- 空、负数、小数或 100 保留用户原输入，设 `aria-invalid=true`，显示 `plans.review.invalid` 并禁用“预览差异”。开关与数值保持同步。
- “预览差异”只展示本地新旧值和影响，不调用模型。确认保存使用当前 revision；冲突无部分保存，保留本地值并显示服务端最新值，用户重新预览后再保存。

## PAGE-212 预设管理

- 保存草稿、生成预览、发布是三个独立动作。改变 draft 字段或 preview mode 会使旧资格 stale。
- basic/enhanced 分别请求自身 preview namespace；Plan/正文/Result 的显示生命周期与 PAGE-204 相同。preview 不读取学习者额度，也不复用用户 canSave。
- validated 后仍以 current `draft_version + preview_content_mode + preview_run_id` 读取有限 status；全部匹配且 valid 才启用发布。
- Q02 显示 `preset.incomplete`，必须勾选 `#publish-confirm`，随后仍由管理员主动点击发布。stale/pending/failed/cancelled/关联不符均禁用。
- 发布失败保留当前完整预览和确认状态，给出错误并允许重试；不得自动重跑模型。

## 键盘、焦点与动效

- DOM 顺序跟视觉顺序一致。首个 Tab 聚焦 `.skip-link`；激活后显式聚焦 `#main`，避免 hash 导航重载。结果/预览/冲突标题用 `tabindex=-1` 仅在用户触发对应动作后编程聚焦。
- 按钮、链接、输入或其关联 label 命中区至少 44×44px。switch/radio 保留原生 input；焦点环不得被 sticky/overflow 裁掉。
- 动效只用于状态辨识：书写点 1200ms、spinner 800ms、结果淡入 240ms、基础 hover/开关 140ms。`prefers-reduced-motion: reduce` 将动画/过渡缩至 0.01ms，滚动为 auto；事件和资格不变。
- 失败使用 alert；pending/成功/简短草稿状态使用 status/polite。正文与逐条 Plan 内容不逐片全文朗读。

## 演示 adapter

`prototype/app.js` 仅为可运行设计预览：exact v5 `wire[]` 驱动 reducer，`playback.after_ms` 只合成节奏，`replaceState` 避免每帧堆 history；折叠 scenario player 仅在非 formal view 出现。生产实现删除 fixture fetch、自动 timer、手动 step、query 状态和输入匹配禁用，保留上述产品交互合同。
