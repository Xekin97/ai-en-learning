---
milestone: M003
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
version: M003-UI-08
date: 2026-10-10
input_version: M003-PRODUCT-07 / M003-BE-05-R1 / M003-DB-03 / M003-FE-01
baseline: M003-UI-07-R1 accepted by USER-M003-FORMAL-DESIGN
---

# M003 UI08 正式设计交接

## 交付结论

UI07-R1 的视觉/交互已经用户确认，本交接不要求重复批准同一原型。UI08 已完成其后的正式设计落地：三页区域和顺序、固定文案真源、动态数据边界、Token/资源、完整状态与中断、响应式/键盘/动效、UIA-401–411 可观察验收和 FE01 接收条件已写入原件。当前仍是 `uiux-design / designer-tony`，等待核对正式设计交付，不自动切角色或启动实现。

## 可直接打开的正式设计预览

- 造文：`http://127.0.0.1:4174/M003/design/prototype/?view=formal&rev=ui08&page=create&scenario=rewrite-once&event=0&status=0&lang=zh`
- 计划管理：`http://127.0.0.1:4174/M003/design/prototype/?view=formal&rev=ui08&page=plans&plan=pro&limit=1&adminState=edit&lang=zh`
- 预设管理：`http://127.0.0.1:4174/M003/design/prototype/?view=formal&rev=ui08&page=presets&mode=enhanced&event=0&status=0&lang=zh`

`view=formal` 隐藏原型场景、fixture 标记和人工造冲突动作。正常按钮仍由本地 adapter 回放 exact v5 fixture，便于查看已确认交互；合成 timer、query 状态、fixture 输入匹配和手动 step 都不进入生产。生产入口仍为 `/create`、`/admin/plans`、`/admin/presets` 与 `/trial/:presetId`。

## 本轮实际改动

- `design-spec.md` 从事件概述改为 PAGE-204/208/212/216 区域级合同：准确 selector、元素顺序、copy key、动态来源、状态入口、可观察结果、检查方式与合理容差；保留 UIA-M003-401–411 并增加 `.a` 正式验收项。
- `copy.json` 补齐 skip、导航、语言切换、退出、必填、空选词、语言/长度/场景、后台服务等固定中英文；quota、选词数、add/remove、eyebrow 改为模板；保存/发布去除“原型演示”产品文案。原型实际 fetch 同一 copy，字面 key 0 missing。
- `prototype/fixtures.json` 只承载演示用户、额度、模型、上限、词库候选和样例预设名；2/3 词、Model A、Xiao、7/2 不再写成正式设计约束。AI 文本与模型/计划/预设名称继续是动态数据。
- `theme.css` 增加 `--target-min`、`--motion-writing`，候选/chip remove/brand/nav/switch/label 达到 44px，长 Plan 内容可断词；新增 900px 管理布局，解决 768px 预设编辑器过窄。
- `prototype/app.js` 增加稳定区域 ID、formal view、模板缺值 `—`、显式 skip 聚焦；正式影响预览移除人工“Show remote conflict”。Plan/正文/Result 的已确认 reducer 行为未改。
- `interactions.md` 定义产品触发、取消与代次隔离、pending/EOF/Q02、保存、预设资格、焦点/滚动/朗读；将 fixture/timer/query 单独标成 demo adapter。
- `responsive-accessibility.md` 定义 ≥1101、901–1100、761–900、≤760、≤360，含 320/768、长内容、44px、键盘、reduced motion 和验收边界。

## 正式原件与恢复

- [正式设计规格](../design/design-spec.md)
- [固定文案真源](../design/copy.json)
- [Token 与样式](../design/theme.css)
- [可运行正式预览](../design/prototype/index.html)、[交互参考](../design/prototype/app.js)、[演示数据 adapter](../design/prototype/fixtures.json)
- [交互与状态](../design/interactions.md)
- [响应式与可访问性](../design/responsive-accessibility.md)
- [UI08 有限验证报告](../design/evidence/ui08/M003-UI-08-formal-browser.json)与[人类可读说明](../design/evidence/ui08/M003-UI-08-verification.md)
- [UI08 待审源码快照](../design/evidence/ui08/M003-UI-08-source.tar.gz)与[hash 清单](../design/evidence/ui08/M003-UI-08-source-manifest.json)

UI07-R1 冻结包及所有旧 evidence 未改。UI08 包包含当前正式设计原件、交接、M002 主题、BE05-R1 display policy、API 参考和完整只读 v5 index/15 wire/packages；排除 evidence，避免递归。它是可恢复待审提交，不是批准或应用实现。

## 有限验证与问题分类

最终 Chromium 8/8 PASS、0 page/console error，覆盖 320 长 Plan/正文/终态、44px、skip 键盘、reduced motion、768 英文计划、768 中文预设、formal demo 隐藏和 copy key。四张最终代表截图已实际查看。

- 首轮 0/1：skip link 激活触发页面重载，是实际键盘行为缺陷；已改显式聚焦 main 后通过。
- 中轮 7/8：`0.01ms` 被浏览器序列化为 `1e-05s`，是检查断言问题；只修断言。
- 自动 8/8 后目视发现 768 预设编辑器过窄，是实际布局缺陷；900px 堆叠修复并定向复验，首轮截图/报告保留。
- root 指出的 “Show remote conflict” 属于演示控制；formal view 已移除，真实产品冲突只由 revision 冲突触发。

UI07-R1 的 exact v5 正常点击、Plan 持续、61 次正文变化、终态与 390 证据仍有效，未重复全矩阵。未验证真实应用/API/DB/模型、生产时延/费用、权限、构建、axe、完整读屏、200% 缩放、Safari/Firefox 或 UAT3302。

## frontend-bob 接收完成条件

1. 以 `design-spec.md` 的 PAGE 区域表和 UIA-M003-401.a–411.a 为 UI 真源；FE01 旧流式/状态设计需重新对齐，不得把 prototype DOM/JS 直接复制为架构。
2. `/create` 与 `/trial/:presetId` 使用稳定 Plan/草稿/Result 组件；BE05-R1 公开 Plan 在草稿/编辑/pending/EOF/finalizing 保留，完整 valid Result/failed/cancel/new request 才按规则清理。
3. 实施 Unicode 码点 splice/occurrence、seq/rev/range/draft/version/generation 隔离；每片保持设置、Plan、focus 和用户 scroll，正文不设 live region。
4. 所有固定 UI 文案从统一 copy 层映射 UI08 keys；模型、用户、额度、词数、计划/预设名称与 AI 内容取真实数据。模板缺值/必填/可选行按规格处理。
5. PAGE-208 保留原字段、基础 2 只读、内容 0–99、影响/冲突；PAGE-212 分离 basic/enhanced preview namespace 与 current draft/mode/run 发布资格，Q02 需确认且手动发布。
6. 使用 M002+UI08 Token 和断点，实际应用检查 320/768/桌面、44px、键盘 skip/focus、reduced motion、长内容、zh/en；补构建、axe/读屏、200% 和目标浏览器证据。
7. 生产删除 fixture fetch、playback timer、scenario player、测试 query 和人工冲突按钮；接真实 API 之后核对取消/断连/结算/DB 竞争与权限。

## 状态

已确认范围：UI07-R1 原型视觉/交互基线。  
已完成范围：UI08 正式设计交付原件与有限设计验证。  
未验证范围：真实应用实现、前端架构更新、生产 API/DB/模型和 UAT。

**BLOCKED：无。新增业务待决：无；CR-302 保持 `product_resolved_downstream_pending`，待 FE/实施等接续。** 当前为 `awaiting_user_review`；不自行切到 technical-design 或 frontend implementation。
