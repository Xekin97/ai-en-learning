---
milestone: M003
version: M003-UI-08
agent_name: designer-tony
date: 2026-10-10
---

# UI08 响应式与可访问性

## 断点与布局

| CSS 范围 | PAGE-204 / PAGE-216 | PAGE-208 / PAGE-212 |
|---|---|---|
| ≥1101px | 配置/结果 `minmax(320,.78fr) / minmax(480,1.22fr)` 双栏；配置 sticky | 190px 管理导航 + 内容；计划两服务卡；预设 250px 列表 + 编辑器 |
| 901–1100px | 单列；配置取消 sticky；Plan/正文保持上下顺序 | 管理导航 150px + 内容；计划与原字段按可用宽度降列 |
| 761–900px（含 768） | 单列，仍保留桌面顶栏；正文最大 760px | 管理导航改顶部横向局部滚动；预设列表两列后编辑器全宽；避免 768 三列挤压 |
| ≤760px | 顶栏换行、主导航局部横滚；配置、Plan 词卡、资源单列；动作换行/吸底 | 管理导航/tabs/预设列表局部横滚；表单、服务卡、模式、预览单列 |
| ≤360px（含 320） | 容器边距 10px；语言按钮 44px；长 scene/sense/phrase/正文任意断词不产生页面横溢 | 数字、错误、动作和资格提示完整换行；不缩小命中区 |

Plan 在上、正文在下是所有宽度的固定信息顺序。内容增长允许页面变长；事件更新不得强制滚动。横向滚动只允许 `.nav`、`.admin-nav-m003`、`#plan-tabs` 和窄屏预设列表，并需要可见的下一项边缘；`documentElement.scrollWidth` 不得超过 clientWidth 1px 以上。

## 长内容与动态数据

- `.story-text` 使用 `white-space: pre-line`、`overflow-wrap:anywhere`，阅读宽度最大 760px；正文行高 1.85。
- `.plan-scene p`、`.plan-use h3/p/small` 与资源卡允许长词换行。entry/form/phrase 标 `lang=en`；sense 语言取 request meaning language。
- 标题、计划名、预设名最多按容器自然换行，不截断关键状态。列表紧凑位置可两行，完整名称在编辑器输入中可见。
- 字数、额度、用户数、N、模型名全部来自数据。未知模板变量显示 `—`；决定动作的数据未知时禁用动作。
- 浏览器缩放与系统字号增大时不以固定高度裁切 panel；sticky 区允许内容换行并回到文档流。

## 命中区与键盘

- `--target-min:44px`。`.btn`、候选词、chip 删除、品牌链接、移动导航、管理导航和 switch label 均至少 44px；checkbox/radio 以关联 label 的完整 44px+ 区域作为命中区。
- Tab 顺序：skip → 顶栏/导航 → 页面表单 → 主要动作 → 结果内必要动作 → footer。视觉重排不改变 DOM 顺序。
- `.skip-link` 常态移出画面，focus-visible 时落在左上且不覆盖权益/页头；激活显式聚焦 `#main`。
- 所有原生字段有可见 label；搜索的视觉隐藏 label 由 placeholder 与 help 补充。错误通过文字、`aria-invalid` 与颜色共同表达。
- switch/mode 的透明 input 保持键盘可操作；focus ring 3px `--focus`、offset 3–4px，不被 overflow 裁切。

## 朗读与状态

- `#planning-preview` 使用标题和 article 分组；`stream.planNote` 为简短 polite 状态。新增条目不把既有 Plan 整段重念。
- `.live-draft-text` 不设 live region；`.draft-status` 为 polite。failed 为 alert，pending/完成/保存为 status。
- 临时稿无 mark/tags/resources，避免把未定内容读成最终学习资料。valid 完整 Result 才建立 `<mark>` 与资源语义。
- 图标 glyph、`≈`、`Aa`、步骤号和箭头为装饰时 `aria-hidden=true`；按钮/链接必须有固定 copy 或模板化可访问名称。

## 运动、焦点与滚动

- 标准动效：hover/switch 140ms，结果替换 240ms，spinner 800ms，书写点 1200ms；不使用百分比进度或逐字光标。
- reduced motion 将动画和 transition 缩至 0.01ms，并关闭平滑滚动；不改变事件消费、结果或资格。
- 首次主动生成可将 `#generation-status` 带入视野；之后 Plan/正文局部更新不聚焦、不滚底。用户滚动位置变化容差为 ±2px。
- 新正文第一次出现只插入一次 `#live-draft`；后续写入 `.live-draft-text`。Plan、设置和外壳 DOM 保持，减少闪烁并保住选择/焦点。

## 本版验证

`evidence/ui08/M003-UI-08-formal-browser.json` 最终 8/8 PASS、0 浏览器错误。覆盖 320 长场景/义项/短语/正文、触控目标、skip 键盘焦点、reduced motion、最终长阅读、768 英文计划、768 中文预设及固定 copy key。代表截图 `01–04` 已实际查看。

自动检查最初暴露 skip 激活导致页面上下文重载，已改成显式聚焦 main；reduced-motion 一项仅为 CSS 时间序列化断言修正。自动通过后的首轮 768 截图仍显示预设编辑器过窄，已保留 `*-first-pass.png` 与 visual-first-pass 报告，新增 900px 管理堆叠后定向复验。UI07-R1 已通过的 v5 事件和 390 交互继续有效，本版未重复 15-wire 矩阵。

未验证：真实应用构建/API/DB/模型、axe、完整读屏、200% 缩放、Safari/Firefox、权限、生产时延或 UAT3302；这些属于实施接收，不影响正式设计源已定义。
