---
milestone: M003
version: M003-UI-12
agent_name: designer-tony
status: awaiting_design_submission_review
date: 2026-10-13
input_version: CR-310 / USER-M003-REGENERATE-CONFIRM-20261013
visual_baseline: M002 current effective formal design plus M003-UI-11
interaction_baseline: M003-UI-09-R3 plus CR-310
---

# M003-UI-12 / CR-310 完成后编辑与再次生成确认

## 当前目标、范围与追踪

`CONFIRMED / USER-M003-REGENERATE-CONFIRM-20261013`：普通造文与游客造文完成后，旧的未收录 Result 保持可见，用户可直接编辑下一次选词和配置；只有按现有“开始生成”时才显示永久放弃确认。取消保留旧 Result 和全部新输入；确认先放弃旧 Result，成功后才以新输入启动一次生成。预设试用继续只读。生成中、pending、保存中仍禁重复动作；离页保护继续按未收录结果判断，不能用配置 disabled 代替。

| 追踪 | 本轮设计结果 | 不变范围 |
|---|---|---|
| PAGE-204 / PAGE-216；CAP-302；现有 generation result/request targets | valid 未收录 Result 与下一次配置并存；Result 标题、正文、释义均来自完成时结果快照 | collect、游客 claim、已保存记录、真实生成与 pending 保护 |
| 现有 `AppDialog` / `discardGeneration` | 同一 Generate 按钮在有未收录 Result 时打开确认；无单独放弃按钮 | 现有后端 Discard 幂等语义；无新 BE/DB/API |
| DATA：当前未收录 story + learning information | 警告只描述这份当前未收录内容永久放弃 | 不删除或暗示删除 Library 历史 |

本节替代 UI11 及更早设计中“valid 等同 busy”“必须先点放弃结果”与 Result 标题读取 live `words` 的规则。UI11 词义列表、阅读列和其他视觉合同继续有效。整改前完整基线为 `reviews/evidence/cr310-design-entry-091/before.tar.gz`。

## 可运行原型与精确文案

仓库根目录运行 `python3 -m http.server 4176 --bind 127.0.0.1 --directory .planning/milestones`。原型只消费 `copy.json` 和既有合成 fixture，不调用 provider。

| 状态 | query / 操作 | 稳定定位 |
|---|---|---|
| 完成结果 + 下一次配置 | `?page=create&lang=zh&view=formal&scenario=rewrite-once&event=74&status=0&style=discussion&rev=ui12` | `#final-result`、`#create-settings`、`#generate` |
| 再次生成确认 | 上述页面点击 `#generate` | `#regenerate-confirm:modal` |
| EN / mobile | `lang=en`，390×844，点击同一按钮 | 同上 |
| 放弃失败 | 上述 query 增加 `discardFailure=1`，确认 | `.m003-regenerate-error[role=alert]`，Result 与输入保持 |

固定文案仅在 `copy.json` 维护，原型实际读取同一键：标题“生成新的短文？” / “Generate a new story?”；正文“继续生成会永久放弃当前未收录的短文和学习信息。” / “Continuing will permanently discard the current unsaved story and its learning information.”；取消“取消” / “Cancel”；确认“放弃并生成” / “Discard and generate”。确认后不承诺恢复。

## 交互与状态

1. `streaming/pending`、保存中：设置、选词和 Generate 按现合同禁用；valid 且未收录：设置、普通词条和 Generate 可用，旧 Result 保持原位；预设试用仍由 `presetId` 只读。
2. 编辑只改下一次 request 草稿。Result 标题从 `generation.result.targets[].entry`（或同一完成 request 快照）生成，正文、tags、释义也只读 result；禁止再用 live `words.join()`。
3. 有 valid 未收录 Result 时点击现有 Generate：打开 `AppDialog` top layer，默认焦点落在取消；Escape、关闭、遮罩与取消都只关闭对话框，焦点返回 Generate，旧 Result 和新配置完全不变。
4. 确认：按钮进入防重入，先 `await workspace.discard()`；成功后调用一次既有 generate，新请求读取用户刚编辑的配置。discard 失败时不调用 generate，保留旧 Result 与新输入并显示错误。后端 `learning.Service.Discard` 已幂等且保存先胜时不修改 saved record，无新后端设计。
5. collect/guest claim 流不变；成功保存后的导航不走本确认。离页/刷新继续保护 in-flight 或 valid 未收录 Result，与表单是否可编辑分离。

## 精确 Vue 接点

| 接点 | 前端接收要求 |
|---|---|
| `GenerationWorkspace.vue` state | 将当前 `busy = streaming/pending/valid` 拆为 `generationBusy = streaming/pending`、`hasUnsavedResult = phase===valid && result`、现有 leave protection；`fieldset`、普通 `WordPicker` 与 Generate 只用 generationBusy（另叠加 saving/既有 submit validity） |
| `GenerationWorkspace.vue` Result | `<h2>` 改读 result targets/request snapshot；移除 `.actions` 内 `confirmation='discard'` 的独立按钮，保留 collect/guest claim |
| `GenerationWorkspace.vue` Generate | `generate()` 在 hasUnsavedResult 时只设 `confirmation='regenerate'`；否则沿现有生成。确认 handler 顺序必须是 `await workspace.discard()` 成功后再 generate；catch 保持 result/input，显示 failure，不发新 call |
| `GenerationWorkspace.vue` / `AppDialog.vue` | 扩展 confirmation union，不改 AppDialog；传 `returnFocus` 指向 Generate（或依赖实际 opener），footer 次序取消→放弃并生成，默认焦点由 shown 后落到取消。Escape/关闭/遮罩均走 close |
| `copy.json` → frontend design copy 同步 | 同步 `m003.regenerate.title/body/confirm/failure` 双语键；不得在 Vue 另写文案 |
| generation store | frontend-bob 判断是复用 `discard()` 后现有表单字段能否保留；若 `discard()` 只重置 generation（当前实现如此）则不扩 store。不得先清表单或 result |

## 验收

| ID | 必须保持的结果 | 充分证据 |
|---|---|---|
| UIA-M003-423 | valid 完成后普通配置、词条及同一 Generate 可用；无独立“放弃本次结果”；编辑 style/words 后旧标题、正文、释义不变 | Vue DOM/状态测试 + 1440 浏览器截图 |
| UIA-M003-424 | 有未收录 Result 时 Generate 打开真实 top-layer AppDialog；准确双语 copy；默认焦点取消；Tab 圈定；Escape/关闭/遮罩/取消保留旧 Result 与新输入并返回焦点 | 实际浏览器 `:modal`、activeElement、键盘与 state 断言；1440/390 截图 |
| UIA-M003-425 | 确认先成功 discard 再且仅一次 generate；discard 失败为 0 次 generate，并保留旧 Result、新输入及可见错误；保存中/生成中/pending 防重复 | mock 调用顺序/次数测试与失败态 DOM 断言 |
| UIA-M003-426 | collect/guest claim、离页保护、预设只读不回归；saved record/Library 历史不在放弃范围；Result 标题不读 live words | 组件测试 + 现有对应回归测试；无真实 provider 调用 |

浏览器证据在 `evidence/cr310/`；只证明 M003-UI-12 设计源和合成状态，不证明 Vue 实现、独立 QA 或 UAT3014。

---

# M003-UI-11 / CR-309 生成状态视觉一致性

## 当前目标与有效范围

- `CONFIRMED / USER-M003-GENERATION-VISUAL-CONSISTENCY-20261013`：按用户指出的现状问题，统一生成前、中、完成后同类内容元素，重点是词义/用法；沿用 M002/UI09，不扩展业务或重做页面。本稿是现有系统内的整改设计交付，不推断为用户已批准新稿。
- 覆盖 `PAGE-204` 造文、`PAGE-216` 试用共享 `GenerationWorkspace`，以及 `PAGE-212` 后台预设预览内相同的 Plan / Result。Explore、Library、已发布内容卡、模型编辑、后端、API、数据和模型配置不在本轮。
- 暂定 Plan 仍只表达暂定 `sense/form/phrase/scene`，权威 Result 仍来自完整 valid 包；视觉一致不得把暂定内容标成最终内容，也不得为了等高删掉 `form · phrase` 或 `hintPhrase`。
- 本版替代 UI09 的“Plan 卡片两列”及实现中的 `resource-grid/resource-card` 结果表达；UI09-R3 的业务状态、760px 阅读列、UI10-R1.1 模型配置和其余 M002 基线继续有效。整改前版本可由 `reviews/evidence/cr309-entry-086/before.tar.gz` 恢复。
- QA 只读前态见 `../verification/evidence/cr309-qa/before/baseline.md`：实际桌面 Plan 为 346px×2 / 12px gap / 有框 padding 卡，final 为约 369px×2 / 22px gap / 无框无 padding，词头与辅助行字体也不同；移动虽同为单列，表面和 gap 仍跳变。该证据仅用于定位，不是本版 QA 通过。

## 设计决定：共用释义面板与词条列表

M002 `preset-meanings` 是唯一视觉依据。Plan 和最终结果都使用同一表面、排版、间距与响应式规则：无独立白底卡；每项以 1px 分隔线起始；词条使用 17px / 600 阅读字体和深绿；两行辅助内容使用 13px / 1.65、muted；桌面两列、24px 列间距，`≤760px` 单列。动态字段不同，但结构固定：

| 状态 | `dt` | 第一行 `dd` | 第二行 `dd.muted` |
|---|---|---|---|
| Plan / 暂定 | `entry` | `sense` | `form · phrase` |
| valid Result / 权威 | `entry` | `entryMeaning` | `hintPhrase` |

原型定位为 `.m003-vocabulary-panel > dl.m003-vocabulary-list > div > dt + dd + dd`。Plan 保留 `.m003-plan-meanings` 与 `data-plan-kind/data-plan-entry`，Result 保留 `.m003-result-meanings`；差异只标识状态，不改变列表视觉。Result 语言标签复用生产 `PresetWordMeanings` 的 `中文 / English / 日本語` 显示或沿现有页面不显示，禁止把 API enum `zh/en/ja` 直接呈现给用户。现有 copy 足够，本版不修改 `copy.json`。

## 共用结果表面与正文节奏

- `#generation-status` / `#preview-result` 内 Plan、草稿和最终态都落在 `.m003-result-body`：桌面 `max-width:760px` 居中，窄屏占满。状态切换不得回到全局 `.article` 的 720px / padding 规则，也不得影响 Library / Explore 的 `.article`。
- `.m003-live-draft .story-text`、`.m003-final-result .story-text`、`.m003-preview-paper .story-text` 统一为 `width:100%`、`max-width:none`、`margin:18px 0 14px`、`white-space:pre-wrap`、`overflow-wrap:anywhere`；桌面行高 `1.85`、移动 `1.78`。
- Scene 保持现有 mint 左边线块，Plan/Result 标题和 notice 保持原状态文案；本轮只消除同类内容在状态变化时的宽度、内边距、卡片表面、字体和行距跳变。

## 打开原型与复现场景

在仓库根目录运行 `python3 -m http.server 4176 --bind 127.0.0.1 --directory .planning/milestones`。前缀为 `http://127.0.0.1:4176/M003/design/prototype/`，全部使用既有 stream-v5 合成 fixture，不调用真实模型。

| 页面 / 状态 | query | 稳定区域 |
|---|---|---|
| PAGE-204/216 生成前 | `?page=create&lang=zh&view=formal&scenario=rewrite-once&event=0&status=0&rev=ui11` | `#generation-status .m003-result-body` |
| PAGE-204/216 Plan + 草稿 | 同上，`event=8` | `#planning-preview .m003-vocabulary-list`、`#live-draft .story-text` |
| PAGE-204/216 valid Result | 同上，`event=74` | `#final-result .m003-vocabulary-list`、`.story-text` |
| PAGE-212 Plan + 草稿 | `?page=presets&lang=zh&view=formal&mode=basic&event=7&status=0&rev=ui11` | `#preview-result` |
| PAGE-212 valid Result | 同上，`event=29&qualified=1` | `#preview-result` |

文案源为 `copy.json`，样式真源为 `theme.css`，结构和 fixture 映射为 `prototype/app.js`。

## 精确 Vue / CSS / 组件接点

| 工程接点 | 必须实现的结果 | 范围保护 |
|---|---|---|
| 新建 `frontend/app/presentation/components/GenerationVocabularyList.vue` | 接收已归一化的 `{ entry, meaning, usage }[]`，输出上述 `dl/dt/dd/dd`；可接收本地化 language label / heading 用于 Result 面板，不决定暂定或最终业务状态 | 仅由 PAGE-204/216/212 调用；不替换 Explore/Library 的 `PresetWordMeanings` |
| `GenerationWorkspace.vue` 的 `#planning-preview` | 把 `m003-plan-uses/article/strong/span/small` 映射为共享列表；`word_use` 映射 `entry/sense/form · phrase` | scene、Plan note、保留时机不变 |
| `GenerationWorkspace.vue` 的 `#final-result` | 把 `study-resources/resource-grid/resource-card` 映射为同一共享列表；Result 映射 `entry/entryMeaning/hintPhrase` | save、tags、valid 权威条件不变 |
| `pages/admin/presets.vue` 的 `#preview-result` | live Plan 的逐个 `<p>` 与 final `PresetWordMeanings` 改用同一共享列表；字段映射同上 | 编辑器外空释义提示、Explore 的 `PresetWordMeanings` 不变 |
| `frontend/app/assets/css/theme.css` | 在 M003 尾层同步原型 `.m003-vocabulary-panel/list` 与三类 `.story-text` 规则；停止使用 CR-309 范围内的 `.m003-plan-use` 卡片和 `resource-grid` | 禁止改全局 `.article`、`.resource-grid` 或 `.preset-meanings`，避免 Library/Explore 回归 |

前端架构接收须先确认该共享组件边界和三个调用点，再进入实现。组件内部命名可按工程规范调整，但必须保持可观察结构、字段顺序、样式结果和范围保护。

## CR-309 验收

| ID | 必须保持的结果 | 充分证据 |
|---|---|---|
| UIA-M003-419 | PAGE-204/216 Plan 与 valid Result 的词条都为同一 `dt + dd + dd` 分隔行列表；字体、颜色、行高、padding、分隔线和桌面列宽一致 | 1440 before/during/after 图 + computed style/DOM 断言 |
| UIA-M003-420 | PAGE-212 live Plan 与 final preview 使用相同列表；不再出现 Plan 行内圆点串或 final 独立样式 | 1440 preview during/final 实看 + DOM/style 断言 |
| UIA-M003-421 | Plan/草稿/final 共用 760px 阅读列；草稿/final 正文宽度、margin、换行和行高不因状态改变 | 1440/390 三状态 width/style 断言 |
| UIA-M003-422 | 1440 两列、390 单列，均无横溢；Plan 保留暂定说明及 `form · phrase`，Result 保留 `hintPhrase`，最终包仍是唯一权威 | fixture 字段/数量断言 + 390 before/during/after 实看 |

浏览器证据为 `evidence/cr309/M003-UI-11-browser.json`，`4/4 PASS`、console error `0`；代表图为同目录 `01-before-*`、`02-during-*`、`03-after-*` 及 PAGE-212 两图。证据只证明正式设计原型和合成状态，不证明 Vue 已实现或 QA/UAT 已通过。

## 继承的既有设计合同

以下 UI10-R1.1 / UI09-R3 内容继续约束本轮未改区域；CR-309 冲突处以上述当前章节为准。

# M003-UI-10-R1.1 合同文案澄清（继承）

> `SUPERSEDED / USER-M003-UI10-MODAL-REWORK`：原 UI10 的 PAGE-208 编辑器仅使用 `<dialog open>`，不在 top layer；其 `UIA-M003-412.a–418.a` 中所有依赖“弹窗成立”的结论失效，不得交前端实施。旧报告、截图及 `evidence/cr306/M003-UI-10-source.tar.gz` 原样保留为失败恢复证据。UI10-R1 已按生产 `AppDialog.vue` 的 `showModal()`、Teleport、`.dialog-body`、固定 footer 与焦点恢复行为整改；新结论只由 `evidence/cr306-r1/` 支持。

> `CLARIFICATION / M003-UI-10-R1.1`：用户已接受 UI10-R1 视觉并接续研发。本小修订继承已接受的完整页面、模态布局、交互与截图，仅补 API-306 已确认的大小、空文本、显式 probe 和快照文案合同；不重新设计、不覆盖 `evidence/cr306-r1/` 的 R1 包、manifest 或报告。增量原件与验证只写入 `evidence/cr306-r1-clarification/`；当前工作流继续由 technical / frontend-bob 接收，CR-306 保持 open。

UI10-R1.1 按 `USER-M003-CUSTOM-PARAMETERS` 与 `TRANSITION-M003-071` 定向修订 CR-306：在 M002 正式视觉和 UI09-R3 完整页面上，为 PAGE-208 模型管理模块加入每模型自定义请求参数 JSON，并把 BE07 的等待/失败/取消/pending 与预览失败映射到 PAGE-204/216/212。旧的专用推理 mode/effort 和自动能力目录方向失效。UI09-R3 的学习者流程、共同 Plan、计划管理和预设业务保持有效；已接受的视觉不因本次文案合同澄清重开评审，也不能据此跳过 technical / frontend-bob 接收。

## UI10-R1.1 当前目标、范围与追踪

| 页面 / 能力 / 数据 | 本轮设计结果 | 来源 |
|---|---|---|
| PAGE-208 模型管理模块 / CAP-306 / DATA-306 | 保留服务商分组与现有模型表单；在每模型“高级选项”加入 JSON 编辑器。`{}` 不追加自定义参数；最大输出 tokens 与结构化输出仍为专用单一权威字段 | PRODUCT09、API-306、BE07 `management.json` / `errors.json` |
| PAGE-204 / PAGE-216 / CAP-302、306 | 沿 UI09-R3 完整工具台展示真实无公开内容等待、可取消、失败、cancelled、settlement pending；不显示私有推理、轮次、假进度 | BE07 `streams.json`；stream-v5 既有业务流 |
| PAGE-212 / CAP-304、306 | 保留 basic/enhanced 预览、旧结果与发布资格；新增 `preview_timeout` 失败映射，不另建测试页 | BE07 `streams.json`；stream-v5 既有预览 |

- `CONFIRMED`：每模型高级 JSON、管理员按供应商文档填写、`{}` 不追加；保护业务/凭据；保存 0 模型调用；新视觉须用户评审。
- `CONFIRMED`：不再设计专用推理 mode/effort 或能力目录；不改变现有导航、计划、模型选择、最大输出 tokens、结构化输出和 v5 业务流。
- `ACCEPTED / 继承`：用户已接受 UI10-R1 的视觉、文案层级和响应式结果；R1.1 只纠正已确认的 API-306 文案合同，不重开视觉范围。
- 历史恢复：UI09-R3 冻结原件为 `../reviews/evidence/cr306-design-baselines/ui-before-cr306.tar.gz`，清单为 `../reviews/evidence/cr306-design-baselines/ui-before-manifest.json`；失败 UI10 包 `evidence/cr306/M003-UI-10-source.tar.gz` 保持不变，UI10-R1 恢复包见 `evidence/cr306-r1/M003-UI-10-R1-source.tar.gz`。

## UI10-R1.1 直接接收入口

前缀：`http://127.0.0.1:4174/M003/design/prototype/`

| 页面 / 状态 | query（均可直接打开） | 稳定区域 |
|---|---|---|
| PAGE-208 完整服务商分组 | `?page=models&lang=zh&view=formal&state=list&rev=ui10-r1.1` | `.generic-provider-list` |
| PAGE-208 JSON 编辑 | `?page=models&lang=zh&view=formal&state=edit&rev=ui10-r1.1` | `#admin-model:modal`、`.dialog-body`、`.custom-parameters` |
| PAGE-208 保护字段错误（EN / 移动同入口） | `?page=models&lang=en&view=formal&state=error&case=protected_model&rev=ui10-r1.1` | `[role=alert]`、`.custom-parameters[aria-invalid=true]` |
| PAGE-208 格式错误 / 冲突 / 测试拒绝 / 保存成功 | `state=error&case=syntax` / `state=conflict` / `state=probe-error` / `state=saved` | 对话框内 alert 或列表页 status |
| PAGE-204/216 无内容超时 / 取消 / pending | `?page=create&lang=zh&view=formal&scenario=cr306-timeout&event=3&status=0&rev=ui10-r1.1`；将 scenario 换为 `cr306-cancelled` 或 `cr306-settlement_pending`（pending 用 `status=1`） | `#generation-status` |
| PAGE-212 预览超时 | `?page=presets&lang=zh&view=formal&mode=basic&previewFailure=timeout&event=3&status=0&rev=ui10-r1.1` | `#preview-result` |

原型直接读取 `../../technical/fixtures/cr306/index.json` 指向的 `management.json`、`errors.json`、`streams.json`，以及既有 stream-v5。`expected`、`internal_evidence`、`boundaries` 和原始 JSON（管理编辑器除外）不渲染。query 与合成数据只用于设计复现，生产路由仍为 `/admin/models`、`/create`、`/trial/:presetId`、`/admin/presets`。

## UI10-R1.1 页面与内容定位

1. PAGE-208 沿现有管理 header/sidebar、服务商卡、模型行和编辑对话框。表单顺序仍是服务商连接 → 模型基本字段 → 高级选项 → 启用/显式测试 → 取消/保存。
2. 高级选项顺序是最大输出 tokens → 结构化输出 → 自定义请求参数 JSON → 模型说明。只有 JSON 区出现必要的 API 参数示例与保护边界；页面其他区域不散落实义实现细节。
3. JSON 说明同时给出 OpenRouter 示例 `{"reasoning":{"enabled":false}}`、`{}` 语义、16 KiB / 深度 8 / 重复键 / U+0000 规则，以及凭据、model/messages/stream、URL/headers、最大输出与结构化字段的保护边界。
4. 格式、重复键、对象类型、保护字段、深度、数值、U+0000 错误在 textarea 下关联呈现，并保留原始输入。版本冲突保留本地草稿，刷新并合并后要求重新核对。
5. 保存文案明确“保存只更新配置，不会调用模型”；成功后回到完整服务商页，并把此前连接测试标为失效。显式测试只证明本次短流连接，不宣称完整生成、结构化结果或参数效果通过。编辑已测试配置时立即显示旧结果失效。
6. 取消先显示放弃确认；“继续编辑”恢复 JSON 和其他输入。`PAGE-204/216/212` 只复用合同已有终态与文案，不显示内部推理，不新增能力。

固定双语文案键只在 `copy.json` 的 `cr306.*` 与沿用 `gm.*` 中维护；动态服务商、模型与错误样例来自 BE07 fixtures。视觉 Token 只在 `theme.css` 维护；本版新增/修订 `#admin-model:modal`、`.dialog-body`、`.m003-model-dialog`、`.custom-json-field`、`.custom-parameters`，其余复用 M002 组件。

## UI10-R1 已接受视觉合同（R1.1 继承）

| ID | 必须保持的可观察结果 | 检查方法 / 证据 |
|---|---|---|
| UIA-M003-412.r1 | PAGE-208 使用完整模型管理列表作背景；从被点击的服务商打开真实 `#admin-model:modal`，不能用 `[open]` 或定位层模拟；新增与编辑标题/初值不同 | 现网只读基线 + R1 列表→指定 provider 实点；`10/11-r1` 截图 |
| UIA-M003-413.r1 | 框体复用 AppDialog：标题固定、`.dialog-body` 独立滚动、footer 固定；背景不可交互且底层 scroll 位置不变 | `:modal=true`、hit test、header/footer rect、page scroll 断言 |
| UIA-M003-414.r1 | 每个模型高级选项分别持有原始 JSON 草稿；`{}`、示例、保护规则与 0 调用说明准确；最大输出和结构化输出仍是单一权威字段 | 多模型不同 raw value；新增模型与协议实点；`12-r1-modal-json-1440.png` |
| UIA-M003-415.r1 | 格式/保护错误紧贴对应 textarea 并保留原始输入；详细安全规则按需展开；版本冲突保留每模型草稿 | BE07 errors fixture → `aria-invalid/aria-describedby`；`14-r1-modal-error-390.png` |
| UIA-M003-416.r1 | 关闭、取消、Escape、遮罩统一进入 dirty 规则；继续编辑保留输入，放弃后关闭；叠层确认限制焦点；最终回到精确 opener | 浏览器实际 Tab/Shift+Tab、Escape、内/外点击、确认层和焦点恢复 |
| UIA-M003-417.r1 | 显式测试只验证短流且按模型取当前快照；任何配置变化使旧测试失效；保存本身 0 模型调用，成功回完整列表 | probe/saved/conflict 文案与每模型草稿映射；API-306 接收合同 |
| UIA-M003-418.r1 | 1440/390 无横溢；手机正常入口从服务商段开始；错误原因在可见区优先于帮助和规则；双语、label/help/error、44px 与 reduced motion 沿 M002 | `modal-rework-browser.json` completed=true/PASS；`13/14/15-r1` 截图 |

R1 浏览器证据为 `evidence/cr306-r1/modal-rework-browser.json`，其中 `completed=true` 且 `result=PASS`；异常中断会记录 `run_error` 并强制失败。现网 AppDialog 只读对照为 `live-appdialog-observation.json`。代表图为同目录 `10-r1-list-1440.png`、`11-r1-modal-initial-1440.png`、`12-r1-modal-json-1440.png`、`13-r1-modal-initial-390.png`、`14-r1-modal-error-390.png`、`15-r1-discard-confirm-390.png`。这些只证明静态正式设计、交互原型与合成合同状态，不证明 Vue/API/DB 实施、供应商参数效果或 CR-306 已修复。

## R1.1 API-306 合同澄清

| 已确认边界 | PAGE-208 文案与错误归属 |
|---|---|
| 单模型规范化紧凑 JSON 的 UTF-8 大小不超过 16,384 字节 | `validation_failed / 422` 的 `too_large` 关联具体模型 textarea，使用 `cr306.error.too_large`；缩进与空白不按原始文本长度误拒绝。无效或未完成 JSON 的紧凑计数显示 `—` |
| 单项 32 KiB、批量 256 KiB、聚合 2 MiB 的 HTTP 请求边界 | `request_too_large / 413` 使用 `cr306.error.request_too_large` 作为表单级错误并保留全部编辑；没有字段路径时不得误贴到首个模型 |
| 空文本与空对象含义不同 | 只有合法对象 `{}` 表示不追加参数；空文本按 `invalid_json` 处理，文案为 `cr306.custom.empty` |
| 显式 probe 固定最大输出 256 tokens | `gm.test.note` 与 `cr306.probe.rejected` 说明此限制；probe 可产生少量费用，不证明参数效果、结构化输出或完整生成；保存 0 模型调用且不以前置 probe 为条件 |
| 测试与生成快照 | `cr306.probe.stale` 只表示旧测试结果不再适用于当前草稿，管理员仍可直接保存。后台模型参数变更只影响之后受理的新请求快照，不追溯改变在途或已完成 run；PAGE-212 的 ready 失效仅由预设本地草稿或预览配置变化触发 |

本节来源为 `technical/api/administration.md#api-306`、`technical/api/presets.md#api-306-preview` 与 `technical/fixtures/cr306/errors.json` 的 `compact_utf8_16384/16385` 边界。增量验证与恢复入口见 `evidence/cr306-r1-clarification/`；已接受的 R1 包、manifest、浏览器报告和截图保持原样。

## UI09-R3 未受影响基线入口（继续有效）

前缀：`http://127.0.0.1:4174/M003/design/prototype/`

| 稳定页面 | 正式预览 query | 生产入口 | 本版范围 |
|---|---|---|---|
| PAGE-204 造文 | `?page=create&lang=zh&view=formal&scenario=rewrite-once&event=0&status=0&rev=ui09-r3` | `/create` | M002 设置、选词、阅读纸面 + Plan/连续草稿/权威结果 |
| PAGE-208 计划管理模块（与模型管理模块沿用同一产品编号） | `?page=plans&lang=zh&view=formal&plan=pro&contentLimit=1&rev=ui09-r3` | `/admin/plans` | M002 完整计划字段 + 基础纠错与内容返修配置 |
| PAGE-212 预设 | `?page=presets&lang=zh&view=formal&mode=enhanced&event=0&status=0&rev=ui09-r3` | `/admin/presets` | M002 完整编辑器 + basic/enhanced 实际预览与发布资格 |
| PAGE-216 试用共享区 | PAGE-204 使用 basic 请求的结果区域 | `/trial/:presetId` | 复用 Plan/草稿/结果表达；本版不重做试用页外壳 |

`view=formal` 隐藏合成演示控件。fixture、scenario/event/status query 与回放 timer 都属于 demo adapter，不进入正式产品。

## 原件与来源

| 来源 | 本版用途 | 精确文件/选择器 |
|---|---|---|
| M002 正式品牌与页壳 | 词涟鱼形/涟漪 SVG、暖白/深绿、顶栏、导航、管理侧栏 | `../../M002/design/prototype/app.js` 的 `mark`、header；`../../M002/design/theme.css` |
| M002 造文 | 310px 设置栏、配置 icon、自定义 select、选词器、右侧阅读纸 | `.workspace`、`.creation-settings`、`.generation-word-panel`、`.article`；本版 `#create-settings` |
| M002 计划 | underline tabs、两栏原字段、单 panel | `.tabs`、`.form-grid`、`.admin-options`; `#plan-priority/#plan-max/#plan-limit/#plan-unlimited` |
| M002 预设 | master-detail、标题→无限制管理选词→4 配置→原动作→纸面预览 | `.admin-master-detail`、`#preset-title`、`#preset-words`、`#preset-model/style/length/language` |
| M002 资源 | 本地 Lucide 图标与无外部字体资源 | `prototype/m002/icons.js`、`prototype/m002/assets/lucide.json`；许可证同目录 |
| PRODUCT07 / BE05-R1 / API-302,304 / DB03 | 状态、数据、资格与持久化约束 | 只引用权威合同，不在设计层复制第二套 DTO |
| stream-v5 | demo exact `wire[]` 与有限 status 回放 | `../../technical/fixtures/stream-v5/index.json` 及 15 个 wire；不读 expected/internal_evidence 渲染 |

固定中英文只取 `copy.json`；样式只取 `theme.css`（先 import M002，后追加 `m003-*`）。模型名、用户、额度、2/3 词、文章、Plan、释义、tags 都是动态数据，不是 copy。缺固定 key 显示 `⟦key⟧` 只作为设计自检，生产需记录错误并采用产品定义的安全回退。

## 页面区域与元素顺序

### PAGE-204 / PAGE-216

1. M002 learner header：真实 mark、主导航、locale、平台消息、账号菜单。
2. `.page-head`：`create.title/create.desc`；右侧 quota 来自权益数据。
3. `.workspace` 左侧 `#create-settings.settings.creation-settings`：model(bot) → style(book-open) → length(layers) → meaning language(book-open-text)。
4. 右侧 `.generation-word-panel`：M002 选词器、随机词、搜索 listbox、正常“开始生成”。目标词以 request 为准。
5. 同列 `#generation-status.m003-generation-paper`：结果抬头 → `#planning-preview` → `#live-draft .live-draft-text` → `#final-result`。Plan 和正文各是纸面内分区，不另起过程轨道。
6. authoritative valid 时用完整 Result 原子替换临时区，建立 passage 高亮、tags、学习资源和保存动作。

Plan 只显示 scene 与每个 request entry 的 sense/phrase；提示 key `m003.plan.note`。Plan 从收到首条 plan_item 起一直保留，初稿、固定编辑、条件修稿、retained、pending/EOF/finalizing 均不清；valid 完整 Result、失败、取消或新请求才清。Plan 不宣称与编辑后正文实时一致。

### PAGE-208

M002 管理 header/sidebar → `a.plans` heading（保留全计划“档位优先级”编辑入口与影响确认）→ 访客/基础/Pro/Plus underline tabs → 单 panel：

- 左列：`a.plan.models` 全部模型；`a.plan.lengths` short/medium/long/xlong。
- 右列：`priority` 数字；`words.limit` 数字；`a.plan.limit` 滚动 24h 数字；`a.plan.unlimited`。
- 其后新增 `#service-settings`：基础纠错预算 2（只读）；内容返修 0–99（普通计划不可用，付费计划可配，0 关闭）。不在产品区写测试到 2 次、99 不实跑等验证策略。
- 最后 `#change-preview/#version-conflict/#plan-actions`。影响预览用 `m003.impact` 分别标注 `basicUsers` 与 `trialUsers`；两类用户可能重叠，禁止相加或声称净影响人数。服务 badge 与派生开关/N 保持一致：N=0 显示基础，N=1–99 显示增强。冲突来自真实版本保存响应，formal 页面无造冲突按钮。

### PAGE-212

M002 管理 header/sidebar → heading/新建 → `.admin-master-detail`：左预设列表；右编辑 panel 按原顺序：

1. 状态 badge、规则说明、`#preset-title`。
2. 管理选词器 `#preset-words`，不套用户计划选词上限，不显示随机词。
3. model/style/length/meaning language 四字段。
4. 新增 `#preview-mode`：basic / enhanced；模式必须和实际 preview fixture/request 一致。
5. 原动作：保存草稿、生成/取消预览、发布、下架；Q02 仅在 incomplete 时追加确认。
6. `#preview-result` 使用与造文相同 Plan/连续正文/Result 纸面规则；preview namespace 独立。发布必须匹配 current draft_version + mode + run 且 status valid；Q02 还需明确确认。

## UIA-M003-401.a–411.a 正式验收合同

以下保留 UI08 已发布的稳定 ID，UI09 只更新其 M002 视觉基线与可观察结果，不缩写、重编号或退休 `.a`。

| ID | 可观察结果 | 前端接收检查 |
|---|---|---|
| UIA-M003-401.a | PAGE-204 完整导航、M002 310px 配置、原选词/额度/纸面结果与保存外壳；真实 fish/infinity mark 与本地 Lucide icon | M002/UI09 1440/390 对照；`#create-settings/#create-words/#generation-status` 同页 |
| UIA-M003-402.a | started 才受理；Plan 按 wire 追加并在正文上方持续到完整 valid | 正常按钮实点；Plan 先显、首 edit/修稿仍在 |
| UIA-M003-403.a | Unicode 码点 splice 与 occurrence；相邻重复 NOOP；seq/rev/range/draft/version 异常停止并有限核对 | 🌱 后高亮、正文精确等于 Result；复用未改 reducer 证据 |
| UIA-M003-404.a | 新稿首片前保留旧文；可见删尾/替换；只更新稳定正文，不重建 Plan/设置 | 节点 identity、focus、scroll 差≤2px |
| UIA-M003-405.a | 完整 valid Result 才原子建立正文、高亮、tags、targets/save；临时稿无正式资源 | valid 前后状态集成与 Result 精确比对 |
| UIA-M003-406.a | pending/EOF/retained 保留只读 Plan+稿；fail/cancel/new 清；Q02 valid 可存且 notice 持续 | 对应状态定向检查；有限 status |
| UIA-M003-407.a | PAGE-208 保留 M002 全字段、页头档位优先级编辑/影响确认；基础预算2只读；派生开关+N 0–99；N0 badge 为基础、N1–99 为增强；基础用户/有效体验用户分别呈现且不求和；影响/冲突重预览 | Pro/Plus N0/N1、两类人数标签、N99/非法、preview-confirm、conflict-recheck；`evidence/ui09-r3/cr303-report.json` 与既有 `admin-interactions.json` |
| UIA-M003-408.a | PAGE-212 保留 M002 标题、无限制管理选词、四配置和原动作；basic/enhanced 各走自身 preview 且 Plan/正文同规则 | 两 actual preview wire 自动播放；不得互借 fixture |
| UIA-M003-409.a | current draft_version/mode/run/status 才 ready；编辑或切模式使旧结果 stale；Q02 需确认后手动发布 | dirty input 保留且旧 publish 禁用；资格组合 |
| UIA-M003-410.a | 每片仅更新稳定正文与简洁状态；不抢焦点/滚动，不把正文设 live region | 61 次正文变化、2 次缩短、settings/result DOM 稳定 |
| UIA-M003-411.a | M002 响应栅格与新增区域在 1440/390 无横溢；目标≥44px；长文换行；skip/reduced motion | UI09 代表截图和横溢检查；320/768/axe/多浏览器留实施复核 |

## 动态数据与容差

- 用户、词、模型、权益、计划、预设来自生产 request/API/路由；Result/Plan 只来自当前 generation/preview namespace。
- 网络事件到达即应用，不显示百分比、内部 stage/reason/version/N/调用次数。demo 的 `playback.after_ms` 不代表生产时延。
- 正文流只更新 `.live-draft-text.textContent` 和简短状态。设置、选词、Plan 节点保持 identity；用户主动滚动后不拉回；渲染前后 scrollY 允许取整误差 ±2px。
- 标题/词义/搭配/正文可任意换行；不截断关键信息。触控/指针目标最小 44×44px。

## 恢复快照

本版纠偏源码快照为 `evidence/ui09-r3/source.tar.gz`，逐文件 hash 在 `evidence/ui09-r3/source-manifest.json`；冻结 UI09/UI09-R1/UI09-R2 包保持原 hash。快照只表示可恢复交付，不替代 FE 接收。

## UI09-R3 PAGE-208 语义纠偏

UI09-R3 只解决 CR-303。影响预览继续复用既有 `m003.impact` 文案，但 `basicUsers` 与 `trialUsers` 分别填入具名位置，不进行加法。服务 badge 直接跟随由合法 N 派生的 `reviewOn`：付费计划 N=0/关闭时为基础，N=1–99/开启时为增强。该修订不改变 UI09-R2 已接受的页面视觉、760px 居中阅读列、其他页面或流式交互。

## UI09-R2 阅读列对齐

UI09-R2 依据 `USER-M003-READING-ALIGNMENT` 将 create/preset 共享结果纸面的 Plan、草稿和最终稿统一放入居中的 760px 阅读列；宽屏左右留白对称，窄屏占满可用宽度，内部文本保持左对齐，不设置右侧功能栏。其余 UI09-R1 间距精修保持：create 的 picker/paper 节奏；plans 的服务标题、badge、开关视觉/焦点顺序与双栏字段/help 对齐；presets 的 icon-label、radio/两行说明、配置→模式→动作→预览节奏。桌面正文行高保持 1.85，移动为 1.78，未以压缩内容换取短页面。`copy.json`、prototype reducer/render、fixtures 与 M002 原件均未修改。

## 本版检查边界

UI09-R3 只新增 PAGE-208 的 Pro/Plus N0/N1、开关往返和两类人数独立显示检查；其余 M002 外壳、三页响应式、流式生成与预设证据复用 UI09-R2 及更早未变部分。UI09-R2 已获用户接受，本次纠偏无需重复选择同一视觉方案。没有验证生产 Vue/DTO、真实模型、数据库或网络时延。
