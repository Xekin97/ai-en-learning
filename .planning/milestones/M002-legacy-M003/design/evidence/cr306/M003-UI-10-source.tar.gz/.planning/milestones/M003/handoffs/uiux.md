---
milestone: M003
version: M003-UI-10
stage: uiux-design
role: uiux/base
agent_name: designer-tony
status: awaiting_user_review
date: 2026-10-12
---

# UI10 CR-306 完整页面设计交接

## 使用的输入与确认闭环

- [PRODUCT09](product.md)、[BE07](backend-architecture.md)、[DB04](database.md)、[API-306](../technical/api/administration.md#api-306)、[BE07 fixture 索引](../technical/fixtures/cr306/index.json)和[门禁071](../reviews/cr306-design-entry-gate-071.md)为本版批准输入。
- `USER-M003-CUSTOM-PARAMETERS` 已确认每模型高级 JSON、管理员按服务商文档填写、`{}` 不追加，取代专用推理 mode/effort 与能力目录；保存 0 模型调用、保护系统/凭据、同请求快照和旧业务保留。无须重复确认。
- `USER-M003-M002-DESIGN-BASELINE` 与 `USER-M003-UI-REVIEW-A` 要求完整页面 → M002 正式视觉 → 向用户展示新视觉 → 再接前端。本交付完成交互原型和正式设计并保持阶段；新视觉尚未获用户接受。
- 没有仍会改变本版结果的关键假设或业务阻塞。若后续要增加供应商策略、费用上限、自动能力目录或新的业务权益，须回产品；本版没有引入。

## 交互原型输入与正式视觉落实

| 层次 | 使用来源 | 本轮产出与可复现依据 |
|---|---|---|
| 交互原型 | BE07 `technical/fixtures/cr306/index.json` 指向的 management/errors/streams；既有 stream-v5 | 原型直接 fetch 合同 fixture；JSON 编辑、错误、冲突、取消、保存、显式 probe、旧测试失效及等待/失败状态可由下列 URL 重现；13 项浏览器断言记录于报告 |
| 正式视觉 | M002 `design/theme.css` 的 admin 栅格与 UI29–31 服务商/模型/对话框组件；当前 `frontend/app/pages/admin/models.vue` 的真实服务商分组和完整表单布局；UI09-R3 完整学习/预设页 | `design/theme.css` 继续 import M002，仅追加 CR-306 JSON 区样式；完整页层级、tokens、双语 copy、响应式和截图均由 UI10 原件交付，不把独立 textarea 草图当正式设计 |
| 可恢复版本 | CR-306 前 UI09-R3 冻结基线、UI10 当前源包 | `reviews/evidence/cr306-design-baselines/ui-before-cr306.tar.gz` 不变；UI10 source tar + manifest 含全部设计真源与 hash |

## 本次产物与直接入口

- [正式规格](../design/design-spec.md)：UIA-M003-412.a–418.a、PAGE/CAP/DATA 追踪、稳定区域及全部状态 URL。
- [统一双语文案](../design/copy.json)、[M002 基准主题层](../design/theme.css)、[可运行完整原型](../design/prototype/index.html)、[交互](../design/interactions.md)、[响应式与无障碍](../design/responsive-accessibility.md)。
- PAGE-208 JSON 编辑（中文）：`http://127.0.0.1:4174/M003/design/prototype/?page=models&lang=zh&view=formal&state=edit&rev=ui10`
- PAGE-208 保护字段错误（英文，可切 390px）：`http://127.0.0.1:4174/M003/design/prototype/?page=models&lang=en&view=formal&state=error&case=protected_model&rev=ui10`
- PAGE-208 列表 / 格式错误 / 冲突 / probe 拒绝 / 保存成功：分别使用 `state=list`、`state=error&case=syntax`、`state=conflict`、`state=probe-error`、`state=saved`。
- PAGE-204/216 无内容超时：`http://127.0.0.1:4174/M003/design/prototype/?page=create&lang=zh&view=formal&scenario=cr306-timeout&event=3&status=0&rev=ui10`；将 scenario 换为 `cr306-cancelled` 或 `cr306-settlement_pending`（pending 用 `status=1`）。
- PAGE-212 预览超时：`http://127.0.0.1:4174/M003/design/prototype/?page=presets&lang=zh&view=formal&mode=basic&previewFailure=timeout&event=3&status=0&rev=ui10`。

## UI 交付与接收

- PAGE-208 复用现有服务商分组、模型行与完整表单。JSON 只进入每模型高级选项；最大输出 tokens 与结构化输出仍是专用单一权威字段。没有改导航或重做其他管理区域。
- JSON 区直接给出 OpenRouter 示例 `{"reasoning":{"enabled":false}}`、`{}` 语义和简短平台文档提示；具体错误紧贴 textarea。保护字段与 16 KiB / 深度 8 / 重复键 / U+0000 规则收进可键盘展开的说明，避免移动首屏压过错误。格式/安全错误保留原始输入；冲突保留草稿；取消可继续编辑；保存成功、probe 成功/拒绝与旧测试失效均有明确状态。
- PAGE-204/216/212 复用 UI09-R3 完整页与 v5 流，只增加 BE07 fixture 已定义的 timeout/fenced/cancelled/pending/preview_timeout 映射。不突出审稿或次数，不投影私有推理，不新造事件。
- 原型直接消费 BE07 fixtures；合成 fixture、query 与 timer 不进入生产。静态原型不是 CR-306 的真实前端或后端修复。
- 前端接收时应把 UIA-M003-412.a–418.a 映射到现有 Vue/DTO；必须保持固定文案、顺序、完整页层级、输入保留、焦点/错误关联和响应式结果。生产保存/probe/冲突/状态由 API-306 驱动，不能从原型 query 反推业务。

## 验证、快照与文档整理

- [浏览器报告](../design/evidence/cr306/M003-UI-10-browser.json)：13/13 通过，覆盖 1440/390、中文/英文、键盘后继焦点、无横溢、错误关联、取消保留、保存、测试失效、冲突、probe 拒绝及四个等待/失败状态；控制台 0 error。
- 代表图：[桌面 JSON 编辑](../design/evidence/cr306/01-model-editor-1440-zh.png)、[手机保护字段错误](../design/evidence/cr306/02-model-protected-error-390-en.png)、[完整页保存成功](../design/evidence/cr306/03-model-saved-1440-zh.png)、[造文无内容超时](../design/evidence/cr306/04-create-timeout-1440-zh.png)。designer-tony 已实际查看四图；移动错误经评审反馈后改为 error-first，并只做定向复验。
- 当前恢复包：[M003-UI-10-source.tar.gz](../design/evidence/cr306/M003-UI-10-source.tar.gz)；逐文件 hash 与冻结基线引用：[M003-UI-10-source-manifest.json](../design/evidence/cr306/M003-UI-10-source-manifest.json)。CR-306 前 UI09-R3 继续由 `reviews/evidence/cr306-design-baselines/ui-before-cr306.tar.gz` 与 manifest 恢复，未覆盖、更早证据未改。
- 当前权威入口仍是 `design/design-spec.md` 与本交接。UI09-R3 的未受影响业务继续有效；其 CR-306 受影响部分由 UI10 替代。CR-306 保持 open。
- 浏览器报告只证明原型和合成合同状态；未验证 Vue、真实 API/DB、供应商参数效果、完整生成速度/质量、模型费用、真实链路或用户 UAT。Profile 仍为 1.0.0；requested `gpt-5.6-sol/high`，actual model 与 usage unknown。

## 未决事项与下一步

- `OPEN / UI10-REVIEW`：用户评审新视觉。完成条件是用户接受 PAGE-208 完整页中的 JSON 高级选项及代表失败/保存状态；不能用旧 UI09 批准代替。
- `OPEN / CR-306`：产品、BE07、DB04、UI10 均为设计输入/交付；前端架构/实施、后端实施、独立 QA、完整真实链路与用户 UAT仍未完成，CR 不关闭。
- 用户接受视觉后，建议由独立门禁接 `frontend-bob`，先更新前端架构映射，再实施。当前不切阶段、不启动前端、不声明真实修复。

> 本交接单不能切换阶段。阶段迁移必须由用户显式提交给守门器。
